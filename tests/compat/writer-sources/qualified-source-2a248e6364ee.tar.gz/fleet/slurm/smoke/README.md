# The SLURM lane, run rather than described

Everything in `fleet/slurm/` and `src/prismabuild/slurm_lane.py` was written
against SchedMD's documentation and tested against fake `sbatch`, `sacct`,
`scontrol`, `squeue` and `scancel` executables. This harness is where a real
controller answers instead.

```
fleet/slurm/smoke/run.sh                                      # Ubuntu 24.04's 23.11.4
DEB_DIR=/home/rob/slurm-build/arm64-24.04 fleet/slurm/smoke/run.sh   # the fleet's 25.11.2
PRISMABUILD_SLURM_SMOKE=1 PYTHONPATH=src pytest -q tests/test_slurm_smoke.py
```

One privileged container, one node, one partition set. The repository is
mounted read-only; the CAS, `pb-queue`, the lane root and the actions' own
checkouts live in a per-run directory under `/home/rob/slurm-build/smoke/`,
mounted at `/mnt/shared` so `pbrun`'s fleet paths resolve without being
patched. The host's real `/mnt/shared` is never touched.

## What it establishes

| Row | Claim |
|-----|-------|
| 1a | `sinfo` shows the node idle offering `shard:2` |
| 1b | a plain `sbatch --wait --wrap=hostname` returns 0 |
| 2 | `pbrun --transport slurm` runs a git-snapshot action end to end, publishes a CAS receipt, and files `pb-queue/done/<key>.json` with `status=executed`, `detail.receipt_published`, the job id and the node |
| 3 | the same action submitted again submits no job: `pbrun` reads the receipt before `sbatch`, files nothing new, and `done/` keeps the run's own record |
| 4 | a failing command files `failed/<key>.json` with a non-zero `detail.returncode` -- the launcher's 1 -- with the action's own `detail.action_returncode=7` beside it, and a stderr tail |
| 5 | `--timeout-s` becomes `--time`, and SLURM -- not `pbrun` -- kills the job, which arrives as `detail.slurm.state=TIMEOUT` with `signal=15`, and which `pbrun` reports as `failed (TIMEOUT)` |
| 6 | `--withdraw` on a running job `scancel`s it and files one `withdrawn/` record carrying `withdrawn_by` and the job's detail; nothing lands in `failed/` |
| 7a | `--gres=shard:1` schedules two jobs on a two-shard node and holds the third |
| 7b | `--constraint` for a Feature no node has is refused at submit and reported by `pbrun` |
| 8 | the Epilog ran for a killed job, matched containers by the action's ownership label, and removed its state file as the job's user rather than as root |
| 9 | with no `slurmdbd`, `sacct` answers nothing and the lane's provenance comes from `scontrol` |
| 10a | a three-row `pbcampaign` manifest with mixed demand -- two `shard:1` rows and one no-GPU row -- runs on the fleet and reports one table with each row's job id and node |
| 10b | the same manifest re-run is three CAS hits: no new job id, no new submission record, and no action ran again |
| 10 | from inside a batch step, `scontrol show job` and `scontrol show node` return `Features=` and `ActiveFeatures=` to the job's owner, and `SLURM_JOB_CONSTRAINTS` is unset |
| 11 | `pbrun --measurement --host-class gb10` executes, and the receipt's producer carries `host_class="gb10"` with the controller's `job_features` and `node_active_features` |
| 12 | `--host-class` for a Feature no node has is refused at submit by `sbatch` |
| 13 | `sstat` answers without `slurmdbd` and lists the fields the lane asks for; a job that sleeps with no output is reported by `pbrun` as stalled ("still running"), is not cancelled, and files `done/<key>.json` with `status=executed` and its samples under `detail.liveness`; `liveness.jsonl` in the lane directory holds them |
| 14a, 14b | with `ConstrainCores=yes`, a `--cpus N` job is confined to N CPUs of a node that has more; with `ConstrainCores=no` it is placed against the count and then sees the whole node |
| 14c | a job that writes past its declared `mem_gb` runs against a `memory.max` equal to the declaration: it is throttled into swap under `ConstrainSwapSpace=no` and killed `OUT_OF_MEMORY` under `ConstrainSwapSpace=yes`, which `pbrun` reports |
| 14d | a job that stays under its declared `mem_gb` completes |
| 15a | a second job of one action key, submitted while the first runs, is held `PENDING` with reason `Dependency` by `--dependency=singleton`; when the first leaves it starts, reads the receipt on the node, writes its cache-hit marker and exits 0, and the action ran exactly once. The running job also answers the adoption query issue #42 uses: `squeue -h -u $USER --name=pb-<key12> --states=all -o '%i\|%k'` prints its `pb:<key>:<attempt>:<nonce>` comment, and `scontrol show job` shows the same `Comment=` |
| 15b | two `pbrun --transport slurm` invocations of one key started together both exit 0, the action runs exactly once, and `done/` holds one `executed` record; which of the three paths the second took -- read the CAS, attached, or held by the scheduler -- is recorded rather than asserted, because it is a race |

## What it does not establish

The container is not the fleet, and four things stay open for the install:

- **Device containment.** `ConstrainDevices` is off here and the node's GRES is
  bound to a character device nothing opens. On cgroup v2 the containment is an
  eBPF program that denies exactly the GRES `File=` devices a job was not
  allocated and admits everything else, and whether it lets a job holding
  `shard:1` initialize CUDA while a job holding nothing cannot open
  `/dev/nvidia0` is answerable only on a box with a GPU.
- **The fleet's cgroup arrangement.** Delegation here needs `--privileged`,
  `--cgroupns=private`, a manual `cgroup.subtree_control` and
  `IgnoreSystemd=yes`; the fleet's boxes have systemd and slurmd under it.
  What *is* established is that `proctrack/cgroup` puts a job's processes in a
  `job_<id>` cgroup that `core._verify_slurm_process_membership` accepts.
- **NFS.** The lane root here is a local bind mount, so `root_squash` -- the
  reason the Epilog removes its state file as `SLURM_JOB_USER` -- cannot be
  reproduced. `tests/test_slurm_epilog.py` covers that at the shell.
- **Three boxes.** One node cannot show controller/slurmd RPC across a version
  skew, a node draining and returning, or an action landing on a box other
  than the submitter's.

## The two SLURMs behave differently, and the differences are recorded

Both pass rows 1 to 9. The campaign rows (10a, 10b), the host-class rows
(10 to 12) and the liveness row (13) were added afterwards and have run on
25.11.2 only (run-20260905T010019, 13/13; run-20260905T010156, 14/14; row 13
in run-20260905T010418, before the renumbering). Row 13 adds about five
minutes: a job has to sleep through the lane's 120 s stall window and then
finish on its own. Two things had
to be worked around for 23.11.4, and neither is a lane defect:

- Its `cgroup/v2` plugin creates its stepd scope under `/sys/fs/cgroup/system.slice`
  and refuses to initialize when that directory is absent (`Could not create
  scope directory .../pbsmoke_slurmstepd.scope`). On a box systemd owns it;
  `inside.sh` creates it. 25.11.2 does not need it.
- With `AccountingStorageType=accounting_storage/none`, every job is scheduled
  as `InvalidAccount` (`_refresh_assoc_mgr_qos_list: no new list given back`)
  and starts about thirty seconds later, once the association refresh fills in
  `Assoc=0` and backfill picks it up. 25.11.2 starts jobs immediately. Nothing
  fails; everything is slower, and a row that read a fixed interval would read
  a stalled fleet. That is an argument for putting the 25.11 packages on the
  nodes beyond the RPC-version one.

## The resource-enforcement arm

Rows 14a-14d run three times, because the settings they measure are the ones Rob has to
decide:

```
fleet/slurm/smoke/run.sh                                  # the fleet's settings
PB_SMOKE_CONSTRAIN_CORES=no fleet/slurm/smoke/run.sh      # cores unenforced
PB_SMOKE_CONSTRAIN_SWAP=yes fleet/slurm/smoke/run.sh      # memory that kills
```

`PB_SMOKE_CONSTRAIN_CORES=no` writes `ConstrainCores=no` into the container's
`cgroup.conf` and drops `task/affinity` from `TaskPlugin`; one variable drives
both, because `task/affinity` with no cores to constrain has no cpuset to
write. `PB_SMOKE_CONSTRAIN_SWAP=yes` writes `ConstrainSwapSpace=yes`, which is
what decides whether an over-declared job is throttled or killed.
`ConstrainRAMSpace` stays `yes` in every arm. The measurements and what they
mean for the cutover are in `docs/resource_enforcement_2026-09-05.md`.

## Deviations from `fleet/slurm/slurm.conf`, and why

`inside.sh` generates the config rather than copying it, and prints every
deviation at the top of the run:

| Setting | Fleet | Here | Why |
|---------|-------|------|-----|
| `SlurmUser` | `slurm` | `root` | no `slurm` user in the image, and creating one would be testing `useradd` |
| `NodeName` | three boxes | the container | one node |
| CPU topology | each box's topology | `slurmd -C` inside the container | `nproc` can reflect `OMP_NUM_THREADS` and cannot describe a sparse admitted CPU mask |
| `TaskPluginParam` | fleet binding options | adds `SlurmdSpecOverride` | SLURM excludes CPUs unavailable in its parent cgroup and adjusts available memory to its container limit |
| `RealMemory` | the `fleet_boxes.json` budget | 16384 | enough for two concurrent shard jobs at the 4 GB default demand |
| `KillWait` | 30 | 10 | rows 5 and 6 would otherwise spend it waiting |
| `ConstrainDevices` | `yes` | `no` | there are no devices to constrain |
| `IgnoreSystemd` | absent | `yes` | there is no systemd to ask for a cgroup scope |
| `ConstrainCores` | `yes` | `yes`, or `no` under `PB_SMOKE_CONSTRAIN_CORES=no` | rows 14a and 14b measure both settings; the default is the fleet's |
| `ConstrainSwapSpace` | `no` | `no`, or `yes` under `PB_SMOKE_CONSTRAIN_SWAP=yes` | row 14c measures both settings; the default is the fleet's |
| `gres.conf` `File=` | `/dev/nvidia0` | `/dev/nvidia0`, a `mknod`'d character device | slurmd refuses `shard` with no `File=` on the sharing GRES; see below |

Every scheduler *choice* is the fleet's unchanged: `select/cons_tres` with
`CR_Core_Memory`, `proctrack/cgroup`, `task/cgroup,task/affinity` (except in the
`PB_SMOKE_CONSTRAIN_CORES=no` arm),
`jobacct_gather/cgroup`, `sched/backfill`, `priority/basic`, `MinJobAge=3600`,
`AccountingStorageType=accounting_storage/none`, and the real `epilog.sh`.

---

# Three nodes: `fleet/slurm/smoke/multinode/`

```
fleet/slurm/smoke/multinode/run.sh                        # the fleet's 25.11.2
PB_SMOKE3_SLURM=24.04 fleet/slurm/smoke/multinode/run.sh  # Ubuntu 24.04's 23.11.4
PRISMABUILD_SLURM_SMOKE=1 PYTHONPATH=src pytest -q tests/test_slurm_smoke_multinode.py
```

A docker network and three privileged containers whose hostnames are the
fleet's own NodeNames. `dl380g10` runs munged, slurmctld and slurmd as the
`cpu` node; `sparky` and `gx10-6b77` run munged and slurmd as `gpu` nodes with
a `mknod`'d `/dev/nvidia0` and the fleet's shard counts. One run volume is
mounted at `/mnt/shared` in all three, so the CAS, `pb-queue` and the lane root
are one filesystem as they are on the fleet; the repository is mounted
read-only in all three; the host's real `/mnt/shared` is never touched.

A passing run takes about four and a half minutes and leaves its transcript in
`/home/rob/slurm-build/smoke/multinode-<stamp>/smoke.log`.

Three things differ from the one-node harness beyond the node count:

- **The configuration is generated from the fleet's own files.** `genconf.py`
  reads `fleet/slurm/slurm.conf`, `gres.conf` and `cgroup.conf` and edits
  them, rather than writing a config from scratch. What the rows check -- the
  partition lines, the Features a `--tag` becomes, the node weights, the shard
  counts -- is exactly what those files say, and a smoke that restates them
  tests the restatement. One copy is generated and installed in all three
  containers, because slurmd sends a config hash at registration and identical
  bytes is the only way to be sure the controller's "different slurm.conf"
  complaint is absent because nothing differs.
- **The rows run on the host.** Three of them reach into a container that is
  not the submitter's, and the image's `docker` is the Epilog's fake one. So
  `rows_multinode.py` drives the containers with `docker exec` and reads the
  records back off the volume at its host path.
- **The action is `./action.sh`, not `bash action.sh`.** `pbrun` pins an action
  to the submitting box whenever argv[0] resolves to an executable that is
  neither in the checkout nor on shared storage, and `/usr/bin/bash` is one.
  Every one-node row therefore carried `--constraint=pbsmoke` without anybody
  noticing, because there the submitter was also the only node. Here it would
  make the scheduler's choice the submitter's.

## What it establishes

| Row | Claim |
|-----|-------|
| M0 | `fleet/slurm/verify.sh`, the runbook's post-install check, runs -- and every row of it passes except the five a container cannot answer |
| M1 | `sinfo -N` shows all three nodes idle with exactly the Gres and Features `fleet/slurm/slurm.conf` declares |
| M2 | an untagged CPU-only `pbrun` lands on `dl380g10` with `--partition=cpu`, no constraint, and no `--time` |
| M3 | a `--gpu` `pbrun` lands on a Spark with `--partition=gpu --gres=shard:1` |
| M4 | a `--tag gx10-6b77` CPU-only `pbrun` lands there with no `--partition`: the constraint decided |
| M9 | a `--tag cpu` `pbrun` lands on the CPU box, `cpu` being a node Feature and not only a partition |
| M10 | an `--anywhere` `pbrun` on an idle fleet still lands on the CPU box, on `Weight=1` against the Sparks' 10 |
| M11 | the same `--anywhere` action overflows to a Spark when `dl380g10` is held by an `--exclusive` job: a preference, not a pin |
| M5 | a `pbrun` submitted in the `sparky` container executes on `dl380g10`, and its output comes back through the shared volume |
| M6 | a node whose slurmd and job processes are killed under a running job ends it as `NODE_FAIL`, `pbrun` reports that state with no receipt, and the node returns to idle on `ReturnToService=2` with no operator action |
| M7 | the controller is restarted for sixty seconds under a running job, `pbrun` says it is waiting rather than reporting an ending, and the job completes and reaches the submitter |
| M8 | repeating M2 and M3 submits nothing: the CAS answers before `sbatch` on both |

Two facts the rows record rather than assert, because they are how the lane
works and not defects:

- **A held repeat costs a job id, never a checkout.** `pbrun` reads the CAS
  before `sbatch`, which is what M8 measures, so a repeat it can see costs
  nothing at all. A repeat it cannot see -- two submitters at the same instant
  -- is held by `--dependency=singleton` until the first job leaves, and then
  reads the receipt on the node before materializing anything. Single-node rows
  15a and 15b measure that half.
- **`TERM` and `KILL` are different controllers.** M7 restarts slurmctld the
  way `systemctl restart` does, with `TERM`, and the job survives because the
  state save on shutdown carries it. A slurmctld killed with `-9` loses a job
  that started since its last periodic save: measured here, the recovered
  controller had JobId=6 as PENDING, logged `error: Registered PENDING JobId=6
  StepId=6.batch on node dl380g10`, and killed it as `non-startable ... Job
  credential revoked`. That is a fact about `StateSaveLocation` and a crash,
  not about a restart.

M7 is also where a lane defect was found. Before the fix, `wait` returned
`UNKNOWN` on the first poll it could not reach the controller for, so a
hundred-second restart made `pbrun` print `failed (UNKNOWN)` and exit 1 for a
job that went on to publish a receipt. A twenty-second outage proves nothing,
because SLURM's own client library absorbs it -- a `scontrol` issued while the
controller is down blocks about forty seconds and then answers. Sixty seconds
is what it takes for a poll to really come back with nothing.

## `fleet/slurm/verify.sh`, run for the first time

`verify.sh` is step 8 of `docs/slurm_runbook_2026-09-04.md` as an executable,
and every one of its rows needs a live controller, three registered nodes and
an ssh route between the boxes. Nothing had ever run it. M0 runs it here,
first, on an otherwise idle fleet, and holds it to a fixed verdict per row: a
row that changes in either direction fails the smoke.

Ten of its fifteen rows pass. Five cannot be answered in containers, and each
is a fact about the containers rather than about the script:

| Row | Why it cannot pass here |
|-----|--------------------------|
| 0, 0b | the installed `slurm.conf` is `genconf.py`'s, which deviates from the checkout's on purpose. What 0b does establish is that its ssh read reached both other boxes: it reports their hashes, and they agree with each other. |
| 3 | no NVIDIA driver, so `nvidia-smi` is not installed and there is no GPU for a shard job to see |
| 4 | `ConstrainDevices=no`, there being no real device to constrain, so the job opens the `mknod`'d `/dev/nvidia0` and the row correctly says so. This is the row that needs a box with a driver. |
| 7 | the repository is mounted read-only, and `pbrun` writes its closure stamp inside the checkout. The claim -- `pbrun` through the lane, end to end -- is what M2 to M11 do eleven times from a writable checkout on the volume. |

Two defects came out of that first run and are fixed on this branch:
`tools/fleet/pbrun.py` was mode 644 with no shebang while three documents
invoke it as a command, and row 4's `smi-rc` reported `sed`'s exit status
rather than `nvidia-smi`'s.

One rough edge is recorded and not fixed: `pbrun` raises `OSError: Read-only
file system` from `main` rather than refusing with a message when its `--cwd`
checkout cannot be written to. A read-only checkout is not a fleet condition,
and the fix is a judgement about where the closure stamp should live.

## Both SLURMs, three nodes

All twelve rows pass on both. The difference is time, and it is the same one
the one-node harness records: with `AccountingStorageType=accounting_storage/none`
23.11.4 schedules every job as `InvalidAccount` and starts it about thirty
seconds later, once the association refresh fills in `Assoc=0`. Measured on
2026-09-05, twelve rows each: 4 min 34 s on 25.11.2, 10 min 37 s on 23.11.4,
same rows, same box.
Nothing fails; a fleet on 23.11 would simply be slower at everything, which is
one more argument for putting the 25.11 packages on the nodes.

## What it does not establish

- **Real GPUs.** `ConstrainDevices` is off and the Sparks' GRES binds a
  `mknod`'d character device nothing opens. Whether a `--gres=shard:1` job can
  open `/dev/nvidia0` and a job with no GRES cannot is answerable only on a box
  with a driver.
- **NFS `root_squash`.** The lane root here is a bind mount shared between
  containers, which makes it one filesystem but not a squashing one. The
  Epilog's delete as `SLURM_JOB_USER` is exercised; the reason it exists is
  not.
- **The addresses in `slurm.conf`.** The fleet pins `SlurmctldHost` and every
  `NodeName` to a LAN address because the boxes do not resolve each other's
  names. `genconf.py` strips both: inside a docker network the names resolve
  and 192.168.1.x is a different fleet entirely. So this shows the daemons find
  each other by name, which is the case `NodeAddr` exists to rescue, and says
  nothing about whether the addresses are right.
- **systemd cgroup delegation.** All three containers need `--privileged`,
  `--cgroupns=private`, a hand-written `cgroup.subtree_control` and
  `IgnoreSystemd=yes`. The fleet's boxes have systemd and slurmd under it.
  What three containers do establish is that this is three independent
  instances of one arrangement, not something that only worked because there
  was one of it.
- **A version skew between boxes.** All three run the same packages. Running
  25.11.2 on two nodes and 23.11.4 on the third would need two images and is
  not what this builds.
- **Wall-clock realism.** Three containers share one GB10's twenty cores and
  one clock. Nothing here says how the fleet behaves under load, and the
  `SlurmdTimeout=30` that makes M6 finish in under a minute is not the fleet's
  five.

## Deviations from `fleet/slurm/*.conf`, and why

`genconf.py` prints these at the top of every run; `topology.py` then prints the
actual hardware topology in each container's boot log. Everything not listed is the
fleet's file unchanged, including the controller's node name, all three
`NodeName` lines' `RealMemory`, `Gres`, `Feature` and `Weight`, all three
`PartitionName` lines, `ReturnToService=2`, `MinJobAge=3600`, every scheduler
and cgroup plugin choice, and the real `epilog.sh`.

| Setting | Fleet | Here | Why |
|---------|-------|------|-----|
| `SlurmUser` | `slurm` | `root` | no `slurm` user in the image, and creating one would be testing `useradd` |
| All node CPU topologies | each fleet box's topology | actual `slurmd -C` topology (20 CPUs, 1x20x1 on GB10) | all three containers share one physical host; generated provisional topology is replaced before either daemon starts |
| `TaskPluginParam` | fleet binding options | adds `SlurmdSpecOverride` | map the PB parent cgroup's unavailable CPUs to SLURM's abstract topology while preserving task binding and the outer PB limits |
| `KillWait` | 30 | 10 | M6 would otherwise spend it waiting |
| `SlurmdTimeout` | absent, so 300 | 30 | M6 waits for the controller to notice a dead node; the value under test is `ReturnToService`, not this |
| `ConstrainDevices` | `yes` | `no` | the GRES binds a `mknod`'d character device nothing opens |
| `IgnoreSystemd` | absent | `yes` | there is no systemd to ask for a cgroup scope |
| `gres.conf` `File=` | the GB10's device | the same path, `mknod`'d | the file itself is unchanged; slurmd refuses a SHARED gres whose SHARING gres has no `File=` |
| `SlurmctldHost` | `dl380g10(192.168.1.107)` | `dl380g10` | docker's own DNS resolves the node names, and the fleet's LAN is not on this network. A controller configured with those addresses binds and dials into nothing and answers no RPC at all -- which is what it did, once. |
| `NodeAddr` | each box's LAN address | absent | the same reason |

The configured `RealMemory` values remain 73728, 81920 and 61440 MiB.
`SlurmdSpecOverride` reserves the difference between those values and each
container's limit, so actual admission respects the parent PB memory budget.
The three containers share one aggregate PB cap; their declared node capacities
are synthetic cluster fixtures, not three independent host reservations.

The munge key is baked into a derived image, generated per run, and the image
is removed when the run ends. That is what makes it one key in all three
containers with no ordering between them. It is test-only; on the fleet the
key is installed per box at mode 0400 and never travels through a build
context.
