"""Find logically duplicated functionality by structure and by name (PB #1328).

Clone-finding audits compare text, and duplicated functionality rarely
repeats text: renamed helpers and re-typed loops look different line by
line. This scanner compares structure and names instead (adapted from PQ's
``tools/duplication_inventory.py``; stdlib only, no PQ import -- PB stands
alone):

- **Near-duplicates.** Each function's body becomes a sequence of AST node
  kinds, keeping attribute names and called names and dropping local
  identifiers, literals and docstrings. The sequence is cut into 6-token
  shingles and hashed with blake2b, so the result does not depend on the
  process's hash seed. Pairs of functions in different files whose Jaccard
  similarity is at least ``THRESHOLD`` are reported. MinHash with seeded
  salts proposes candidates, and each candidate's Jaccard is then computed
  exactly.
- **Same-name helpers.** A module-level function name defined in more than
  one module. A collision whose contracts genuinely differ keeps its name
  and is recorded in the baseline's ``same_name_distinct`` list as exact
  ``(name, path)`` exceptions with a reason (#1386): the registry is policy,
  not one of the shrink-only arrays; the guard refuses a stale or malformed
  entry and a third path joining an exempt name, and every unregistered
  definition is still a growth.
- **Primitive digest sites** (PB #1328). Raw ``hashlib`` constructor calls
  and literal ``sort_keys=True`` JSON encodings, counted per enclosing
  scope with import aliases resolved. Sites inside :data:`DIGEST_OWNERS`
  belong to the single core owner: its main file and its shipped standard-library
  half, ``digest_primitives.py`` (#1547, CEO dec-1005-170450-5ec5). New sites
  anywhere else fail; removing one lowers the baseline. Byte work calls the
  owner's named profiles, never a new raw recipe or per-site exemption.

``tests/test_duplication_baseline.py`` holds the live result against
``tests/fixtures/duplication_baseline.json``, which only shrinks.
``--write-baseline`` rewrites the baseline after a consolidation removes
entries.

A pair that must stay two implementations is recorded in the baseline's
``must_differ`` list with its reason: for example, an independent
reference oracle, or a sealed module whose bytes are bound into receipts.
``--write-baseline`` keeps those records for pairs that still exist, applies
the registered same-name exceptions when it filters the groups so the
shrink-only map never absorbs them, and keeps registry rows whose names are
still live.
"""
from __future__ import annotations

import argparse
import ast
import hashlib
import json
import random
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SCANNED = ("src/prismabuild", "tools")
EXCLUDED_PARTS = {"__pycache__"}
BASELINE = ROOT / "tests" / "fixtures" / "duplication_baseline.json"
THRESHOLD = 0.9
MIN_LINES = 6
MIN_SHINGLES = 20
SHINGLE = 6
_K, _BANDS = 64, 16
# CLI entry points are expected once per script, not duplication.
ENTRY_POINTS = frozenset({"main", "_main", "parse_args", "_parse_args",
                          "build_parser", "_build_parser", "cli"})
#: One owner in two attested files, not two independently sanctioned modules.
#: The standard-library half exists only so pbtest can ship the exact owner
#: source into target interpreters without installing PrismaBuild (#1547).
#: No third file or raw-site exemption may be added.
DIGEST_OWNERS = frozenset({"src/prismabuild/core.py",
                           "src/prismabuild/digest_primitives.py"})


def _files(root: Path):
    for top in SCANNED:
        for path in sorted((root / top).rglob("*.py")):
            if EXCLUDED_PARTS.isdisjoint(path.relative_to(root).parts):
                yield path


def _tokens(node: ast.AST) -> list[str]:
    out = []
    for sub in ast.walk(node):
        kind = type(sub).__name__
        if isinstance(sub, ast.Attribute):
            kind += "." + sub.attr
        elif isinstance(sub, ast.Call) and isinstance(sub.func, ast.Name):
            kind += ":" + sub.func.id
        out.append(kind)
    return out


def _shingles(tokens: list[str]) -> frozenset[int]:
    return frozenset(
        int.from_bytes(hashlib.blake2b(
            "\x1f".join(tokens[i:i + SHINGLE]).encode(), digest_size=8).digest(), "big")
        for i in range(max(0, len(tokens) - SHINGLE + 1)))


def _import_aliases(tree: ast.Module) -> dict[str, str]:
    """Map every bound name to the dotted name it resolves to, module-wide.

    ``import hashlib as h`` yields ``h -> hashlib``; ``from hashlib import
    sha256`` yields ``sha256 -> hashlib.sha256``. Module-wide is
    conservative: a function-local import is visible to the whole module's
    resolution, which over-approximates (never misses) a digest site.
    """
    aliases: dict[str, str] = {}
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                aliases[alias.asname or alias.name] = alias.name
        elif isinstance(node, ast.ImportFrom) and node.module:
            for alias in node.names:
                aliases[alias.asname or alias.name] = f"{node.module}.{alias.name}"
    return aliases


def _resolved_callee(func: ast.expr, aliases: dict[str, str]) -> str | None:
    """The dotted callee for ``Name`` and ``Name.attr`` calls, else None."""
    if isinstance(func, ast.Name):
        return aliases.get(func.id, func.id)
    if isinstance(func, ast.Attribute) and isinstance(func.value, ast.Name):
        return aliases.get(func.value.id, func.value.id) + "." + func.attr
    return None


def _iter_scoped_calls(tree: ast.Module):
    """Yield ``(call, scope)`` with the innermost enclosing scope's name.

    The scope is the dotted chain of function/class names, or ``<module>``
    at module level. A site is identified by scope, not line number, so the
    baseline does not churn when unrelated lines shift; several calls of
    one family inside the same scope count as one ratcheted site.
    """
    stack: list[tuple[ast.AST, list[str]]] = [(tree, [])]
    while stack:
        node, scope = stack.pop()
        for child in ast.iter_child_nodes(node):
            child_scope = scope
            if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                child_scope = scope + [child.name]
            if isinstance(child, ast.Call):
                yield child, ".".join(child_scope) or "<module>"
            stack.append((child, child_scope))


def digest_sites(root: Path = ROOT) -> list[str]:
    """Every primitive digest site, as ``family:file::scope`` strings.

    Families: a call whose alias-resolved callee starts with ``hashlib.``
    is a ``hashlib`` site; a ``json.dumps``/``json.JSONEncoder`` call with
    literal ``sort_keys=True`` is a ``sorted-json`` site (``json.dump``
    and dynamic ``sort_keys`` values are outside this static method).
    Both families are returned for every scanned file; the ratchet gates
    only the sites outside :data:`DIGEST_OWNERS`.
    """
    sites: set[str] = set()
    for path in _files(root):
        rel = path.relative_to(root).as_posix()
        tree = ast.parse(path.read_text(encoding="utf-8"))
        aliases = _import_aliases(tree)
        for call, scope in _iter_scoped_calls(tree):
            callee = _resolved_callee(call.func, aliases)
            if callee is None:
                continue
            if callee.startswith("hashlib."):
                sites.add(f"hashlib:{rel}::{scope}")
            elif callee in ("json.dumps", "json.JSONEncoder") and any(
                    keyword.arg == "sort_keys"
                    and isinstance(keyword.value, ast.Constant)
                    and keyword.value.value is True
                    for keyword in call.keywords):
                sites.add(f"sorted-json:{rel}::{scope}")
    return sorted(sites)


def scan(root: Path = ROOT) -> dict:
    fingerprints = []
    names: dict[str, set[str]] = defaultdict(set)
    for path in _files(root):
        rel = path.relative_to(root).as_posix()
        tree = ast.parse(path.read_text(encoding="utf-8"))
        for top in tree.body:
            if isinstance(top, (ast.FunctionDef, ast.AsyncFunctionDef)) and not top.name.startswith("__") and top.name not in ENTRY_POINTS:
                names[top.name].add(rel)

        def walk(node, scope):
            for child in ast.iter_child_nodes(node):
                if isinstance(child, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef)):
                    qual = scope + [child.name]
                    if not isinstance(child, ast.ClassDef) and child.end_lineno - child.lineno >= MIN_LINES:
                        body = child.body
                        if (body and isinstance(body[0], ast.Expr)
                                and isinstance(body[0].value, ast.Constant)
                                and isinstance(body[0].value.value, str)):
                            body = body[1:]
                        shingles = _shingles([t for stmt in body for t in _tokens(stmt)])
                        if len(shingles) >= MIN_SHINGLES:
                            fingerprints.append((f"{rel}::{'.'.join(qual)}", shingles))
                    walk(child, qual)
                else:
                    walk(child, scope)

        walk(tree, [])
    rng = random.Random(7)
    salts = [rng.getrandbits(61) for _ in range(_K)]
    rows = _K // _BANDS
    buckets = defaultdict(list)
    for index, (_, shingles) in enumerate(fingerprints):
        signature = [min(((h ^ s) * 0x9E3779B97F4A7C15) & ((1 << 61) - 1) for h in shingles)
                     for s in salts]
        for band in range(_BANDS):
            buckets[(band, tuple(signature[band * rows:(band + 1) * rows]))].append(index)
    pairs = set()
    for members in buckets.values():
        for i in range(len(members)):
            for j in range(i + 1, len(members)):
                a, b = fingerprints[members[i]], fingerprints[members[j]]
                if a[0].split("::")[0] == b[0].split("::")[0]:
                    continue
                if len(a[1] & b[1]) / len(a[1] | b[1]) >= THRESHOLD:
                    pairs.add(tuple(sorted((a[0], b[0]))))
    return {
        "near_duplicates": sorted([list(p) for p in pairs]),
        "same_name_helpers": {n: sorted(m) for n, m in sorted(names.items()) if len(m) > 1},
        # The ratcheted set: every primitive digest site outside the owner.
        "primitive_digest_sites": [s for s in digest_sites(root)
                                   if s.split(":", 1)[1].split("::", 1)[0] not in DIGEST_OWNERS],
    }


def registered_same_name(old: dict) -> dict[str, set[str]]:
    """Exact ``(name, path)`` same-name exceptions from a baseline (#1386)."""

    names: dict[str, set[str]] = {}
    for row in old.get("same_name_distinct", []):
        names.setdefault(row["name"], set()).update(row["modules"])
    return names


def same_name_growth(live: dict, base: dict, exempt: dict) -> dict:
    """The name/path deltas a group may not add: baseline members and exact
    registered exceptions are allowed; every other definition is a growth."""

    return {name: sorted(set(members) - set(base.get(name, ()))
                         - exempt.get(name, set()))
            for name, members in live.items()
            if set(members) - set(base.get(name, ())) - exempt.get(name, set())}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument("--write-baseline", action="store_true")
    args = parser.parse_args()
    live = scan()
    old = json.loads(BASELINE.read_text(encoding="utf-8")) if BASELINE.exists() else {}
    exempt = registered_same_name(old)
    # The shrink-only map never absorbs a registered exception.
    raw_groups = live["same_name_helpers"]
    live["same_name_helpers"] = {}
    for name, modules in raw_groups.items():
        members = [module for module in modules
                   if module not in exempt.get(name, set())]
        if members:
            live["same_name_helpers"][name] = members
    live["same_name_distinct"] = [
        row for row in old.get("same_name_distinct", [])
        if any(module in raw_groups.get(row["name"], ())
               for module in row["modules"])]
    pairs = {tuple(p) for p in live["near_duplicates"]}
    live["must_differ"] = [row for row in old.get("must_differ", [])
                           if tuple(row["pair"]) in pairs]
    if args.write_baseline:
        BASELINE.parent.mkdir(parents=True, exist_ok=True)
        BASELINE.write_text(json.dumps(live, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    groups = live["same_name_helpers"]
    digest_count = len(live["primitive_digest_sites"])
    print(f"near-duplicate pairs >= {THRESHOLD}: {len(live['near_duplicates'])}; "
          f"same-name helper groups: {len(groups)} "
          f"({sum(len(v) for v in groups.values())} definitions); "
          f"must-differ pairs: {len(live['must_differ'])}; "
          f"gated primitive digest sites: {digest_count}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
