#!/bin/bash
# Install the per-box PrismaBuild supervisor as a systemd user unit.
#
# Why a unit and not only the crontab: the crontab's `--ensure` line is a
# five-minute poll, so a reboot leaves the box out of the pool for up to five
# minutes and nothing reports it. On 2026-09-06 all three boxes booted at
# 10:59 and rejoined at 11:05. A unit under linger starts the supervisor at
# boot and restarts it within RestartSec if it exits. Once this unit is
# installed, cron's --ensure defers even while the unit is stopped. The
# --systemd invocation below makes startup ownership explicit.
#
# KillMode=process is load-bearing. Worker loops are spawned by the supervisor
# and land in its cgroup. The supervisor forwards TERM to their exact PIDs,
# then waits for each current action and cleanup. Never signal payload groups
# or impose a shutdown deadline that can strand a claim.
set -euo pipefail
if [ "$(id -u)" -eq 0 ]; then
    echo 'install_supervisor_unit.sh runs as rob, not root' >&2
    exit 1
fi
unit_dir=$HOME/.config/systemd/user
unit=$unit_dir/prismabuild-supervisor.service
mkdir -p "$unit_dir" "$HOME/tmp"
if [ -e "$unit" ]; then
    cp -a "$unit" "$unit.backup-$(date +%s)"
fi
cat > "$unit" <<'UNIT'
[Unit]
Description=PrismaBuild per-box worker supervisor
Documentation=file:///mnt/shared/prismabuild-fleet/repo/tools/supervise.py
After=network-online.target remote-fs.target
RequiresMountsFor=/mnt/shared
# The supervisor is expected to exit 0 in the --ensure no-op case and to exit
# when it re-execs onto a newly published runtime generation, so no restart
# budget may ever retire this unit. This directive is only honoured in [Unit];
# in [Service] it is silently ignored and the 10s/5 default stays in force.
StartLimitIntervalSec=0

[Service]
Type=simple
# --systemd distinguishes the service owner from cron's compatibility entry.
# --ensure still serializes a handover from an existing supervisor.
ExecStart=/usr/bin/python3 /mnt/shared/prismabuild-fleet/repo/tools/supervise.py --ensure --systemd
Restart=always
RestartSec=30
# The supervisor drains workers without signalling their action children.
KillMode=process
TimeoutStopSec=infinity
SendSIGKILL=no
# One log file, the path the runbook already names.
StandardOutput=append:/home/rob/tmp/pb-supervisor.log
StandardError=append:/home/rob/tmp/pb-supervisor.log

[Install]
WantedBy=default.target
UNIT
systemctl --user daemon-reload
systemctl --user enable --now prismabuild-supervisor.service
echo "installed $unit"
