#!/bin/bash
# Install as root. Keep privileged Python and every ancestor root-owned.
set -euo pipefail
if [ "$(id -u)" -ne 0 ]; then
    echo 'install_resource_broker.sh must run as root' >&2
    exit 1
fi
# Never replace one half of a running broker/helper pair. For upgrades, drain
# PB on this host, verify its job groups are empty, then stop this service.
if systemctl is-active --quiet prismabuild-resource-broker.service; then
    echo 'broker already active: drain host work and stop the service before upgrading' >&2
    exit 1
fi
source_dir=$(cd -- "$(dirname -- "${BASH_SOURCE[0]}")" && pwd)
gpu_source=
for candidate in "$source_dir/gpu_memory.py" \
    "$source_dir/../../src/prismabuild/gpu_memory.py" \
    "$source_dir/../src/prismabuild/gpu_memory.py"; do
    if [ -f "$candidate" ]; then
        gpu_source=$candidate
        break
    fi
done
if [ -z "$gpu_source" ]; then
    echo 'missing resource monitor module; refusing an incomplete installation' >&2
    exit 1
fi
gpu_capacity_source=$(dirname -- "$gpu_source")/gpu_capacity.py
if [ ! -f "$gpu_capacity_source" ]; then
    echo 'missing GPU capacity module; refusing an incomplete installation' >&2
    exit 1
fi
install -d -o root -g root -m 0755 /opt/prismabuild-resource-broker
install -d -o root -g root -m 0700 /var/lib/prismabuild-resource-broker
for source_file in resource_broker.py resource_payload.py; do
    install -o root -g root -m 0644 "$source_dir/$source_file" "/opt/prismabuild-resource-broker/$source_file"
done
install -o root -g root -m 0644 "$gpu_source" /opt/prismabuild-resource-broker/gpu_memory.py
install -o root -g root -m 0644 "$gpu_capacity_source" /opt/prismabuild-resource-broker/gpu_capacity.py
maintenance_state=/var/lib/prismabuild-resource-broker/maintenance.json
# A fresh installation has no old /run gate to migrate.  This is an explicit
# administrator initialization, never an inference from a missing state file.
if [ ! -e "$maintenance_state" ] && [ ! -e "$maintenance_state.initialized" ] \
        && [ ! -e /run/prismabuild/maintenance.json ]; then
    /usr/bin/python3 -I /opt/prismabuild-resource-broker/resource_broker.py \
        --maintenance-state "$maintenance_state" --initialize-maintenance-state
fi
unit=/etc/systemd/system/prismabuild-resource-broker.service
if [ -e "$unit" ]; then
    cp -a "$unit" "$unit.backup-$(date +%s)"
fi
cat > "$unit" <<'UNIT'
[Unit]
Description=PrismaBuild per-job resource authority
After=local-fs.target

[Service]
Type=simple
ExecStart=/usr/bin/python3 -I /opt/prismabuild-resource-broker/resource_broker.py --uid 1000 --maintenance-state /var/lib/prismabuild-resource-broker/maintenance.json
Restart=on-failure
RestartSec=1
RuntimeDirectory=prismabuild
RuntimeDirectoryMode=0755
RuntimeDirectoryPreserve=yes
StateDirectory=prismabuild-resource-broker
StateDirectoryMode=0700
UMask=0077
NoNewPrivileges=yes
MemoryMax=256M
TasksMax=1024
OOMScoreAdjust=-900

[Install]
WantedBy=multi-user.target
UNIT
chmod 0644 "$unit"
# An OS library update must not queue this service for needrestart's automatic
# restart: stopping the broker closes every connected launcher's execution
# channel without its result, and a payload that then finishes is recorded
# failed (#1378).  This provisions the exact-service exclusion; it restarts
# nothing, and deliberate PrismaBuild upgrades are unchanged because they
# drain the host's attempts and stop the service before this script will run.
install -d -o root -g root -m 0755 /etc/needrestart/conf.d
install -o root -g root -m 0644 \
    "$source_dir/50-prismabuild-resource-broker.conf" \
    /etc/needrestart/conf.d/50-prismabuild-resource-broker.conf
systemctl daemon-reload
systemctl enable --now prismabuild-resource-broker.service
systemctl is-active prismabuild-resource-broker.service
