#!/usr/bin/python3
"""Local resource authority: contain PB payloads and Docker children together.

Runs as root behind a local Unix socket. Client commands never execute as root.
Only the configured local UID may create bounded scopes, launch user processes through a fixed privilege-dropping helper, or stop/release an exact token-authenticated attempt.
"""
from __future__ import annotations
import argparse
import array
import errno
import hashlib
import hmac
import importlib.util
import json
import os
from pathlib import Path
import pwd
import re
import secrets
import select
import socket
import socketserver
import stat
import struct
import subprocess
import sys
import threading
import time

HEX64=re.compile(r'[0-9a-f]{64}\Z');HEX32=re.compile(r'[0-9a-f]{32}\Z')
MAINTENANCE_SCHEMA='prismabuild.resource-maintenance.v1'
MAINTENANCE_EVIDENCE_SCHEMA='prismabuild.resource-maintenance-evidence.v1'
MAINTENANCE_DURABLE_PROTOCOL=1
# The updater owns initialization of admission after /run is cleared. It must
# verify desired/installed/loaded clients and health before releasing this hold.
MAINTENANCE_BOOT_OWNER='client-upgrade'
# A drain opened without a stated holder. Callers that predate drain ownership
# cannot name themselves, so their gates carry this identity and stay releasable
# by any root caller, exactly as every gate was before ownership existed.
MAINTENANCE_UNOWNED='unattributed'
# Raised when the maintenance wire gains a field a caller must ask for. A client
# reads this from a status reply before it sends an owner, because an earlier
# broker refuses an unknown request field outright (Authority.admin).
MAINTENANCE_PROTOCOL=2
# The holder's proof that no container of this attempt can still arrive: its
# ownership marker is gone and the local daemon lists nothing under either of
# the shim's reserved labels. The broker trusts this exactly as it already
# trusts the same holder's `release` to mean the payload stopped -- same
# attempt token, same authority, same caller -- and it is what turns a
# retained tombstone into something the inventory pass may remove.
SETTLEMENT_SCHEMA='prismabuild.container-settlement.v1'
# A retired, settled scope whose kernel group is already gone -- an operator
# removed the slice out of band, or a reboot lost it -- has no group left to
# stop, reclaim or release.  Its administrative lifetime may still close on
# the same settlement proof the tombstone path trusts, but the reason it
# stamps must not read as a verified reclamation of page charge.
VANISHED_CLEANUP_REASON='retired scope disappeared externally; reclamation unverified'


def _settlement_evidence(value):
    """Validate and normalize a holder's container settlement.

    Refused unless it is complete. A settlement that still names a container is
    not a weaker settlement; it is a scope that is not settled, and a holder in
    that state must not send one.
    """
    if not isinstance(value,dict):raise ValueError('invalid container settlement evidence')
    checked=value.get('checked_unix',0.0)
    if (set(value)-{'schema','marker_absent','owner_container_ids','scope_container_ids','checked_unix'}
            or value.get('schema')!=SETTLEMENT_SCHEMA
            or value.get('marker_absent') is not True
            or value.get('owner_container_ids')!=[] or value.get('scope_container_ids')!=[]
            or type(checked) not in (int,float) or not 0<=checked<=2**53):
        raise ValueError('invalid container settlement evidence')
    return {'schema':SETTLEMENT_SCHEMA,'marker_absent':True,'owner_container_ids':[],
            'scope_container_ids':[],'checked_unix':float(checked)}


def _recorded_identity(value):
    """Whether ``value`` is the two-integer device/inode identity this broker records.

    Kernel rows and authority records both carry ``[st_dev, st_ino]``.  A
    missing or malformed shape -- a bool (an int subclass), a string, a
    mapping, the wrong length, a float, a negative device or a non-positive
    inode -- is not an identity this broker can compare, so a vanished scope
    that carries one must fail closed rather than retire on it.
    """
    return (isinstance(value,list) and len(value)==2
            and all(type(part) is int for part in value)
            and value[0]>=0 and value[1]>0)


def scope_id(key, nonce):
    """The scope identity the broker issues for an action+nonce.

    Canonical formula: ``'prismabuild-job' + sha256(key+nonce)[:32] +
    '.slice'``.  This definition is the issuer and cannot move into the
    package: the broker is a stdlib-only root daemon.  The package mirrors
    it in ``produced_output._broker_scope_id`` (control-identity check) and
    ``resource_scope._adopt_created_scope`` enforces it on every broker
    response; the three agree by the cross test
    ``tests/test_broker_scope_contract_1301.py``, never by import.
    """
    return 'prismabuild-job'+hashlib.sha256((key+nonce).encode()).hexdigest()[:32]+'.slice'

#: ASCII-decimal nonzero start time (field 22 of /proc/<pid>/stat is clock
#: ticks since boot; 20 digits bound it far above any real uptime while
#: keeping the match itself the proof, with no int() conversion to fail).
_STARTIME_RE = re.compile(r'[1-9][0-9]*')

def _supervisor_owner_parts(owner):
    """(host, pid, starttime) for a membership supervisor owner, else None.

    The membership owner kind is exactly ``{host}:supervisor-{pid}:
    {starttime}``. Upgrade, operator, and unattributed owners never parse
    here and therefore never qualify for takeover, only for ``force_end``.
    """
    try:
        text = str(owner)
        host, _, rest = text.partition(':')
        kind, _, starttime = rest.partition(':')
        label, _, pid_text = kind.partition('-')
        if not host or label != 'supervisor' or not starttime:
            return None
        pid = int(pid_text)
        if pid <= 0:
            return None
    except (ValueError, AttributeError):
        return None
    return host, pid, starttime


def _proc_starttime(pid):
    try:
        line = Path(f'/proc/{pid}/stat').read_text()
    except OSError:
        return None
    _, _, rest = line.rpartition(')')
    fields = rest.split()
    return fields[19] if len(fields) > 19 else None


def _proven_starttime(starttime):
    """Positive ASCII-decimal /proc start-time proof, nothing else.

    Owner strings mint ``unknown`` when /proc was unreadable, and a
    hand-written owner can name anything at all. Neither proves PID reuse:
    only an ASCII all-digit nonzero value can be compared against a live
    ``/proc/<pid>/stat`` field-22 read. Anything else is unproven, never
    dead. The check is a character-class test on purpose: ``str.isdigit``
    accepts non-ASCII decimals (e.g. superscripts) that ``int`` rejects,
    and unbounded digit strings must not reach ``int`` at all.
    """
    return (isinstance(starttime, str) and len(starttime) <= 20
            and _STARTIME_RE.fullmatch(starttime) is not None)


def _live_supervisor_owner(owner):
    """Whether ``owner`` names this box's live supervision, verified here.

    The host must be this box and ``/proc/<pid>/stat`` start time (field
    22, counted from the last ``)`` so a ``comm`` with spaces cannot shift
    it) must equal the named one, defeating PID reuse. Anything else —
    legacy owners, unattributed drains, malformed strings, dead processes —
    is not a live supervisor and never authorizes a takeover.
    """
    parts = _supervisor_owner_parts(owner)
    if parts is None:
        return False
    host, pid, starttime = parts
    if host != socket.gethostname():
        return False
    if not _proven_starttime(starttime):
        return False
    return _proc_starttime(pid) == starttime


def _dead_supervisor_owner(owner):
    """Whether the named supervision is provably gone (dead or replaced).

    True only on proof: the owner is membership-shaped for THIS host and
    its pid is absent (dead) or answers a different start time (reused for
    another process). A live pid with the SAME start time is still around.
    Anything else — unshaped owners (never a membership drain), another
    host's owner (not this broker's business), permission or read errors
    (unreadable is not proven dead) — answers False, and a takeover
    requiring dead stays refused.
    """
    parts = _supervisor_owner_parts(owner)
    if parts is None:
        return False
    host, pid, starttime = parts
    if host != socket.gethostname():
        return False
    if not _proven_starttime(starttime):
        # Minted without proof (``unknown``) or malformed: can never prove
        # gone or reuse. A named non-decimal value always differs from a
        # real field-22 read, which must not read as PID reuse.
        return False
    try:
        line = Path(f'/proc/{pid}/stat').read_text()
    except FileNotFoundError:
        return True
    except OSError:
        return False
    _, _, rest = line.rpartition(')')
    fields = rest.split()
    current = fields[19] if len(fields) > 19 else None
    if current is None:
        # Malformed stat: missing parsed proof is unknown, never reuse.
        return False
    return current != starttime

def _atomic(path, value, *, mode=0o600):
    temp=path.with_name('.'+path.name+'.'+secrets.token_hex(8))
    try:
        fd=os.open(temp,os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600)
        os.fchmod(fd,mode)
        with os.fdopen(fd,'w') as out:
            json.dump(value,out,sort_keys=True);out.write('\n');out.flush();os.fsync(out.fileno())
        os.replace(temp,path)
        directory=os.open(path.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(directory)
        finally:os.close(directory)
    finally:temp.unlink(missing_ok=True)


def _write_control(path, value):
    """Write one kernel control, and never create one.

    A cgroup control that is not there is a kernel that does not offer it, not
    a file to make: `write_text` would open O_CREAT and turn "this kernel has
    no memory.reclaim" into a plain file nothing reads.
    """
    fd=os.open(path,os.O_WRONLY|os.O_NOFOLLOW)
    try:os.write(fd,value.encode())
    finally:os.close(fd)


def _trusted_file(path):
    path=Path(path).resolve(strict=True)
    info=path.stat()
    if (not stat.S_ISREG(info.st_mode) or info.st_uid!=0 or info.st_mode&0o022
            or any(q.stat().st_uid!=0 or q.stat().st_mode&0o022 for q in path.parents)):
        raise ValueError('privileged module must be root-owned and immutable to callers')
    return path


def _load_gpu_module(filename='gpu_memory.py'):
    if filename not in {'gpu_memory.py','gpu_capacity.py'}:raise ValueError('invalid GPU module')
    path=_trusted_file(Path(__file__).resolve().with_name(filename))
    name='_prismabuild_privileged_'+Path(filename).stem
    spec=importlib.util.spec_from_file_location(name,path)
    module=importlib.util.module_from_spec(spec)
    sys.modules[name]=module
    spec.loader.exec_module(module)
    return module

class SystemdBackend:
    def __init__(self, root=Path('/sys/fs/cgroup')):self.root=Path(root)
    def path(self, scope):
        if not re.fullmatch(r'prismabuild-job[0-9a-f]{32}\.slice',scope):raise ValueError('invalid scope')
        return self.root/'prismabuild.slice'/scope
    def command(self,*argv):
        r=subprocess.run(['/usr/bin/systemctl',*argv],capture_output=True,text=True,timeout=15)
        if r.returncode:raise ValueError('systemd resource operation failed: '+r.stderr.strip()[:500])
    def create(self, scope, budget):
        # A generated name already containing processes is not ours to adopt.
        existing=self.path(scope)
        if existing.exists() and 'populated 1' in (existing/'cgroup.events').read_text():
            raise ValueError('refusing to adopt a populated pre-existing scope')
        # No process enters until the complete aggregate envelope is installed.
        self.command('start',scope)
        self.command('set-property','--runtime',scope,
                     f'MemoryMax={budget}','MemoryHigh=infinity',
                     'MemorySwapMax=0','CPUAccounting=yes','CPUWeight=100','MemoryAccounting=yes')
        group=self.path(scope)
        # Older supported systemd releases lack a MemoryOOMGroup property.
        # Install and verify the kernel contract directly before any launch.
        (group/'memory.oom.group').write_text('1')
        if (int((group/'memory.max').read_text())!=budget
                or (group/'memory.high').read_text().strip()!='max'
                or (group/'memory.oom.group').read_text().strip()!='1'):
            raise ValueError('kernel memory envelope differs from requested scope')
        available=set((group/'cgroup.controllers').read_text().split())
        if not {'cpu','memory'}<=available:raise ValueError('CPU/memory controllers unavailable')
        (group/'cgroup.subtree_control').write_text('+cpu +memory')
        leaf=group/'payload';leaf.mkdir(exist_ok=True)
        # The payload reads its own limits through this directory, as a
        # container reads its docker scope's: CaptureMemoryGuard walks its
        # cgroup reading memory.max. UMask=0077 would leave it drwx------
        # root, so set the mode rather than inherit it. Traversable and
        # listable, never writable: control files keep the kernel's modes,
        # and only root may create or remove cgroups here (#916).
        os.chmod(leaf,0o755)
        if stat.S_IMODE(leaf.stat().st_mode)!=0o755:
            raise ValueError('payload cgroup is not readable by its payload')
        info=group.stat()
        events=dict(line.split() for line in (group/'memory.events').read_text().splitlines())
        local_events=dict(line.split() for line in (group/'memory.events.local').read_text().splitlines())
        return {'cgroup_path':str(group),'leaf_path':str(leaf),
                'cgroup_identity':[info.st_dev,info.st_ino],
                'memory_oom_kill_baseline':int(events.get('oom_kill',0)),
                'memory_oom_local_baseline':int(local_events['oom'])}
    def run(self, scope, uid, command, stdio):
        helper=_trusted_file(Path(__file__).resolve().with_name('resource_payload.py'))
        read_fd=os.memfd_create('pb-user-command',os.MFD_CLOEXEC)
        write_fd=-1;ready_read,ready_write=os.pipe()
        process=None
        try:
            # A bounded seekable command avoids pipe-capacity deadlock while
            # privileged startup or NSS is stalled. Consumed only after UID drop.
            data=json.dumps(command).encode()
            os.write(read_fd,data);os.lseek(read_fd,0,os.SEEK_SET)
            process=subprocess.Popen(['/usr/bin/python3','-I',str(helper),
                '--leaf',str(self.path(scope)/'payload'),'--uid',str(uid),
                '--command-fd',str(read_fd),'--ready-fd',str(ready_write)],
                stdin=stdio[0],stdout=stdio[1],stderr=stdio[2],cwd='/',
                env={'PATH':'/usr/bin:/bin','LANG':'C.UTF-8'},
                pass_fds=(read_fd,ready_write),start_new_session=True)
            os.close(read_fd);read_fd=-1
            os.close(ready_write);ready_write=-1
            if not select.select([ready_read],[],[],10)[0] or os.read(ready_read,1)!=b'1':
                raise ValueError('payload did not confirm containment and identity drop')
            return process
        except BaseException:
            if process is not None:
                self.stop(scope)
                process.kill();process.wait(timeout=10)
            raise
        finally:
            for fd in (read_fd,write_fd,ready_read,ready_write):
                if fd>=0:os.close(fd)
    def stop(self, scope):
        group=self.path(scope)
        if group.exists():
            (group/'cgroup.freeze').write_text('1')
            (group/'cgroup.kill').write_text('1')
    def empty(self, scope):
        group=self.path(scope)
        return not group.exists() or 'populated 1' not in (group/'cgroup.events').read_text()
    def reclaim(self, scope):
        """Give back what an empty group still holds, before anything removes it.

        A memory cgroup removed while it still holds LRU page cache goes
        offline as a zombie: the kernel reparents its kernel memory on offline
        but not its page cache, so the charge outlives the directory it was
        charged to. Reclaim first, remove after -- never the other way round.

        Returns the charge before and after, and whether the kernel finished.
        A partial reclaim answers EAGAIN or EBUSY, and that is progress rather
        than failure: the bytes it did drop stay dropped, and the next pass
        asks for the rest.
        """
        group=self.path(scope)
        before=int((group/'memory.current').read_text())
        complete=True
        if before>0:
            try:_write_control(group/'memory.reclaim',str(before))
            except OSError as exc:
                if exc.errno not in {errno.EAGAIN,errno.EBUSY}:raise
                complete=False
        stats=dict(line.split() for line in (group/'memory.stat').read_text().splitlines())
        pages=[int(stats[name]) for name in ('anon','file')]
        if any(value<0 for value in pages):raise ValueError('invalid residual page charge')
        return {'before':before,'after':int((group/'memory.current').read_text()),
                'complete':complete,'page_bytes_after':sum(pages)}
    def exists(self, scope):
        try:self.path(scope).stat()
        except FileNotFoundError:return False
        return True
    def observe(self, scope):
        """One group's inventory row, read now. None when it is already gone.

        `inventory` answers for the whole namespace and is read once per pass.
        Removing a group is the one operation that must not act on a row that
        old, so it re-reads exactly the group it is about to remove.
        """
        group=self.path(scope)
        try:info=group.lstat()
        except FileNotFoundError:return None
        events=dict(line.split() for line in (group/'cgroup.events').read_text().splitlines())
        populated=events.get('populated')
        if populated not in {'0','1'}:raise ValueError('invalid cgroup population evidence')
        return {'populated':populated=='1',
                'frozen':(group/'cgroup.freeze').read_text().strip()=='1',
                'identity':[info.st_dev,info.st_ino]}
    def healthy(self):
        return {'cpu','memory'}<=set((self.root/'cgroup.controllers').read_text().split())
    def inventory(self):
        parent=self.root/'prismabuild.slice'
        try:entries=list(parent.iterdir())
        except FileNotFoundError:return {}
        result={}
        for path in entries:
            info=path.lstat()
            if not stat.S_ISDIR(info.st_mode):continue
            events=dict(line.split() for line in (path/'cgroup.events').read_text().splitlines())
            populated=events.get('populated')
            if populated not in {'0','1'}:raise ValueError('invalid cgroup population evidence')
            result[path.name]={'populated':populated=='1',
                'frozen':(path/'cgroup.freeze').read_text().strip()=='1',
                'identity':[info.st_dev,info.st_ino]}
        return result
    def release(self, scope):
        group=self.path(scope)
        if group.exists():
            if 'populated 1' in (group/'cgroup.events').read_text():raise ValueError('scope still populated')
            leaf=group/'payload'
            if leaf.exists():leaf.rmdir()
        self.command('stop',scope)

class Authority:
    def __init__(self,state_dir,uid,backend,*,max_memory_bytes,maintenance_state=None):
        self.state_dir=Path(state_dir);self.uid=int(uid);self.backend=backend
        self.max_memory_bytes=int(max_memory_bytes);self.lock=threading.RLock();self.records={}
        # The worker reads this volatile v1 mirror.  The canonical authority is
        # separate so clearing /run at boot cannot turn a named hold into an
        # admission grant.
        self.maintenance_path=self.state_dir.parent/'maintenance.json'
        self.maintenance_state_path=Path(maintenance_state or self.maintenance_path)
        self.durable_maintenance=maintenance_state is not None
        self.maintenance_evidence_path=self.maintenance_state_path.with_name(
            self.maintenance_state_path.name+'.initialized')
        self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':False}
        self.maintenance_error=None
        self.installed_sha256={};self.installation_paths={};self.health_check=lambda:True
        self.state_dir.mkdir(parents=True,exist_ok=True,mode=0o700)
        info=self.state_dir.lstat()
        if not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.geteuid() or info.st_mode&0o077:
            raise ValueError('state directory must be private and owned by broker')
        for path in self.state_dir.glob('*.json'):
            st=path.lstat()
            if not stat.S_ISREG(st.st_mode) or st.st_uid!=os.geteuid() or st.st_mode&0o077:
                raise ValueError('unsafe stored resource authority')
            record=json.loads(path.read_text())
            key,nonce=self.identity(record)
            if path.stem!=scope_id(key,nonce) or record.get('scope_id')!=path.stem:
                raise ValueError('stored resource scope identity mismatch')
            if record.get('uid')!=self.uid or not HEX64.fullmatch(str(record.get('token',''))):
                raise ValueError('invalid stored resource owner')
            self.records[path.stem]=record
        self._restore_maintenance()

    def _private_maintenance_parent(self):
        parent=self.maintenance_state_path.parent
        parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        upper=os.open(parent.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(upper)
        finally:os.close(upper)
        info=parent.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid!=os.geteuid()
                or info.st_mode&0o077):
            raise ValueError('maintenance state directory must be private and owned by broker')

    @staticmethod
    def _maintenance_value(path):
        info=path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid()
                or info.st_mode&0o022):
            raise ValueError('unsafe maintenance gate')
        value=json.loads(path.read_text())
        if (not isinstance(value,dict) or value.get('schema')!=MAINTENANCE_SCHEMA
                or type(value.get('draining')) is not bool
                or not isinstance(value.get('owner',MAINTENANCE_UNOWNED),str)):
            raise ValueError('invalid maintenance gate')
        return value

    def _write_maintenance_evidence(self):
        _atomic(self.maintenance_evidence_path,{
            'schema':MAINTENANCE_EVIDENCE_SCHEMA,'initialized_unix':time.time()},mode=0o600)

    def _maintenance_evidence(self):
        info=self.maintenance_evidence_path.lstat()
        if (not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid()
                or info.st_mode&0o077):
            raise ValueError('unsafe durable maintenance evidence')
        value=json.loads(self.maintenance_evidence_path.read_text())
        if (not isinstance(value,dict) or value.get('schema')!=MAINTENANCE_EVIDENCE_SCHEMA
                or not isinstance(value.get('initialized_unix'),(int,float))):
            raise ValueError('invalid durable maintenance evidence')
        return value

    def _sync_maintenance_gate(self,value=None):
        _atomic(self.maintenance_path,value or self.maintenance,mode=0o644)

    def _force_volatile_gate_closed(self):
        """Best-effort last fence when a normal gate publication failed."""
        closed={'schema':MAINTENANCE_SCHEMA,'draining':True}
        try:
            self._sync_maintenance_gate(closed)
            return None
        except OSError as write_error:
            try:
                info=self.maintenance_path.lstat()
                if (not stat.S_ISREG(info.st_mode) or info.st_uid!=os.geteuid()
                        or info.st_mode&0o022):
                    raise ValueError('unsafe maintenance gate')
                self.maintenance_path.unlink()
                directory=os.open(self.maintenance_path.parent,os.O_RDONLY|os.O_DIRECTORY)
                try:os.fsync(directory)
                finally:os.close(directory)
                return 'volatile maintenance gate was removed after write failure: '+str(write_error)[:900]
            except (OSError,ValueError) as unlink_error:
                return ('volatile maintenance gate could not be closed after write failure: '
                        +str(write_error)[:450]+'; '+str(unlink_error)[:450])

    def _restore_maintenance(self):
        """Restore durable authority, using /run only for a one-time migration.

        The marker is deliberately written before the first canonical state. A
        crash there blocks the host; it must never make a later missing durable
        file look like an uninitialized installation that can copy an old open
        /run mirror.
        """
        if not self.durable_maintenance:
            try:self.maintenance=self._maintenance_value(self.maintenance_path)
            except FileNotFoundError:pass
            return
        try:self._private_maintenance_parent()
        except (OSError,ValueError) as exc:
            self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
            self.maintenance_error='durable maintenance parent is unavailable: '+str(exc)[:1200]
            self._force_volatile_gate_closed()
            return
        try:
            evidence=self._maintenance_evidence()
        except FileNotFoundError:
            evidence=None
        except (OSError,ValueError,json.JSONDecodeError) as exc:
            self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
            self.maintenance_error='durable maintenance evidence is unreadable: '+str(exc)[:1200]
            evidence=False
        try:
            if evidence is False: raise ValueError('durable maintenance evidence is unreadable')
            self.maintenance=self._maintenance_value(self.maintenance_state_path)
            if evidence is None:
                raise ValueError('durable maintenance state lacks initialized evidence')
        except FileNotFoundError:
            if evidence is not None:
                self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
                self.maintenance_error='durable maintenance evidence is missing'
            else:
                try:legacy=self._maintenance_value(self.maintenance_path)
                except FileNotFoundError:
                    self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
                    self.maintenance_error='durable maintenance state has not been initialized'
                except (OSError,ValueError,json.JSONDecodeError) as exc:
                    self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
                    self.maintenance_error='volatile maintenance gate is unreadable: '+str(exc)[:1200]
                else:
                    try:
                        self._write_maintenance_evidence()
                        _atomic(self.maintenance_state_path,legacy,mode=0o600)
                    except OSError as exc:
                        self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
                        self.maintenance_error='durable maintenance migration failed: '+str(exc)[:1200]
                        self._force_volatile_gate_closed()
                    else:self.maintenance=legacy
        except (OSError,ValueError,json.JSONDecodeError) as exc:
            self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True}
            self.maintenance_error='durable maintenance state is unreadable: '+str(exc)[:1200]
        if not self.maintenance_error and not self.maintenance['draining']:
            try:
                self.maintenance_path.lstat()
            except FileNotFoundError:
                # A persisted release is not proof that this boot loaded the
                # desired clients. Retain #505's updater handshake before the
                # worker mirror or broker grants any fresh admission.
                self.maintenance={'schema':MAINTENANCE_SCHEMA,'draining':True,
                    'changed_unix':time.time(),'owner':MAINTENANCE_BOOT_OWNER,
                    'reason':'boot admission awaits current-client verification'}
                try:_atomic(self.maintenance_state_path,self.maintenance,mode=0o600)
                except OSError as exc:
                    self.maintenance_error='boot maintenance hold could not be committed: '+str(exc)[:1200]
            except OSError as exc:
                self.maintenance['draining']=True
                self.maintenance_error='boot maintenance gate is unavailable: '+str(exc)[:1200]
        try:self._sync_maintenance_gate()
        except OSError as exc:
            closed=self._force_volatile_gate_closed()
            self.maintenance['draining']=True
            self.maintenance_error=(self.maintenance_error or closed or
                'volatile maintenance gate could not be restored: '+str(exc)[:1200])
    @staticmethod
    def identity(request):
        key=request.get('action_key');nonce=request.get('nonce')
        if not isinstance(key,str) or not HEX64.fullmatch(key):raise ValueError('invalid action key')
        if not isinstance(nonce,str) or not HEX32.fullmatch(nonce):raise ValueError('invalid attempt nonce')
        return key,nonce
    def handle(self,uid,pid,request):
        if not isinstance(request,dict):raise ValueError('request must be an object')
        op=request.get('op')
        if not isinstance(op,str):raise ValueError('operation must be a string')
        if op in {'maintenance_begin','maintenance_status','maintenance_end','maintenance_force_end','maintenance_takeover'}:
            return self.admin(uid,request)
        if uid!=self.uid:raise PermissionError('caller UID is not authorized')
        if op in {'container_begin','container_end'}:return self.container(uid,pid,request)
        key,nonce=self.identity(request);scope=scope_id(key,nonce)
        allowed=({'op','action_key','nonce','memory_max_bytes','gpu_memory_max_bytes','recovery_protocol'} if op=='create'
                 else {'op','action_key','nonce','memory_max_bytes','gpu_memory_max_bytes'} if op=='recover_create'
                 else {'op','action_key','nonce','token','evidence'} if op=='settle'
                 else {'op','action_key','nonce','token','reason','memory_max_bytes'})
        if set(request)-allowed:raise ValueError('unknown request field')
        if op in {'create','recover_create'}:
            gpu_budget=request.get('gpu_memory_max_bytes',request.get('memory_max_bytes'))
            # VRAM can exceed system RAM on a discrete host. Host RAM bounds
            # do not describe this independent logical budget; admission uses
            # trusted device capacity. Keep RPC values within signed byte range.
            if type(gpu_budget) is not int or not 0<gpu_budget<=2**63-1:
                raise ValueError('GPU memory budget outside supported bounds')
        with self.lock:
            if op=='recover_create':
                budget=request.get('memory_max_bytes')
                if type(budget) is not int or not 0<budget<=self.max_memory_bytes:
                    raise ValueError('memory budget outside host bounds')
                record=self.records.get(scope)
                if record is None:
                    if self.backend.exists(scope):raise PermissionError('unknown kernel scope cannot be recovered')
                    # A timed-out create may still be queued on this lock.
                    # Fence it durably before declaring this attempt absent.
                    record={'uid':uid,'action_key':key,'nonce':nonce,'scope_id':scope,
                            'memory_max_bytes':budget,'gpu_memory_max_bytes':gpu_budget,'token':secrets.token_hex(32),
                            'released_unix':time.time(),'creation_cancelled_unix':time.time()}
                    _atomic(self.state_dir/(scope+'.json'),record);self.records[scope]=record
                    return {'ok':True,'scope_id':scope,'missing':True}
                if (record['memory_max_bytes']!=budget
                        or record.get('gpu_memory_max_bytes',record['memory_max_bytes'])!=gpu_budget):
                    raise ValueError('attempt budget cannot change')
                if 'gpu_memory_max_bytes' not in record:
                    record['gpu_memory_max_bytes']=gpu_budget
                    _atomic(self.state_dir/(scope+'.json'),record)
                return {'ok':True,**record,'cgroup_path':str(self.backend.path(scope))}
            if op=='create':
                if 'recovery_protocol' in request and (type(request['recovery_protocol']) is not int
                        or request['recovery_protocol']!=1):raise ValueError('unsupported creation recovery protocol')
                budget=request.get('memory_max_bytes')
                if type(budget) is not int or not 0<budget<=self.max_memory_bytes:raise ValueError('memory budget outside host bounds')
                existing=self.records.get(scope)
                if (self.maintenance['draining'] or self.maintenance_error) and (existing is None or existing.get('pending')):
                    return {'ok':False,'maintenance':True,'retryable':True,
                            'error':'resource broker is draining for maintenance'}
                if existing:
                    if (existing['memory_max_bytes']!=budget
                            or existing.get('gpu_memory_max_bytes',existing['memory_max_bytes'])!=gpu_budget):
                        raise ValueError('attempt budget cannot change')
                    if 'gpu_memory_max_bytes' not in existing:
                        existing['gpu_memory_max_bytes']=gpu_budget
                        _atomic(self.state_dir/(scope+'.json'),existing)
                    if existing.get('released_unix'):raise ValueError('attempt is released')
                    if existing.get('stopped_unix'):raise ValueError('attempt is stopped')
                    if existing.get('pending'):
                        existing.update(self.backend.create(scope,budget));existing.pop('pending',None)
                        _atomic(self.state_dir/(scope+'.json'),existing)
                    return {'ok':True,**existing}
                record={'uid':uid,'action_key':key,'nonce':nonce,'scope_id':scope,
                        'memory_max_bytes':budget,'gpu_memory_max_bytes':gpu_budget,
                        'token':secrets.token_hex(32),'created_unix':time.time()}
                # Persist authority before OS creation so a broker restart can
                # retain exact recovery ownership even after partial setup.
                path=self.state_dir/(scope+'.json');record['pending']=True
                _atomic(path,record);self.records[scope]=record
                try:record.update(self.backend.create(scope,budget))
                except Exception:
                    # No payload was attached. Retain pending evidence; do not
                    # silently treat a partially configured scope as runnable.
                    raise
                record.pop('pending',None);_atomic(path,record)
                return {'ok':True,**record}
            if op not in {'stop','release','status','settle','export_stopped'}:raise ValueError('unknown operation')
            record=self.records.get(scope)
            token=request.get('token')
            if not isinstance(token,str) or HEX64.fullmatch(token) is None:raise PermissionError('invalid attempt token')
            if record is None and not self.backend.exists(scope):
                # Reboot loses /run authority and kernel groups together. Only
                # absence is sufficient; never operate on an unknown group.
                return {'ok':True,'scope_id':scope,'released':True}
            if record is None or not hmac.compare_digest(token,record['token']):
                raise PermissionError('attempt authority does not match')
            if op=='export_stopped':
                # Read-only verdict for containment export, BEFORE the
                # released-record shortcut below: a repeated export after
                # release must keep the full proof (retired/empty/evidence),
                # not the shortcut's reduced shape.  The token holder (or
                # the membership lane it hands the verdict to) learns
                # whether this attempt's scope provably stopped and empty,
                # without mutating authority.  Unknown kernel state after a
                # reboot answers released only through the absent-group rule
                # above; a stopped-but-populated scope -- unresolved Docker
                # tickets, a live cgroup -- exports empty False, which
                # authorizes nothing.  The membership lane files queue
                # attestations from this verdict; reader containment
                # additionally requires terminal broker telemetry, so the
                # verdict alone never frees a ref.
                if record.get('released_unix'):
                    try:empty=self.backend.empty(scope)
                    except Exception:empty=not self.backend.exists(scope)
                    return {'ok':True,'scope_id':scope,'stopped':True,
                            'empty':bool(empty),'released':True,
                            'retired':bool(record.get('retired_unix')),
                            'settled':bool(record.get('settled_unix')),
                            'tickets_pending':bool(record.get('container_tickets')) and not bool(record.get('settled_unix')),
                            **self._stop_details(record)}
                if not record.get('stopped_unix'):
                    raise ValueError('scope not stopped')
                try:empty=self.backend.empty(scope)
                except Exception:raise ValueError('scope emptiness unavailable')
                return {'ok':True,'scope_id':scope,'stopped':True,
                        'empty':bool(empty),'released':False,
                        'retired':bool(record.get('retired_unix')),
                        'settled':bool(record.get('settled_unix')),
                        'tickets_pending':bool(record.get('container_tickets')) and not bool(record.get('settled_unix')),
                        **self._stop_details(record)}
            if record.get('released_unix'):
                # Recovery after a worker crash may repeat cleanup. Retain
                # authority, but never touch a subsequently recreated group.
                return {'ok':True,'scope_id':scope,'released':True,**self._stop_details(record)}
            if record.get('pending'):
                if (op not in {'stop','release'} or record.get('launched_unix')
                        or record.get('container_tickets') or not self.backend.empty(scope)):
                    raise ValueError('scope setup incomplete')
                # No payload or daemon RPC was admitted. Close exact pending
                # authority without signalling processes or recreating a group.
                record.setdefault('stopped_unix',time.time())
                record.setdefault('stop_reason',str(request.get('reason','incomplete scope setup'))[:1000])
                if op=='release':
                    if self.backend.exists(scope):self.backend.release(scope)
                    record['released_unix']=time.time()
                _atomic(self.state_dir/(scope+'.json'),record)
                return {'ok':True,'scope_id':scope,'released':bool(record.get('released_unix')),
                        **self._stop_details(record)}
            if op=='settle':
                # The holder proved its Docker transaction closed. This broker
                # trusts that exactly as it already trusts the same holder's
                # `release` to mean the payload stopped: one caller, one
                # attempt token, one authority. What settlement adds is the one
                # fact `release` cannot have -- that no ticket this scope still
                # retains can ever be redeemed -- and it is the only thing that
                # makes removing the retained parent safe.
                #
                # The scope-label half of that evidence is an identity match,
                # not a name match: `prismabuild.scope` is a reserved label the
                # shim refuses to let any caller set (`_has_reserved_label`),
                # and the shim writes it from the kernel cgroup it is actually
                # running in, never from its environment.
                #
                # What remains after settlement is a container the daemon
                # created and nothing ever started. runc makes a container's
                # cgroup when its task is created, at `start`, not at `create`,
                # so such a container holds no processes and no cgroup: it is a
                # Docker object leak, not an escape from containment. A later
                # `start` needs a container the daemon already registered, and
                # `docker ps -aq` lists those -- `-a` is the whole point -- so
                # the holder's settlement saw it.
                evidence=_settlement_evidence(request.get('evidence'))
                if not record.get('stopped_unix'):raise ValueError('scope not stopped')
                record['container_settlement']=evidence
                record['settled_unix']=time.time()
                _atomic(self.state_dir/(scope+'.json'),record)
                return {'ok':True,'scope_id':scope,'settled':True,**self._stop_details(record)}
            if op=='stop':
                reason=str(request.get('reason','requested'))[:1000]
                if record.get('stopped_unix'):record['last_cleanup_reason']=reason
                else:record['stopped_unix']=time.time();record['stop_reason']=reason
                _atomic(self.state_dir/(scope+'.json'),record)
                self.backend.stop(scope)
            elif op=='release':
                if record.get('container_tickets'):
                    if not record.get('stopped_unix'):
                        raise ValueError('scope not stopped')
                    # Persisted stop intent survives a failed freeze. Reassert
                    # the kernel operation before treating emptiness as safe.
                    self.backend.stop(scope)
                    if not self.backend.empty(scope):
                        raise ValueError('scope still populated or not stopped')
                    # A killed client cannot prove a daemon RPC completed.
                    # Keep the empty frozen parent: a late container cannot
                    # reactivate an unfrozen replacement after admission ends.
                    record['retired_unix']=time.time()
                    _atomic(self.state_dir/(scope+'.json'),record)
                    return {'ok':True,'scope_id':scope,'retired':True}
                self.backend.release(scope)
                record['released_unix']=time.time()
                _atomic(self.state_dir/(scope+'.json'),record)
            return {'ok':True,'scope_id':scope,**self._stop_details(record)}

    @staticmethod
    def _stop_details(record):
        return {key:record[key] for key in ('stop_reason','stopped_unix',
                'termination_evidence','last_cleanup_reason') if key in record}

    def admin(self,uid,request):
        """Operate the one gate that stops this host, as a claim with a holder.

        Every caller here is root, so the caller UID cannot tell the periodic
        client upgrade apart from a person who stopped this host deliberately.
        The holder does that instead: a drain records who opened it, and only
        that caller reopens admission.

        A caller that states no owner gets MAINTENANCE_UNOWNED, and a gate held
        under that identity stays open to every root caller. That is deliberate
        and it is the whole mixed-version story: a client that predates this
        field cannot name itself, and must still be able to close the drain it
        opened through a broker that has since been replaced underneath it.
        A holder that is named is refused to everybody else, and only
        `maintenance_force_end` passes it, recording what it took so that a
        forced release never reads as an ordinary one.

        Beginning a drain that is already open never rewrites the gate. The
        stated reason and the time admission closed are the record of the stop
        that is already in force, and a later caller restating its own claim
        must not replace them.
        """
        if uid!=0:raise PermissionError('maintenance requires root')
        op=request['op']
        allowed=({'op','reason','owner','expected_changed_unix'} if op=='maintenance_begin'
                 else {'op'} if op=='maintenance_status'
                 else {'op','owner','expected_changed_unix'}
                 if op in {'maintenance_end','maintenance_force_end'}
                 else {'op','owner','reason','expected_changed_unix'}
                 if op=='maintenance_takeover' else set())
        if not allowed:raise ValueError('unknown maintenance operation')
        if (set(request)-allowed or ('reason' in request and not isinstance(request['reason'],str))
                or ('owner' in request and (not isinstance(request['owner'],str) or not request['owner'].strip()))
                or ('expected_changed_unix' in request and (
                    not isinstance(request['expected_changed_unix'],(int,float))
                    or isinstance(request['expected_changed_unix'],bool)))
                or (op=='maintenance_takeover' and (
                    'expected_changed_unix' not in request
                    or 'owner' not in request or not request['owner'].strip()))):
            raise ValueError('invalid maintenance fields')
        owner=request.get('owner',MAINTENANCE_UNOWNED)[:200]
        with self.lock:
            held=self.maintenance.get('owner',MAINTENANCE_UNOWNED) if self.maintenance['draining'] else None
            # An unclaimed drain belongs to nobody, so it is not somebody else's.
            foreign=held not in (None,owner,MAINTENANCE_UNOWNED)
            if 'expected_changed_unix' in request:
                # Compare-and-set through this mutex: the gate may have moved
                # between the caller's read and this call, and only the value
                # enforced here is the linearization. A stale process holding
                # an old epoch refuses; it never clears a newer drain.
                current=self.maintenance.get('changed_unix')
                if current!=request['expected_changed_unix']:
                    raise ValueError('maintenance epoch changed during call: '
                                     f'expected {request["expected_changed_unix"]!r}, '
                                     f'gate holds {current!r}')
            if op=='maintenance_begin':
                if foreign:raise PermissionError('maintenance drain is held by '+held)
                if held is None:
                    value={'schema':MAINTENANCE_SCHEMA,'draining':True,'changed_unix':time.time(),
                           'reason':request.get('reason','automatic upgrade')[:1000],'owner':owner}
                    # Durable closure precedes every worker-visible close.  If
                    # the latter fails, remove the old open mirror if possible;
                    # #505 treats absence as closed and this authority is closed.
                    try:_atomic(self.maintenance_state_path,value,
                                mode=0o600 if self.durable_maintenance else 0o644)
                    except OSError:
                        if self.durable_maintenance:
                            self.maintenance=value
                            self.maintenance_error='durable maintenance closure could not be committed'
                            self._force_volatile_gate_closed()
                        raise
                    self.maintenance=value
                    if self.durable_maintenance:
                        try:self._sync_maintenance_gate(value)
                        except OSError:
                            self.maintenance_error=self._force_volatile_gate_closed()
                            raise
            status=self._maintenance_status()
            if op=='maintenance_takeover':
                # Take over THIS membership's own abandoned drain without
                # opening admission: the gate stays closed on the SAME epoch
                # so parked markers and in-flight proofs keep naming it.
                # Only a membership-shaped hold whose supervision is
                # provably dead or replaced may be taken, by a caller that
                # names the exact epoch and proves live supervision itself.
                # Operator/upgrade holds, live old supervisors, stale
                # epochs, and an open gate all refuse; force_end (root-owned,
                # recorded) remains their only path.
                if not self.maintenance['draining']:
                    raise ValueError('no membership drain is in force to take over')
                if not _dead_supervisor_owner(held):
                    raise PermissionError('maintenance drain is held by '+str(held))
                if not _live_supervisor_owner(owner):
                    raise PermissionError('takeover owner is not live supervision')
                value={'schema':MAINTENANCE_SCHEMA,'draining':True,
                       'changed_unix':self.maintenance.get('changed_unix',time.time()),
                       'reason':request.get('reason','membership takeover')[:1000],
                       'owner':owner,'takeover_of':held,'takeover_by':owner,
                       'takeover_unix':time.time()}
                try:_atomic(self.maintenance_state_path,value,
                            mode=0o600 if self.durable_maintenance else 0o644)
                except OSError:
                    if self.durable_maintenance:
                        self.maintenance_error='durable maintenance takeover could not be committed'
                        self._force_volatile_gate_closed()
                    raise
                self.maintenance=value
                if self.durable_maintenance:
                    try:self._sync_maintenance_gate(value)
                    except OSError:
                        self.maintenance_error=self._force_volatile_gate_closed()
                        raise
            if op in {'maintenance_end','maintenance_force_end'}:
                takeover=None
                if foreign and op=='maintenance_end':
                    # Supervisor-restart takeover of THIS membership's own
                    # drain, never of another maintenance: the caller names
                    # the exact epoch it read (enforced above), proves it IS
                    # the live supervision of this box, and the held owner
                    # must be a membership drain whose supervision is
                    # verifiably dead or replaced. A live old supervisor, an
                    # upgrade/operator/unshaped hold, or a stale epoch stays
                    # refused — a live root supervisor is no license to steal
                    # another maintenance, and ``force_end`` (root-owned,
                    # recorded) remains the only path for those.
                    if ('expected_changed_unix' in request
                            and _live_supervisor_owner(owner)
                            and _dead_supervisor_owner(held)):
                        takeover={'takeover_of':held,'takeover_by':owner}
                    else:
                        raise PermissionError('maintenance drain is held by '+held)
                if not status['health']:raise ValueError('resource broker is not healthy; maintenance remains active')
                value={'schema':MAINTENANCE_SCHEMA,'draining':False,'changed_unix':time.time()}
                # A forced release is evidence, not a state: it stays in the gate
                # until the next drain overwrites it, naming both parties.
                if foreign:value.update({'forced_end_of':held,'forced_end_by':owner})
                if takeover is not None:value.update(takeover)
                # The volatile open mirror never precedes durable release.  If
                # the mirror fails, retain this process's in-memory closure;
                # a restart reads the committed release and retries the mirror.
                _atomic(self.maintenance_state_path,value,
                        mode=0o600 if self.durable_maintenance else 0o644)
                if self.durable_maintenance:
                    try:self._sync_maintenance_gate(value)
                    except OSError:
                        self.maintenance_error='durable maintenance release committed; volatile admission fenced'
                        self._force_volatile_gate_closed()
                        raise
                self.maintenance=value;self.maintenance_error=None
                status['draining']=False;status.pop('maintenance_owner',None)
            return status

    def _reclaim_retired_scope(self,scope,record):
        """Drop a retained tombstone's charge. Never removes, never fails the pass.

        `release` keeps an empty frozen parent when a container ticket was
        never resolved, because a killed client cannot prove the daemon RPC
        completed. Nothing ever reclaimed what that parent still held, so the
        charge stayed on the host until it rebooted (#486).

        A failure here is recorded on the record and nowhere else. Reclaim
        removes nothing, so a reclaim that did not work leaves precisely the
        state this broker already tolerates -- and housekeeping must never be
        able to hold a host's maintenance gate closed.
        """
        observation={'reclaim_before_bytes':None,'reclaim_after_bytes':None,
                     'reclaim_page_bytes_after':None,
                     'reclaim_complete':None,'reclaim_error':None}
        try:
            result=self.backend.reclaim(scope)
            observation.update({'reclaim_before_bytes':result['before'],
                                'reclaim_after_bytes':result['after'],
                                'reclaim_page_bytes_after':result.get('page_bytes_after'),
                                'reclaim_complete':bool(result['complete'])})
        except (OSError,ValueError,KeyError) as exc:
            observation['reclaim_error']=str(exc)[:500]
        # A pass that observed exactly what the record already says writes
        # nothing: a tombstone with nothing left to give back would otherwise
        # rewrite its own state file on every upgrade cycle, forever.
        if not all(record.get(key)==value for key,value in observation.items()):
            record.update(observation);record['reclaimed_unix']=time.time()
            try:_atomic(self.state_dir/(scope+'.json'),record)
            except OSError:pass  # retain the observation in memory for this pass
        # memory.current includes kernel allocations; reclaim may return
        # EAGAIN after all anon/file pages are gone. Kernel-only residuals do
        # not need another reclaim attempt before the group goes offline.
        return observation['reclaim_page_bytes_after']==0

    def _verify_retired_scope(self,scope,record):
        observed=self.backend.observe(scope)
        if (observed is None or observed['populated'] or not observed['frozen']
                or observed.get('identity')!=record.get('cgroup_identity')):
            raise ValueError('retired scope changed before removal: '+scope)

    def _reap_retired_scope(self,scope,record):
        """Remove a tombstone whose holder proved its container transaction closed.

        The order is not interchangeable. A memory cgroup removed while it
        still holds LRU page cache goes offline as a zombie -- the kernel
        reparents kernel memory on offline but not page cache -- so removing
        first would delete the directory and leave the charge behind, which is
        the half of #486 a removal alone does not fix. Complete reclaim, verify
        the exact group, reassert its stop, verify again, and only then remove.

        Inventory precedes reclaim, which can take time. Check before stop so
        a mismatch is not discovered only after signalling a replacement.
        Retain the post-stop observation and final `backend.empty` check too.
        """
        if not self._reclaim_retired_scope(scope,record):
            # A failed reclaim or one with residual/unknown page charge must
            # leave the group online for retry without failing the gate.
            return False
        # Reclaim can take time. Do not stop a replacement or a group that
        # became populated since inventory; checking only after stop would
        # discover the mismatch after signalling it.
        self._verify_retired_scope(scope,record)
        # Persisted stop intent, reasserted: the same move `release` makes
        # before it is willing to treat emptiness as safe.
        self.backend.stop(scope)
        self._verify_retired_scope(scope,record)
        if not self.backend.empty(scope):raise ValueError('retired scope became populated: '+scope)
        self.backend.release(scope)
        record['released_unix']=time.time()
        record['maintenance_cleanup']='settled container transaction'
        _atomic(self.state_dir/(scope+'.json'),record)
        return True

    def _release_vanished_retired_scope(self,scope,record):
        """Close a retired tombstone whose kernel group is already gone.

        Metadata only: no kernel operation can act on a group that is not
        there, so the record's identity, stop, settlement and any earlier
        reclaim observation are carried over unchanged and only
        ``released_unix`` plus the explicit ``maintenance_cleanup`` reason are
        added.  The replacement is persisted under the caller's authority lock
        BEFORE the in-memory record changes: a durable write that fails must
        leave the record active rather than release it in memory only, and the
        caller keeps it active and reports the failure.
        """
        released=dict(record)
        released['released_unix']=time.time()
        released['maintenance_cleanup']=VANISHED_CLEANUP_REASON
        _atomic(self.state_dir/(scope+'.json'),released)
        self.records[scope]=released
        return released

    def _maintenance_status(self):
        errors=[];active=set();inventory={}
        if self.maintenance_error:errors.append(self.maintenance_error)
        try:
            if not self.backend.healthy():errors.append('kernel resource controllers unavailable')
            inventory=self.backend.inventory()
        except (OSError,ValueError) as exc:errors.append(str(exc)[:1500]);active.add('unreadable kernel inventory')
        # Named here rather than read off `errors` below, because the scan that
        # reports these runs after this loop: a removal must not be gated on an
        # error that has not been appended yet.
        unknown=set(inventory)-set(self.records)
        for scope,record in self.records.items():
            kernel=inventory.get(scope)
            if (kernel is not None and record.get('cgroup_identity')
                    and record['cgroup_identity']!=kernel.get('identity')):
                active.add(scope);errors.append('kernel scope identity changed: '+scope)
                continue
            if record.get('released_unix'):
                if kernel is not None:
                    active.add(scope);errors.append('released scope has an unknown kernel group: '+scope)
                continue
            # A failed create has no launcher or Docker RPC. Retire only exact
            # owned empty setup remnants, without signalling any processes.
            if (self.maintenance['draining'] and record.get('pending')
                    and not record.get('launched_unix') and not record.get('container_tickets')
                    and not errors and (kernel is None or not kernel['populated'])):
                try:
                    if kernel is None:
                        if self.backend.exists(scope):raise ValueError('pending scope appeared during inventory')
                    else:
                        if not self.backend.empty(scope):raise ValueError('pending scope became populated')
                        self.backend.release(scope)
                    record['released_unix']=time.time();record['maintenance_cleanup']='unlaunched empty setup'
                    _atomic(self.state_dir/(scope+'.json'),record)
                    inventory.pop(scope,None)
                    continue
                except (OSError,ValueError) as exc:errors.append(str(exc)[:1500])
            if record.get('retired_unix') and kernel is not None and not kernel['populated'] and kernel['frozen']:
                if not record.get('cgroup_identity') or record['cgroup_identity']==kernel.get('identity'):
                    # Only a tombstone whose kernel identity this broker can
                    # still prove is one it may work on. A record written
                    # before identity was recorded stays inactive and
                    # untouched, exactly as it was.
                    if record.get('cgroup_identity'):
                        if record.get('settled_unix') and not errors and not unknown:
                            # The same gate the unlaunched-setup cleanup above
                            # uses: a pass that cannot read its own namespace,
                            # or that found a group in it this broker does not
                            # own, defers removal rather than acting on a
                            # picture it has already found wrong.
                            try:
                                if self._reap_retired_scope(scope,record):
                                    inventory.pop(scope,None)
                            except (OSError,ValueError) as exc:errors.append(str(exc)[:1500])
                        else:
                            self._reclaim_retired_scope(scope,record)
                    continue
            if record.get('retired_unix') and kernel is None:
                # The group this tombstone names is no longer in the kernel.
                # Nothing can be stopped, reclaimed or released, and without
                # this branch the record was counted active forever -- the
                # wedge left after an out-of-band slice removal.  Close only
                # the administrative lifetime, and only on proof this broker
                # already trusts: a stopped, retired record whose stored
                # settlement the holder's own validator accepts, observed by a
                # complete healthy inventory with no unknown namespace group,
                # with a fresh absence check still saying absent.  A missing
                # or malformed identity, unsettled tickets, a malformed or
                # reappearing group and any inventory error all fail closed.
                if (record.get('stopped_unix') and record.get('settled_unix')
                        and _recorded_identity(record.get('cgroup_identity'))
                        and not errors and not unknown):
                    try:
                        _settlement_evidence(record.get('container_settlement'))
                    except ValueError:
                        active.add(scope);continue
                    try:
                        if not self.backend.exists(scope):
                            self._release_vanished_retired_scope(scope,record)
                            continue
                    except (OSError,ValueError) as exc:errors.append(str(exc)[:1500])
                active.add(scope);continue
            active.add(scope)
        for scope in inventory:
            if scope not in self.records:
                active.add(scope);errors.append('unknown broker namespace group: '+scope)
        try:
            for name,path in self.installation_paths.items():
                if hashlib.sha256(_trusted_file(path).read_bytes()).hexdigest()!=self.installed_sha256[name]:
                    errors.append('installed privileged file changed: '+name)
            if not self.health_check():errors.append('resource monitor is not healthy')
        except (OSError,ValueError,KeyError) as exc:errors.append(str(exc)[:1500])
        # maintenance_protocol is unconditional: a caller decides whether it may
        # send an owner from its presence, and a gate that happens to be open
        # would otherwise read exactly like a broker that has no holders at all.
        return {'ok':True,'draining':self.maintenance['draining'],'active_scopes':len(active),
                'active_scope_ids':sorted(active)[:128],'active_scopes_truncated':len(active)>128,
                'health':not errors,'errors':[error[:500] for error in errors[:32]],
                'errors_truncated':len(errors)>32,'maintenance_protocol':MAINTENANCE_PROTOCOL,
                **({'maintenance_durable_protocol':MAINTENANCE_DURABLE_PROTOCOL,
                    'maintenance_state_path':str(self.maintenance_state_path)}
                   if self.durable_maintenance else {}),
                **({'maintenance_owner':self.maintenance.get('owner',MAINTENANCE_UNOWNED)}
                   if self.maintenance['draining'] else {}),
                'installed_sha256':dict(self.installed_sha256)}

    def run(self,uid,pid,request,stdio):
        allowed={'op','action_key','nonce','token','argv','cwd','env','affinity','umask'}
        if not isinstance(request,dict) or set(request)-allowed:raise ValueError('unknown run field')
        command={k:request.get(k) for k in ('argv','cwd','env')}
        if 'umask' in request:
            mask=request['umask']
            if type(mask) is not int or not 0<=mask<=0o777:
                raise ValueError('invalid inherited umask')
            command['umask']=mask
        if 'affinity' in request:
            mask=request['affinity']
            if (not isinstance(mask,list) or not mask or len(mask)!=len(set(mask))
                    or any(type(x) is not int or x<0 for x in mask)
                    or not set(mask)<=os.sched_getaffinity(0)):
                raise ValueError('invalid inherited CPU affinity')
            command['affinity']=mask
        argv,cwd,env=command['argv'],command['cwd'],command['env']
        if (not isinstance(argv,list) or not argv or len(argv)>4096
                or any(not isinstance(x,str) or '\x00' in x for x in argv)
                or not isinstance(cwd,str) or not cwd.startswith('/') or '\x00' in cwd
                or not isinstance(env,dict) or any(not isinstance(k,str) or not k or '=' in k
                    or '\x00' in k or not isinstance(v,str) or '\x00' in v for k,v in env.items())
                or len(json.dumps(command).encode())>49152 or len(stdio)!=3):
            raise ValueError('invalid bounded command or stdio descriptors')
        with self.lock:
            identity={k:request[k] for k in ('action_key','nonce','token')}
            if self.handle(uid,pid,{'op':'status',**identity}).get('released'):
                raise ValueError('attempt is released')
            record=self.records[scope_id(identity['action_key'],identity['nonce'])]
            if record.get('released_unix'):raise ValueError('attempt is released')
            if record.get('stopped_unix'):raise ValueError('attempt is stopped')
            if record.get('launched_unix'):raise ValueError('attempt already launched')
            # Persist launch intent before spawning; ambiguous restart refuses
            # a duplicate, retaining the exact scope for stop/recovery.
            record['launched_unix']=time.time()
            _atomic(self.state_dir/(record['scope_id']+'.json'),record)
            return self.backend.run(record['scope_id'],uid,command,stdio)

    def container(self,uid,pid,request):
        op=request['op'];scope=request.get('scope_id')
        fields={'op','scope_id'} if op=='container_begin' else {'op','scope_id','ticket'}
        if set(request)-fields or not isinstance(scope,str) or not re.fullmatch(r'prismabuild-job[0-9a-f]{32}\.slice',scope):
            raise ValueError('invalid container intent fields')
        with self.lock:
            record=self.records.get(scope)
            if record is None or record.get('uid')!=uid:raise PermissionError('unknown scope owner')
            if record.get('released_unix'):raise ValueError('attempt is released')
            if op=='container_begin':
                if record.get('stopped_unix'):raise ValueError('attempt is stopped')
                # This check grants only conservative intent registration, not
                # process migration or a kill capability. A vanished peer
                # cannot make another scope runnable or clear an intent.
                group=Path(f'/proc/{pid}/cgroup').read_text()
                if not any(scope in line.split('/') for line in group.splitlines()):
                    raise PermissionError('container creator is not in its scope')
                ticket=secrets.token_hex(32)
                record.setdefault('container_tickets',[]).append(ticket)
                _atomic(self.state_dir/(scope+'.json'),record)
                return {'ok':True,'ticket':ticket}
            ticket=request.get('ticket')
            if not isinstance(ticket,str) or HEX64.fullmatch(ticket) is None or ticket not in record.get('container_tickets',[]):
                raise PermissionError('container intent authority does not match')
            record['container_tickets'].remove(ticket)
            _atomic(self.state_dir/(scope+'.json'),record)
            return {'ok':True}

class ResourceMonitor:
    """Sample outside admission locks; stop only the same recorded kernel group."""
    identity_fields=('action_key','nonce','token','memory_max_bytes','gpu_memory_max_bytes','cgroup_identity')

    def __init__(self,authority,gpu_module,*,capacity_module=None,interval_s=1.0,timeout_s=1.0):
        self.capacity=capacity_module
        self.authority=authority;self.gpu=gpu_module;self.guard=gpu_module.Guard()
        self.interval_s=interval_s;self.timeout_s=timeout_s
        self.stopping=threading.Event();self.thread=None;self.last_success_monotonic=None

    def _records(self):
        with self.authority.lock:
            return {scope:{key:value for key,value in record.items() if key in {
                    *self.identity_fields,'gpu_memory_max_bytes','memory_oom_kill_baseline','memory_oom_local_baseline','monitor_stop_pending',
                    'termination_evidence','stop_reason'}}
                for scope,record in self.authority.records.items()
                if not record.get('pending') and not record.get('released_unix')
                and (not record.get('stopped_unix') or record.get('monitor_stop_pending'))
                and isinstance(record.get('cgroup_identity'),list)
                and len(record['cgroup_identity'])==2}

    def _stop(self,scope,expected,identity,reason,evidence):
        with self.authority.lock:
            current=self.authority.records.get(scope)
            if (current is None or current.get('pending') or current.get('released_unix')
                    or (current.get('stopped_unix') and not current.get('monitor_stop_pending'))
                    or any(current.get(key)!=expected.get(key) for key in self.identity_fields)
                    or tuple(current['cgroup_identity'])!=tuple(identity)):
                return False
            info=self.authority.backend.path(scope).stat()
            if (info.st_dev,info.st_ino)!=tuple(identity):return False
            current.setdefault('stopped_unix',time.time())
            current.setdefault('stop_reason',reason)
            current.setdefault('termination_evidence',evidence)
            current['monitor_stop_pending']=True
            path=self.authority.state_dir/(scope+'.json')
            _atomic(path,current)
            self.authority.backend.stop(scope)
            current['monitor_stop_pending']=False
            _atomic(path,current)
            return True

    def poll_once(self):
        records=self._records();stopped=[];errors=[]
        # Only a local OOM identifies exhaustion of this aggregate limit.
        # Hierarchical victim counts also include safely contained child OOMs.
        # Stop at local exhaustion even before a victim appears: allocation
        # failure itself proves the attempt exhausted its budget. Docker victims
        # can be charged to descendants, so local oom_kill is not the trigger.
        for scope,record in records.items():
            try:
                path=self.authority.backend.path(scope);info=path.stat()
                identity=(info.st_dev,info.st_ino)
                if identity!=tuple(record['cgroup_identity']):continue
                if record.get('monitor_stop_pending'):
                    if self._stop(scope,record,identity,record['stop_reason'],record['termination_evidence']):
                        stopped.append(scope)
                    continue
                events=dict(line.split() for line in (path/'memory.events').read_text().splitlines())
                local_events=dict(line.split() for line in (path/'memory.events.local').read_text().splitlines())
                after=path.stat()
                if (after.st_dev,after.st_ino)!=identity:continue
                count=int(events.get('oom_kill',0))
                baseline=int(record.get('memory_oom_kill_baseline',0))
                local_count=int(local_events['oom'])
                local_baseline=int(record.get('memory_oom_local_baseline',0))
                if local_count>local_baseline:
                    evidence={'source':'cgroup.memory.events.local','scope_id':scope,
                              'cgroup_identity':list(identity),'oom_kill':count,
                              'oom_local':local_count,'oom_local_baseline':local_baseline,
                              'oom_kill_baseline':baseline,'sampled_unix':time.time()}
                    if self._stop(scope,record,identity,'memory_limit_oom',evidence):stopped.append(scope)
            except (OSError,ValueError,KeyError) as exc:errors.append({'scope_id':scope,'error':str(exc)[:1500]})
        scopes=[self.gpu.Scope(scope,self.authority.backend.path(scope),record['memory_max_bytes'],
                    **({'gpu_budget_bytes':record.get('gpu_memory_max_bytes',record['memory_max_bytes'])}
                       if self.capacity is not None or record.get('gpu_memory_max_bytes') is not None else {}))
                for scope,record in records.items() if scope not in stopped and not record.get('monitor_stop_pending')]
        snapshot=None;device_readings=None;memory_options={}
        if self.capacity is not None:
            device_readings=self.capacity.devices(timeout_s=self.timeout_s)
            memory_options['gpu_memory_domains']={device['uuid']:device['memory_domain']
                                                 for device in device_readings[0]}
            # The census needs the vendor as well as the domain: which reader
            # can attribute a process is a property of the device, and the one
            # device query already made here is the only place that is known.
            memory_options['gpu_devices']=device_readings[0]
        if scopes or self.capacity is not None:
            snapshot=self.gpu.collect(scopes,timeout_s=self.timeout_s,**memory_options)
            for decision in self.guard.observe(snapshot):
                expected=records.get(decision.scope_id)
                if expected is None:continue
                try:
                    if self._stop(decision.scope_id,expected,decision.cgroup_identity,
                                  decision.reason,decision.as_dict()):stopped.append(decision.scope_id)
                except (OSError,ValueError,KeyError) as exc:
                    errors.append({'scope_id':decision.scope_id,'error':str(exc)[:1500]})
        status={'sampled_unix':time.time(),'active_scopes':len(records),'stopped':stopped,
                'errors':errors,'gpu':snapshot.as_dict() if snapshot is not None else None}
        if self.capacity is not None and snapshot is not None:
            # This sanitized root-owned sibling is readable by pool workers;
            # private monitor/authority records retain their mode 0600.
            active={scope:record for scope,record in records.items() if scope not in stopped}
            public=self.capacity.collect(snapshot.as_dict(),active,timeout_s=self.timeout_s,
                                         device_readings=device_readings)
            if stopped or errors:
                public['complete']=False
                public['errors'].append('scope inventory changed or monitor errors during sample')
            _atomic(self.authority.state_dir.parent/'gpu-capacity.json',public,mode=0o644)
        _atomic(self.authority.state_dir/'monitor.status',status)
        self.last_success_monotonic=time.monotonic()
        return status

    def healthy(self):
        return (self.thread is not None and self.thread.is_alive()
                and self.last_success_monotonic is not None
                and time.monotonic()-self.last_success_monotonic<15)

    def _loop(self):
        while not self.stopping.is_set():
            try:self.poll_once()
            except Exception as exc:
                print('resource monitor sample failed: '+str(exc)[:1500],flush=True)
            self.stopping.wait(self.interval_s)

    def start(self):
        self.thread=threading.Thread(target=self._loop,name='resource-monitor',daemon=True)
        self.thread.start()

    def close(self):
        self.stopping.set()
        if self.thread is not None:self.thread.join(timeout=self.timeout_s+self.interval_s+1)


class Handler(socketserver.BaseRequestHandler):
    def handle(self):
        self.request.settimeout(10);descriptors=[];process=None;request=None
        pid,uid,_=struct.unpack('3i',self.request.getsockopt(socket.SOL_SOCKET,socket.SO_PEERCRED,struct.calcsize('3i')))
        try:
            raw,ancillary,flags,_=self.request.recvmsg(65537,socket.CMSG_SPACE(16*array.array('i').itemsize))
            for level,kind,data in ancillary:
                if level==socket.SOL_SOCKET and kind==socket.SCM_RIGHTS:
                    fds=array.array('i');fds.frombytes(data[:len(data)-len(data)%fds.itemsize]);descriptors.extend(fds)
            while not raw.endswith(b'\n') and len(raw)<=65536:
                more=self.request.recv(65537-len(raw))
                if not more:break
                raw+=more
            if flags&socket.MSG_CTRUNC or len(raw)>65536 or not raw.endswith(b'\n'):
                raise ValueError('request exceeds framing limit')
            request=json.loads(raw)
            if isinstance(request,dict) and request.get('op')=='run':
                process=self.server.authority.run(uid,pid,request,descriptors)
                # Close our duplicates; only the launched child needs stdio.
                for fd in descriptors:os.close(fd)
                descriptors=[];self.request.settimeout(None)
                exit_fd=os.pidfd_open(process.pid)
                try:
                    while process.poll() is None:
                        ready=select.select([self.request,exit_fd],[],[],1)[0]
                        if self.request in ready:
                            extra=self.request.recv(1)
                            # Both EOF and unexpected in-flight protocol data
                            # end only this attempt; never spin on unread bytes.
                            self.server.authority.handle(uid,pid,{k:v for k,v in {
                                **request,'op':'stop','reason':'execution client disconnected or sent unexpected data'}.items()
                                if k in {'op','action_key','nonce','token','reason'}})
                            break
                    code=process.wait(timeout=15)
                finally:os.close(exit_fd)
                answer={'ok':True,'returncode':code}
            else:
                if descriptors:raise ValueError('descriptors only accepted for run')
                answer=self.server.authority.handle(uid,pid,request)
        except (ValueError,PermissionError,OSError,KeyError,TypeError,subprocess.SubprocessError) as exc:
            if process is not None and process.poll() is None and isinstance(request,dict):
                try:
                    self.server.authority.handle(uid,pid,{k:v for k,v in {
                        **request,'op':'stop','reason':'execution control connection failed'}.items()
                        if k in {'op','action_key','nonce','token','reason'}})
                    process.wait(timeout=15)
                except (OSError,ValueError,PermissionError,subprocess.SubprocessError):pass
            answer={'ok':False,'error':str(exc)[:1500]}
        finally:
            for fd in descriptors:os.close(fd)
        try:self.request.sendall((json.dumps(answer)+'\n').encode())
        except OSError:pass

class Server(socketserver.ThreadingUnixStreamServer):
    daemon_threads=True

def main():
    parser=argparse.ArgumentParser(description=__doc__.splitlines()[0])
    parser.add_argument('--socket',default='/run/prismabuild/resources.sock',
                        help='local Unix socket for authenticated resource requests')
    parser.add_argument('--state-dir',default='/run/prismabuild/jobs',
                        help='private root-owned directory for attempt authority and recovery')
    parser.add_argument('--maintenance-state',default='/var/lib/prismabuild-resource-broker/maintenance.json',
                        help='root-owned persistent maintenance authority')
    parser.add_argument('--initialize-maintenance-state',action='store_true',
                        help='explicitly initialize an unconfigured persistent maintenance authority open')
    parser.add_argument('--uid',type=int,default=1000,
                        help='local execution user allowed to create and control job scopes')
    args=parser.parse_args()
    if os.geteuid()!=0:raise SystemExit('resource broker must run as root')
    if args.initialize_maintenance_state:
        state=Path(args.maintenance_state)
        evidence=state.with_name(state.name+'.initialized')
        state.parent.mkdir(parents=True,exist_ok=True,mode=0o700)
        upper=os.open(state.parent.parent,os.O_RDONLY|os.O_DIRECTORY)
        try:os.fsync(upper)
        finally:os.close(upper)
        info=state.parent.lstat()
        if (not stat.S_ISDIR(info.st_mode) or info.st_uid!=0 or info.st_mode&0o077):
            raise SystemExit('maintenance state directory must be private and root-owned')
        for path in (state,evidence):
            try:path.lstat()
            except FileNotFoundError:continue
            else:raise SystemExit('persistent maintenance authority is already initialized')
        legacy=Path(args.state_dir).parent/'maintenance.json'
        try:legacy.lstat()
        except FileNotFoundError:pass
        else:
            raise SystemExit('legacy maintenance gate exists; start broker to migrate or reject it')
        _atomic(evidence,{'schema':MAINTENANCE_EVIDENCE_SCHEMA,'initialized_unix':time.time()},mode=0o600)
        _atomic(state,{'schema':MAINTENANCE_SCHEMA,'draining':False,'changed_unix':time.time(),
                       'reason':'explicit initial installation'},mode=0o600)
        return
    total=next(int(x.split()[1])*1024 for x in Path('/proc/meminfo').read_text().splitlines() if x.startswith('MemTotal:'))
    authority=Authority(args.state_dir,args.uid,SystemdBackend(),max_memory_bytes=total,
                        maintenance_state=args.maintenance_state)
    endpoint=Path(args.socket);endpoint.parent.mkdir(mode=0o755,parents=True,exist_ok=True)
    if endpoint.exists():
        # systemd owns one broker; refuse an active endpoint rather than take it.
        probe=socket.socket(socket.AF_UNIX)
        try:
            probe.connect(str(endpoint));raise SystemExit('resource broker socket already active')
        except ConnectionRefusedError:endpoint.unlink()
        finally:probe.close()
    with Server(str(endpoint),Handler) as server:
        server.authority=authority
        os.chown(endpoint,0,pwd.getpwuid(args.uid).pw_gid);endpoint.chmod(0o660)
        monitor=ResourceMonitor(authority,_load_gpu_module(),capacity_module=_load_gpu_module('gpu_capacity.py'))
        for name in ('resource_broker.py','resource_payload.py','gpu_memory.py','gpu_capacity.py'):
            path=_trusted_file(Path(__file__).resolve().with_name(name))
            authority.installation_paths[name]=path
            authority.installed_sha256[name]=hashlib.sha256(path.read_bytes()).hexdigest()
        authority.health_check=monitor.healthy
        monitor.start()
        print('PrismaBuild resource broker ready',flush=True)
        try:server.serve_forever(poll_interval=0.5)
        finally:monitor.close()

if __name__=='__main__':main()
