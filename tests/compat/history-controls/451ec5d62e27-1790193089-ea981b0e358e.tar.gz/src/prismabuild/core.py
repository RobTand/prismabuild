"""Deterministic PrismaBuild action keys, local execution, and immutable CAS.

This is the dependency-free core beneath a future Dagster/SLURM deployment.
It deliberately does not contain a queue or a weight cache.  An action is an
exact, self-hashed contract; a local worker executes its argv with
``shell=False`` and a closed environment; and successful file results are
published to a content-addressed store with NFS-safe, first-writer-wins hard
links.

Portable actions omit machine identity from their key.  Platform- and
host-class-keyed actions bind the corresponding explicit execution scope.
Measurement actions are never portable.  Explicit codebook-family generation
is also never portable because D29 records cross-architecture row-scale byte
drift.
"""

from __future__ import annotations

import argparse
from collections.abc import Callable, Mapping, Sequence
from contextlib import contextmanager, suppress
import errno
import fcntl
import gzip
import hashlib
import json
import math
import os
from pathlib import Path, PurePosixPath
import platform
import posixpath
import re
import shutil
import signal
import socket
import stat
import subprocess
import sys
import tempfile
import time
import zlib

ACTION_SCHEMA_V1 = "prismaquant.prismabuild.action.v1"
ACTION_SCHEMA_V2 = "prismaquant.prismabuild.action.v2"
CODE_CLOSURE_SCHEMA_V1 = "prismaquant.prismabuild.code_closure.v1"
CAS_RECEIPT_SCHEMA_V3 = "prismaquant.prismabuild.cas_receipt.v3"
WORKER_ATTESTATION_SCHEMA_V2 = "prismaquant.prismabuild.worker_attestation.v2"
WORKER_RUNTIME_SCHEMA_V1 = "prismaquant.prismabuild.worker_runtime.v1"

#: Where a transport asks this worker to leave the action's own exit status.
#:
#: An environment variable rather than an argument, because ``pool.worker_argv``
#: is pinned byte-identical across both transports -- an action executed under
#: SLURM and the same action executed by the pull queue must be the same
#: execution -- and a flag on one of them would end that. The action's own argv
#: never sees this: ``run_local_action`` builds the sealed environment it runs
#: in, and this variable is not in it.  (The progress variables below are the
#: deliberate exception, and say so.)
ACTION_STATUS_PATH_ENV = "PRISMABUILD_ACTION_STATUS_PATH"

#: The action-side half of the progress contract, whose definitions live in
#: :mod:`prismabuild.progress` and are **mirrored** here.
#:
#: Mirrored rather than imported, and the reason is
#: ``test_worker_core_has_no_unattested_repository_imports``: the worker
#: attestation hashes this file and the launcher, so anything this file
#: imported from the repository would be code the worker runs and the
#: attestation does not cover.  ``progress`` is a leaf the *action* loads --
#: by name, by path, or as a program -- precisely because it cannot import
#: this one either.  The mirror is held to its source by
#: ``test_one_definition_of_the_schema_and_the_channel``; change it there
#: first.
#:
#: Unlike ``ACTION_STATUS_PATH_ENV`` these DO reach the action's own
#: environment: ``run_local_action`` forwards them, and only when the sealed
#: params declare :data:`PROGRESS_PARAM`.  They have to -- the whole point is a
#: fact the *application* knows and the launcher does not.  An action that
#: seals any of the names is refused rather than overwritten, exactly as the
#: profile contract already refuses one.
#:
#: The token is minted per LAUNCH rather than per action key.  Unlinking the
#: file before the launch is not enough on its own: an action that outlived
#: SIGKILL on a previous attempt (a D-state GPU wedge does) keeps the same
#: path open and would replay its counter into the next attempt's watchdog.
ACTION_PROGRESS_PATH_ENV = "PRISMABUILD_ACTION_PROGRESS_PATH"
ACTION_PROGRESS_TOKEN_ENV = "PRISMABUILD_ACTION_PROGRESS_TOKEN"
ACTION_PROGRESS_PHASES_ENV = "PRISMABUILD_ACTION_PROGRESS_PHASES"
ACTION_PROGRESS_HELPER_ENV = "PRISMABUILD_ACTION_PROGRESS_HELPER"
ACTION_PROGRESS_ENV = (
    ACTION_PROGRESS_PATH_ENV,
    ACTION_PROGRESS_TOKEN_ENV,
    ACTION_PROGRESS_PHASES_ENV,
    ACTION_PROGRESS_HELPER_ENV,
)

#: The residency channel (#583), **mirrored** from
#: :mod:`prismabuild.residency_map` for the same reason the progress names
#: above are mirrored: attested worker core imports no repository module.
#: ``tests/test_a_residency_map_names_bytes_a_mover_verified.py`` pins the two
#: definitions to one string.
#:
#: Neither is sealed, and neither may be.  The map says *where a copy of the
#: action's own inputs is*, and every entry in it carries the sha256 the
#: manifest declared -- so an action that reads a staged copy computes what an
#: action that reads the pool computes, byte for byte.  Sealing the map would
#: make the same work under two different keys and cost every staged run its
#: CAS hit; forwarding it unsealed is what keeps staging a placement decision
#: rather than a different question.  ``ACTION_KEY_ENV`` is the action's own
#: identity, which cannot be an argument for the actions that need it most:
#: a movement node files its receipt and holds its tier tokens under its key,
#: and a key inside the argv the key is computed from does not converge.
ACTION_KEY_ENV = "PRISMABUILD_ACTION_KEY"
RESIDENCY_MAP_ENV = "PRISMABUILD_RESIDENCY_MAP"
#: The payload's public attempt identity, set by the resource_exec proxy
#: from the exact launch identity (never the broker token) and protected
#: here the same way as the action key: a sealed variable of any of these
#: names is a refusal rather than an overwrite, so an action cannot spoof
#: the attempt its readers bind their pins to, nor the sealed helper root
#: they import from.  Core sets no values for these three; they arrive
#: with the execution.  Strict readers without forwarded identity refuse
#: (legacy inspection without acquiring is a separate helper).
ACTION_NONCE_ENV = "PRISMABUILD_ACTION_NONCE"
ACTION_SCOPE_ENV = "PRISMABUILD_ACTION_SCOPE"
#: Sealed helper root for reader-lease imports, set by the resource_exec
#: proxy from its own sealed script path (never the broker token, never a
#: user value): consumers add ``<root>/src`` to ``sys.path`` and import
#: ``prismabuild.reader_lease`` from sealed bytes.  Protected exactly like
#: the action key below.
READER_HELPER_ROOT_ENV = "PRISMABUILD_READER_HELPER_ROOT"
ACTION_RESIDENCY_ENV = (ACTION_KEY_ENV, RESIDENCY_MAP_ENV,
                        ACTION_NONCE_ENV, ACTION_SCOPE_ENV,
                        READER_HELPER_ROOT_ENV)

#: The sealed request key that declares the progress contract, and the two
#: schema names that version it.  ``PROGRESS_PARAM`` is sealed into the action
#: key like ``PROFILE_PARAM``: an action admitted under the progress contract
#: is a different action from its unbounded twin, so nothing already in the
#: store is answered by a receipt filed under the other policy.
PROGRESS_PARAM = "progress"
PROGRESS_POLICY_SCHEMA_V1 = "prismabuild.action_progress_policy.v1"
#: Mirrored from :mod:`prismabuild.progress`; see the note above.
PROGRESS_RECORD_SCHEMA_V1 = "prismabuild.action_progress.v1"
# A report is metadata, never a checkpoint payload. Bound both accepted bytes
# and parser work; use the existing stable regular-file reader in the watcher.
MAX_ACTION_PROGRESS_BYTES = 64 * 1024

#: The placement tag a worker offers when it can enforce the progress contract,
#: and which the submitter requires of any action that declares one.
#:
#: The announcement in a worker's offer says who *understands* the contract; it
#: is a diagnostic, and a diagnostic cannot stop a claim.  During a rolling
#: upgrade the boxes on the previous generation are still polling, and a
#: progress-admitted action they claim runs under their whole-run ceiling --
#: killed by the very default the contract removes.  Requiring a tag they do
#: not offer is what makes that unreachable, and it needs no matcher of its
#: own: item tags must already be a subset of the worker's.
#:
#: Versioned with the record schema on purpose.  A future record format is a
#: new tag, so an old worker cannot claim work whose reports it would reject as
#: foreign and then kill for the silence.
PROGRESS_TAG = "progress-v1"
#: The action-side helper and phase-list environment added by #488.  It is a
#: separate capability from :data:`PROGRESS_TAG`: an older v1 watcher accepts
#: the record but cannot launch code that reads these names.
PROGRESS_HELPER_TAG = "progress-helper-v1"
# Optional cyclic phase semantics; older v1 policy readers reject the field.
PROGRESS_CYCLE_TAG = "progress-cycle-v1"
#: The placement tag a worker offers when it can check an action's declared
#: container images against its own local Docker before claiming.
#:
#: Same shape and same reason as :data:`PROGRESS_TAG`: the claim check is code
#: a worker either has or does not, and a loop from before the check would
#: claim image-pinned work, consume the attempt and die inside the action --
#: #714.  Item tags must already be a subset of the worker's, so requiring a
#: tag the old loops do not offer is what makes that unreachable.  A worker
#: without Docker still offers the tag: it performs the check, finds the
#: presence unknown, and refuses, leaving the item ready for a box that can
#: see it -- which is the fail-closed behavior this tag exists to reach, not
#: a reason to hide the capability.
CONTAINER_IMAGE_TAG = "container-image-v1"
PBRUN_STAMP_PREFIX = ".pbrun-closure."
PBRUN_RESULT_PREFIX = "pbrun_result."
PBRUN_GENERATED_FINGERPRINT_HEX_LENGTH = 16
PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V1 = (
    "prismaquant.prismabuild.pbrun_checkout_snapshot.v1"
)
PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2 = (
    "prismaquant.prismabuild.pbrun_checkout_snapshot.v2"
)
PBRUN_CHECKOUT_SNAPSHOT_INPUT_ID = "pbrun.checkout-snapshot"
PBRUN_CHECKOUT_SNAPSHOT_REF_NAME = "prismabuild-snapshot"
#: A second content-addressed input: the exact bytes an action will read off
#: the shared mount, so a storage-role loop can make them resident before the
#: action is claimed.  It is an ordinary ``action.inputs`` row, which means the
#: action key covers it -- attaching a manifest to an otherwise identical
#: submission produces a different action.
PBCAMPAIGN_DATA_MANIFEST_INPUT_ID = "pbcampaign.data-manifest"
#: A tiny validated immutable produced-output template, captured as an
#: ordinary CAS declared input so the action key covers it. Changing the
#: template changes the key; modifying the source file after seal changes
#: nothing the worker reads.
PRODUCED_OUTPUT_TEMPLATE_INPUT_ID = "prismabuild.produced-output-template"
PRODUCED_OUTPUT_TEMPLATE_PARAM = "produced_output_template"
PRODUCED_OUTPUT_DECLARATION_SCHEMA_V1 = (
    "prismabuild.produced_output_declaration.v1"
)
#: Templates are envelopes, not payloads: a bound that keeps the declaration
#: tiny, validated and immutable. Larger files are a submitter error, not a
#: working window.
PRODUCED_OUTPUT_TEMPLATE_MAX_BYTES = 64 * 1024
DATA_MANIFEST_SCHEMA_V1 = "prismaquant.prismabuild.data_manifest.v1"
DATA_MANIFEST_SCHEMA_V2 = "prismaquant.prismabuild.data_manifest.v2"
#: Stored bytes retain the original ceiling. Gzip permits larger read lists
#: without an unbounded decompression; parsed JSON objects cost extra memory.
DATA_MANIFEST_MAX_BYTES = 64 * 1024 * 1024
DATA_MANIFEST_MAX_DECODED_BYTES = 512 * 1024 * 1024
DATA_MANIFEST_MAX_ENTRIES = 1_000_000
DATA_MANIFEST_MAX_READS = 4_000_000
LOCAL_RESULT_CLAIM_SCHEMA_V1 = "prismaquant.prismabuild.local_result_claim.v1"
INITIAL_MISS_RENDEZVOUS_MANIFEST_SCHEMA_V1 = (
    "prismaquant.prismabuild.initial_miss_rendezvous_manifest.v1"
)
INITIAL_MISS_RENDEZVOUS_PROCESS_SCHEMA_V1 = (
    "prismaquant.prismabuild.initial_miss_rendezvous_process.v1"
)
INITIAL_MISS_RENDEZVOUS_ARRIVAL_SCHEMA_V1 = (
    "prismaquant.prismabuild.initial_miss_rendezvous_arrival.v1"
)
INITIAL_MISS_RENDEZVOUS_READY_SCHEMA_V1 = (
    "prismaquant.prismabuild.initial_miss_rendezvous_ready.v1"
)
INITIAL_MISS_RENDEZVOUS_RECEIPT_SCHEMA_V1 = (
    "prismaquant.prismabuild.initial_miss_rendezvous_receipt.v1"
)
_CAS_RECEIPT_NAMESPACE = CAS_RECEIPT_SCHEMA_V3.rsplit(".", 1)[-1]

_ACTION_BODY_KEYS = frozenset(
    {
        "schema",
        "task",
        "inputs",
        "code_closure",
        "params",
        "environment",
        "execution_scope",
    }
)
_ACTION_KEYS = _ACTION_BODY_KEYS | {"action_key"}
_TASK_KEYS = frozenset(
    {
        "definition_id",
        "definition_version",
        "task_class",
        "determinism",
        "artifact_family",
        "artifact_kind",
        "argv",
        "working_directory",
        "result_path",
    }
)
_INPUT_KEYS = frozenset({"id", "sha256", "bytes"})
_CLOSURE_KEYS = frozenset({"schema", "files", "closure_sha256"})
_CLOSURE_FILE_KEYS = frozenset({"path", "sha256", "bytes"})
_ENVIRONMENT_KEYS = frozenset({"variables", "toolchain"})
_SCOPE_KEYS = frozenset({"portability", "platform_key", "host_class"})
_RECEIPT_BODY_KEYS = frozenset(
    {"schema", "action_key", "action_manifest_sha256", "result", "producer"}
)
_RECEIPT_KEYS = _RECEIPT_BODY_KEYS | {"receipt_sha256"}
_RESULT_KEYS = frozenset({"sha256", "bytes"})
_PRODUCER_KEYS = frozenset(
    {
        "schema",
        "action_key",
        "worker_id",
        "platform_key",
        "host_class",
        "evidence",
        "runtime",
        "executable",
        "toolchain",
        "inputs",
        "attestation_sha256",
    }
)
_EVIDENCE_KEYS = frozenset(
    {"source", "hostname", "system", "machine", "libc", "accelerators", "slurm"}
)
_ACCELERATOR_KEYS = frozenset(
    {"kind", "compute_capability", "driver_version"}
)
_SLURM_EVIDENCE_KEYS = frozenset(
    {"job_id", "node_name", "partition", "constraints", "cgroup"}
)
#: What the controller said about the job and its node, recorded only for a
#: ``host_class_keyed`` action.  Optional in the persisted shape so that every
#: receipt written before the controller was consulted keeps validating.
_SLURM_CONTROLLER_EVIDENCE_KEYS = frozenset(
    {"partition", "batch_host", "job_features", "node_active_features"}
)
#: How long to wait between attempts to reach the controller, in seconds.  The
#: sum bounds how long a job whose controller is down spends before it refuses.
SCONTROL_RETRY_DELAYS_S: tuple[float, ...] = (1.0, 2.0, 4.0, 8.0, 15.0)
_SCONTROL_CANDIDATES = ("/usr/bin/scontrol", "/usr/local/bin/scontrol")
_EXECUTABLE_KEYS = frozenset({"path", "resolved_path", "sha256", "bytes"})
_RUNTIME_KEYS = frozenset(
    {"schema", "launch_kind", "core", "launcher", "runtime_sha256"}
)
_TOOLCHAIN_ATTESTATION_KEYS = frozenset({"declared", "verified"})
_LOCAL_RESULT_CLAIM_BODY_KEYS = frozenset(
    {
        "schema",
        "action_key",
        "action_manifest_sha256",
        "checkout_root",
        "working_directory",
        "result_path",
    }
)
_LOCAL_RESULT_CLAIM_KEYS = _LOCAL_RESULT_CLAIM_BODY_KEYS | {"claim_sha256"}
# Public, immutable schema surfaces for read-only receipt/claim reporters.
# These are the producer's key sets, not independent copies of the formats.
CAS_RECEIPT_BODY_KEYS = _RECEIPT_BODY_KEYS
CAS_RECEIPT_KEYS = _RECEIPT_KEYS
LOCAL_RESULT_CLAIM_BODY_KEYS = _LOCAL_RESULT_CLAIM_BODY_KEYS
_INITIAL_MISS_RENDEZVOUS_MANIFEST_BODY_KEYS = frozenset(
    {
        "schema",
        "rendezvous_namespace",
        "cas_root",
        "run_nonce",
        "action_key",
        "participants",
        "timeout_seconds",
    }
)
_INITIAL_MISS_RENDEZVOUS_MANIFEST_KEYS = (
    _INITIAL_MISS_RENDEZVOUS_MANIFEST_BODY_KEYS | {"manifest_sha256"}
)
_INITIAL_MISS_RENDEZVOUS_PROCESS_BODY_KEYS = frozenset(
    {
        "schema",
        "hostname",
        "pid",
        "proc_start_ticks",
        "invocation_nonce",
        "runtime",
    }
)
_INITIAL_MISS_RENDEZVOUS_PROCESS_KEYS = (
    _INITIAL_MISS_RENDEZVOUS_PROCESS_BODY_KEYS | {"process_identity_sha256"}
)
_INITIAL_MISS_RENDEZVOUS_ARRIVAL_BODY_KEYS = frozenset(
    {
        "schema",
        "manifest_sha256",
        "run_nonce",
        "action_key",
        "participant",
        "process",
        "observation",
    }
)
_INITIAL_MISS_RENDEZVOUS_ARRIVAL_KEYS = (
    _INITIAL_MISS_RENDEZVOUS_ARRIVAL_BODY_KEYS | {"arrival_sha256"}
)
_INITIAL_MISS_RENDEZVOUS_READY_BODY_KEYS = frozenset(
    {
        "schema",
        "manifest_sha256",
        "run_nonce",
        "action_key",
        "participant",
        "process_identity_sha256",
        "arrival_sha256",
        "arrival_set_sha256",
        "observation",
    }
)
_INITIAL_MISS_RENDEZVOUS_READY_KEYS = (
    _INITIAL_MISS_RENDEZVOUS_READY_BODY_KEYS | {"ready_sha256"}
)
_INITIAL_MISS_RENDEZVOUS_RECEIPT_BODY_KEYS = frozenset(
    {
        "schema",
        "manifest_sha256",
        "rendezvous_namespace",
        "cas_root",
        "run_nonce",
        "action_key",
        "participants",
        "participant",
        "process_identity_sha256",
        "arrival_sha256",
        "ready_sha256",
        "arrival_set_sha256",
        "ready_set_sha256",
    }
)
_INITIAL_MISS_RENDEZVOUS_RECEIPT_KEYS = (
    _INITIAL_MISS_RENDEZVOUS_RECEIPT_BODY_KEYS | {"receipt_sha256"}
)

_ID_RE = re.compile(r"[a-z0-9][a-z0-9._/-]{0,255}\Z")
_DATA_MANIFEST_KEYS = frozenset(
    {"schema", "produced_by", "mount_prefix", "entries", "entry_count",
     "total_bytes", "annotations"}
)
_DATA_MANIFEST_V2_KEYS = _DATA_MANIFEST_KEYS | {"read_plan"}
_DATA_MANIFEST_READ_PLAN_KEYS = frozenset({"phases", "read_bytes"})
_DATA_MANIFEST_READ_PHASE_KEYS = frozenset(
    {"name", "entry_indices", "bytes", "cumulative_bytes"}
)
_DATA_MANIFEST_ENTRY_KEYS = frozenset({"path", "offset", "bytes", "sha256"})
_GIT_OBJECT_ID_RE = re.compile(r"(?:[0-9a-f]{40}|[0-9a-f]{64})\Z")
#: A snapshot ref name is an allow-list, not Git's full branch grammar: it is
#: spelled into a worker's ``git fetch`` refspec, so everything the revision
#: grammar and the option parser can reach stays out of the character class.
_SNAPSHOT_REF_NAME_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._/-]{0,127}\Z")
_VERSION_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+:-]{0,127}\Z")
_SCOPE_TOKEN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9._+:/-]{0,255}\Z")
_ENV_RE = re.compile(r"[A-Za-z_][A-Za-z0-9_]*\Z")
_SHA256_RE = re.compile(r"[0-9a-f]{64}\Z")
_RUN_NONCE_RE = re.compile(r"[0-9a-f]{32}\Z")
_INVOCATION_NONCE_RE = re.compile(r"[0-9a-f]{32}\Z")
_HOSTNAME_RE = re.compile(
    r"[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?\Z"
)

_PORTABILITY = frozenset({"portable", "platform_keyed", "host_class_keyed"})
_TASK_CLASSES = frozenset({"generation", "measurement"})
_DETERMINISM = frozenset({"deterministic", "stochastic"})
_ARTIFACT_FAMILIES = frozenset({"generic", "codebook"})
_PROCESS_GROUP_GRACE_SECONDS = 5.0

#: How often the bounded group-exit wait re-probes group membership.
_PROCESS_GROUP_POLL_SECONDS = 0.01
_MAX_LOCAL_RESULT_STAGING_FILES = 64
_MAX_INITIAL_MISS_RENDEZVOUS_BYTES = 64 * 1024
_MAX_INITIAL_MISS_RENDEZVOUS_DIRECTORY_ENTRIES = 8
_MAX_INITIAL_MISS_RENDEZVOUS_TIMEOUT_SECONDS = 24 * 60 * 60
_INITIAL_MISS_RENDEZVOUS_POLL_SECONDS = 0.01
# NFS may return one internally inconsistent ctime/nlink snapshot while a
# first-writer hard link becomes visible.  Never accept that read: reopen the
# no-follow path and replay the entire read from byte zero, at most this many
# times, until one attempt is internally stable.
_STABLE_FILE_READ_ATTEMPTS = 3
_ATTESTABLE_TOOLCHAIN_KEYS = frozenset(
    {
        "argv0.sha256",
        "argv0.bytes",
        "python",
        "torch",
        "transformers",
        "vllm",
        "gridbook",
        "system",
        "machine",
        "libc",
        "cuda_compute_capability",
        "nvidia_driver",
        "accelerator_models.sha256",
    }
)
_PYTHON_DISTRIBUTIONS = frozenset({"torch", "transformers", "vllm", "gridbook"})


class PrismaBuildError(RuntimeError):
    """Base class for PrismaBuild core failures."""


class ActionContractError(PrismaBuildError, ValueError):
    """An action, closure, receipt, or worker identity is not exact."""


class CASTamperError(PrismaBuildError):
    """An existing content-addressed entry failed verification."""


class CASUnavailableError(PrismaBuildError):
    """The content-addressed store could not be read reliably."""


class CASConflictError(PrismaBuildError):
    """A deterministic recomputation disagreed with the canonical result."""


class LocalActionError(PrismaBuildError):
    """A local action could not execute or did not produce its declared file.

    ``returncode`` and ``signal`` carry the action's own ending when the action
    ran and ended by itself.  Everything else this error reports -- a missing
    result file, a changed closure, a timeout -- is the worker's verdict rather
    than the action's, and leaves both attributes ``None``.

    The message text is unchanged by either attribute.  A reader that scraped
    "exited with status 7" out of a stderr tail keeps working, and a reader that
    wants the number as a number no longer has to scrape anything.
    ``returncode`` follows ``subprocess``: a signalled action carries the
    negative signal number, and ``signal`` carries the positive one.

    ``profile`` is the profile of a run that failed, when there is one.  A
    timed-out action is the case somebody most wants a profile of, so the
    record travels on the error rather than only on a successful ending.
    """

    def __init__(
        self,
        *args: object,
        returncode: int | None = None,
        signal: int | None = None,
        profile: Mapping[str, object] | None = None,
    ) -> None:
        super().__init__(*args)
        self.returncode = returncode
        self.signal = signal
        self.profile = profile


class InitialMissRendezvousError(LocalActionError):
    """An opt-in initial-cache-miss rendezvous failed closed."""


class _FileLinkCountError(CASTamperError):
    """A stable file did not have the required single canonical link."""


def _fail(message: str) -> None:
    raise ActionContractError(message)


def _exact_mapping(
    value: object, *, keys: frozenset[str], where: str
) -> Mapping[str, object]:
    if not isinstance(value, Mapping):
        _fail(f"{where} must be an object")
    if any(type(key) is not str for key in value):
        _fail(f"{where} keys must be strings")
    actual = set(value)
    if actual != set(keys):
        _fail(
            f"{where} fields differ: missing={sorted(set(keys) - actual)}, "
            f"extra={sorted(actual - set(keys))}"
        )
    return value


def _text(
    value: object,
    *,
    where: str,
    pattern: re.Pattern[str] | None = None,
    allow_empty: bool = False,
    allow_control: bool = False,
) -> str:
    """Validate one text field.

    Identifiers, keys, digests, paths and tokens refuse every control
    character: nothing that names a thing may carry bytes a log line or a
    filename cannot show.  Payload text -- an argv element, an environment
    value, a params string value -- is what ``execve`` and JSON carry
    verbatim, and its only illegal byte is NUL.  A ``bash -lc`` script with a
    newline in it is an ordinary argument, not a contract violation (issue
    #21), so payload callers pass ``allow_control=True``.
    """

    if type(value) is not str or (not value and not allow_empty):
        _fail(f"{where} must be a {'string' if allow_empty else 'non-empty string'}")
    if "\x00" in value:
        _fail(f"{where} contains a NUL character")
    if not allow_control and any(ord(char) < 32 for char in value):
        _fail(f"{where} contains a NUL or control character")
    if pattern is not None and pattern.fullmatch(value) is None:
        _fail(f"{where} has an invalid value")
    return value


def _optional_token(value: object, *, where: str) -> str | None:
    if value is None:
        return None
    return _text(value, where=where, pattern=_SCOPE_TOKEN_RE)


def _nonnegative_integer(value: object, *, where: str) -> int:
    if type(value) is not int or value < 0:
        _fail(f"{where} must be a non-negative integer")
    return value


def _sha256(value: object, *, where: str) -> str:
    return _text(value, where=where, pattern=_SHA256_RE)


def _canonical_bytes(value: object) -> bytes:
    try:
        return json.dumps(
            value,
            sort_keys=True,
            separators=(",", ":"),
            ensure_ascii=False,
            allow_nan=False,
        ).encode("utf-8")
    except (TypeError, ValueError) as exc:
        raise ActionContractError("value is not finite canonical JSON data") from exc


def _canonical_file_bytes(value: object) -> bytes:
    return _canonical_bytes(value) + b"\n"


def canonical_sha256(value: object) -> str:
    """Hash canonical JSON without importing another repository module."""

    return hashlib.sha256(_canonical_bytes(value)).hexdigest()


def _normalize_relative_path(value: object, *, where: str, dot_ok: bool) -> str:
    raw = _text(value, where=where)
    if "\\" in raw or re.match(r"^[A-Za-z]:", raw):
        _fail(f"{where} must be a normalized relative POSIX path")
    path = PurePosixPath(raw)
    if path.is_absolute() or any(part in {"", ".."} for part in raw.split("/")):
        _fail(f"{where} must be a normalized relative POSIX path")
    if raw == ".":
        if dot_ok:
            return raw
        _fail(f"{where} must name a file, not '.'")
    if any(part == "." for part in raw.split("/")) or str(path) != raw:
        _fail(f"{where} must be a normalized relative POSIX path")
    return raw


def _normalize_json_value(value: object, *, where: str) -> object:
    """Validate JSON recursively without Python's silent key coercions."""

    if value is None or type(value) is bool:
        return value
    if type(value) is int:
        return value
    if type(value) is float:
        if not math.isfinite(value):
            _fail(f"{where} contains a non-finite number")
        return value
    if type(value) is str:
        return _text(value, where=where, allow_empty=True, allow_control=True)
    if type(value) is list:
        return [
            _normalize_json_value(item, where=f"{where}[{index}]")
            for index, item in enumerate(value)
        ]
    if isinstance(value, Mapping):
        normalized: dict[str, object] = {}
        for raw_key, raw_value in value.items():
            key = _text(raw_key, where=f"{where} key", allow_empty=True)
            normalized[key] = _normalize_json_value(
                raw_value, where=f"{where}.{key}"
            )
        return normalized
    _fail(f"{where} contains a value that is not JSON data")


def _normalize_argv(value: object) -> list[str]:
    if type(value) is not list or not value:
        _fail("action.task.argv must be a non-empty array")
    argv = [
        _text(
            item,
            where=f"action.task.argv[{index}]",
            allow_empty=True,
            allow_control=True,
        )
        for index, item in enumerate(value)
    ]
    if not PurePosixPath(argv[0]).is_absolute():
        _fail("action.task.argv[0] must be an absolute executable path")
    return argv


def _normalize_string_mapping(
    value: object,
    *,
    where: str,
    key_pattern: re.Pattern[str] | None = None,
) -> dict[str, str]:
    if not isinstance(value, Mapping):
        _fail(f"{where} must be an object")
    normalized: dict[str, str] = {}
    for raw_key, raw_value in value.items():
        key = _text(raw_key, where=f"{where} key", pattern=key_pattern)
        normalized[key] = _text(
            raw_value, where=f"{where}.{key}", allow_empty=True, allow_control=True
        )
    return dict(sorted(normalized.items()))


def _decode_strict_json(raw: bytes, *, where: str) -> object:
    def pairs_hook(pairs: list[tuple[str, object]]) -> dict[str, object]:
        result: dict[str, object] = {}
        for key, value in pairs:
            if key in result:
                raise ActionContractError(f"{where} contains duplicate key {key!r}")
            result[key] = value
        return result

    def reject_constant(value: str) -> object:
        raise ActionContractError(f"{where} contains non-finite number {value}")

    try:
        return json.loads(
            raw.decode("utf-8"),
            object_pairs_hook=pairs_hook,
            parse_constant=reject_constant,
        )
    except ActionContractError:
        raise
    except (UnicodeDecodeError, ValueError) as exc:
        # ``json.loads`` can raise a plain ValueError when an integer exceeds
        # Python's configured digit limit.  Durable hostile input must stay in
        # the fail-closed PrismaBuild error vocabulary instead of escaping as
        # an implementation-specific parser exception.
        raise ActionContractError(f"{where} is not strict UTF-8 JSON") from exc


#: ``O_NONBLOCK`` on a regular-file open exists to keep a FIFO or a device from
#: blocking before ``fstat`` can refuse it; POSIX gives it no meaning for a
#: regular file. On NFSv4 it acquires one anyway -- the client may answer
#: EAGAIN while a delegation is recalled -- so an open that is correct, and
#: would succeed a millisecond later, fails instead. The fleet's checkouts all
#: live on one NFS export and a dozen workers open the same closure stamp, which
#: is exactly the shape that provokes it: five actions in the live queue died
#: this way, each burning an attempt against its retry limit for a reason that
#: had nothing to do with the work.
_WOULD_BLOCK_OPEN_ATTEMPTS = 6
_WOULD_BLOCK_OPEN_BACKOFF_S = 0.02


def _open_retrying_would_block(
    path: Path | str | bytes,
    flags: int,
    *,
    dir_fd: int | None = None,
) -> int:
    """``os.open``, with "would block" treated as transient, not terminal.

    Every other error is re-raised untouched, so each caller keeps its own
    mapping from errno to the contract violation it means; only EAGAIN is
    retried, and only for as long as the backoff allows. A path that keeps
    saying "would block" still fails -- a blocking open would be the wrong
    answer for a FIFO, which is what the flag is protecting against.
    """

    delay = _WOULD_BLOCK_OPEN_BACKOFF_S
    last = _WOULD_BLOCK_OPEN_ATTEMPTS - 1
    for attempt in range(_WOULD_BLOCK_OPEN_ATTEMPTS):
        try:
            if dir_fd is None:
                return os.open(path, flags)
            return os.open(path, flags, dir_fd=dir_fd)
        except OSError as exc:
            transient = exc.errno in {errno.EAGAIN, errno.EWOULDBLOCK}
            if not transient or attempt == last:
                raise
            time.sleep(delay)
            delay *= 2
    raise AssertionError("unreachable")


def _read_regular_file(path: Path, *, where: str) -> bytes:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = _open_retrying_would_block(path, flags)
    except OSError as exc:
        raise ActionContractError(f"cannot open {where} as a regular file: {path}") from exc
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ActionContractError(f"{where} is not a regular file: {path}")
        chunks: list[bytes] = []
        while True:
            chunk = os.read(descriptor, 1024 * 1024)
            if not chunk:
                break
            chunks.append(chunk)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mode,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mode,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ):
            raise ActionContractError(f"{where} changed while it was read: {path}")
        return b"".join(chunks)
    finally:
        os.close(descriptor)


def _file_identity(path: Path, *, where: str) -> tuple[str, int]:
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        descriptor = _open_retrying_would_block(path, flags)
    except OSError as exc:
        raise ActionContractError(
            f"cannot open {where} as a regular file: {path}"
        ) from exc
    digest = hashlib.sha256()
    size = 0
    try:
        before = os.fstat(descriptor)
        if not stat.S_ISREG(before.st_mode):
            raise ActionContractError(f"{where} is not a regular file: {path}")
        while True:
            chunk = os.read(descriptor, 4 * 1024 * 1024)
            if not chunk:
                break
            digest.update(chunk)
            size += len(chunk)
        after = os.fstat(descriptor)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mode,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mode,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ):
            raise ActionContractError(f"{where} changed while it was read: {path}")
        return digest.hexdigest(), size
    finally:
        os.close(descriptor)


def identify_executable(path: str | Path) -> dict[str, object]:
    """Return the exact regular-file identity behind an absolute argv[0]."""

    declared = Path(path)
    if not declared.is_absolute():
        _fail("executable path must be absolute")
    try:
        resolved = declared.resolve(strict=True)
    except OSError as exc:
        raise ActionContractError(
            f"cannot resolve executable path: {declared}"
        ) from exc
    digest, size = _file_identity(resolved, where="action executable")
    try:
        mode = resolved.stat().st_mode
    except OSError as exc:
        raise ActionContractError(
            f"cannot inspect executable path: {resolved}"
        ) from exc
    if mode & 0o111 == 0:
        _fail(f"action executable is not executable: {resolved}")
    return {
        "path": str(declared),
        "resolved_path": str(resolved),
        "sha256": digest,
        "bytes": size,
    }


def _identify_runtime_source(path: str | Path, *, where: str) -> dict[str, object]:
    """Return the exact regular-file identity of worker implementation source."""

    declared = Path(path)
    if not declared.is_absolute():
        _fail(f"{where} path must be absolute")
    try:
        resolved = declared.resolve(strict=True)
    except OSError as exc:
        raise ActionContractError(f"cannot resolve {where}: {declared}") from exc
    digest, size = _file_identity(resolved, where=where)
    return {
        "path": str(declared),
        "resolved_path": str(resolved),
        "sha256": digest,
        "bytes": size,
    }


# This snapshot is part of module initialization, not worker preflight.  It
# therefore precedes action loading and execution and represents the source
# implementation this worker process loaded as closely as Python exposes it.
_LOADED_WORKER_CORE_IDENTITY = _identify_runtime_source(
    Path(__file__).resolve(), where="PrismaBuild worker core"
)


def _normalize_runtime_source(value: object, *, where: str) -> dict[str, object]:
    raw = _exact_mapping(value, keys=_EXECUTABLE_KEYS, where=where)
    path = _text(raw["path"], where=f"{where}.path")
    resolved_path = _text(
        raw["resolved_path"], where=f"{where}.resolved_path"
    )
    if not Path(path).is_absolute() or not Path(resolved_path).is_absolute():
        _fail(f"{where} paths must be absolute")
    return {
        "path": path,
        "resolved_path": resolved_path,
        "sha256": _sha256(raw["sha256"], where=f"{where}.sha256"),
        "bytes": _nonnegative_integer(raw["bytes"], where=f"{where}.bytes"),
    }


def _verify_runtime_source_unchanged(
    expected: Mapping[str, object], *, where: str, changed_message: str
) -> None:
    try:
        observed = _identify_runtime_source(str(expected["path"]), where=where)
    except ActionContractError as exc:
        raise LocalActionError(f"{changed_message}: {exc}") from exc
    if observed != expected:
        raise LocalActionError(changed_message)


def _worker_runtime_identity(
    worker_launcher_identity: object | None,
) -> dict[str, object]:
    """Bind the load-time core and optional entry-point launcher snapshot."""

    core = _normalize_runtime_source(
        _LOADED_WORKER_CORE_IDENTITY,
        where="loaded PrismaBuild worker core",
    )
    _verify_runtime_source_unchanged(
        core,
        where="PrismaBuild worker core",
        changed_message="PrismaBuild worker core changed after module import",
    )
    launcher = (
        None
        if worker_launcher_identity is None
        else _normalize_runtime_source(
            worker_launcher_identity,
            where="captured PrismaBuild worker launcher",
        )
    )
    if launcher is not None:
        _verify_runtime_source_unchanged(
            launcher,
            where="PrismaBuild worker launcher",
            changed_message=(
                "PrismaBuild worker launcher changed after entry-point capture"
            ),
        )
    body: dict[str, object] = {
        "schema": WORKER_RUNTIME_SCHEMA_V1,
        "launch_kind": "in_process" if launcher is None else "script",
        "core": core,
        "launcher": launcher,
    }
    return {**body, "runtime_sha256": canonical_sha256(body)}


def _validate_worker_runtime(value: object) -> dict[str, object]:
    raw = _exact_mapping(
        value, keys=_RUNTIME_KEYS, where="worker attestation.runtime"
    )
    if raw["schema"] != WORKER_RUNTIME_SCHEMA_V1:
        _fail(
            "worker attestation.runtime.schema must be "
            f"{WORKER_RUNTIME_SCHEMA_V1!r}"
        )
    launch_kind = _text(
        raw["launch_kind"], where="worker attestation.runtime.launch_kind"
    )
    if launch_kind not in {"in_process", "script"}:
        _fail("worker attestation.runtime.launch_kind is unsupported")
    core = _normalize_runtime_source(
        raw["core"], where="worker attestation.runtime.core"
    )
    launcher_raw = raw["launcher"]
    launcher = (
        None
        if launcher_raw is None
        else _normalize_runtime_source(
            launcher_raw, where="worker attestation.runtime.launcher"
        )
    )
    if (launch_kind == "in_process") != (launcher is None):
        _fail("worker attestation runtime launch_kind and launcher disagree")
    body: dict[str, object] = {
        "schema": WORKER_RUNTIME_SCHEMA_V1,
        "launch_kind": launch_kind,
        "core": core,
        "launcher": launcher,
    }
    recorded = _sha256(
        raw["runtime_sha256"],
        where="worker attestation.runtime.runtime_sha256",
    )
    if recorded != canonical_sha256(body):
        _fail("worker attestation runtime digest does not match its body")
    return {**body, "runtime_sha256": recorded}


def _verify_worker_runtime_unchanged(runtime: object) -> None:
    expected = _validate_worker_runtime(runtime)
    core = expected["core"]
    assert isinstance(core, Mapping)
    loaded_core = _normalize_runtime_source(
        _LOADED_WORKER_CORE_IDENTITY,
        where="loaded PrismaBuild worker core",
    )
    if core != loaded_core:
        raise LocalActionError(
            "attested PrismaBuild worker core differs from module import identity"
        )
    _verify_runtime_source_unchanged(
        core,
        where="PrismaBuild worker core",
        changed_message="PrismaBuild worker core changed after module import",
    )
    launcher = expected["launcher"]
    if isinstance(launcher, Mapping):
        _verify_runtime_source_unchanged(
            launcher,
            where="PrismaBuild worker launcher",
            changed_message=(
                "PrismaBuild worker launcher changed after entry-point capture"
            ),
        )


def executable_toolchain_contract(path: str | Path) -> dict[str, str]:
    """Build the action-key fields that bind argv[0] to exact file bytes."""

    identity = identify_executable(path)
    return {
        "argv0.sha256": str(identity["sha256"]),
        "argv0.bytes": str(identity["bytes"]),
    }


def _probe_nvidia_accelerators(*, include_identity: bool = False) -> list[dict[str, str]]:
    """Read live NVIDIA compute/driver facts without importing the task stack."""

    executable = Path("/usr/bin/nvidia-smi")
    if not executable.is_file():
        return []
    argv = [
        str(executable),
        "--query-gpu=compute_cap,driver_version" + (",name,uuid" if include_identity else ""),
        "--format=csv,noheader,nounits",
    ]
    try:
        completed = subprocess.run(
            argv,
            shell=False,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="strict",
            env={"LANG": "C", "LC_ALL": "C"},
            timeout=10.0,
        )
    except (OSError, UnicodeError, subprocess.TimeoutExpired) as exc:
        if include_identity:
            raise ActionContractError("cannot attest NVIDIA device identity") from exc
        return []
    if completed.returncode != 0:
        if include_identity:
            raise ActionContractError("cannot attest NVIDIA device identity: nvidia-smi failed")
        return []
    facts: set[tuple[str, ...]] = set()
    for raw_line in completed.stdout.splitlines():
        fields = [field.strip() for field in raw_line.split(",")]
        if len(fields) != (4 if include_identity else 2):
            raise ActionContractError("nvidia-smi returned malformed accelerator facts")
        capability, driver = fields[:2]
        if re.fullmatch(r"[0-9]+\.[0-9]+", capability) is None:
            raise ActionContractError("nvidia-smi returned an invalid compute capability")
        if _VERSION_RE.fullmatch(driver) is None:
            raise ActionContractError("nvidia-smi returned an invalid driver version")
        if include_identity:
            name, uuid = fields[2:]
            if not name or name in {"N/A", "[N/A]"} or not uuid.startswith("GPU-"):
                raise ActionContractError("nvidia-smi returned invalid device identity")
        facts.add(tuple(fields))
    if include_identity and not facts:
        raise ActionContractError("nvidia-smi returned no device identity")
    return [
        {
            "kind": "nvidia",
            "compute_capability": row[0],
            "driver_version": row[1],
            **({"name": row[2], "uuid": row[3]} if include_identity else {}),
        }
        for row in sorted(facts)
    ]


def _constraint_tokens(value: str) -> list[str]:
    return sorted(
        {
            token
            for token in re.split(r"[^A-Za-z0-9._+:/-]+", value)
            if token
        }
    )


_CGROUP_JOB_RE = re.compile(r"(?:^|/)job_([1-9][0-9]*)(?:[./]|$)")


def _slurm_job_from_cgroup() -> tuple[str, str] | None:
    """Read the SLURM job that owns this process from its kernel-owned cgroup.

    Returns ``(job_id, cgroup_path)`` when exactly one ``job_<id>`` cgroup
    holds the process, or ``None`` when no controller row names a job.  The
    job id is derived here, not read from the environment: ``proctrack/cgroup``
    places a job's processes under ``job_<id>``, and a batch script cannot
    move itself out of that hierarchy, whereas it can export any variable.
    """

    raw = _read_regular_file(Path("/proc/self/cgroup"), where="worker cgroup")
    try:
        lines = raw.decode("utf-8").splitlines()
    except UnicodeDecodeError as exc:
        raise ActionContractError("worker cgroup is not UTF-8") from exc
    jobs: set[str] = set()
    paths: set[str] = set()
    for line in lines:
        fields = line.split(":", 2)
        if len(fields) != 3:
            continue
        match = _CGROUP_JOB_RE.search(fields[2])
        if match is not None:
            jobs.add(match.group(1))
            paths.add(fields[2])
    if not jobs:
        return None
    if len(jobs) != 1 or len(paths) != 1:
        raise ActionContractError(
            "worker cgroup membership names more than one SLURM job"
        )
    return next(iter(jobs)), _text(next(iter(paths)), where="worker SLURM cgroup")


def _verify_slurm_process_membership(job_id: str) -> str:
    """Bind a claimed SLURM job id to this process's kernel-owned cgroup."""

    if re.fullmatch(r"[1-9][0-9]*", job_id) is None:
        raise ActionContractError("SLURM_JOB_ID must be a positive numeric job id")
    kernel = _slurm_job_from_cgroup()
    if kernel is None or kernel[0] != job_id:
        raise ActionContractError(
            "SLURM environment is not attested by this process's cgroup membership"
        )
    return kernel[1]


def _run_scontrol(argv: Sequence[str]) -> subprocess.CompletedProcess[str]:
    """Run one ``scontrol`` invocation by absolute path; tests replace this."""

    executable = next(
        (candidate for candidate in _SCONTROL_CANDIDATES if Path(candidate).is_file()),
        None,
    )
    if executable is None:
        raise ActionContractError(
            "scontrol is not installed at any of "
            f"{', '.join(_SCONTROL_CANDIDATES)}; the controller cannot be asked"
        )
    return subprocess.run(
        [executable, *argv],
        capture_output=True,
        text=True,
        encoding="utf-8",
        errors="replace",
        env={"LANG": "C", "LC_ALL": "C", **{
            key: value for key, value in os.environ.items()
            if key in {"SLURM_CONF", "SLURM_CLUSTER_NAME", "HOME"}
        }},
        timeout=30.0,
    )


def _controller_name(environment: Mapping[str, str]) -> str:
    """Name the controller for a refusal, without asking the controller."""

    cluster = environment.get("SLURM_CLUSTER_NAME") or ""
    conf = Path(environment.get("SLURM_CONF") or "/etc/slurm/slurm.conf")
    host = ""
    try:
        for line in conf.read_text(encoding="utf-8", errors="replace").splitlines():
            stripped = line.strip()
            if stripped.startswith("SlurmctldHost="):
                host = stripped.split("=", 1)[1].strip()
                break
    except OSError:
        pass
    parts = [part for part in (
        f"cluster {cluster!r}" if cluster else "",
        f"SlurmctldHost={host}" if host else "",
    ) if part]
    return "the SLURM controller" + (f" ({', '.join(parts)})" if parts else "")


def _scontrol_show(
    kind: str, name: str, *, environment: Mapping[str, str]
) -> dict[str, str]:
    """Ask the controller for one job or node record, as ``key=value`` fields.

    Retries on the schedule in ``SCONTROL_RETRY_DELAYS_S`` and then refuses.
    An unreachable controller is never read as attested.
    """

    argv = ["--oneliner", "show", kind, name]
    failures: list[str] = []
    for attempt, delay in enumerate((*SCONTROL_RETRY_DELAYS_S, None)):
        try:
            completed = _run_scontrol(argv)
        except (OSError, subprocess.TimeoutExpired) as exc:
            failures.append(f"attempt {attempt + 1}: {exc}")
        else:
            if completed.returncode == 0 and completed.stdout.strip():
                fields: dict[str, str] = {}
                for token in completed.stdout.strip().split():
                    key, sep, value = token.partition("=")
                    if sep and key not in fields:
                        fields[key] = value
                return fields
            detail = (completed.stderr or completed.stdout).strip()
            failures.append(
                f"attempt {attempt + 1}: exit {completed.returncode}: "
                f"{detail or 'no output'}"
            )
        if delay is None:
            break
        time.sleep(delay)
    raise ActionContractError(
        f"{_controller_name(environment)} did not answer `scontrol show "
        f"{kind} {name}` after {len(failures)} attempts; a host_class_keyed "
        f"action is refused rather than assumed placed: {failures[-1]}"
    )


def _feature_conjunction(value: str) -> list[str]:
    """The Feature names a job's constraint requires, or ``[]``.

    Only a plain conjunction (``a&b``) counts.  A disjunction, a bracketed
    set, a count, or a parenthesized group can be satisfied without any one
    named Feature, so such a constraint attests no class and yields ``[]``.
    """

    text = value.strip()
    if not text or text == "(null)":
        return []
    if re.search(r"[|\[\]()*]", text):
        return []
    terms = [term.strip() for term in text.split("&")]
    if any(_SCOPE_TOKEN_RE.fullmatch(term) is None for term in terms):
        return []
    return sorted(set(terms))


def _feature_list(value: str) -> list[str]:
    text = value.strip()
    if not text or text == "(null)":
        return []
    return sorted({
        token for token in (item.strip() for item in text.split(","))
        if token and _SCOPE_TOKEN_RE.fullmatch(token) is not None
    })


def _controller_evidence(
    job_id: str, *, environment: Mapping[str, str]
) -> dict[str, object]:
    """What the controller holds for this job and the node running it."""

    job = _scontrol_show("job", job_id, environment=environment)
    if job.get("JobId") != job_id:
        raise ActionContractError(
            f"the SLURM controller answered for a different job than {job_id}"
        )
    batch_host = job.get("BatchHost", "").strip().lower()
    if not batch_host or batch_host == "(null)":
        raise ActionContractError(
            "the SLURM controller reports no BatchHost for this job"
        )
    node = _scontrol_show("node", batch_host, environment=environment)
    return {
        "partition": _text(
            job.get("Partition", ""), where="scontrol Partition",
            pattern=_SCOPE_TOKEN_RE,
        ),
        "batch_host": _text(batch_host, where="scontrol BatchHost", pattern=_ID_RE),
        "job_features": _feature_conjunction(job.get("Features", "")),
        "node_active_features": _feature_list(node.get("ActiveFeatures", "")),
    }


def _collect_worker_evidence(
    environment: Mapping[str, str] | None = None,
    *,
    attest_host_class: str | None = None,
    attest_accelerator_identity: bool = False,
) -> dict[str, object]:
    """Collect facts from the live worker and its SLURM job, if any.

    The job id comes from this process's cgroup; ``SLURM_JOB_ID``,
    ``SLURMD_NODENAME`` and ``SLURM_JOB_PARTITION`` are recorded and checked
    for consistency but decide nothing.  When ``attest_host_class`` names a
    class, the controller is also asked for the job's constraint and the
    node's active Features, which is the only evidence that can attest it.
    """

    env = os.environ if environment is None else environment
    system = platform.system().lower()
    machine = platform.machine().lower()
    libc_name, libc_version = platform.libc_ver()
    libc = f"{libc_name.lower()}-{libc_version}" if libc_name else "unknown"
    hostname = socket.gethostname().lower()
    slurm_values = {
        "job_id": env.get("SLURM_JOB_ID"),
        "node_name": env.get("SLURMD_NODENAME"),
        "partition": env.get("SLURM_JOB_PARTITION"),
    }
    present = [value is not None for value in slurm_values.values()]
    if any(present) and not all(present):
        raise ActionContractError(
            "partial SLURM worker evidence is ambiguous; job, node, and partition are required"
        )
    slurm: dict[str, object] | None = None
    source = "local"
    kernel = _slurm_job_from_cgroup() if any(present) else None
    if all(present):
        source = "slurm"
        claimed = _text(
            slurm_values["job_id"], where="SLURM_JOB_ID", pattern=_SCOPE_TOKEN_RE
        )
        if kernel is None or kernel[0] != claimed:
            raise ActionContractError(
                "SLURM environment is not attested by this process's cgroup membership"
            )
        job_id, cgroup = kernel
        node_name = str(slurm_values["node_name"]).lower()
        partition = str(slurm_values["partition"])
        slurm = {
            "job_id": job_id,
            "node_name": _text(
                node_name, where="SLURMD_NODENAME", pattern=_ID_RE
            ),
            "partition": _text(
                partition, where="SLURM_JOB_PARTITION", pattern=_SCOPE_TOKEN_RE
            ),
            # Never set in a job's environment (SLURM sets it only for the
            # Prolog and Epilog), and submitter-writable if it were; kept as
            # recorded provenance, read by no verdict.
            "constraints": _constraint_tokens(env.get("SLURM_JOB_CONSTRAINTS", "")),
            "cgroup": cgroup,
        }
        if attest_host_class is not None:
            controller = _controller_evidence(job_id, environment=env)
            if controller["batch_host"] != slurm["node_name"]:
                raise ActionContractError(
                    "SLURMD_NODENAME disagrees with the BatchHost the SLURM "
                    "controller holds for this job"
                )
            slurm["controller"] = controller
    elif attest_host_class is not None:
        raise ActionContractError(
            "host_class_keyed actions require complete SLURM job evidence"
        )
    return {
        "source": source,
        "hostname": _text(hostname, where="worker hostname", pattern=_ID_RE),
        "system": _text(system, where="worker system", pattern=_SCOPE_TOKEN_RE),
        "machine": _text(machine, where="worker machine", pattern=_SCOPE_TOKEN_RE),
        "libc": _text(libc, where="worker libc", pattern=_SCOPE_TOKEN_RE),
        "accelerators": (_probe_nvidia_accelerators(include_identity=True)
                         if attest_accelerator_identity else _probe_nvidia_accelerators()),
        "slurm": slurm,
    }


def _platform_key_from_evidence(evidence: Mapping[str, object]) -> str:
    system = str(evidence["system"])
    machine = str(evidence["machine"])
    accelerators = evidence["accelerators"]
    assert isinstance(accelerators, list)
    capabilities = {
        str(accelerator["compute_capability"])
        for accelerator in accelerators
        if isinstance(accelerator, Mapping) and accelerator.get("kind") == "nvidia"
    }
    if len(capabilities) > 1:
        raise ActionContractError(
            "worker exposes heterogeneous NVIDIA compute capabilities; platform is ambiguous"
        )
    suffix = ""
    if capabilities:
        capability = next(iter(capabilities))
        suffix = f"-sm{capability.replace('.', '')}"
    return _text(
        f"{system}-{machine}{suffix}",
        where="derived worker platform_key",
        pattern=_SCOPE_TOKEN_RE,
    )


def _worker_identity_from_evidence(evidence: Mapping[str, object]) -> str:
    slurm = evidence["slurm"]
    if isinstance(slurm, Mapping):
        return str(slurm["node_name"])
    return str(evidence["hostname"])


def _host_class_from_evidence(
    evidence: Mapping[str, object], *, expected: str | None
) -> str | None:
    """The attested host class, or ``None`` for work that keys on none.

    A class is attested only by what the controller holds: the node's
    ``ActiveFeatures`` name it, and the job's own constraint requires it, so
    the scheduler enforced the placement rather than a worker observing it.
    Partition names and ``SLURM_*`` variables are recorded evidence, never
    the verdict: no partition is a class, and a batch script can export
    anything.  Scheduler metadata is never turned into an ambient class
    assertion for portable or platform-keyed work.
    """

    if expected is None:
        return None
    slurm = evidence["slurm"]
    if not isinstance(slurm, Mapping):
        raise ActionContractError(
            "host_class_keyed actions require complete SLURM job evidence"
        )
    controller = slurm.get("controller")
    if not isinstance(controller, Mapping):
        raise ActionContractError(
            "host_class_keyed actions require the SLURM controller's record "
            "of the job and its node; environment variables attest no class"
        )
    active = controller["node_active_features"]
    required = controller["job_features"]
    assert isinstance(active, list) and isinstance(required, list)
    if expected not in active:
        raise ActionContractError(
            f"the SLURM node {controller['batch_host']} does not carry the "
            f"Feature {expected!r} the action is keyed on"
        )
    if expected not in required:
        raise ActionContractError(
            f"the SLURM job's constraint does not require the Feature "
            f"{expected!r}; placement on it was not enforced by the scheduler"
        )
    return expected


def accelerator_models_contract(evidence: Mapping[str, object]) -> str:
    """Bind device models/counts while keeping physical UUIDs as provenance.

    Class-scoped measurements may select a second matching device, never a
    different model merely sharing a compute capability. Legacy evidence
    without model/UUID facts cannot establish this stronger contract.
    """

    rows = evidence["accelerators"]
    assert isinstance(rows, list)
    models = []
    for row in rows:
        if not isinstance(row, Mapping) or not row.get("name") or not row.get("uuid"):
            raise ActionContractError("accelerator model identity is unavailable")
        models.append({key: row[key] for key in ("kind", "name", "compute_capability")})
    return canonical_sha256(sorted(models, key=_canonical_bytes))


def live_platform_toolchain_contract(
    *, evidence: Mapping[str, object] | None = None,
) -> dict[str, str]:
    """The ABI and accelerator toolchain fields of this box.

    Together with ``executable_toolchain_contract`` these are the fields a
    nonportable action must declare, and they can be read only on the box
    whose facts they are.  A submitter that seals them binds the action to
    boxes that verify identically.
    """

    evidence = _collect_worker_evidence() if evidence is None else evidence
    fields = {
        "system": str(evidence["system"]),
        "machine": str(evidence["machine"]),
        "libc": str(evidence["libc"]),
    }
    accelerators = evidence["accelerators"]
    assert isinstance(accelerators, list)
    capabilities = {str(row["compute_capability"]) for row in accelerators}
    drivers = {str(row["driver_version"]) for row in accelerators}
    if len(capabilities) == 1 and len(drivers) == 1:
        fields["cuda_compute_capability"] = next(iter(capabilities))
        fields["nvidia_driver"] = next(iter(drivers))
    return fields


def _probe_python_toolchain(executable: Path) -> dict[str, str]:
    script = "\n".join(
        (
            "import importlib.metadata as metadata",
            "import json",
            "import platform",
            "out = {'python': platform.python_version()}",
            "for name in ('torch', 'transformers', 'vllm', 'gridbook'):",
            "    try:",
            "        out[name] = metadata.version(name)",
            "    except metadata.PackageNotFoundError:",
            "        pass",
            "print(json.dumps(out, sort_keys=True, separators=(',', ':')))",
        )
    )
    try:
        completed = subprocess.run(
            [str(executable), "-I", "-c", script],
            shell=False,
            check=False,
            capture_output=True,
            text=True,
            encoding="utf-8",
            errors="strict",
            env={"LANG": "C.UTF-8", "LC_ALL": "C.UTF-8"},
            timeout=30.0,
        )
    except (OSError, UnicodeError, subprocess.TimeoutExpired) as exc:
        raise ActionContractError(
            f"cannot probe declared Python toolchain through {executable}"
        ) from exc
    if completed.returncode != 0 or "\n" in completed.stdout.strip():
        raise ActionContractError(
            f"declared Python toolchain probe failed through {executable}"
        )
    value = _decode_strict_json(
        completed.stdout.strip().encode("utf-8"), where="Python toolchain probe"
    )
    if not isinstance(value, Mapping) or any(
        type(key) is not str or type(item) is not str for key, item in value.items()
    ):
        raise ActionContractError("Python toolchain probe returned malformed data")
    return dict(value)


def _toolchain_value_matches(declared: str, observed: str) -> bool:
    if declared == observed:
        return True
    short = re.fullmatch(r"([0-9]+\.[0-9]+)(?:\+([A-Za-z0-9._-]+))?", declared)
    full = re.fullmatch(
        r"([0-9]+\.[0-9]+)(?:\.[0-9]+)?(?:\+([A-Za-z0-9._-]+))?",
        observed,
    )
    return bool(
        short
        and full
        and short.group(1) == full.group(1)
        and short.group(2) == full.group(2)
    )


def build_code_closure(root: str | Path, files: Sequence[str]) -> dict[str, object]:
    """Hash a declared, path-independent code closure below ``root``.

    Only declared regular files participate.  Symlinks and traversal are
    refused, and the logical relative paths (not the checkout root) are bound
    into the closure identity.
    """

    checkout_root = Path(root)
    if not checkout_root.is_absolute():
        _fail("code closure root must be absolute")
    normalized_paths = [
        _normalize_relative_path(path, where=f"code closure file[{index}]", dot_ok=False)
        for index, path in enumerate(files)
    ]
    if not normalized_paths:
        _fail("code closure must contain at least one file")
    if len(set(normalized_paths)) != len(normalized_paths):
        _fail("code closure file paths must be unique")
    entries: list[dict[str, object]] = []
    for relative in sorted(normalized_paths):
        digest, size = _file_identity(
            checkout_root / relative, where=f"code closure file {relative!r}"
        )
        entries.append({"path": relative, "sha256": digest, "bytes": size})
    body: dict[str, object] = {
        "schema": CODE_CLOSURE_SCHEMA_V1,
        "files": entries,
    }
    return {**body, "closure_sha256": canonical_sha256(body)}


def validate_code_closure(value: object) -> dict[str, object]:
    closure = _exact_mapping(value, keys=_CLOSURE_KEYS, where="action.code_closure")
    if closure["schema"] != CODE_CLOSURE_SCHEMA_V1:
        _fail(f"action.code_closure.schema must be {CODE_CLOSURE_SCHEMA_V1!r}")
    raw_files = closure["files"]
    if type(raw_files) is not list or not raw_files:
        _fail("action.code_closure.files must be a non-empty array")
    files: list[dict[str, object]] = []
    previous: str | None = None
    for index, raw_entry in enumerate(raw_files):
        entry = _exact_mapping(
            raw_entry,
            keys=_CLOSURE_FILE_KEYS,
            where=f"action.code_closure.files[{index}]",
        )
        path = _normalize_relative_path(
            entry["path"],
            where=f"action.code_closure.files[{index}].path",
            dot_ok=False,
        )
        if previous is not None and path <= previous:
            _fail("action.code_closure.files must be unique and sorted by path")
        previous = path
        files.append(
            {
                "path": path,
                "sha256": _sha256(
                    entry["sha256"],
                    where=f"action.code_closure.files[{index}].sha256",
                ),
                "bytes": _nonnegative_integer(
                    entry["bytes"],
                    where=f"action.code_closure.files[{index}].bytes",
                ),
            }
        )
    body = {"schema": CODE_CLOSURE_SCHEMA_V1, "files": files}
    expected = canonical_sha256(body)
    recorded = _sha256(
        closure["closure_sha256"], where="action.code_closure.closure_sha256"
    )
    if recorded != expected:
        _fail("action.code_closure.closure_sha256 does not match its files")
    return {**body, "closure_sha256": recorded}


def verify_code_closure(value: object, root: str | Path) -> dict[str, object]:
    """Re-hash every closure member from a live checkout."""

    expected = validate_code_closure(value)
    live = build_code_closure(
        root, [str(entry["path"]) for entry in expected["files"]]  # type: ignore[index]
    )
    if live != expected:
        raise ActionContractError(
            "live code closure differs from the action-pinned closure"
        )
    return expected


def is_pbrun_generated_path(path: str | Path) -> bool:
    """Return whether a basename belongs to pbrun's generated-file grammar."""

    name = Path(path).name
    for prefix, suffix in (
        (PBRUN_STAMP_PREFIX, ".json"),
        (PBRUN_RESULT_PREFIX, ".txt"),
    ):
        if not (name.startswith(prefix) and name.endswith(suffix)):
            continue
        token = name[len(prefix):-len(suffix)]
        if len(token) == PBRUN_GENERATED_FINGERPRINT_HEX_LENGTH and all(
            character in "0123456789abcdef" for character in token
        ):
            return True
    return False


def pbrun_git_exclude_patterns() -> tuple[str, str]:
    """Return Git patterns for exactly pbrun's generated basenames."""

    fingerprint = "[0-9a-f]" * PBRUN_GENERATED_FINGERPRINT_HEX_LENGTH
    return (
        f"{PBRUN_STAMP_PREFIX}{fingerprint}.json",
        f"{PBRUN_RESULT_PREFIX}{fingerprint}.txt",
    )


def find_git_worktree_marker(root: str | Path) -> Path | None:
    """Find a filesystem ``.git`` marker at or above a requested cwd."""

    requested = Path(root).resolve(strict=False)
    for directory in (requested, *requested.parents):
        marker = directory / ".git"
        try:
            marker.lstat()
        except FileNotFoundError:
            continue
        except OSError as exc:
            raise ActionContractError(
                f"cannot inspect Git worktree marker {marker}: {exc}"
            ) from exc
        return marker
    return None


def git_checkout_identity(root: str | Path) -> dict[str, str]:
    """Return pbrun's canonical commit-plus-working-tree identity.

    The submitter and the trusted worker must call this same implementation.
    Hashing a JSON file that merely *claims* this identity does not bind the
    tree: a queued or retried action can otherwise execute whatever bytes the
    checkout contains when a worker eventually claims it.

    A plain directory remains representable as ``no-git`` for the legacy
    path-addressed pbrun mode. Commit-addressed materialisation is responsible
    for refusing that mode when portability is requested.
    """

    checkout = Path(root)
    repository_detected = find_git_worktree_marker(checkout) is not None

    def _git(
        *args: str,
        input_text: str | None = None,
        accepted_returncodes: tuple[int, ...] = (0,),
        env: Mapping[str, str] | None = None,
    ) -> str:
        try:
            completed = subprocess.run(
                ["git", "-C", str(checkout), "-c",
                 "core.excludesFile=/dev/null", *args],
                capture_output=True,
                text=True,
                errors="surrogateescape",
                input=input_text,
                timeout=30,
                env=env,
            )
        except (OSError, subprocess.SubprocessError) as exc:
            if repository_detected:
                raise ActionContractError(
                    "cannot compute pbrun checkout identity: Git "
                    f"{' '.join(args)} failed: {exc}"
                ) from exc
            return ""
        if completed.returncode not in accepted_returncodes:
            if repository_detected:
                detail = (completed.stderr or completed.stdout).strip()
                raise ActionContractError(
                    "cannot compute pbrun checkout identity: Git "
                    f"{' '.join(args)} failed: "
                    f"{detail or completed.returncode}"
                )
            return ""
        return completed.stdout

    top_level = _git("rev-parse", "--show-toplevel").rstrip("\n")
    if top_level:
        # Identity covers the repository, even when pbrun's requested cwd is
        # a package below it. Git reports the tracked delta for that closure;
        # the filesystem special-inode scan must cover the same closure.
        checkout = Path(top_level)
        repository_detected = True
    head = _git("rev-parse", "HEAD").strip() or "no-git"

    # Personal excludes must not change either the untracked roster or the
    # special-inode screen. The helper pins them off for every Git call;
    # repository .gitignore and info/exclude rules continue to apply.
    # Let Git delimit untracked pathnames. Line-oriented porcelain C-quotes
    # newlines, quotes, and backslashes, and hand-unquoting that display form
    # can bind ``:unreadable`` instead of the actual file bytes. ``ls-files
    # -z`` emits the repository-root-relative filesystem path verbatim.
    untracked_paths = [
        path
        for path in _git(
            "ls-files", "--others", "--exclude-standard", "-z"
        ).split("\0")
        if path and not is_pbrun_generated_path(path)
    ]
    # Git deliberately omits FIFOs, sockets, and device nodes from its
    # untracked roster. Find those without opening them: opening a FIFO can
    # block forever, and no special inode has stable bytes Git can transport.
    # Prune Git-ignored directories before walking so an ignored environment
    # or cache does not turn identity into an unrelated filesystem crawl.
    ignored_directory_output = _git(
        "ls-files",
        "--others",
        "--ignored",
        "--exclude-standard",
        "--directory",
        "-z",
    )
    ignored_directories = {
        value.rstrip("/")
        for value in ignored_directory_output.split("\0")
        if value.endswith("/")
    }
    special_paths: list[str] = []

    # Use scandir directly rather than os.walk followed by a second lstat for
    # every entry.  Identity is on pbrun's submission hot path, and DirEntry
    # can answer the supported-kind predicates from the directory record on
    # common filesystems while preserving fail-closed error handling.
    pending = [checkout]
    while pending:
        current = pending.pop()
        relative_directory = current.relative_to(checkout)
        try:
            with os.scandir(current) as entries:
                for entry in entries:
                    relative = (relative_directory / entry.name).as_posix()
                    try:
                        if entry.is_symlink():
                            continue
                        if entry.is_dir(follow_symlinks=False):
                            if (
                                entry.name != ".git"
                                and relative not in ignored_directories
                            ):
                                pending.append(Path(entry.path))
                            continue
                        if entry.is_file(follow_symlinks=False):
                            continue
                    except OSError as exc:
                        raise ActionContractError(
                            "cannot inspect pbrun checkout path "
                            f"{relative!r}: {exc}"
                        ) from exc
                    special_paths.append(relative)
        except OSError as exc:
            raise ActionContractError(
                f"cannot inspect pbrun checkout identity: {exc}"
            ) from exc
    if special_paths:
        ignored_specials = set(
            value
            for value in _git(
                "check-ignore",
                "--no-index",
                "-z",
                "--stdin",
                input_text="\0".join(special_paths) + "\0",
                accepted_returncodes=(0, 1),
            ).split("\0")
            if value
        )
        unsupported = sorted(set(special_paths) - ignored_specials)
        if unsupported:
            raise ActionContractError(
                "pbrun checkout identity refuses untracked paths with an "
                "unsupported file type: " + ", ".join(map(repr, unsupported))
            )
    untracked: list[tuple[str, str]] = []
    for relative in untracked_paths:
        member = checkout / relative
        try:
            digest = hashlib.sha256()
            member_stat = member.lstat()
            if stat.S_ISDIR(member_stat.st_mode):
                continue
            if stat.S_ISLNK(member_stat.st_mode):
                digest.update(b"symlink\0")
                digest.update(os.fsencode(os.readlink(member)))
            elif stat.S_ISREG(member_stat.st_mode):
                digest.update(b"file\0")
                with member.open("rb") as handle:
                    for chunk in iter(lambda: handle.read(1 << 20), b""):
                        digest.update(chunk)
            else:
                raise ActionContractError(
                    "pbrun checkout identity refuses an untracked path with "
                    f"an unsupported file type: {relative!r}"
                )
            untracked.append((relative, digest.hexdigest()))
        except OSError as exc:
            raise ActionContractError(
                f"cannot hash untracked path {relative!r}: {exc}"
            ) from exc
    # Plumbing bypasses porcelain presentation settings, but still reads
    # custom diff-driver configuration, personal attributes and GIT_DIFF_OPTS.
    # Read the original index and objects through a private Git directory with
    # canonical configuration. This neither copies nor modifies the source
    # index, and preserves default diff bytes (including binary/rename keys).
    # Tracked .gitattributes remains part of the tree; per-clone info/attributes
    # and global attributes do not belong to the checkout's content identity.
    dirty = bytearray()
    if head != "no-git":
        objects = _git(
            "rev-parse", "--path-format=absolute", "--git-path", "objects"
        ).rstrip("\n")
        index = _git(
            "rev-parse", "--path-format=absolute", "--git-path", "index"
        ).rstrip("\n")
        diff_env = {
            key: value for key, value in os.environ.items()
            if not key.startswith("GIT_CONFIG") and key not in {
                "GIT_DIR", "GIT_COMMON_DIR", "GIT_WORK_TREE", "GIT_ATTR_SOURCE",
                "GIT_DIFF_OPTS", "GIT_PREFIX",
            }
        }
        diff_env.update({
            "GIT_CONFIG_NOSYSTEM": "1",
            "GIT_CONFIG_GLOBAL": os.devnull,
            "GIT_ATTR_NOSYSTEM": "1",
            "GIT_INDEX_FILE": index,
            "GIT_OBJECT_DIRECTORY": objects,
        })
        with tempfile.TemporaryDirectory(prefix="prismabuild-identity-") as temporary:
            private_git = Path(temporary)
            (private_git / "refs").mkdir()
            (private_git / "objects").mkdir()
            (private_git / "HEAD").write_text(head + "\n")
            if len(head) == 64:
                (private_git / "config").write_text(
                    "[core]\nrepositoryformatversion = 1\n"
                    "[extensions]\nobjectformat = sha256\n"
                )
            dirty.extend(os.fsencode(_git(
                "--git-dir=" + str(private_git),
                "--work-tree=" + str(checkout),
                "-c", "core.abbrev=auto",
                "-c", "core.attributesFile=" + os.devnull,
                "diff-index", "-p", "--binary", "-M",
                "--no-ext-diff", "--no-textconv", "HEAD",
                env=diff_env,
            )))
    for relative, digest in sorted(untracked, key=lambda item: os.fsencode(item[0])):
        dirty.extend(b"\0untracked\0")
        dirty.extend(os.fsencode(relative))
        dirty.extend(b"\0")
        dirty.extend(digest.encode("ascii"))
    return {
        "head": head,
        "dirty_sha256": hashlib.sha256(dirty).hexdigest(),
    }


def validate_pbrun_snapshot_ref_name(value: object, *, where: str) -> str:
    """One branch name a materializing worker may create from a queue record.

    These names are not constants: they arrive on the queue item and become
    ``refs/heads/<name>`` and a ``git fetch`` refspec inside the claiming
    worker.  A colon splits a refspec, a leading dash becomes an option, and
    the Git revision grammar (``~ ^ @{ ..``) turns a name into a different
    object than the one the record priced.  ``HEAD`` and the snapshot's own
    ref name are refused for a second reason: both would make every later
    revision lookup in the materialized checkout ambiguous, which is the
    failure this whole contract exists to remove.
    """

    name = _text(value, where=where, pattern=_SNAPSHOT_REF_NAME_RE)
    if (
        name == "HEAD"
        or name.startswith(
            ("-", "/", ".", "refs/", PBRUN_CHECKOUT_SNAPSHOT_REF_NAME)
        )
        or name.endswith((".", "/", ".lock"))
        or ".." in name
        or "//" in name
        or "@{" in name
    ):
        _fail(f"{where} is not a usable branch name")
    return name


def validate_pbrun_checkout_snapshot(value: object) -> dict[str, object]:
    """Validate the immutable Git bundle a pbrun action executes from."""

    if not isinstance(value, Mapping):
        _fail("pbrun checkout snapshot must be an object")
    schema = value.get("schema")
    if schema not in {
        PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V1, PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2
    }:
        _fail(
            "pbrun checkout snapshot.schema must be "
            f"{PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V1!r} or "
            f"{PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2!r}"
        )
    ancestral = schema == PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2
    keys = {"schema", "commit", "subdirectory", "input"}
    raw = _exact_mapping(
        value,
        # Each schema owns one exact key set, so a v1 record cannot smuggle
        # ancestry a v1 materializer would silently ignore.
        keys=frozenset(keys | {"parent", "refs"} if ancestral else keys),
        where="pbrun checkout snapshot",
    )
    snapshot_input = validate_input_contract(raw["input"])
    if snapshot_input["id"] != PBRUN_CHECKOUT_SNAPSHOT_INPUT_ID:
        _fail(
            "pbrun checkout snapshot input.id must be "
            f"{PBRUN_CHECKOUT_SNAPSHOT_INPUT_ID!r}"
        )
    validated: dict[str, object] = {
        "schema": schema,
        "commit": _text(
            raw["commit"],
            where="pbrun checkout snapshot.commit",
            pattern=_GIT_OBJECT_ID_RE,
        ),
        "subdirectory": _normalize_relative_path(
            raw["subdirectory"],
            where="pbrun checkout snapshot.subdirectory",
            dot_ok=True,
        ),
        "input": snapshot_input,
    }
    if not ancestral:
        return validated
    parent = raw["parent"]
    validated["parent"] = None if parent is None else _text(
        parent,
        where="pbrun checkout snapshot.parent",
        pattern=_GIT_OBJECT_ID_RE,
    )
    raw_refs = raw["refs"]
    if not isinstance(raw_refs, Mapping):
        _fail("pbrun checkout snapshot.refs must be an object")
    refs: dict[str, str] = {}
    for raw_name in raw_refs:
        name = validate_pbrun_snapshot_ref_name(
            raw_name, where="pbrun checkout snapshot.refs name"
        )
        refs[name] = _text(
            raw_refs[raw_name],
            where=f"pbrun checkout snapshot.refs[{name}]",
            pattern=_GIT_OBJECT_ID_RE,
        )
    validated["refs"] = {name: refs[name] for name in sorted(refs)}
    return validated


def _materialized_git(root: Path, *args: str) -> str:
    """One read of the materialized checkout, refused rather than guessed."""

    try:
        completed = subprocess.run(
            ["git", "-C", str(root), *args],
            capture_output=True,
            text=True,
            timeout=30,
        )
    except (OSError, subprocess.SubprocessError) as exc:
        raise ActionContractError(
            f"cannot read materialized pbrun checkout: Git "
            f"{' '.join(args)} failed: {exc}"
        ) from exc
    if completed.returncode != 0:
        detail = (completed.stderr or completed.stdout).strip()
        raise ActionContractError(
            f"cannot read materialized pbrun checkout: Git "
            f"{' '.join(args)} failed: {detail or completed.returncode}"
        )
    return completed.stdout.strip()


def _verify_pbrun_checkout_ancestry(
    snapshot: Mapping[str, object], root: Path
) -> None:
    """Prove the ancestry the v2 contract sells, in the tree that will run.

    A snapshot whose bundle omitted a parent still checks out clean at the
    sealed commit, so the identity proof above cannot see the difference --
    and the action then fails inside its own diff-derived gate with
    ``fatal: ambiguous argument``, on a worker, after the queue said yes.
    Ancestry is part of what the record promises, so it is part of what the
    preflight proves.
    """

    parent = snapshot["parent"]
    lineage = _materialized_git(
        root, "rev-list", "--max-count=1", "--parents", "HEAD"
    ).split()
    expected = [str(snapshot["commit"])] + ([str(parent)] if parent else [])
    if lineage != expected:
        raise ActionContractError(
            "materialized pbrun checkout does not carry its sealed parent"
        )
    refs = snapshot["refs"]
    assert isinstance(refs, Mapping)
    for name in sorted(refs):
        resolved = _materialized_git(
            root, "rev-parse", "--verify", f"refs/heads/{name}^{{commit}}"
        )
        if resolved != str(refs[name]):
            raise ActionContractError(
                f"materialized pbrun checkout ref {name!r} differs from the "
                "sealed snapshot"
            )


def _verify_pbrun_checkout_snapshot(
    action: Mapping[str, object],
    root: Path,
    raw_snapshot: object,
    *,
    subdirectory: str | None,
) -> None:
    """Prove the live tree is the sealed commit, clean, with its ancestry.

    ``subdirectory`` is the directory the action declares it runs in, for a
    definition that declares one, and ``None`` for a producer that does not.
    """

    snapshot = validate_pbrun_checkout_snapshot(raw_snapshot)
    if subdirectory is not None and subdirectory != snapshot["subdirectory"]:
        raise ActionContractError(
            "pbrun checkout stamp cwd differs from snapshot subdirectory"
        )
    inputs = action["inputs"]
    assert isinstance(inputs, list)
    if snapshot["input"] not in inputs:
        raise ActionContractError(
            "pbrun checkout snapshot is absent from action.inputs"
        )
    live = git_checkout_identity(root)
    clean = hashlib.sha256(b"").hexdigest()
    if live != {"head": snapshot["commit"], "dirty_sha256": clean}:
        raise ActionContractError(
            "materialized pbrun checkout differs from its sealed commit"
        )
    if snapshot["schema"] == PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2:
        _verify_pbrun_checkout_ancestry(snapshot, root)


def _verify_pbrun_checkout_identity(
    action: Mapping[str, object], root: Path
) -> None:
    """Verify the live Git semantics an action's checkout claims.

    Two proofs live here and they belong to different things. The snapshot
    proof belongs to ``params.checkout_snapshot``: whatever built the action,
    a sealed snapshot promises the worker a clean tree at one commit with a
    named ancestry, and the worker must hold it to that before running
    anything. The stamp proof belongs to ``fleet/pbrun``, which is the only
    definition that writes a closure stamp.

    Keying the whole function on the definition id conflated them, so every
    action a producer sealed itself skipped the snapshot proof.
    ``fleet_submit`` seals a snapshot for ``tessera/*`` on the SLURM lane, and
    those nodes ran a materialized tree nothing had checked.
    """

    task = action["task"]
    assert isinstance(task, Mapping)
    params = action["params"]
    assert isinstance(params, Mapping)
    raw_snapshot = params.get("checkout_snapshot")
    if task["definition_id"] != "fleet/pbrun":
        if raw_snapshot is not None:
            # A producer that builds its own action body writes no stamp and
            # declares no cwd, so there is no cwd to cross-check. The
            # snapshot still names the commit the tree must be.
            _verify_pbrun_checkout_snapshot(
                action, root, raw_snapshot, subdirectory=None
            )
        return
    closure = action["code_closure"]
    assert isinstance(closure, Mapping)
    raw_files = closure["files"]
    assert isinstance(raw_files, list)
    stamps = [
        str(entry["path"])
        for entry in raw_files
        if isinstance(entry, Mapping)
        and Path(str(entry["path"])).name.startswith(PBRUN_STAMP_PREFIX)
    ]
    if len(stamps) != 1:
        raise ActionContractError(
            "fleet/pbrun code closure must contain exactly one pbrun stamp"
        )
    raw = _read_regular_file_nofollow(
        root / stamps[0], where="pbrun checkout identity stamp", max_bytes=4096
    )
    stamp = _exact_mapping(
        _decode_strict_json(raw, where="pbrun checkout identity stamp"),
        keys=frozenset({"cwd", "head", "dirty_sha256"}),
        where="pbrun checkout identity stamp",
    )
    recorded = {
        "head": _text(stamp["head"], where="pbrun checkout identity stamp.head"),
        "dirty_sha256": _sha256(
            stamp["dirty_sha256"],
            where="pbrun checkout identity stamp.dirty_sha256",
        ),
    }
    stamped_cwd = _text(
        stamp["cwd"], where="pbrun checkout identity stamp.cwd"
    )
    source_cwd = _text(params.get("cwd"), where="fleet/pbrun params.cwd")
    if stamped_cwd != source_cwd:
        raise ActionContractError(
            "pbrun checkout identity stamp cwd differs from action params"
        )
    if raw_snapshot is not None:
        _verify_pbrun_checkout_snapshot(
            action, root, raw_snapshot, subdirectory=source_cwd
        )
        return
    if git_checkout_identity(root) != recorded:
        raise ActionContractError(
            "live pbrun checkout identity differs from its sealed stamp"
        )


def _normalize_inputs(value: object) -> list[dict[str, object]]:
    if type(value) is not list:
        _fail("action.inputs must be an array")
    inputs: list[dict[str, object]] = []
    seen: set[str] = set()
    for index, raw_entry in enumerate(value):
        entry = _exact_mapping(
            raw_entry, keys=_INPUT_KEYS, where=f"action.inputs[{index}]"
        )
        identity = _text(
            entry["id"], where=f"action.inputs[{index}].id", pattern=_ID_RE
        )
        if identity in seen:
            _fail("action.inputs ids must be unique")
        seen.add(identity)
        inputs.append(
            {
                "id": identity,
                "sha256": _sha256(
                    entry["sha256"], where=f"action.inputs[{index}].sha256"
                ),
                "bytes": _nonnegative_integer(
                    entry["bytes"], where=f"action.inputs[{index}].bytes"
                ),
            }
        )
    return sorted(inputs, key=lambda entry: str(entry["id"]))


def validate_input_contract(value: object) -> dict[str, object]:
    """Normalize one content-addressed input row used by an action.

    The returned object is exactly the ``{id, sha256, bytes}`` shape accepted
    in ``action.inputs``.  Keeping this validation public lets input ingestion
    and later lookup share the action schema instead of inventing a second
    descriptor vocabulary.
    """

    return _normalize_inputs([value])[0]


def _manifest_path(value: object, *, prefix: str, where: str) -> str:
    """One absolute path inside the declared mount, named exactly.

    A manifest is submitter-supplied and the loop that reads it runs on the
    storage host, so this is the boundary that decides what that loop may
    open.  Exact identity means what it says: one literal path per entry, no
    glob, no ``..``, no symlink-resolved detour, nothing outside the prefix the
    manifest itself declares.  ``realpath`` is deliberately not consulted --
    the check must be a property of the manifest bytes, identical on every
    host and stable across a remount; the reader opens ``O_NOFOLLOW`` instead,
    which refuses the link rather than following it somewhere this check
    already approved.
    """

    text = _text(value, where=where)
    if not text.startswith(prefix + "/"):
        _fail(f"{where} must be inside {prefix}")
    if posixpath.normpath(text) != text:
        _fail(f"{where} must already be normalized")
    return text


def validate_data_manifest(value: object) -> dict[str, object]:
    """Normalize the file list an action declares it will read.

    The manifest answers one question -- which bytes, in which order -- and
    deliberately answers no others.  ``sha256`` may be null on every entry:
    hashing a terabyte of calibration captures costs more than the residency
    it buys, and integrity is not what this contract carries.  What binds the
    list to the action is that the *manifest file* is content-addressed in the
    CAS like any other input, so the action key covers these bytes exactly.
    """

    if not isinstance(value, Mapping):
        _fail("data manifest must be an object")
    raw_schema = value.get("schema")
    if raw_schema not in (DATA_MANIFEST_SCHEMA_V1, DATA_MANIFEST_SCHEMA_V2):
        _fail("data manifest schema must be a supported version")
    manifest = _exact_mapping(
        value, keys=(_DATA_MANIFEST_V2_KEYS if raw_schema == DATA_MANIFEST_SCHEMA_V2
                     else _DATA_MANIFEST_KEYS), where="data manifest"
    )
    schema = _text(manifest["schema"], where="data manifest schema")
    if not isinstance(manifest["produced_by"], Mapping):
        _fail("data manifest produced_by must be an object")
    if not isinstance(manifest["annotations"], Mapping):
        _fail("data manifest annotations must be an object")
    prefix = _text(manifest["mount_prefix"], where="data manifest mount_prefix")
    if not prefix.startswith("/") or prefix != posixpath.normpath(prefix):
        _fail("data manifest mount_prefix must be a normalized absolute path")
    if prefix == "/":
        _fail("data manifest mount_prefix must name a mount, not the root")
    raw_entries = manifest["entries"]
    if type(raw_entries) is not list or not raw_entries:
        _fail("data manifest entries must be a non-empty array")
    if len(raw_entries) > DATA_MANIFEST_MAX_ENTRIES:
        _fail(
            "data manifest entries exceed "
            f"{DATA_MANIFEST_MAX_ENTRIES}"
        )
    entries: list[dict[str, object]] = []
    seen: set[tuple[str, int]] = set()
    total = 0
    for index, raw in enumerate(raw_entries):
        where = f"data manifest entries[{index}]"
        entry = _exact_mapping(
            raw, keys=_DATA_MANIFEST_ENTRY_KEYS, where=where
        )
        path = _manifest_path(
            entry["path"], prefix=prefix, where=f"{where}.path"
        )
        offset = _nonnegative_integer(entry["offset"], where=f"{where}.offset")
        size = _nonnegative_integer(entry["bytes"], where=f"{where}.bytes")
        if size == 0:
            _fail(f"{where}.bytes must be positive")
        digest = (
            None
            if entry["sha256"] is None
            else _sha256(entry["sha256"], where=f"{where}.sha256")
        )
        if (path, offset) in seen:
            _fail("data manifest entries must not repeat a (path, offset)")
        seen.add((path, offset))
        total += size
        entries.append(
            {"path": path, "offset": offset, "bytes": size, "sha256": digest}
        )
    # Both totals are stated by the producer and recomputed here, because the
    # loop budgets ARC against ``total_bytes`` before it opens anything: a
    # total that disagreed with the list would let a manifest reserve one
    # amount of memory and read another.
    if _nonnegative_integer(
        manifest["entry_count"], where="data manifest entry_count"
    ) != len(entries):
        _fail("data manifest entry_count disagrees with entries")
    if _nonnegative_integer(
        manifest["total_bytes"], where="data manifest total_bytes"
    ) != total:
        _fail("data manifest total_bytes disagrees with entries")
    normalized = {
        "schema": schema,
        "produced_by": dict(manifest["produced_by"]),
        "annotations": dict(manifest["annotations"]),
        "mount_prefix": prefix,
        "entries": entries,
        "entry_count": len(entries),
        "total_bytes": total,
    }
    if schema == DATA_MANIFEST_SCHEMA_V2:
        if "phases" in manifest["annotations"]:
            _fail("data manifest v2 uses read_plan, not annotations.phases")
        plan = _exact_mapping(manifest["read_plan"],
                              keys=_DATA_MANIFEST_READ_PLAN_KEYS,
                              where="data manifest read_plan")
        raw_phases = plan["phases"]
        if type(raw_phases) is not list or not raw_phases:
            _fail("data manifest read_plan.phases must be a non-empty array")
        phases: list[dict[str, object]] = []
        names: set[str] = set()
        used: set[int] = set()
        cumulative = 0
        reads = 0
        for index, raw in enumerate(raw_phases):
            where = f"data manifest read_plan.phases[{index}]"
            phase = _exact_mapping(raw, keys=_DATA_MANIFEST_READ_PHASE_KEYS,
                                   where=where)
            name = _text(phase["name"], where=f"{where}.name")
            if name.strip() != name or "\x00" in name:
                _fail(f"{where}.name must match a progress phase name")
            if name in names:
                _fail("data manifest read phase names must be unique")
            names.add(name)
            indices = phase["entry_indices"]
            if type(indices) is not list:
                _fail(f"{where}.entry_indices must be an array")
            reads += len(indices)
            if reads > DATA_MANIFEST_MAX_READS:
                _fail(f"data manifest read references exceed {DATA_MANIFEST_MAX_READS}")
            local: set[int] = set()
            size = 0
            for ref in indices:
                ref = _nonnegative_integer(ref, where=f"{where}.entry_indices")
                if ref >= len(entries):
                    _fail(f"{where}.entry_indices references an absent entry")
                if ref in local:
                    _fail(f"{where}.entry_indices repeats an entry within a phase")
                local.add(ref)
                used.add(ref)
                size += int(entries[ref]["bytes"])
            if _nonnegative_integer(phase["bytes"], where=f"{where}.bytes") != size:
                _fail(f"{where}.bytes disagrees with entry references")
            cumulative += size
            if (_nonnegative_integer(phase["cumulative_bytes"],
                                     where=f"{where}.cumulative_bytes") != cumulative):
                _fail(f"{where}.cumulative_bytes disagrees with entry references")
            phases.append({"name": name, "entry_indices": list(indices),
                           "bytes": size, "cumulative_bytes": cumulative})
        if len(used) != len(entries):
            _fail("data manifest read_plan must reference every unique entry")
        if (_nonnegative_integer(plan["read_bytes"], where="data manifest read_plan.read_bytes")
                != cumulative):
            _fail("data manifest read_plan.read_bytes disagrees with phases")
        normalized["read_plan"] = {"phases": phases, "read_bytes": cumulative}
    return normalized


def read_data_manifest(path: str | Path) -> tuple[dict[str, object], str]:
    """Validate plain JSON or one gzip member and return its wire encoding.

    Detection uses the gzip header, never a suffix: a CAS blob has no suffix.
    Stored bytes and decoded bytes are bounded independently, before JSON
    parsing. Trailing bytes, concatenated members and incomplete streams refuse.
    """

    source = Path(path)
    try:
        # Bound the read itself as well as the size check: a file may grow
        # after stat. O_NONBLOCK prevents a FIFO from blocking the submitter.
        fd = os.open(source, os.O_RDONLY | os.O_NONBLOCK)
        with os.fdopen(fd, "rb") as handle:
            info = os.fstat(handle.fileno())
            if not stat.S_ISREG(info.st_mode):
                _fail("data manifest must be a regular file")
            if info.st_size > DATA_MANIFEST_MAX_BYTES:
                _fail(f"data manifest exceeds {DATA_MANIFEST_MAX_BYTES} bytes: {info.st_size}")
            raw = handle.read(DATA_MANIFEST_MAX_BYTES + 1)
    except OSError as exc:
        raise ActionContractError(f"unreadable data manifest: {exc}") from exc
    if len(raw) > DATA_MANIFEST_MAX_BYTES:
        _fail(f"data manifest exceeds {DATA_MANIFEST_MAX_BYTES} bytes")
    encoding = "gzip" if raw.startswith(b"\x1f\x8b") else "identity"
    if encoding == "gzip":
        try:
            decoder = zlib.decompressobj(wbits=16 + zlib.MAX_WBITS)
            decoded = decoder.decompress(raw, DATA_MANIFEST_MAX_DECODED_BYTES + 1)
        except zlib.error as exc:
            raise ActionContractError(f"invalid gzip data manifest: {exc}") from exc
        if len(decoded) > DATA_MANIFEST_MAX_DECODED_BYTES:
            _fail(f"decoded data manifest exceeds {DATA_MANIFEST_MAX_DECODED_BYTES} bytes")
        if not decoder.eof or decoder.unused_data or decoder.unconsumed_tail:
            _fail("gzip data manifest must contain exactly one complete member")
        raw = decoded
    try:
        loaded = json.loads(raw.decode("utf-8"))
    except ValueError as exc:
        raise ActionContractError(f"unreadable data manifest: {exc}") from exc
    return validate_data_manifest(loaded), encoding


def load_data_manifest(path: str | Path) -> dict[str, object]:
    """Read a bounded plain or gzip manifest, preserving the v1 return shape."""

    return read_data_manifest(path)[0]


def validate_produced_output_declaration(
    value: object, inputs: Sequence[Mapping[str, object]] | None = None,
) -> dict[str, object]:
    """Check the sealed produced-output template declaration in action params.

    The declaration names the immutable template bytes already carried as an
    ordinary CAS input: ``template_id`` + canonical ``template_sha256`` plus
    the input row ``{id, sha256, bytes}`` whose ``id`` is
    :data:`PRODUCED_OUTPUT_TEMPLATE_INPUT_ID`. The template body itself is
    validated by the produced-output owner (``produced_output.
    validate_template``); this checks the sealed binding only: closed field
    set, digest shapes, and -- when ``inputs`` is given -- that the named row
    is present in ``action.inputs`` with identical bytes. A declaration whose
    input row is missing or mismatched is a tampered seal, not a different
    template.
    """

    declaration = _exact_mapping(
        value,
        keys=frozenset({"schema", "template_id", "template_sha256", "input"}),
        where="action.params.produced_output_template",
    )
    if declaration["schema"] != PRODUCED_OUTPUT_DECLARATION_SCHEMA_V1:
        _fail(
            "action.params.produced_output_template.schema must be "
            f"{PRODUCED_OUTPUT_DECLARATION_SCHEMA_V1!r}"
        )
    template_id = _text(
        declaration["template_id"],
        where="action.params.produced_output_template.template_id",
    )
    if not template_id or "/" in template_id:
        _fail(
            "action.params.produced_output_template.template_id must be a "
            "non-empty name with no '/'"
        )
    template_sha = _sha256(
        declaration["template_sha256"],
        where="action.params.produced_output_template.template_sha256",
    )
    input_ref = _exact_mapping(
        declaration["input"],
        keys=_INPUT_KEYS,
        where="action.params.produced_output_template.input",
    )
    input_id = _text(
        input_ref["id"],
        where="action.params.produced_output_template.input.id",
        pattern=_ID_RE,
    )
    if input_id != PRODUCED_OUTPUT_TEMPLATE_INPUT_ID:
        _fail(
            "action.params.produced_output_template.input.id must be "
            f"{PRODUCED_OUTPUT_TEMPLATE_INPUT_ID!r}"
        )
    input_sha = _sha256(
        input_ref["sha256"],
        where="action.params.produced_output_template.input.sha256",
    )
    input_bytes = _nonnegative_integer(
        input_ref["bytes"],
        where="action.params.produced_output_template.input.bytes",
    )
    # The declaration binds a tiny envelope, never a payload: empty and
    # oversized inputs refuse here rather than becoming action keys no
    # worker can honestly execute.
    if input_bytes <= 0 or input_bytes > PRODUCED_OUTPUT_TEMPLATE_MAX_BYTES:
        _fail(
            "action.params.produced_output_template.input.bytes must be "
            f"within 1..{PRODUCED_OUTPUT_TEMPLATE_MAX_BYTES}")
    if inputs is not None:
        matches = [
            entry for entry in inputs
            if isinstance(entry, Mapping)
            and entry.get("id") == PRODUCED_OUTPUT_TEMPLATE_INPUT_ID
            and entry.get("sha256") == input_sha
            and entry.get("bytes") == input_bytes
        ]
        if not matches:
            _fail(
                "action.params.produced_output_template.input names no row "
                "in action.inputs: the declaration is tampered"
            )
    return {
        "schema": PRODUCED_OUTPUT_DECLARATION_SCHEMA_V1,
        "template_id": template_id,
        "template_sha256": template_sha,
        "input": {
            "id": PRODUCED_OUTPUT_TEMPLATE_INPUT_ID,
            "sha256": input_sha,
            "bytes": input_bytes,
        },
    }


#: What a movement node produces: a statement that one byte range of one
#: manifest's read order is resident on one tier.  Deterministic from the plan,
#: so a consumer can bind it as a CAS dependency *before* the mover runs, which
#: is what lets ``ActionGraph``'s content-binding check apply to residency edges
#: unchanged (#583).
RESIDENCY_DESCRIPTOR_SCHEMA_V1 = "prismaquant.prismabuild.residency_descriptor.v1"
#: The tiers a movement node may name.  ``pool`` is the raidz1 the export is
#: served from; ``stage`` is a PB-owned pool on solid-state devices; ``arc`` is
#: the file server's ARC, a best-effort tier ZFS exposes no pin for.
STORAGE_TIERS = frozenset({"pool", "stage", "arc"})
_STORAGE_TIER_RE = re.compile(r"(pool|stage|arc)\Z")


def residency_descriptor(
    *,
    manifest_sha256: object,
    manifest_bytes: object,
    tier: object,
    range_start_bytes: object,
    range_end_bytes: object,
) -> dict[str, object]:
    """The canonical result of a movement node, validated.

    ``range_start_bytes``/``range_end_bytes`` are a half-open interval in the
    manifest's own read order (v1 ``entries`` order, v2 ``read_plan`` order),
    never file offsets: the manifest is the only thing that maps them to
    files, and it is bound by ``manifest_sha256``.
    """

    start = _nonnegative_integer(range_start_bytes, where="residency.range_start_bytes")
    end = _nonnegative_integer(range_end_bytes, where="residency.range_end_bytes")
    if end <= start:
        _fail("residency range must be non-empty and half-open (start < end)")
    return {
        "schema": RESIDENCY_DESCRIPTOR_SCHEMA_V1,
        "manifest_sha256": _sha256(manifest_sha256, where="residency.manifest_sha256"),
        "manifest_bytes": _nonnegative_integer(manifest_bytes, where="residency.manifest_bytes"),
        "tier": _text(tier, where="residency.tier", pattern=_STORAGE_TIER_RE),
        "range_start_bytes": start,
        "range_end_bytes": end,
    }


def residency_descriptor_binding(descriptor: Mapping[str, object]) -> dict[str, object]:
    """``{"sha256", "bytes"}`` of the descriptor's canonical bytes, for ``inputs``."""

    raw = _canonical_bytes(residency_descriptor(
        manifest_sha256=descriptor["manifest_sha256"],
        manifest_bytes=descriptor["manifest_bytes"],
        tier=descriptor["tier"],
        range_start_bytes=descriptor["range_start_bytes"],
        range_end_bytes=descriptor["range_end_bytes"],
    ))
    return {"sha256": hashlib.sha256(raw).hexdigest(), "bytes": len(raw)}


def _normalize_task(value: object) -> dict[str, object]:
    task = _exact_mapping(value, keys=_TASK_KEYS, where="action.task")
    task_class = _text(task["task_class"], where="action.task.task_class")
    if task_class not in _TASK_CLASSES:
        _fail(f"action.task.task_class must be one of {sorted(_TASK_CLASSES)}")
    determinism = _text(task["determinism"], where="action.task.determinism")
    if determinism not in _DETERMINISM:
        _fail(f"action.task.determinism must be one of {sorted(_DETERMINISM)}")
    artifact_family = _text(
        task["artifact_family"], where="action.task.artifact_family"
    )
    if artifact_family not in _ARTIFACT_FAMILIES:
        _fail(
            "action.task.artifact_family must be one of "
            f"{sorted(_ARTIFACT_FAMILIES)}"
        )
    return {
        "definition_id": _text(
            task["definition_id"],
            where="action.task.definition_id",
            pattern=_ID_RE,
        ),
        "definition_version": _text(
            task["definition_version"],
            where="action.task.definition_version",
            pattern=_VERSION_RE,
        ),
        "task_class": task_class,
        "determinism": determinism,
        "artifact_family": artifact_family,
        "artifact_kind": _text(
            task["artifact_kind"],
            where="action.task.artifact_kind",
            pattern=_ID_RE,
        ),
        "argv": _normalize_argv(task["argv"]),
        "working_directory": _normalize_relative_path(
            task["working_directory"],
            where="action.task.working_directory",
            dot_ok=True,
        ),
        "result_path": _normalize_relative_path(
            task["result_path"], where="action.task.result_path", dot_ok=False
        ),
    }


def _normalize_environment(value: object) -> dict[str, object]:
    environment = _exact_mapping(
        value, keys=_ENVIRONMENT_KEYS, where="action.environment"
    )
    return {
        "variables": _normalize_string_mapping(
            environment["variables"],
            where="action.environment.variables",
            key_pattern=_ENV_RE,
        ),
        "toolchain": _normalize_string_mapping(
            environment["toolchain"], where="action.environment.toolchain"
        ),
    }


def _normalize_scope(value: object) -> dict[str, object]:
    scope = _exact_mapping(value, keys=_SCOPE_KEYS, where="action.execution_scope")
    portability = _text(
        scope["portability"], where="action.execution_scope.portability"
    )
    if portability not in _PORTABILITY:
        _fail(
            "action.execution_scope.portability must be one of "
            f"{sorted(_PORTABILITY)}"
        )
    platform_key = _optional_token(
        scope["platform_key"], where="action.execution_scope.platform_key"
    )
    host_class = _optional_token(
        scope["host_class"], where="action.execution_scope.host_class"
    )
    if portability == "portable" and (platform_key is not None or host_class is not None):
        _fail("portable actions must set platform_key and host_class to null")
    if portability == "platform_keyed" and (
        platform_key is None or host_class is not None
    ):
        _fail("platform_keyed actions require platform_key and null host_class")
    if portability == "host_class_keyed" and (
        host_class is None or platform_key is not None
    ):
        _fail("host_class_keyed actions require host_class and null platform_key")
    return {
        "portability": portability,
        "platform_key": platform_key,
        "host_class": host_class,
    }


def _normalize_action_body(value: object) -> dict[str, object]:
    body = _exact_mapping(value, keys=_ACTION_BODY_KEYS, where="action body")
    if body["schema"] == ACTION_SCHEMA_V1:
        _fail(
            "v1 actions must be redeclared and resealed with an explicit "
            f"artifact_family under {ACTION_SCHEMA_V2!r}"
        )
    if body["schema"] != ACTION_SCHEMA_V2:
        _fail(f"action.schema must be {ACTION_SCHEMA_V2!r}")
    task = _normalize_task(body["task"])
    scope = _normalize_scope(body["execution_scope"])
    if task["task_class"] == "measurement" and scope["portability"] == "portable":
        _fail("measurement actions must be platform_keyed or host_class_keyed")
    if (
        task["artifact_family"] == "codebook"
        and scope["portability"] == "portable"
    ):
        _fail(
            "codebook actions cannot be portable: D29 records cross-architecture "
            "row-scale byte drift"
        )
    params = body["params"]
    if not isinstance(params, Mapping):
        _fail("action.params must be an object with string keys")
    normalized_params = _normalize_json_value(params, where="action.params")
    assert isinstance(normalized_params, Mapping)
    # Detach the sealed value from caller-owned mutable containers and replay
    # the strict decoder used for persisted manifests.
    normalized_params = _decode_strict_json(
        _canonical_bytes(normalized_params), where="action.params"
    )
    if PROGRESS_PARAM in normalized_params:
        # Refused here rather than at the worker: a policy the worker cannot
        # read would be sealed into an action key that then answers every later
        # submission of the same command with the same unreadable policy.
        declared = validate_progress_policy(normalized_params[PROGRESS_PARAM])
        if declared != normalized_params[PROGRESS_PARAM]:
            _fail("action.params.progress is valid but not in normalized form")
    normalized_inputs = _normalize_inputs(body["inputs"])
    if PRODUCED_OUTPUT_TEMPLATE_PARAM in normalized_params:
        # A tampered binding (declaration without its input row, or with a
        # mismatched digest) is a submitter error here, before it becomes an
        # action key no worker can honestly execute.
        declared_template = validate_produced_output_declaration(
            normalized_params[PRODUCED_OUTPUT_TEMPLATE_PARAM], normalized_inputs
        )
        if declared_template != normalized_params[PRODUCED_OUTPUT_TEMPLATE_PARAM]:
            _fail(
                "action.params.produced_output_template is valid but not in "
                "normalized contract form"
            )
    environment = _normalize_environment(body["environment"])
    toolchain = environment["toolchain"]
    assert isinstance(toolchain, Mapping)
    if "argv0.sha256" in toolchain:
        _sha256(
            toolchain["argv0.sha256"],
            where="action.environment.toolchain.argv0.sha256",
        )
    if "argv0.bytes" in toolchain:
        raw_bytes = toolchain["argv0.bytes"]
        if (
            re.fullmatch(r"0|[1-9][0-9]*", str(raw_bytes)) is None
            or str(int(str(raw_bytes))) != raw_bytes
        ):
            _fail(
                "action.environment.toolchain.argv0.bytes must be a canonical "
                "integer string"
            )
    if "cuda_compute_capability" in toolchain and re.fullmatch(
        r"[0-9]+\.[0-9]+", str(toolchain["cuda_compute_capability"])
    ) is None:
        _fail("action.environment.toolchain.cuda_compute_capability is malformed")
    if "accelerator_models.sha256" in toolchain:
        _sha256(toolchain["accelerator_models.sha256"],
                where="action.environment.toolchain.accelerator_models.sha256")
    if scope["portability"] != "portable":
        unknown = set(toolchain) - _ATTESTABLE_TOOLCHAIN_KEYS
        if unknown:
            _fail(
                "nonportable action toolchain contains fields with no worker "
                f"preflight: {sorted(unknown)}"
            )
        required = {
            "argv0.sha256",
            "argv0.bytes",
            "system",
            "machine",
            "libc",
        }
        if not required <= set(toolchain):
            _fail(
                "nonportable actions must bind argv[0] and platform ABI with "
                "toolchain fields argv0.sha256, argv0.bytes, system, machine, "
                "and libc"
            )
    return {
        "schema": ACTION_SCHEMA_V2,
        "task": task,
        "inputs": normalized_inputs,
        "code_closure": validate_code_closure(body["code_closure"]),
        "params": normalized_params,
        "environment": environment,
        "execution_scope": scope,
    }


def seal_action(value: object) -> dict[str, object]:
    """Normalize an action body and attach its action key."""

    body = _normalize_action_body(value)
    return {**body, "action_key": canonical_sha256(body)}


def validate_action(value: object) -> dict[str, object]:
    action = _exact_mapping(value, keys=_ACTION_KEYS, where="action")
    raw_body = {key: action[key] for key in _ACTION_BODY_KEYS}
    body = _normalize_action_body(raw_body)
    if raw_body != body:
        _fail("action body is valid but not in normalized contract form")
    recorded = _sha256(action["action_key"], where="action.action_key")
    expected = canonical_sha256(body)
    if recorded != expected:
        _fail("action.action_key does not match the canonical action body")
    return {**body, "action_key": recorded}


def validate_worker_scope(
    action: object,
    *,
    attestation: object,
) -> None:
    """Validate scope from live-derived, self-hashed worker evidence.

    Scheduler placement strings are intentionally not accepted here: they are
    intent, not evidence that the allocated machine has the requested scope.
    """

    validate_worker_attestation(attestation, action=action)


def _validate_scope_labels(
    action: Mapping[str, object], *, platform_key: str | None, host_class: str | None
) -> None:
    actual_platform = _optional_token(platform_key, where="worker platform_key")
    actual_host = _optional_token(host_class, where="worker host_class")
    normalized = validate_action(action)
    scope = normalized["execution_scope"]
    assert isinstance(scope, Mapping)
    if (
        scope["portability"] == "platform_keyed"
        and actual_platform != scope["platform_key"]
    ):
        raise ActionContractError(
            "worker platform_key does not match the action execution scope"
        )
    if (
        scope["portability"] == "host_class_keyed"
        and actual_host != scope["host_class"]
    ):
        raise ActionContractError(
            "worker host_class does not match the action execution scope"
        )


def _atomic_publish(
    path: Path,
    raw: bytes,
    *,
    prelink_verify: Callable[[], None] | None = None,
) -> bool:
    """Publish immutable bytes relative to a held no-follow parent FD."""

    path = _absolute_nofollow_path(path, where="publication path")
    directory_fd = _open_directory_nofollow(
        path.parent, where="publication directory", create=True
    )
    temporary_name: str | None = None
    try:
        descriptor, temporary_raw = tempfile.mkstemp(
            prefix=f".{path.name}.",
            suffix=".tmp",
            dir=f"/proc/self/fd/{directory_fd}",
        )
        temporary_name = Path(temporary_raw).name
        with os.fdopen(descriptor, "wb") as handle:
            handle.write(raw)
            handle.flush()
            os.fchmod(handle.fileno(), 0o444)
            os.fsync(handle.fileno())
            temporary_identity = os.fstat(handle.fileno())
        if prelink_verify is not None:
            prelink_verify()
        try:
            os.link(
                temporary_name,
                path.name,
                src_dir_fd=directory_fd,
                dst_dir_fd=directory_fd,
                follow_symlinks=False,
            )
            won = True
        except FileExistsError:
            won = False
        os.fsync(directory_fd)
        if won:
            try:
                published_identity = os.stat(
                    path.name, dir_fd=directory_fd, follow_symlinks=False
                )
            except OSError as exc:
                raise CASTamperError(
                    f"published file changed before readback: {path}"
                ) from exc
            if (
                not stat.S_ISREG(published_identity.st_mode)
                or (
                    temporary_identity.st_dev,
                    temporary_identity.st_ino,
                )
                != (
                    published_identity.st_dev,
                    published_identity.st_ino,
                )
            ):
                raise CASTamperError(
                    f"published file changed before readback: {path}"
                )
        _assert_directory_identity(
            directory_fd, path.parent, where="publication directory"
        )
        return won
    finally:
        if temporary_name is not None:
            try:
                os.unlink(temporary_name, dir_fd=directory_fd)
            except FileNotFoundError:
                pass
        os.close(directory_fd)


def _absolute_nofollow_path(path: Path, *, where: str) -> Path:
    """Return an absolute lexical path that cannot walk through ``..``."""

    candidate = path if path.is_absolute() else Path.cwd() / path
    if ".." in candidate.parts:
        raise ActionContractError(f"{where} must not contain parent traversal")
    return candidate


def _open_directory_nofollow(
    path: Path,
    *,
    where: str,
    create: bool = False,
    mode: int = 0o755,
) -> int:
    """Open/create an absolute directory using only mkdirat/openat operations."""

    path = _absolute_nofollow_path(path, where=where)
    flags = os.O_RDONLY | os.O_CLOEXEC | os.O_DIRECTORY | os.O_NOFOLLOW
    try:
        descriptor = os.open(path.anchor, flags)
    except OSError as exc:
        raise CASUnavailableError(f"cannot open {where} filesystem root: {exc}") from exc
    try:
        for part in path.parts[1:]:
            created = False
            if create:
                try:
                    os.mkdir(part, mode=mode, dir_fd=descriptor)
                    created = True
                except FileExistsError:
                    pass
                except OSError as exc:
                    raise CASUnavailableError(
                        f"cannot create {where} component {part!r}: {exc}"
                    ) from exc
            try:
                child = os.open(part, flags, dir_fd=descriptor)
            except FileNotFoundError:
                raise
            except OSError as exc:
                if exc.errno in {errno.ENOTDIR, errno.ELOOP}:
                    raise CASTamperError(
                        f"{where} ancestor is not a real directory: {path}"
                    ) from exc
                raise CASUnavailableError(
                    f"cannot open {where} component {part!r}: {exc}"
                ) from exc
            try:
                if created:
                    os.fchmod(child, mode)
                    os.fsync(child)
                    os.fsync(descriptor)
            except OSError as exc:
                os.close(child)
                raise CASUnavailableError(
                    f"cannot durably create {where} component {part!r}: {exc}"
                ) from exc
            os.close(descriptor)
            descriptor = child
        return descriptor
    except BaseException:
        os.close(descriptor)
        raise


def _assert_directory_identity(descriptor: int, path: Path, *, where: str) -> None:
    """Fail if the held directory is no longer the configured pathname."""

    try:
        current = _open_directory_nofollow(path, where=where)
    except FileNotFoundError as exc:
        raise CASTamperError(f"{where} disappeared during operation: {path}") from exc
    try:
        held = os.fstat(descriptor)
        observed = os.fstat(current)
        if (held.st_dev, held.st_ino) != (observed.st_dev, observed.st_ino):
            raise CASTamperError(f"{where} changed during operation: {path}")
    finally:
        os.close(current)


def _open_regular_nofollow(path: Path, *, where: str) -> tuple[int, int]:
    """Open a regular-file candidate relative to its held no-follow parent."""

    path = _absolute_nofollow_path(path, where=where)
    parent_fd = _open_directory_nofollow(path.parent, where=f"{where} parent")
    try:
        candidate = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
    except FileNotFoundError:
        os.close(parent_fd)
        raise
    except OSError as exc:
        os.close(parent_fd)
        raise CASUnavailableError(f"cannot inspect {where}: {path}: {exc}") from exc
    if not stat.S_ISREG(candidate.st_mode):
        os.close(parent_fd)
        raise CASTamperError(
            f"cannot open {where} as a real regular file: {path}"
        )
    flags = (
        os.O_RDONLY
        | os.O_CLOEXEC
        | os.O_NOFOLLOW
        | getattr(os, "O_NONBLOCK", 0)
    )
    try:
        descriptor = _open_retrying_would_block(
            path.name, flags, dir_fd=parent_fd)
    except FileNotFoundError:
        os.close(parent_fd)
        raise
    except OSError as exc:
        os.close(parent_fd)
        if exc.errno in {errno.ENOTDIR, errno.ELOOP, errno.EISDIR}:
            raise CASTamperError(
                f"cannot open {where} as a real regular file: {path}"
            ) from exc
        raise CASUnavailableError(f"cannot open {where}: {path}: {exc}") from exc
    return descriptor, parent_fd


def _assert_regular_identity(
    descriptor: int, parent_fd: int, path: Path, *, where: str
) -> None:
    """Fail if a held regular inode is no longer its canonical leaf name."""

    try:
        observed = os.stat(path.name, dir_fd=parent_fd, follow_symlinks=False)
    except FileNotFoundError as exc:
        raise CASTamperError(f"{where} changed during operation: {path}") from exc
    except OSError as exc:
        # An unreadable name is not evidence that the held inode changed.
        # Recovery callers may retire work on tamper, but must retain it when
        # an NFS or permission fault prevents this final identity check.
        raise CASUnavailableError(f"cannot inspect {where}: {path}: {exc}") from exc
    held = os.fstat(descriptor)
    if (
        not stat.S_ISREG(observed.st_mode)
        or (held.st_dev, held.st_ino) != (observed.st_dev, observed.st_ino)
    ):
        raise CASTamperError(f"{where} changed during operation: {path}")


def _stable_file_read_identity(info: os.stat_result) -> tuple[int, ...]:
    """Metadata that must agree within one accepted regular-file read."""

    return (
        info.st_dev,
        info.st_ino,
        info.st_size,
        info.st_mode,
        info.st_uid,
        info.st_gid,
        info.st_mtime_ns,
        info.st_nlink,
        info.st_ctime_ns,
    )


def _substantive_file_read_identity(info: os.stat_result) -> tuple[int, ...]:
    """Metadata changes that are tamper, not an NFS link-visibility retry."""

    identity = _stable_file_read_identity(info)
    return identity[:7]


def _read_regular_file_nofollow(
    path: Path,
    *,
    where: str,
    require_readonly: bool = False,
    require_single_link: bool = False,
    max_bytes: int | None = None,
) -> bytes:
    """Read one stable inode without following any pathname component.

    A ctime/nlink-only mismatch is discarded and retried through a fresh path
    resolution and FD.  No bytes from an unstable attempt are returned. When
    ``max_bytes`` is set, both the opening size and streamed byte count are
    bounded so a dishonest or racing size cannot cause unbounded allocation.
    """

    if max_bytes is not None and (type(max_bytes) is not int or max_bytes < 0):
        raise ActionContractError("stable regular-file read max_bytes is invalid")
    for attempt in range(_STABLE_FILE_READ_ATTEMPTS):
        descriptor, parent_fd = _open_regular_nofollow(path, where=where)
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise CASTamperError(f"{where} is not a regular file: {path}")
            if require_readonly and before.st_mode & 0o222:
                raise CASTamperError(f"{where} is writable: {path}")
            if require_single_link and before.st_nlink != 1:
                raise _FileLinkCountError(
                    f"{where} must have exactly one link: {path}"
                )
            if max_bytes is not None and before.st_size > max_bytes:
                raise CASTamperError(f"{where} exceeds the byte bound: {path}")
            chunks: list[bytes] = []
            size = 0
            while True:
                chunk = os.read(descriptor, 1024 * 1024)
                if not chunk:
                    break
                size += len(chunk)
                if max_bytes is not None and size > max_bytes:
                    raise CASTamperError(f"{where} exceeds the byte bound: {path}")
                chunks.append(chunk)
            after = os.fstat(descriptor)
            if require_single_link and after.st_nlink != 1:
                raise _FileLinkCountError(
                    f"{where} must have exactly one link: {path}"
                )
            if _stable_file_read_identity(before) != _stable_file_read_identity(after):
                if _substantive_file_read_identity(
                    before
                ) != _substantive_file_read_identity(after):
                    raise CASTamperError(
                        f"{where} changed substantively while it was read: {path}"
                    )
                _assert_regular_identity(descriptor, parent_fd, path, where=where)
                _assert_directory_identity(
                    parent_fd, path.parent, where=f"{where} parent"
                )
                if attempt + 1 < _STABLE_FILE_READ_ATTEMPTS:
                    continue
                raise CASTamperError(
                    f"{where} did not stabilize after "
                    f"{_STABLE_FILE_READ_ATTEMPTS} fresh reads: {path}"
                )
            _assert_regular_identity(descriptor, parent_fd, path, where=where)
            _assert_directory_identity(
                parent_fd, path.parent, where=f"{where} parent"
            )
            return b"".join(chunks)
        finally:
            os.close(descriptor)
            os.close(parent_fd)
    raise AssertionError("stable file read retry loop did not return or raise")


def _file_identity_nofollow(
    path: Path,
    *,
    where: str,
    expected_sha256: str | None = None,
    expected_bytes: int | None = None,
) -> tuple[str, int, int]:
    """Hash one stable inode reached through a fresh held no-follow parent.

    Every retry reopens the full path and hashes from byte zero.  A wrong
    expected address is immediate tamper even when metadata is also unstable.
    """

    for attempt in range(_STABLE_FILE_READ_ATTEMPTS):
        descriptor, parent_fd = _open_regular_nofollow(path, where=where)
        digest = hashlib.sha256()
        size = 0
        try:
            before = os.fstat(descriptor)
            if not stat.S_ISREG(before.st_mode):
                raise CASTamperError(f"{where} is not a regular file: {path}")
            while True:
                chunk = os.read(descriptor, 4 * 1024 * 1024)
                if not chunk:
                    break
                digest.update(chunk)
                size += len(chunk)
            observed_digest = digest.hexdigest()
            if expected_bytes is not None and size != expected_bytes:
                raise CASTamperError(
                    f"{where} content differs from its expected byte count: {path}"
                )
            if expected_sha256 is not None and observed_digest != expected_sha256:
                raise CASTamperError(
                    f"{where} content differs from its expected address: {path}"
                )
            after = os.fstat(descriptor)
            if _stable_file_read_identity(before) != _stable_file_read_identity(after):
                if _substantive_file_read_identity(
                    before
                ) != _substantive_file_read_identity(after):
                    raise CASTamperError(
                        f"{where} changed substantively while it was read: {path}"
                    )
                _assert_regular_identity(descriptor, parent_fd, path, where=where)
                _assert_directory_identity(
                    parent_fd, path.parent, where=f"{where} parent"
                )
                if attempt + 1 < _STABLE_FILE_READ_ATTEMPTS:
                    continue
                raise CASTamperError(
                    f"{where} did not stabilize after "
                    f"{_STABLE_FILE_READ_ATTEMPTS} fresh reads: {path}"
                )
            _assert_regular_identity(descriptor, parent_fd, path, where=where)
            _assert_directory_identity(
                parent_fd, path.parent, where=f"{where} parent"
            )
            return observed_digest, size, before.st_mode
        finally:
            os.close(descriptor)
            os.close(parent_fd)
    raise AssertionError("stable file identity retry loop did not return or raise")


def _unlink_nofollow(path: Path, *, where: str) -> None:
    """Unlink a leaf only through its current no-follow parent directory."""

    try:
        directory_fd = _open_directory_nofollow(path.parent, where=f"{where} parent")
    except FileNotFoundError:
        return
    try:
        try:
            os.unlink(path.name, dir_fd=directory_fd)
        except FileNotFoundError:
            return
        os.fsync(directory_fd)
        _assert_directory_identity(
            directory_fd, path.parent, where=f"{where} parent"
        )
    finally:
        os.close(directory_fd)


#: Only fully initialized ingest directories enter the reaper-visible namespace.
PRIVATE_STAGING_PREFIX = "ingest."
PRIVATE_STAGING_OWNER = ".owner.lock"


@contextmanager
def _private_staging_directory(staging_directory: Path):
    """Hold a shared-filesystem ownership lock until one ingest is cleaned up.

    A killed ingest leaves a payload with a lock the kernel releases. A
    sweeper must acquire that same lock nonblocking before removing anything;
    a hostname or a local PID lookup cannot prove a remote writer is dead.
    Initialize under a hidden name, then rename only after locking so a
    sweeper never sees the interval between creating and locking the marker.
    """

    parent_fd = _open_directory_nofollow(
        staging_directory, where="CAS staging directory", create=True
    )
    name = ".ingest." + os.urandom(16).hex()
    private_fd = owner_fd = None
    created = False
    try:
        os.mkdir(name, mode=0o700, dir_fd=parent_fd)
        created = True
        private_fd = os.open(
            name, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
            dir_fd=parent_fd,
        )
        owner_fd = os.open(
            PRIVATE_STAGING_OWNER,
            os.O_RDWR | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW | os.O_CLOEXEC,
            0o600, dir_fd=private_fd,
        )
        fcntl.flock(owner_fd, fcntl.LOCK_EX)
        published_name = name[1:]
        os.rename(name, published_name, src_dir_fd=parent_fd, dst_dir_fd=parent_fd)
        name = published_name
        private = staging_directory / name
        _assert_directory_identity(
            parent_fd, staging_directory, where="CAS staging directory"
        )
        _assert_directory_identity(
            private_fd, private, where="CAS private staging directory"
        )
        yield private
    finally:
        # Keep the owner locked through payload and ownership-marker removal.
        # Cleanup failure retains evidence without masking the ingest's error.
        if private_fd is not None:
            if owner_fd is not None:
                with suppress(OSError):
                    # If payload cleanup failed, retain its released ownership
                    # marker so a later reaper can still prove abandonment.
                    # Enumeration starts from a fresh open-file description.
                    # A held directory descriptor can retain an exhausted
                    # directory offset (observed on Python 3.14/Btrfs). Open
                    # relative to that inode, never through a mutable pathname.
                    listing_fd = os.open(
                        ".", os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW | os.O_CLOEXEC,
                        dir_fd=private_fd,
                    )
                    try:
                        contents = os.listdir(listing_fd)
                    finally:
                        os.close(listing_fd)
                    if contents == [PRIVATE_STAGING_OWNER]:
                        os.unlink(PRIVATE_STAGING_OWNER, dir_fd=private_fd)
            os.close(private_fd)
        if owner_fd is not None:
            # On NFS, unlinking an open marker creates a .nfs* placeholder
            # until this close. Release it before rmdir so success leaves no
            # empty directory behind. The missing marker prevents a reaper
            # from claiming the directory during this final removal interval.
            os.close(owner_fd)
        if created:
            with suppress(OSError):
                os.rmdir(name, dir_fd=parent_fd)
        os.close(parent_fd)


def _copy_to_staging(source: Path, staging_directory: Path) -> tuple[Path, str, int]:
    """Take a stable regular-file snapshot into the CAS filesystem."""

    staging_directory = _absolute_nofollow_path(
        staging_directory, where="CAS staging directory"
    )
    staging_fd = _open_directory_nofollow(
        staging_directory, where="CAS staging directory", create=True
    )
    flags = (
        os.O_RDONLY
        | getattr(os, "O_CLOEXEC", 0)
        | getattr(os, "O_NONBLOCK", 0)
    )
    if hasattr(os, "O_NOFOLLOW"):
        flags |= os.O_NOFOLLOW
    try:
        source_fd = _open_retrying_would_block(source, flags)
    except OSError as exc:
        os.close(staging_fd)
        raise LocalActionError(f"result is not a readable regular file: {source}") from exc
    try:
        descriptor, temporary_raw = tempfile.mkstemp(
            prefix=".payload.", suffix=".tmp", dir=f"/proc/self/fd/{staging_fd}"
        )
    except BaseException:
        os.close(source_fd)
        os.close(staging_fd)
        raise
    temporary_name = Path(temporary_raw).name
    temporary = staging_directory / temporary_name
    digest = hashlib.sha256()
    size = 0
    try:
        before = os.fstat(source_fd)
        if not stat.S_ISREG(before.st_mode):
            raise LocalActionError(f"result is not a regular file: {source}")
        handle = os.fdopen(descriptor, "wb")
        # ``os.fdopen`` owns the descriptor from here; the ``finally`` below
        # must not close it a second time.
        descriptor = -1
        with handle as destination:
            while True:
                chunk = os.read(source_fd, 4 * 1024 * 1024)
                if not chunk:
                    break
                destination.write(chunk)
                digest.update(chunk)
                size += len(chunk)
            destination.flush()
            os.fchmod(destination.fileno(), 0o444)
            os.fsync(destination.fileno())
        after = os.fstat(source_fd)
        if (
            before.st_dev,
            before.st_ino,
            before.st_size,
            before.st_mode,
            before.st_mtime_ns,
            before.st_ctime_ns,
        ) != (
            after.st_dev,
            after.st_ino,
            after.st_size,
            after.st_mode,
            after.st_mtime_ns,
            after.st_ctime_ns,
        ):
            raise LocalActionError(f"result changed while it was copied: {source}")
        _assert_directory_identity(
            staging_fd, staging_directory, where="CAS staging directory"
        )
        return temporary, digest.hexdigest(), size
    except BaseException:
        # A rejection before fdopen still owns the writable descriptor. Close
        # before unlink so an NFS .nfs* placeholder cannot outlive the payload
        # and confuse the enclosing private-directory cleanup.
        if descriptor >= 0:
            with suppress(OSError):
                os.close(descriptor)
            descriptor = -1
        try:
            os.unlink(temporary_name, dir_fd=staging_fd)
        except FileNotFoundError:
            pass
        raise
    finally:
        # Every rejection between ``mkstemp`` and ``os.fdopen`` used to leave
        # this descriptor open on an unlinked staging file.  A directory or a
        # FIFO source is refused there, so a caller that kept refusing invalid
        # inputs ran out of descriptors and could no longer do valid work.
        if descriptor >= 0:
            with suppress(OSError):
                os.close(descriptor)
        os.close(source_fd)
        os.close(staging_fd)


def _stage_bytes(raw: bytes, staging_directory: Path) -> tuple[Path, str, int]:
    """Take a stable regular-file snapshot of bytes already in memory.

    The same private inode ``_copy_to_staging`` produces, for a caller whose
    payload was never a file.  A decomposition's batch envelopes are the case:
    they are derived from the request, so writing them out just to read them
    back would be a temporary file per child, in a directory somebody has to
    choose, for bytes this process already holds.

    Nothing here reads a source, so the source-did-not-change check has
    nothing to check; everything else -- the mode, the fsync, the directory
    identity -- is the ceremony a copy performs, because what the CAS then
    publishes must be the same kind of inode either way.
    """

    staging_directory = _absolute_nofollow_path(
        staging_directory, where="CAS staging directory"
    )
    staging_fd = _open_directory_nofollow(
        staging_directory, where="CAS staging directory", create=True
    )
    descriptor = -1
    temporary_name: str | None = None
    try:
        descriptor, temporary_raw = tempfile.mkstemp(
            prefix=".payload.", suffix=".tmp", dir=f"/proc/self/fd/{staging_fd}"
        )
        temporary_name = Path(temporary_raw).name
        handle = os.fdopen(descriptor, "wb")
        # ``os.fdopen`` owns the descriptor from here.
        descriptor = -1
        with handle as destination:
            destination.write(raw)
            destination.flush()
            os.fchmod(destination.fileno(), 0o444)
            os.fsync(destination.fileno())
        _assert_directory_identity(
            staging_fd, staging_directory, where="CAS staging directory"
        )
        return (staging_directory / temporary_name,
                hashlib.sha256(raw).hexdigest(), len(raw))
    except BaseException:
        if descriptor >= 0:
            with suppress(OSError):
                os.close(descriptor)
            descriptor = -1
        if temporary_name is not None:
            try:
                os.unlink(temporary_name, dir_fd=staging_fd)
            except FileNotFoundError:
                pass
        raise
    finally:
        if descriptor >= 0:
            with suppress(OSError):
                os.close(descriptor)
        os.close(staging_fd)


def _normalize_controller_evidence(value: object) -> dict[str, object]:
    controller = _exact_mapping(
        value,
        keys=_SLURM_CONTROLLER_EVIDENCE_KEYS,
        where="worker evidence.slurm.controller",
    )

    def features(key: str) -> list[str]:
        raw = controller[key]
        if type(raw) is not list:
            _fail(f"worker evidence.slurm.controller.{key} must be an array")
        items = [
            _text(
                item,
                where=f"worker evidence.slurm.controller.{key}[{index}]",
                pattern=_SCOPE_TOKEN_RE,
            )
            for index, item in enumerate(raw)
        ]
        if items != sorted(set(items)):
            _fail(
                f"worker evidence.slurm.controller.{key} must be unique and sorted"
            )
        return items

    return {
        "partition": _text(
            controller["partition"],
            where="worker evidence.slurm.controller.partition",
            pattern=_SCOPE_TOKEN_RE,
        ),
        "batch_host": _text(
            controller["batch_host"],
            where="worker evidence.slurm.controller.batch_host",
            pattern=_ID_RE,
        ),
        "job_features": features("job_features"),
        "node_active_features": features("node_active_features"),
    }


def _normalize_worker_evidence(value: object) -> dict[str, object]:
    evidence = _exact_mapping(
        value, keys=_EVIDENCE_KEYS, where="worker attestation.evidence"
    )
    source = _text(evidence["source"], where="worker evidence.source")
    if source not in {"local", "slurm"}:
        _fail("worker evidence.source must be 'local' or 'slurm'")
    accelerators_raw = evidence["accelerators"]
    if type(accelerators_raw) is not list:
        _fail("worker evidence.accelerators must be an array")
    accelerators: list[dict[str, str]] = []
    for index, raw in enumerate(accelerators_raw):
        identity_keys = {"name", "uuid"} if isinstance(raw, Mapping) and (
            "name" in raw or "uuid" in raw) else set()
        accelerator = _exact_mapping(
            raw,
            keys=_ACCELERATOR_KEYS | identity_keys,
            where=f"worker evidence.accelerators[{index}]",
        )
        kind = _text(
            accelerator["kind"],
            where=f"worker evidence.accelerators[{index}].kind",
            pattern=_SCOPE_TOKEN_RE,
        )
        if kind != "nvidia":
            _fail("worker evidence contains an unsupported accelerator kind")
        capability = _text(
            accelerator["compute_capability"],
            where=f"worker evidence.accelerators[{index}].compute_capability",
        )
        if re.fullmatch(r"[0-9]+\.[0-9]+", capability) is None:
            _fail("worker evidence compute capability is malformed")
        accelerators.append(
            {
                "kind": kind,
                "compute_capability": capability,
                "driver_version": _text(
                    accelerator["driver_version"],
                    where=f"worker evidence.accelerators[{index}].driver_version",
                    pattern=_VERSION_RE,
                ),
                **({
                    "name": _text(accelerator["name"], where="worker accelerator.name"),
                    "uuid": _text(accelerator["uuid"], where="worker accelerator.uuid",
                                  pattern=re.compile(r"GPU-[A-Za-z0-9-]+")),
                } if identity_keys else {}),
            }
        )
    accelerators.sort(
        key=lambda row: (row["kind"], row["compute_capability"], row["driver_version"],
                         row.get("name", ""), row.get("uuid", ""))
    )
    if len({_canonical_bytes(row) for row in accelerators}) != len(accelerators):
        _fail("worker evidence accelerator rows must be unique")
    raw_slurm = evidence["slurm"]
    slurm: dict[str, object] | None
    if raw_slurm is None:
        slurm = None
    else:
        has_controller = isinstance(raw_slurm, Mapping) and "controller" in raw_slurm
        slurm_mapping = _exact_mapping(
            raw_slurm,
            keys=_SLURM_EVIDENCE_KEYS | ({"controller"} if has_controller else set()),
            where="worker evidence.slurm",
        )
        constraints_raw = slurm_mapping["constraints"]
        if type(constraints_raw) is not list:
            _fail("worker evidence.slurm.constraints must be an array")
        constraints = [
            _text(
                item,
                where=f"worker evidence.slurm.constraints[{index}]",
                pattern=_SCOPE_TOKEN_RE,
            )
            for index, item in enumerate(constraints_raw)
        ]
        if constraints != sorted(set(constraints)):
            _fail("worker evidence.slurm.constraints must be unique and sorted")
        cgroup = _text(
            slurm_mapping["cgroup"], where="worker evidence.slurm.cgroup"
        )
        if not cgroup.startswith("/") or ".." in PurePosixPath(cgroup).parts:
            _fail("worker evidence.slurm.cgroup must be an absolute cgroup path")
        job_id = _text(
            slurm_mapping["job_id"],
            where="worker evidence.slurm.job_id",
            pattern=_SCOPE_TOKEN_RE,
        )
        if re.fullmatch(r"[1-9][0-9]*", job_id) is None:
            _fail("worker evidence.slurm.job_id must be a positive numeric job id")
        slurm = {
            "job_id": job_id,
            "node_name": _text(
                slurm_mapping["node_name"],
                where="worker evidence.slurm.node_name",
                pattern=_ID_RE,
            ),
            "partition": _text(
                slurm_mapping["partition"],
                where="worker evidence.slurm.partition",
                pattern=_SCOPE_TOKEN_RE,
            ),
            "constraints": constraints,
            "cgroup": cgroup,
        }
        if has_controller:
            controller = _normalize_controller_evidence(
                slurm_mapping["controller"]
            )
            if controller["batch_host"] != slurm["node_name"]:
                _fail(
                    "worker evidence.slurm.controller.batch_host differs from "
                    "the node the worker reported"
                )
            slurm["controller"] = controller
        job_pattern = re.compile(
            rf"(?:^|/)job_{re.escape(str(slurm['job_id']))}(?:[./]|$)"
        )
        if job_pattern.search(str(slurm["cgroup"])) is None:
            _fail("worker evidence SLURM cgroup does not bind its job id")
    if (source == "slurm") != (slurm is not None):
        _fail("worker evidence source and SLURM evidence disagree")
    return {
        "source": source,
        "hostname": _text(
            evidence["hostname"], where="worker evidence.hostname", pattern=_ID_RE
        ),
        "system": _text(
            evidence["system"], where="worker evidence.system", pattern=_SCOPE_TOKEN_RE
        ),
        "machine": _text(
            evidence["machine"], where="worker evidence.machine", pattern=_SCOPE_TOKEN_RE
        ),
        "libc": _text(
            evidence["libc"], where="worker evidence.libc", pattern=_SCOPE_TOKEN_RE
        ),
        "accelerators": accelerators,
        "slurm": slurm,
    }


def validate_worker_attestation(
    value: object, *, action: object
) -> dict[str, object]:
    """Validate a persisted preflight against the exact sealed action."""

    normalized_action = validate_action(action)
    raw = _exact_mapping(value, keys=_PRODUCER_KEYS, where="worker attestation")
    if raw["schema"] != WORKER_ATTESTATION_SCHEMA_V2:
        _fail(
            f"worker attestation.schema must be {WORKER_ATTESTATION_SCHEMA_V2!r}"
        )
    action_key = _sha256(raw["action_key"], where="worker attestation.action_key")
    if action_key != normalized_action["action_key"]:
        _fail("worker attestation is bound to a different action")
    evidence = _normalize_worker_evidence(raw["evidence"])
    worker_id = _text(
        raw["worker_id"], where="worker attestation.worker_id", pattern=_ID_RE
    )
    if worker_id != _worker_identity_from_evidence(evidence):
        _fail("worker_id is not derived from the worker evidence")
    platform_key = _optional_token(
        raw["platform_key"], where="worker attestation.platform_key"
    )
    derived_platform = _platform_key_from_evidence(evidence)
    if platform_key != derived_platform:
        _fail("platform_key is not derived from the worker evidence")
    host_class = _optional_token(
        raw["host_class"], where="worker attestation.host_class"
    )
    scope = normalized_action["execution_scope"]
    assert isinstance(scope, Mapping)
    expected_host = (
        str(scope["host_class"])
        if scope["portability"] == "host_class_keyed"
        else None
    )
    derived_host = _host_class_from_evidence(evidence, expected=expected_host)
    if host_class != derived_host:
        _fail("host_class is not derived from SLURM worker evidence")
    runtime = _validate_worker_runtime(raw["runtime"])

    executable_raw = _exact_mapping(
        raw["executable"], keys=_EXECUTABLE_KEYS, where="worker attestation.executable"
    )
    task = normalized_action["task"]
    assert isinstance(task, Mapping)
    argv = task["argv"]
    assert isinstance(argv, list)
    executable = {
        "path": _text(
            executable_raw["path"], where="worker attestation.executable.path"
        ),
        "resolved_path": _text(
            executable_raw["resolved_path"],
            where="worker attestation.executable.resolved_path",
        ),
        "sha256": _sha256(
            executable_raw["sha256"], where="worker attestation.executable.sha256"
        ),
        "bytes": _nonnegative_integer(
            executable_raw["bytes"], where="worker attestation.executable.bytes"
        ),
    }
    if executable["path"] != argv[0] or not Path(
        str(executable["resolved_path"])
    ).is_absolute():
        _fail("worker attestation executable differs from action.task.argv[0]")

    toolchain_raw = _exact_mapping(
        raw["toolchain"],
        keys=_TOOLCHAIN_ATTESTATION_KEYS,
        where="worker attestation.toolchain",
    )
    declared = _normalize_string_mapping(
        toolchain_raw["declared"], where="worker attestation.toolchain.declared"
    )
    environment = normalized_action["environment"]
    assert isinstance(environment, Mapping)
    if declared != environment["toolchain"]:
        _fail("worker attestation toolchain differs from the action")
    if "accelerator_models.sha256" in declared:
        if declared["accelerator_models.sha256"] != accelerator_models_contract(evidence):
            _fail("worker accelerator model identity differs from the action")
        observed_platform = live_platform_toolchain_contract(evidence=evidence)
        for key in ("system", "machine", "libc", "cuda_compute_capability", "nvidia_driver"):
            if key in declared and declared[key] != observed_platform.get(key):
                _fail(f"worker recorded evidence for {key!r} differs from the action")
    verified = _normalize_string_mapping(
        toolchain_raw["verified"], where="worker attestation.toolchain.verified"
    )
    if not set(verified) <= set(declared):
        _fail("worker attestation verifies undeclared toolchain fields")
    for key, observed in verified.items():
        matches = (declared[key] == observed if "accelerator_models.sha256" in declared
                   else _toolchain_value_matches(declared[key], observed))
        if not matches:
            _fail(f"worker toolchain field {key!r} differs from the action")
    if (
        declared.get("argv0.sha256") is not None
        and declared["argv0.sha256"] != executable["sha256"]
    ):
        _fail("worker executable digest differs from toolchain argv0.sha256")
    if (
        declared.get("argv0.bytes") is not None
        and declared["argv0.bytes"] != str(executable["bytes"])
    ):
        _fail("worker executable size differs from toolchain argv0.bytes")

    inputs = _normalize_inputs(raw["inputs"])
    expected_inputs = {
        str(entry["id"]): entry
        for entry in normalized_action["inputs"]  # type: ignore[union-attr]
    }
    if any(expected_inputs.get(str(entry["id"])) != entry for entry in inputs):
        _fail("worker attestation contains an input not bound by the action")

    nonportable = scope["portability"] != "portable"
    if nonportable:
        if evidence["libc"] == "unknown":
            _fail("nonportable action cannot attest an unknown libc ABI")
        if set(verified) != set(declared):
            _fail("nonportable action has unverified toolchain fields")
        if len(inputs) != len(expected_inputs):
            _fail("nonportable action has unresolved input artifacts")
        accelerators = evidence["accelerators"]
        assert isinstance(accelerators, list)
        if accelerators and not {
            "cuda_compute_capability",
            "nvidia_driver",
        } <= set(verified):
            _fail(
                "nonportable NVIDIA action must bind cuda_compute_capability "
                "and nvidia_driver in its toolchain"
            )

    _validate_scope_labels(
        normalized_action, platform_key=platform_key, host_class=host_class
    )
    body = {
        "schema": WORKER_ATTESTATION_SCHEMA_V2,
        "action_key": action_key,
        "worker_id": worker_id,
        "platform_key": platform_key,
        "host_class": host_class,
        "evidence": evidence,
        "runtime": runtime,
        "executable": executable,
        "toolchain": {"declared": declared, "verified": verified},
        "inputs": inputs,
    }
    recorded = _sha256(
        raw["attestation_sha256"], where="worker attestation.attestation_sha256"
    )
    if recorded != canonical_sha256(body):
        _fail("worker attestation digest does not match its body")
    return {**body, "attestation_sha256": recorded}


def _verified_toolchain(
    declared: Mapping[str, str],
    *,
    executable: Mapping[str, object],
    evidence: Mapping[str, object],
) -> dict[str, str]:
    observed: dict[str, str] = {
        "argv0.sha256": str(executable["sha256"]),
        "argv0.bytes": str(executable["bytes"]),
        "system": str(evidence["system"]),
        "machine": str(evidence["machine"]),
        "libc": str(evidence["libc"]),
    }
    if "accelerator_models.sha256" in declared:
        observed["accelerator_models.sha256"] = accelerator_models_contract(evidence)
    accelerators = evidence["accelerators"]
    assert isinstance(accelerators, list)
    if accelerators:
        capabilities = {str(row["compute_capability"]) for row in accelerators}
        drivers = {str(row["driver_version"]) for row in accelerators}
        if len(capabilities) == 1:
            observed["cuda_compute_capability"] = next(iter(capabilities))
        if len(drivers) == 1:
            observed["nvidia_driver"] = next(iter(drivers))
    python_keys = set(declared) & ({"python"} | _PYTHON_DISTRIBUTIONS)
    if python_keys:
        observed.update(
            _probe_python_toolchain(Path(str(executable["path"])))
        )
    verified: dict[str, str] = {}
    for key, expected in declared.items():
        actual = observed.get(key)
        if actual is None:
            continue
        matches = (expected == actual if "accelerator_models.sha256" in declared
                   else _toolchain_value_matches(expected, actual))
        if not matches:
            raise ActionContractError(
                f"worker toolchain field {key!r} differs: "
                f"declared={expected!r}, observed={actual!r}"
            )
        verified[key] = actual
    return dict(sorted(verified.items()))


def _verified_input_contracts(
    action: Mapping[str, object], cas: "PrismaBuildCAS"
) -> list[dict[str, object]]:
    scope = action["execution_scope"]
    assert isinstance(scope, Mapping)
    required = scope["portability"] != "portable"
    verified: list[dict[str, object]] = []
    for entry in action["inputs"]:  # type: ignore[union-attr]
        assert isinstance(entry, Mapping)
        path = cas._blob_path(str(entry["sha256"]))
        try:
            path.lstat()
        except FileNotFoundError:
            if required:
                raise ActionContractError(
                    f"nonportable action input is absent from the CAS: {entry['id']}"
                )
            continue
        except OSError as exc:
            raise CASUnavailableError(
                f"cannot inspect action input in the CAS: {entry['id']}: {exc}"
            ) from exc
        cas.input_path(entry)
        verified.append(dict(entry))
    return sorted(verified, key=lambda entry: str(entry["id"]))


def preflight_action(
    action: object,
    *,
    cas_root: str | Path,
    checkout_root: str | Path,
    worker_launcher_identity: object | None = None,
) -> dict[str, object]:
    """Derive and verify the execution facts required before launching argv."""

    normalized = validate_action(action)
    root = Path(checkout_root)
    if not root.is_absolute():
        _fail("checkout_root must be absolute")
    verify_code_closure(normalized["code_closure"], root)
    _verify_pbrun_checkout_identity(normalized, root)
    scope = normalized["execution_scope"]
    assert isinstance(scope, Mapping)
    expected_host = (
        str(scope["host_class"])
        if scope["portability"] == "host_class_keyed"
        else None
    )
    environment = normalized["environment"]
    assert isinstance(environment, Mapping)
    declared = environment["toolchain"]
    assert isinstance(declared, Mapping)
    evidence = _collect_worker_evidence(
        attest_host_class=expected_host,
        **({"attest_accelerator_identity": True}
           if "accelerator_models.sha256" in declared else {}),
    )
    host_class = _host_class_from_evidence(evidence, expected=expected_host)
    executable = identify_executable(
        normalized["task"]["argv"][0]  # type: ignore[index]
    )
    verified = _verified_toolchain(
        declared, executable=executable, evidence=evidence  # type: ignore[arg-type]
    )
    inputs = _verified_input_contracts(normalized, PrismaBuildCAS(cas_root))
    body: dict[str, object] = {
        "schema": WORKER_ATTESTATION_SCHEMA_V2,
        "action_key": normalized["action_key"],
        "worker_id": _worker_identity_from_evidence(evidence),
        "platform_key": _platform_key_from_evidence(evidence),
        "host_class": host_class,
        "evidence": evidence,
        "runtime": _worker_runtime_identity(worker_launcher_identity),
        "executable": executable,
        "toolchain": {"declared": dict(declared), "verified": verified},
        "inputs": inputs,
    }
    attestation = {**body, "attestation_sha256": canonical_sha256(body)}
    return validate_worker_attestation(attestation, action=normalized)


def _verify_attested_executable_unchanged(
    attestation: Mapping[str, object], action: Mapping[str, object]
) -> None:
    validated = validate_worker_attestation(attestation, action=action)
    expected = validated["executable"]
    assert isinstance(expected, Mapping)
    observed = identify_executable(str(expected["path"]))
    if observed != expected:
        raise LocalActionError("action executable changed after worker preflight")


def _verify_attested_worker_runtime_unchanged(
    attestation: Mapping[str, object], action: Mapping[str, object]
) -> None:
    validated = validate_worker_attestation(attestation, action=action)
    _verify_worker_runtime_unchanged(validated["runtime"])


class PrismaBuildCAS:
    """Immutable file-result CAS with verified first-result-wins receipts."""

    def __init__(self, root: str | Path):
        self.root = Path(root)
        if not self.root.is_absolute() or self.root == Path("/"):
            raise ActionContractError("CAS root must be a non-root absolute path")
        if ".." in self.root.parts:
            raise ActionContractError("CAS root must not contain parent traversal")

    def _receipt_path(self, action_key: str) -> Path:
        # Receipt schemas are immutable interpretation domains.  v2 occupied
        # the unversioned path below ``actions/``; v3 must coexist with it and
        # must never parse, overwrite, or delete those historical bytes.
        return (
            self.root
            / "actions"
            / _CAS_RECEIPT_NAMESPACE
            / action_key[:2]
            / f"{action_key}.json"
        )

    def _legacy_v2_receipt_path(self, action_key: str) -> Path:
        return self.root / "actions" / action_key[:2] / f"{action_key}.json"

    def _blob_path(self, digest: str) -> Path:
        return self.root / "blobs" / digest[:2] / digest

    def _open_input_blob_shard(self, digest: str) -> tuple[Path, int]:
        """Open a real CAS shard directory without following CAS symlinks."""

        shard = self.root / "blobs" / digest[:2]
        descriptor = _open_directory_nofollow(
            shard,
            where="CAS input directory",
            create=True,
        )
        return shard / digest, descriptor

    def _publish_staged_input_blob(
        self, staging: Path, contract: Mapping[str, object]
    ) -> tuple[Path, bool]:
        """Link a verified staging inode into the CAS and verify its name.

        ``staging`` is the private, read-only inode just returned by
        ``_copy_to_staging`` together with ``contract``.  If this process wins
        the hard-link publication, identity of the canonical name to that
        already-hashed inode proves the content without rereading a potentially
        huge payload.  A pre-existing race winner remains untrusted and is
        always reopened and hashed in full.
        """

        digest = str(contract["sha256"])
        blob_path, directory_fd = self._open_input_blob_shard(digest)
        try:
            source_fd = _open_directory_nofollow(
                staging.parent, where="CAS staging directory"
            )
        except BaseException:
            os.close(directory_fd)
            raise
        try:
            try:
                staged_identity = os.stat(
                    staging.name, dir_fd=source_fd, follow_symlinks=False
                )
            except OSError as exc:
                raise CASTamperError(
                    f"CAS staging file changed before publication: {staging}"
                ) from exc
            if not stat.S_ISREG(staged_identity.st_mode):
                raise CASTamperError(
                    f"CAS staging file is not regular: {staging}"
                )
            if staged_identity.st_mode & 0o222:
                raise CASTamperError(
                    f"CAS staging file is writable: {staging}"
                )
            if staged_identity.st_size != int(contract["bytes"]):
                raise CASTamperError(
                    f"CAS staging file size differs from its contract: {staging}"
                )
            try:
                os.link(
                    staging.name,
                    digest,
                    src_dir_fd=source_fd,
                    dst_dir_fd=directory_fd,
                    follow_symlinks=False,
                )
                won = True
            except FileExistsError:
                won = False
            if won:
                os.fsync(directory_fd)
                flags = (
                    os.O_RDONLY
                    | os.O_CLOEXEC
                    | os.O_NOFOLLOW
                    | getattr(os, "O_NONBLOCK", 0)
                )
                try:
                    published_fd = _open_retrying_would_block(
                        digest, flags, dir_fd=directory_fd
                    )
                except OSError as exc:
                    raise CASTamperError(
                        f"published CAS blob changed before readback: {blob_path}"
                    ) from exc
                try:
                    published_identity = os.fstat(published_fd)
                    if _substantive_file_read_identity(
                        published_identity
                    ) != _substantive_file_read_identity(staged_identity):
                        fields = (
                            "st_dev", "st_ino", "st_size", "st_mode",
                            "st_uid", "st_gid", "st_mtime_ns",
                        )
                        identity = {
                            name: {field: getattr(info, field) for field in fields}
                            for name, info in (
                                ("staged", staged_identity),
                                ("published", published_identity),
                            )
                        }
                        raise CASTamperError(
                            "published CAS blob differs from the verified staging "
                            f"inode: {blob_path}; identity="
                            f"{json.dumps(identity, sort_keys=True)}"
                        )
                    _assert_regular_identity(
                        published_fd,
                        directory_fd,
                        blob_path,
                        where="published CAS blob",
                    )
                finally:
                    os.close(published_fd)
            _assert_directory_identity(
                source_fd, staging.parent, where="CAS staging directory"
            )
            _assert_directory_identity(
                directory_fd, blob_path.parent, where="CAS blob directory"
            )
        finally:
            os.close(source_fd)
            os.close(directory_fd)
        if won:
            return blob_path, True
        # A different inode won the content address.  Its name is only a claim;
        # reopen and hash every byte before it can satisfy this publication.
        return self._verify_input_blob(contract), False

    def ingest_input(
        self,
        source_path: str | Path,
        *,
        input_id: str,
        expected_sha256: str | None = None,
        expected_bytes: int | None = None,
    ) -> tuple[dict[str, object], bool]:
        """Publish one stable file snapshot as an immutable action input.

        The digest and byte count are derived from the staged bytes.  Optional
        expectations fail before publication when the source differs.  The
        returned row can be inserted directly into ``action.inputs``; ``won``
        is false only when an independently verified identical blob already
        occupied the content address.
        """

        identity = _text(input_id, where="input id", pattern=_ID_RE)
        expected_digest = (
            _sha256(expected_sha256, where="expected input sha256")
            if expected_sha256 is not None
            else None
        )
        expected_size = (
            _nonnegative_integer(expected_bytes, where="expected input bytes")
            if expected_bytes is not None
            else None
        )
        with _private_staging_directory(self.root / ".staging") as private:
            staging, digest, size = _copy_to_staging(Path(source_path), private)
            try:
                if expected_digest is not None and digest != expected_digest:
                    raise ActionContractError(
                        "ingested input sha256 differs from the expected digest"
                    )
                if expected_size is not None and size != expected_size:
                    raise ActionContractError(
                        "ingested input byte count differs from the expected size"
                    )
                entry = validate_input_contract(
                    {"id": identity, "sha256": digest, "bytes": size}
                )
                contract = {"sha256": digest, "bytes": size}
                _, won = self._publish_staged_input_blob(staging, contract)
                return entry, won
            finally:
                _unlink_nofollow(staging, where="CAS staging file")

    def ingest_bytes(
        self, raw: bytes, *, input_id: str
    ) -> tuple[dict[str, object], bool]:
        """Publish bytes held in memory as an immutable action input.

        ``ingest_input`` for a payload that was never a file.  It publishes
        through the same staging inode and the same hard-link race, so the
        blob is indistinguishable from one ingested off disk -- which is the
        point: a reader cannot tell, and must not have to.
        """

        identity = _text(input_id, where="input id", pattern=_ID_RE)
        if not isinstance(raw, (bytes, bytearray)):
            raise ActionContractError(
                f"ingested input bytes must be bytes, not {type(raw).__name__}"
            )
        raw = bytes(raw)
        with _private_staging_directory(self.root / ".staging") as private:
            staging, digest, size = _stage_bytes(raw, private)
            try:
                entry = validate_input_contract(
                    {"id": identity, "sha256": digest, "bytes": size}
                )
                _, won = self._publish_staged_input_blob(
                    staging, {"sha256": digest, "bytes": size}
                )
                return entry, won
            finally:
                _unlink_nofollow(staging, where="CAS staging file")

    def blob_path(self, digest: str) -> Path:
        """Where a blob of this digest lives, whether or not it is there yet.

        Naming is not verification, and the two have different callers.  A
        worker about to read an input calls ``input_path``, which reads the
        whole blob back to prove it is the bytes the action named.  A
        submitter sealing a CAS path into an action's command needs only the
        name, and needs it for a blob it has just written itself -- re-reading
        it would prove nothing the ingest did not already prove, and on a
        campaign's worth of children it would do so once per child.
        """

        return self._blob_path(_sha256(digest, where="CAS blob digest"))

    def input_path(self, input_contract: object) -> Path:
        """Return an action input's CAS path after full content verification."""

        entry = validate_input_contract(input_contract)
        return self._verify_input_blob(
            {"sha256": entry["sha256"], "bytes": entry["bytes"]}
        )

    def publish_action_request(self, action: object) -> Path:
        """Publish the canonical immutable request consumed by remote workers."""

        normalized = validate_action(action)
        key = str(normalized["action_key"])
        path = self.root / "requests" / key[:2] / f"{key}.json"
        raw = _canonical_file_bytes(normalized)
        won = _atomic_publish(path, raw)
        if not won:
            observed = _read_regular_file_nofollow(
                path,
                where="PrismaBuild action request",
                require_readonly=True,
            )
            if observed != raw:
                raise CASTamperError(
                    "existing PrismaBuild action request differs from its action key"
                )
        # Re-read after either side of a publication race.  A scheduler must
        # never send a path whose bytes the submitter merely assumes.
        verified = _read_regular_file_nofollow(
            path,
            where="PrismaBuild action request",
            require_readonly=True,
        )
        if verified != raw:
            raise CASTamperError(
                "published PrismaBuild action request failed canonical readback"
            )
        return path

    def _load_receipt_bytes(self, path: Path) -> bytes:
        try:
            return _read_regular_file_nofollow(
                path, where="CAS receipt", require_readonly=True
            )
        except FileNotFoundError as exc:
            raise FileNotFoundError(path) from exc

    def _validate_receipt(
        self, value: object, *, action: Mapping[str, object]
    ) -> dict[str, object]:
        try:
            receipt = _exact_mapping(value, keys=_RECEIPT_KEYS, where="CAS receipt")
            if receipt["schema"] != CAS_RECEIPT_SCHEMA_V3:
                _fail(f"CAS receipt schema must be {CAS_RECEIPT_SCHEMA_V3!r}")
            action_key = _sha256(receipt["action_key"], where="CAS receipt.action_key")
            if action_key != action["action_key"]:
                _fail("CAS receipt action_key differs from the requested action")
            manifest_sha = _sha256(
                receipt["action_manifest_sha256"],
                where="CAS receipt.action_manifest_sha256",
            )
            if manifest_sha != canonical_sha256(action):
                _fail("CAS receipt action manifest digest differs from the action")
            raw_result = _exact_mapping(
                receipt["result"], keys=_RESULT_KEYS, where="CAS receipt.result"
            )
            result = {
                "sha256": _sha256(
                    raw_result["sha256"], where="CAS receipt.result.sha256"
                ),
                "bytes": _nonnegative_integer(
                    raw_result["bytes"], where="CAS receipt.result.bytes"
                ),
            }
            raw_producer = _exact_mapping(
                receipt["producer"],
                keys=_PRODUCER_KEYS,
                where="CAS receipt.producer",
            )
            # Publication runs this preflight live.  Lookup independently
            # replays its derivations and action binding from persisted data.
            producer = validate_worker_attestation(raw_producer, action=action)
            body = {
                "schema": CAS_RECEIPT_SCHEMA_V3,
                "action_key": action_key,
                "action_manifest_sha256": manifest_sha,
                "result": result,
                "producer": producer,
            }
            recorded = _sha256(
                receipt["receipt_sha256"], where="CAS receipt.receipt_sha256"
            )
            if recorded != canonical_sha256(body):
                _fail("CAS receipt.receipt_sha256 does not match its body")
            return {**body, "receipt_sha256": recorded}
        except ActionContractError as exc:
            raise CASTamperError(str(exc)) from exc

    def _verify_blob(
        self,
        result: Mapping[str, object],
        *,
        writable_label: str = "CAS payload",
    ) -> Path:
        digest = str(result["sha256"])
        path = self._blob_path(digest)
        try:
            observed_digest, observed_size, observed_mode = _file_identity_nofollow(
                path,
                where="CAS payload",
                expected_sha256=digest,
                expected_bytes=int(result["bytes"]),
            )
        except FileNotFoundError as exc:
            raise CASTamperError(f"CAS payload is missing: {path}") from exc
        if observed_size != result["bytes"]:
            raise CASTamperError(
                f"CAS payload content differs from receipt (size mismatch): {path}"
            )
        if observed_digest != digest or observed_size != result["bytes"]:
            raise CASTamperError(
                f"CAS payload content differs from receipt: {path}"
            )
        if observed_mode & 0o222:
            raise CASTamperError(f"{writable_label} is writable: {path}")
        return path

    def _verify_input_blob(self, contract: Mapping[str, object]) -> Path:
        return self._verify_blob(contract, writable_label="CAS input payload")

    def _lookup_receipt_only(
        self, action: Mapping[str, object]
    ) -> dict[str, object] | None:
        """Validate canonical receipt bytes without consuming its blob."""

        path = self._receipt_path(str(action["action_key"]))
        try:
            raw = self._load_receipt_bytes(path)
        except FileNotFoundError:
            return None
        try:
            value = _decode_strict_json(raw, where="CAS receipt")
            receipt = self._validate_receipt(value, action=action)
        except ActionContractError as exc:
            raise CASTamperError(str(exc)) from exc
        if raw != _canonical_file_bytes(receipt):
            raise CASTamperError("CAS receipt bytes are not canonical JSON")
        return receipt

    def lookup(self, action: object) -> dict[str, object] | None:
        """Return a content-verified v3 receipt, or ``None`` on a v3 miss.

        An unversioned legacy-v2 receipt is deliberately neither migrated nor
        interpreted here.  It remains immutable history while v3 recomputes
        into its disjoint namespace.
        """

        normalized = validate_action(action)
        receipt = self._lookup_receipt_only(normalized)
        if receipt is None:
            return None
        self._verify_blob(receipt["result"])  # type: ignore[arg-type]
        return receipt

    def _verified_receipt_result_path(self, receipt: Mapping[str, object]) -> Path:
        """Return the blob path after ``lookup`` has already verified it."""

        result = receipt["result"]
        assert isinstance(result, Mapping)
        return self._blob_path(str(result["sha256"]))

    def result_path(self, receipt: object, action: object) -> Path:
        normalized = validate_action(action)
        validated = self._validate_receipt(receipt, action=normalized)
        return self._verify_blob(validated["result"])  # type: ignore[arg-type]

    def publish_result(
        self,
        action: object,
        result_path: str | Path,
        *,
        attestation: object,
        precommit_verify: Callable[[], None] | None = None,
        staging_namespace: str | None = None,
    ) -> tuple[dict[str, object], bool]:
        """Publish a result and return ``(canonical_receipt, won_publication)``.

        A losing deterministic producer must reproduce the winner byte-for-byte;
        a stochastic producer accepts the already-published canonical result.
        ``precommit_verify`` runs after the payload copy and temporary receipt
        fsync. Local workers use it for their action-specific closure checks;
        the worker core and optional script launcher are rechecked after that
        callback as the final userspace operation before the no-clobber link.
        This cannot make mutable source an immutable snapshot; the remaining
        verification-to-link syscall interval is deliberately small.
        """

        normalized = validate_action(action)
        producer = validate_worker_attestation(attestation, action=normalized)
        if staging_namespace is None:
            staging_directory = self.root / ".staging"
        else:
            namespace = _sha256(
                staging_namespace, where="result staging namespace"
            )
            staging_directory = (
                self.root / ".staging" / "local-results" / namespace
            )
        staging, digest, size = _copy_to_staging(
            Path(result_path), staging_directory
        )
        result = {"sha256": digest, "bytes": size}
        try:
            _, blob_won = self._publish_staged_input_blob(staging, result)
            body: dict[str, object] = {
                "schema": CAS_RECEIPT_SCHEMA_V3,
                "action_key": normalized["action_key"],
                "action_manifest_sha256": canonical_sha256(normalized),
                "result": result,
                "producer": producer,
            }
            candidate = {**body, "receipt_sha256": canonical_sha256(body)}
            receipt_path = self._receipt_path(str(normalized["action_key"]))

            def verify_publication_provenance() -> None:
                # Action-specific closure/executable checks may be relatively
                # slow.  Run them first so the runtime recheck is the final
                # userspace operation before _atomic_publish calls os.link.
                if precommit_verify is not None:
                    precommit_verify()
                _verify_worker_runtime_unchanged(producer["runtime"])

            won = _atomic_publish(
                receipt_path,
                _canonical_file_bytes(candidate),
                prelink_verify=verify_publication_provenance,
            )
            # The canonical blob was already consumed above: a winning link
            # was proven identical to our private hashed staging inode, while
            # a losing link was hashed in full.  Re-read and validate the
            # receipt, but do not perform a redundant full blob pass when it
            # names that same result.
            canonical = self._lookup_receipt_only(normalized)
            if canonical is None:
                raise CASTamperError("CAS receipt vanished after publication race")
            if won:
                if canonical != candidate:
                    raise CASTamperError(
                        "published CAS receipt failed canonical readback"
                    )
                return canonical, True
            task = normalized["task"]
            assert isinstance(task, Mapping)
            canonical_result = canonical["result"]
            assert isinstance(canonical_result, Mapping)
            if canonical_result != result:
                # A stochastic receipt race may select a different blob.  It
                # has not been consumed by this publication and must retain
                # the ordinary full-content verification contract.
                self._verify_blob(canonical_result)
            if task["determinism"] == "deterministic" and canonical_result != result:
                raise CASConflictError(
                    "deterministic recomputation differs from the canonical CAS result"
                )
            return canonical, False
        finally:
            _unlink_nofollow(staging, where="CAS staging file")


def _validate_initial_miss_rendezvous_manifest(
    value: object, *, action: Mapping[str, object], cas: PrismaBuildCAS
) -> dict[str, object]:
    raw = _exact_mapping(
        value,
        keys=_INITIAL_MISS_RENDEZVOUS_MANIFEST_KEYS,
        where="initial-miss rendezvous manifest",
    )
    if raw["schema"] != INITIAL_MISS_RENDEZVOUS_MANIFEST_SCHEMA_V1:
        _fail(
            "initial-miss rendezvous manifest.schema must be "
            f"{INITIAL_MISS_RENDEZVOUS_MANIFEST_SCHEMA_V1!r}"
        )
    namespace_text = _text(
        raw["rendezvous_namespace"],
        where="initial-miss rendezvous manifest.rendezvous_namespace",
    )
    namespace = Path(namespace_text)
    if (
        not namespace.is_absolute()
        or namespace == Path("/")
        or ".." in namespace.parts
        or str(namespace) != namespace_text
    ):
        _fail(
            "initial-miss rendezvous namespace must be a normalized, "
            "non-root absolute path"
        )
    cas_root_text = _text(
        raw["cas_root"],
        where="initial-miss rendezvous manifest.cas_root",
    )
    cas_root = Path(cas_root_text)
    if (
        not cas_root.is_absolute()
        or cas_root == Path("/")
        or ".." in cas_root.parts
        or str(cas_root) != cas_root_text
    ):
        _fail(
            "initial-miss rendezvous CAS root must be a normalized, "
            "non-root absolute path"
        )
    if cas_root != cas.root:
        _fail("initial-miss rendezvous CAS root differs from the worker CAS")
    run_nonce = _text(
        raw["run_nonce"],
        where="initial-miss rendezvous manifest.run_nonce",
        pattern=_RUN_NONCE_RE,
    )
    action_key = _sha256(
        raw["action_key"],
        where="initial-miss rendezvous manifest.action_key",
    )
    if action_key != action["action_key"]:
        _fail("initial-miss rendezvous manifest action_key differs from the action")
    participants_raw = raw["participants"]
    if type(participants_raw) is not list or len(participants_raw) != 2:
        _fail(
            "initial-miss rendezvous manifest.participants must contain "
            "exactly two hostnames"
        )
    participants = [
        _text(
            participant,
            where=f"initial-miss rendezvous manifest.participants[{index}]",
            pattern=_HOSTNAME_RE,
        )
        for index, participant in enumerate(participants_raw)
    ]
    if participants != sorted(participants) or len(set(participants)) != 2:
        _fail(
            "initial-miss rendezvous participants must be exact, sorted, "
            "unique lowercase hostnames"
        )
    timeout_raw = raw["timeout_seconds"]
    if (
        type(timeout_raw) not in {int, float}
        or not math.isfinite(float(timeout_raw))
        or float(timeout_raw) <= 0.0
        or float(timeout_raw) > _MAX_INITIAL_MISS_RENDEZVOUS_TIMEOUT_SECONDS
    ):
        _fail(
            "initial-miss rendezvous timeout_seconds must be a positive finite "
            f"number no greater than {_MAX_INITIAL_MISS_RENDEZVOUS_TIMEOUT_SECONDS}"
        )
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_MANIFEST_SCHEMA_V1,
        "rendezvous_namespace": namespace_text,
        "cas_root": cas_root_text,
        "run_nonce": run_nonce,
        "action_key": action_key,
        "participants": participants,
        "timeout_seconds": timeout_raw,
    }
    manifest_sha256 = _sha256(
        raw["manifest_sha256"],
        where="initial-miss rendezvous manifest.manifest_sha256",
    )
    if manifest_sha256 != canonical_sha256(body):
        _fail("initial-miss rendezvous manifest digest does not match its body")
    return {**body, "manifest_sha256": manifest_sha256}


def _load_initial_miss_rendezvous_manifest(
    path: str | Path, *, action: Mapping[str, object], cas: PrismaBuildCAS
) -> dict[str, object]:
    manifest_path = Path(path)
    if (
        not manifest_path.is_absolute()
        or manifest_path == Path("/")
        or ".." in manifest_path.parts
    ):
        raise ActionContractError(
            "initial-miss rendezvous manifest path must be a non-root absolute path"
        )
    raw = _read_regular_file_nofollow(
        manifest_path,
        where="initial-miss rendezvous manifest",
        require_readonly=True,
        require_single_link=True,
        max_bytes=_MAX_INITIAL_MISS_RENDEZVOUS_BYTES,
    )
    value = _decode_strict_json(raw, where="initial-miss rendezvous manifest")
    manifest = _validate_initial_miss_rendezvous_manifest(
        value, action=action, cas=cas
    )
    if raw != _canonical_file_bytes(manifest):
        raise ActionContractError(
            "initial-miss rendezvous manifest bytes are not canonical JSON"
        )
    return manifest


def _initial_miss_hostname() -> str:
    """Derive the exact lowercase host participant; never trust environment."""

    hostname = socket.gethostname().lower()
    return _text(
        hostname,
        where="initial-miss rendezvous local hostname",
        pattern=_HOSTNAME_RE,
    )


def _process_start_ticks() -> int:
    """Return this process's Linux start tick, disambiguating PID reuse."""

    pid = os.getpid()
    raw = _read_regular_file(
        Path(f"/proc/{pid}/stat"), where="initial-miss rendezvous process stat"
    )
    try:
        text = raw.decode("ascii")
    except UnicodeDecodeError as exc:
        raise InitialMissRendezvousError(
            "initial-miss rendezvous process stat is not ASCII"
        ) from exc
    close = text.rfind(")")
    if close < 0 or text[:close].split("(", 1)[0].strip() != str(pid):
        raise InitialMissRendezvousError(
            "initial-miss rendezvous process stat has a mismatched PID"
        )
    fields = text[close + 1 :].split()
    if len(fields) <= 19 or re.fullmatch(r"[1-9][0-9]*", fields[19]) is None:
        raise InitialMissRendezvousError(
            "initial-miss rendezvous process stat has no canonical start tick"
        )
    return int(fields[19])


def _initial_miss_process_identity(
    *, hostname: str, worker_launcher_identity: object | None
) -> dict[str, object]:
    runtime = _worker_runtime_identity(worker_launcher_identity)
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_PROCESS_SCHEMA_V1,
        "hostname": hostname,
        "pid": os.getpid(),
        "proc_start_ticks": _process_start_ticks(),
        "invocation_nonce": os.urandom(16).hex(),
        "runtime": runtime,
    }
    return {**body, "process_identity_sha256": canonical_sha256(body)}


def _validate_initial_miss_process_identity(
    value: object,
    *,
    participant: str,
    runtime: Mapping[str, object],
) -> dict[str, object]:
    raw = _exact_mapping(
        value,
        keys=_INITIAL_MISS_RENDEZVOUS_PROCESS_KEYS,
        where="initial-miss rendezvous process identity",
    )
    if raw["schema"] != INITIAL_MISS_RENDEZVOUS_PROCESS_SCHEMA_V1:
        _fail("initial-miss rendezvous process identity schema is unsupported")
    hostname = _text(
        raw["hostname"],
        where="initial-miss rendezvous process identity.hostname",
        pattern=_HOSTNAME_RE,
    )
    if hostname != participant:
        _fail("initial-miss rendezvous process hostname differs from participant")
    pid = raw["pid"]
    start_ticks = raw["proc_start_ticks"]
    if type(pid) is not int or pid <= 0:
        _fail("initial-miss rendezvous process pid must be positive")
    if type(start_ticks) is not int or start_ticks <= 0:
        _fail("initial-miss rendezvous process start tick must be positive")
    invocation_nonce = _text(
        raw["invocation_nonce"],
        where="initial-miss rendezvous process identity.invocation_nonce",
        pattern=_INVOCATION_NONCE_RE,
    )
    observed_runtime = _validate_worker_runtime(raw["runtime"])
    if observed_runtime != runtime:
        _fail(
            "initial-miss rendezvous participant runtime differs from the "
            "loaded core and launcher identity"
        )
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_PROCESS_SCHEMA_V1,
        "hostname": hostname,
        "pid": pid,
        "proc_start_ticks": start_ticks,
        "invocation_nonce": invocation_nonce,
        "runtime": observed_runtime,
    }
    digest = _sha256(
        raw["process_identity_sha256"],
        where="initial-miss rendezvous process identity digest",
    )
    if digest != canonical_sha256(body):
        _fail("initial-miss rendezvous process identity digest does not match")
    return {**body, "process_identity_sha256": digest}


def _initial_miss_arrival(
    *,
    manifest: Mapping[str, object],
    participant: str,
    process: Mapping[str, object],
) -> dict[str, object]:
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_ARRIVAL_SCHEMA_V1,
        "manifest_sha256": manifest["manifest_sha256"],
        "run_nonce": manifest["run_nonce"],
        "action_key": manifest["action_key"],
        "participant": participant,
        "process": process,
        "observation": "initial_cas_lookup_absent",
    }
    return {**body, "arrival_sha256": canonical_sha256(body)}


def _validate_initial_miss_arrival(
    value: object,
    *,
    manifest: Mapping[str, object],
    participant: str,
    runtime: Mapping[str, object],
) -> dict[str, object]:
    raw = _exact_mapping(
        value,
        keys=_INITIAL_MISS_RENDEZVOUS_ARRIVAL_KEYS,
        where="initial-miss rendezvous arrival",
    )
    if raw["schema"] != INITIAL_MISS_RENDEZVOUS_ARRIVAL_SCHEMA_V1:
        _fail("initial-miss rendezvous arrival schema is unsupported")
    for key in ("manifest_sha256", "run_nonce", "action_key"):
        if raw[key] != manifest[key]:
            _fail(f"initial-miss rendezvous arrival {key} differs from manifest")
    observed_participant = _text(
        raw["participant"],
        where="initial-miss rendezvous arrival.participant",
        pattern=_HOSTNAME_RE,
    )
    if observed_participant != participant:
        _fail("initial-miss rendezvous arrival participant differs from filename")
    if raw["observation"] != "initial_cas_lookup_absent":
        _fail("initial-miss rendezvous arrival observation is unsupported")
    process = _validate_initial_miss_process_identity(
        raw["process"], participant=participant, runtime=runtime
    )
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_ARRIVAL_SCHEMA_V1,
        "manifest_sha256": manifest["manifest_sha256"],
        "run_nonce": manifest["run_nonce"],
        "action_key": manifest["action_key"],
        "participant": participant,
        "process": process,
        "observation": "initial_cas_lookup_absent",
    }
    digest = _sha256(
        raw["arrival_sha256"], where="initial-miss rendezvous arrival digest"
    )
    if digest != canonical_sha256(body):
        _fail("initial-miss rendezvous arrival digest does not match")
    return {**body, "arrival_sha256": digest}


def _initial_miss_ready(
    *,
    manifest: Mapping[str, object],
    participant: str,
    process: Mapping[str, object],
    arrival: Mapping[str, object],
    arrival_set_sha256: str,
) -> dict[str, object]:
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_READY_SCHEMA_V1,
        "manifest_sha256": manifest["manifest_sha256"],
        "run_nonce": manifest["run_nonce"],
        "action_key": manifest["action_key"],
        "participant": participant,
        "process_identity_sha256": process["process_identity_sha256"],
        "arrival_sha256": arrival["arrival_sha256"],
        "arrival_set_sha256": arrival_set_sha256,
        "observation": "cas_absent_after_complete_arrival_set",
    }
    return {**body, "ready_sha256": canonical_sha256(body)}


def _validate_initial_miss_ready(
    value: object,
    *,
    manifest: Mapping[str, object],
    participant: str,
    arrivals: Mapping[str, Mapping[str, object]],
    arrival_set_sha256: str,
) -> dict[str, object]:
    raw = _exact_mapping(
        value,
        keys=_INITIAL_MISS_RENDEZVOUS_READY_KEYS,
        where="initial-miss rendezvous ready record",
    )
    if raw["schema"] != INITIAL_MISS_RENDEZVOUS_READY_SCHEMA_V1:
        _fail("initial-miss rendezvous ready schema is unsupported")
    for key in ("manifest_sha256", "run_nonce", "action_key"):
        if raw[key] != manifest[key]:
            _fail(f"initial-miss rendezvous ready {key} differs from manifest")
    observed_participant = _text(
        raw["participant"],
        where="initial-miss rendezvous ready.participant",
        pattern=_HOSTNAME_RE,
    )
    if observed_participant != participant:
        _fail("initial-miss rendezvous ready participant differs from filename")
    arrival = arrivals[participant]
    process = arrival["process"]
    if not isinstance(process, Mapping):
        _fail("initial-miss rendezvous arrival process is not an object")
    if raw["process_identity_sha256"] != process["process_identity_sha256"]:
        _fail("initial-miss rendezvous ready process differs from its arrival")
    if raw["arrival_sha256"] != arrival["arrival_sha256"]:
        _fail("initial-miss rendezvous ready record differs from its arrival")
    if raw["arrival_set_sha256"] != arrival_set_sha256:
        _fail("initial-miss rendezvous ready record binds the wrong arrival set")
    if raw["observation"] != "cas_absent_after_complete_arrival_set":
        _fail("initial-miss rendezvous ready observation is unsupported")
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_READY_SCHEMA_V1,
        "manifest_sha256": manifest["manifest_sha256"],
        "run_nonce": manifest["run_nonce"],
        "action_key": manifest["action_key"],
        "participant": participant,
        "process_identity_sha256": process["process_identity_sha256"],
        "arrival_sha256": arrival["arrival_sha256"],
        "arrival_set_sha256": arrival_set_sha256,
        "observation": "cas_absent_after_complete_arrival_set",
    }
    digest = _sha256(
        raw["ready_sha256"], where="initial-miss rendezvous ready digest"
    )
    if digest != canonical_sha256(body):
        _fail("initial-miss rendezvous ready digest does not match")
    return {**body, "ready_sha256": digest}


def _rendezvous_directory_entries(path: Path, *, where: str) -> set[str]:
    descriptor = _open_directory_nofollow(path, where=where)
    try:
        try:
            names: list[str] = []
            with os.scandir(descriptor) as entries:
                for entry in entries:
                    names.append(entry.name)
                    if (
                        len(names)
                        > _MAX_INITIAL_MISS_RENDEZVOUS_DIRECTORY_ENTRIES
                    ):
                        raise InitialMissRendezvousError(
                            f"{where} exceeds the bounded entry count"
                        )
        except InitialMissRendezvousError:
            raise
        except OSError as exc:
            raise InitialMissRendezvousError(
                f"cannot list {where}: {path}: {exc}"
            ) from exc
        if any(type(name) is not str for name in names):
            raise InitialMissRendezvousError(
                f"{where} returned a non-text directory entry"
            )
        _assert_directory_identity(descriptor, path, where=where)
        return set(names)
    finally:
        os.close(descriptor)


def _initial_miss_phase_temp_name(name: str, expected: set[str]) -> bool:
    return any(
        name.startswith(f".{leaf}.") and name.endswith(".tmp")
        for leaf in expected
    )


def _scan_initial_miss_phase(
    directory: Path,
    *,
    phase: str,
    participants: Sequence[str],
    validate: Callable[[object, str], dict[str, object]],
) -> dict[str, dict[str, object]] | None:
    expected = {f"{participant}.json" for participant in participants}
    observed = _rendezvous_directory_entries(
        directory, where=f"initial-miss rendezvous {phase} directory"
    )
    unexpected = {
        name
        for name in observed - expected
        if not _initial_miss_phase_temp_name(name, expected)
    }
    if unexpected:
        raise InitialMissRendezvousError(
            f"initial-miss rendezvous {phase} directory has unexpected entries: "
            f"{sorted(unexpected)}"
        )
    incomplete = observed != expected
    records: dict[str, dict[str, object]] = {}
    for participant in participants:
        leaf = f"{participant}.json"
        if leaf not in observed:
            continue
        path = directory / leaf
        try:
            raw = _read_regular_file_nofollow(
                path,
                where=f"initial-miss rendezvous {phase} record",
                require_readonly=True,
                require_single_link=True,
                max_bytes=_MAX_INITIAL_MISS_RENDEZVOUS_BYTES,
            )
        except FileNotFoundError:
            incomplete = True
            continue
        except _FileLinkCountError:
            # A valid hard-link publication briefly has two names until its
            # private temporary name is removed.  It may become acceptable,
            # but a persistent or hostile hard link can only reach timeout.
            incomplete = True
            continue
        value = _decode_strict_json(
            raw, where=f"initial-miss rendezvous {phase} record"
        )
        record = validate(value, participant)
        if raw != _canonical_file_bytes(record):
            raise InitialMissRendezvousError(
                f"initial-miss rendezvous {phase} record is not canonical JSON"
            )
        records[participant] = record
    after = _rendezvous_directory_entries(
        directory, where=f"initial-miss rendezvous {phase} directory"
    )
    after_unexpected = {
        name
        for name in after - expected
        if not _initial_miss_phase_temp_name(name, expected)
    }
    if after_unexpected:
        raise InitialMissRendezvousError(
            f"initial-miss rendezvous {phase} directory has unexpected entries: "
            f"{sorted(after_unexpected)}"
        )
    if after != expected or len(records) != len(expected):
        incomplete = True
    return None if incomplete else records


def _publish_initial_miss_record(
    path: Path,
    record: Mapping[str, object],
    *,
    phase: str,
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    runtime: Mapping[str, object],
) -> None:
    def verify_absence_and_runtime() -> None:
        if cas.lookup(action) is not None:
            raise InitialMissRendezvousError(
                "CAS receipt appeared before initial-miss rendezvous release"
            )
        _verify_worker_runtime_unchanged(runtime)

    if not _atomic_publish(
        path,
        _canonical_file_bytes(record),
        prelink_verify=verify_absence_and_runtime,
    ):
        raise InitialMissRendezvousError(
            f"duplicate or replayed initial-miss rendezvous {phase} participant: "
            f"{path.stem}"
        )


def _wait_initial_miss_arrivals(
    *,
    directory: Path,
    manifest: Mapping[str, object],
    runtime: Mapping[str, object],
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    deadline: float,
) -> dict[str, dict[str, object]]:
    participants = manifest["participants"]
    if not isinstance(participants, list):
        raise InitialMissRendezvousError(
            "validated rendezvous participants are not an array"
        )
    while True:
        records = _scan_initial_miss_phase(
            directory,
            phase="arrival",
            participants=participants,
            validate=lambda value, participant: _validate_initial_miss_arrival(
                value,
                manifest=manifest,
                participant=participant,
                runtime=runtime,
            ),
        )
        # Complete arrivals are not a release. Every participant must make a
        # fresh absence observation before publishing its second-phase ready.
        if cas.lookup(action) is not None:
            raise InitialMissRendezvousError(
                "CAS receipt appeared before initial-miss arrivals completed"
            )
        if records is not None:
            return records
        remaining = deadline - time.monotonic()
        if remaining <= 0.0:
            raise InitialMissRendezvousError(
                "initial-miss rendezvous timed out waiting for exact arrivals"
            )
        time.sleep(min(_INITIAL_MISS_RENDEZVOUS_POLL_SECONDS, remaining))


def _wait_initial_miss_ready(
    *,
    directory: Path,
    manifest: Mapping[str, object],
    arrivals: Mapping[str, Mapping[str, object]],
    arrival_set_sha256: str,
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    deadline: float,
) -> dict[str, dict[str, object]]:
    participants = manifest["participants"]
    if not isinstance(participants, list):
        raise InitialMissRendezvousError(
            "validated rendezvous participants are not an array"
        )
    receipt_observed = False
    while True:
        records = _scan_initial_miss_phase(
            directory,
            phase="ready",
            participants=participants,
            validate=lambda value, participant: _validate_initial_miss_ready(
                value,
                manifest=manifest,
                participant=participant,
                arrivals=arrivals,
                arrival_set_sha256=arrival_set_sha256,
            ),
        )
        # The exact second ready link is the logical release event. A fast
        # peer may legitimately acquire the output lock and publish after it;
        # do not turn that post-release receipt into a false refusal here.
        if records is not None:
            return records
        if not receipt_observed and cas.lookup(action) is not None:
            # Release may already have happened while NFS still returns a
            # stale ready-directory view. Once a receipt is visible, continue
            # bounded exact scans through the original monotonic deadline.
            # An actually missing in-protocol ready cannot newly link after
            # this observation because its pre-link CAS check fails closed.
            receipt_observed = True
        remaining = deadline - time.monotonic()
        if remaining <= 0.0:
            if receipt_observed:
                raise InitialMissRendezvousError(
                    "CAS receipt appeared before initial-miss ready release"
                )
            raise InitialMissRendezvousError(
                "initial-miss rendezvous timed out waiting for exact ready records"
            )
        time.sleep(min(_INITIAL_MISS_RENDEZVOUS_POLL_SECONDS, remaining))


def _run_initial_miss_rendezvous(
    *,
    manifest_path: str | Path,
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    worker_launcher_identity: object | None,
) -> dict[str, object]:
    """Prove exact peers observed one initial miss before either may publish."""

    manifest = _load_initial_miss_rendezvous_manifest(
        manifest_path, action=action, cas=cas
    )
    deadline = time.monotonic() + float(manifest["timeout_seconds"])
    participant = _initial_miss_hostname()
    participants = manifest["participants"]
    if not isinstance(participants, list) or participant not in participants:
        raise InitialMissRendezvousError(
            "local lowercase hostname is not an exact rendezvous participant"
        )
    process = _initial_miss_process_identity(
        hostname=participant,
        worker_launcher_identity=worker_launcher_identity,
    )
    runtime = process["runtime"]
    if not isinstance(runtime, Mapping):
        raise InitialMissRendezvousError(
            "initial-miss rendezvous runtime identity is not an object"
        )
    namespace = Path(str(manifest["rendezvous_namespace"]))
    for directory, where in (
        (namespace, "initial-miss rendezvous namespace"),
        (namespace / "arrivals", "initial-miss rendezvous arrival directory"),
        (namespace / "ready", "initial-miss rendezvous ready directory"),
    ):
        descriptor = _open_directory_nofollow(directory, where=where, create=True)
        os.close(descriptor)
    if _rendezvous_directory_entries(
        namespace, where="initial-miss rendezvous namespace"
    ) != {"arrivals", "ready"}:
        raise InitialMissRendezvousError(
            "initial-miss rendezvous namespace has missing or extra entries"
        )
    if time.monotonic() >= deadline:
        raise InitialMissRendezvousError(
            "initial-miss rendezvous timed out during manifest validation"
        )
    if cas.lookup(action) is not None:
        raise InitialMissRendezvousError(
            "CAS receipt appeared after the worker's initial miss"
        )
    arrival = _initial_miss_arrival(
        manifest=manifest,
        participant=participant,
        process=process,
    )
    _publish_initial_miss_record(
        namespace / "arrivals" / f"{participant}.json",
        arrival,
        phase="arrival",
        cas=cas,
        action=action,
        runtime=runtime,
    )
    arrivals = _wait_initial_miss_arrivals(
        directory=namespace / "arrivals",
        manifest=manifest,
        runtime=runtime,
        cas=cas,
        action=action,
        deadline=deadline,
    )
    arrival_set_sha256 = canonical_sha256(
        [arrivals[name] for name in participants]
    )
    # This is the second-phase observation required from every participant.
    # The same check runs again as the final userspace operation before link.
    if cas.lookup(action) is not None:
        raise InitialMissRendezvousError(
            "CAS receipt appeared before initial-miss ready publication"
        )
    ready = _initial_miss_ready(
        manifest=manifest,
        participant=participant,
        process=process,
        arrival=arrivals[participant],
        arrival_set_sha256=arrival_set_sha256,
    )
    _publish_initial_miss_record(
        namespace / "ready" / f"{participant}.json",
        ready,
        phase="ready",
        cas=cas,
        action=action,
        runtime=runtime,
    )
    ready_records = _wait_initial_miss_ready(
        directory=namespace / "ready",
        manifest=manifest,
        arrivals=arrivals,
        arrival_set_sha256=arrival_set_sha256,
        cas=cas,
        action=action,
        deadline=deadline,
    )
    _verify_worker_runtime_unchanged(runtime)
    ready_set_sha256 = canonical_sha256(
        [ready_records[name] for name in participants]
    )
    body: dict[str, object] = {
        "schema": INITIAL_MISS_RENDEZVOUS_RECEIPT_SCHEMA_V1,
        "manifest_sha256": manifest["manifest_sha256"],
        "rendezvous_namespace": manifest["rendezvous_namespace"],
        "cas_root": manifest["cas_root"],
        "run_nonce": manifest["run_nonce"],
        "action_key": manifest["action_key"],
        "participants": participants,
        "participant": participant,
        "process_identity_sha256": process["process_identity_sha256"],
        "arrival_sha256": arrival["arrival_sha256"],
        "ready_sha256": ready["ready_sha256"],
        "arrival_set_sha256": arrival_set_sha256,
        "ready_set_sha256": ready_set_sha256,
    }
    receipt = {**body, "receipt_sha256": canonical_sha256(body)}
    if set(receipt) != set(_INITIAL_MISS_RENDEZVOUS_RECEIPT_KEYS):
        raise InitialMissRendezvousError(
            "initial-miss rendezvous receipt schema drifted"
        )
    return receipt


# -- Opt-in profiles (issue #372, Tier 1) ------------------------------------
#
# Which profiler runs around an action's child, and what it must leave behind.
#
# Tier 1 of issue #372.  A submitter asks for a profile with ``pbrun --profile
# <mode>``; the mode is sealed into the action's params, and this module says
# what that mode means on the box that runs it.  Tier 2 adds ``torch``/``nsys``
# by putting another backend in :data:`BACKENDS`, which is why the selection is a
# table rather than a branch.
#
# Two mechanisms here are measured facts about this fleet rather than choices,
# and both are load-bearing.
#
# **The profiler is the child's parent.**  ``kernel.yama.ptrace_scope`` is 1 on
# dl380g10, sparky and sparklina (measured 2026-09-07), which lets a process
# trace only its own descendants.  A profiler started beside the action -- the
# ``--pid`` shape -- is the action's *sibling*, and attaching was refused with
# ``Permission Denied``.  ``prctl(PR_SET_PTRACER)`` on the child does not rescue
# it either: the sealed argv is ``bash -c '... | tee log; exit ${PIPESTATUS[0]}'``
# and bash *forks* a pipeline member rather than exec'ing it, so the Python
# process that does the work is a grandchild with no relation of its own, and
# py-spy answered ``No python processes found``.  Launching the profiler as the
# argv's parent satisfies the other clause Yama accepts, and it is the only
# shape that was measured to work on the real argv.  ``--subprocesses`` follows
# from the same fact: the process the profiler spawns is bash, not Python.
#
# **The action's exit status travels out of band.**  py-spy 0.4.2 exits 0
# whatever the program it ran exited (measured: a child exiting 3 and 7 both gave
# ``py-spy`` exit 0), so a profiled run that reported the launcher's status would
# call every failing action a pass.  :func:`profile_exit_status_relay` puts one
# process between the profiler and the sealed argv whose only job is to wait for
# it and write down how it ended.  The sealed argv is exec'd verbatim underneath,
# so the executed contract is the same one the unprofiled action has.
#
# **The relay waits, so it must be able to see a signal.**  The first version of
# this relay was ``/bin/sh -c '"$@"; printf %d $? > "$0"'``, and a shell reports
# a signalled child as 128+n with no way to tell it from a literal ``exit 137``.
# That made a profiled OOM-kill report ``returncode=137, signal=None`` where the
# unprofiled path reports ``-9`` and ``signal 9``: the shape of the failure
# record changed with the flag, which is the one thing an opt-in diagnostic must
# never do.  The relay is a Python process instead, because ``waitpid`` is the
# only interface on this box that distinguishes the two.  Its cost was measured
# rather than assumed (action ``83d2530f3eda`` on sparky, 2026-09-07): under
# ``py-spy record --subprocesses`` at 100 Hz, three paired repeats of the same
# fixed-work argv gave 41/46/31 samples through the shell relay and 43/35/49
# through this one, of which the relay's own interpreter startup accounted for
# 0/1/1.  py-spy excludes idle threads by default and the relay is blocked in
# ``waitpid`` for the whole run, so it is not in the flamegraph anybody reads.

#: The document a speedscope reader opens.  Checked rather than assumed: a
#: profiler that wrote a truncated or empty file has not produced a profile,
#: and the run that asked for one has to say so.
PROFILE_SPEEDSCOPE_SCHEMA = "https://www.speedscope.app/file-format-schema.json"

#: Samples per second for ``--profile sample``.  Measured through the fleet on
#: dl380g10 (action ``69a4a7fdf902``, 2026-09-07): a fixed-work ~60 s CPU loop,
#: five repeats per arm, 60.845 s +/- 1.310 unprofiled against 63.352 s +/-
#: 2.208 profiled -- 2.50 % on the medians, 4.12 % on the means, paired 95 %
#: interval 1.2-7.0 % (n = 5), on a box that other work had at loadavg
#: 1.4-3.4.  The tier's ~5 % budget is met as a point estimate, not
#: established.  ``docs/operating_prismabuild.md`` carries the table and the
#: paired deltas.  The rate is a property of the mode, not of the
#: submission, so it is reported in the ending and never sealed into the key.
PROFILE_SAMPLE_RATE_HZ = 100

#: Where a profile is written while the action runs.  Under the action's own
#: working directory: it is materialized for this attempt and removed with it,
#: and ``/tmp`` has taken artifacts on this fleet before.
PROFILE_SCRATCH_DIRNAME = ".prismabuild-profile"

#: The guard and the route marker a sampled action shares with PB's Docker
#: shim.  py-spy follows the action's own process tree, and a container the
#: Docker daemon starts is a child of ``containerd-shim`` rather than of the
#: action, so this descendant sampler does not see the workload it runs (#562).
#: The worker *arms* the marker before the action starts and the shim replaces
#: the armed record with a route record before it refuses, so a launcher that
#: swallows the shim's ``125`` and exits zero is still settled against a
#: marker that is missing, incomplete or malformed -- every one of which is
#: unknown coverage, never a clean profile.  The marker lives and dies with
#: the profile scratch directory.
PROFILE_SAMPLE_GUARD_ENV = "PRISMABUILD_PROFILE_SAMPLE"
PROFILE_SAMPLE_MARKER_ENV = "PRISMABUILD_PROFILE_SAMPLE_MARKER"
PROFILE_SAMPLE_ROUTE_FILENAME = "container-route"
PROFILE_ROUTE_SCHEMA = "prismabuild.profile_container_route.v1"
PROFILE_ROUTE_ARMED = "armed"
PROFILE_ROUTE_RECORDED = "route"
PROFILE_ROUTE_UNKNOWN = "unrecorded"
PROFILE_ROUTE_MAX_BYTES = 4096


def profile_container_route_path(profile_path: Path) -> Path:
    """The marker naming a Docker route attempted under ``--profile sample``."""

    return Path(profile_path).parent / PROFILE_SAMPLE_ROUTE_FILENAME


#: The relay's file format.  Named in the file it writes so a reader that
#: finds one from another era refuses it instead of misreading it.
PROFILE_EXIT_STATUS_SCHEMA = "prismabuild.profile_exit_status.v1"

#: How often the worker looks again when it is waiting for an action whose
#: profiler already exited.  Short enough not to add measurable wall time to a
#: settle, long enough not to spin on a filesystem for the length of an action.
_PROFILE_SETTLE_POLL_SECONDS = 0.05


class ProfileBackendUnavailable(Exception):
    """This box has no profiler for the mode the action asked for."""


class ProfileUnusable(Exception):
    """The profiler ran but left nothing a reader could open."""


#: The relay's whole program.  Small enough to read in one sitting, because it
#: is the only thing standing between a profiler and the truth about how an
#: action ended.
#:
#: ``close_fds=False`` is load-bearing rather than lax: ``_run_local_action``
#: hands the output lock's descriptor to the action so the exclusion outlives a
#: killed worker, and Python's default would close it here, one process short of
#: the argv that has to hold it.
#:
#: A launch that never happened is reported as a launch that never happened.
#: The unprofiled path calls a failing ``Popen`` a worker verdict, not an
#: action's ending; a relay that wrote ``127`` instead would turn one into the
#: other, and 127 is a status a shell really can return.
#:
#: It writes twice, and both writes are ``os.replace`` of a fully written file,
#: because a reader of this file has three questions and one write can only
#: answer two.  ``launched`` says the sealed argv is running and names its pid;
#: ``ended`` replaces it with how it ended.  A relay that is itself killed --
#: which is what a pool deadline does, since the pool signals the launcher's
#: whole session -- leaves ``launched`` behind, and that is how the timeout
#: path can say "the action started and its ending is unknown" rather than
#: guessing between a crashed profiler and an action that never began.  Without
#: the staging file a reader that arrived mid-write would see half a JSON
#: document and call it malformed.
PROFILE_RELAY_SOURCE = """\
import json, os, subprocess, sys, time
status_path, argv = sys.argv[1], sys.argv[2:]
def start_ticks():
    raw = open("/proc/%d/stat" % os.getpid(), "rb").read()
    _, _, tail = raw.rpartition(b")")
    return int(tail.split()[19])
def record(body):
    body["schema"] = "prismabuild.profile_exit_status.v1"
    staged = status_path + ".partial"
    with open(staged, "w") as handle:
        handle.write(json.dumps(body, sort_keys=True))
    os.replace(staged, status_path)
try:
    child = subprocess.Popen(argv, close_fds=False)
except OSError as exc:
    record({"phase": "launch_failed",
            "launch_error": "%s: %s" % (type(exc).__name__, exc)})
    sys.exit(1)
record({"phase": "launched", "child_pid": child.pid,
        "relay_pid": os.getpid(), "relay_start_ticks": start_ticks()})
code = child.wait()
record({"phase": "ended", "ended_monotonic": time.monotonic(), "returncode": code,
        "signal": -code if code < 0 else None})
sys.exit(0)
"""


def profile_exit_status_relay(argv, status_path) -> list[str]:
    """Run ``argv`` and record how it ended where the worker can read it.

    ``-I`` is not decoration.  The relay's working directory is the action's
    checkout, and ``python -c`` would otherwise put that directory on
    ``sys.path``: an action carrying its own ``json.py`` would be importing
    into the worker's own status relay.  ``-S`` drops ``site`` as well, whose
    only job here would be to slow a process that imports four stdlib modules.
    """

    return [
        sys.executable, "-I", "-S", "-c", PROFILE_RELAY_SOURCE,
        str(status_path), *[str(word) for word in argv],
    ]


def _profile_relay_is_live(pid: int, start_ticks: int) -> bool:
    """Whether the exact Linux relay incarnation is still runnable.

    ``kill(pid, 0)`` includes zombies and cannot distinguish a reused PID.
    This worker's profile relay and its payload run on Linux, so field 22 of
    ``/proc/<pid>/stat`` supplies the same exact incarnation proof used by
    process accounting.  An unreadable or malformed record is not proof that
    a relay remains able to write an ending.
    """

    try:
        raw = Path(f"/proc/{pid}/stat").read_bytes()
    except OSError:
        return False
    _, _, tail = raw.rpartition(b")")
    fields = tail.split()
    if len(fields) <= 19 or fields[0] in {b"Z", b"X", b"x"}:
        return False
    try:
        return int(fields[19]) == start_ticks
    except ValueError:
        return False


def read_speedscope(path: Path) -> dict[str, object]:
    """Open a speedscope file and say how many samples it holds.

    The sample count is reported, never gated on: an action fast enough to end
    between two ticks leaves a valid profile with no samples in it, and that is
    a true statement about the action rather than a broken profiler.
    """

    try:
        raw = Path(path).read_bytes()
    except OSError as exc:
        raise ProfileUnusable(f"no profile was written to {path}: {exc}") from exc
    if not raw:
        raise ProfileUnusable(f"the profile at {path} is empty")
    try:
        document = json.loads(raw)
    except ValueError as exc:
        raise ProfileUnusable(
            f"the profile at {path} is not readable JSON: {exc}"
        ) from exc
    if not isinstance(document, dict):
        raise ProfileUnusable(f"the profile at {path} is not a speedscope object")
    if document.get("$schema") != PROFILE_SPEEDSCOPE_SCHEMA:
        raise ProfileUnusable(
            f"the profile at {path} does not declare {PROFILE_SPEEDSCOPE_SCHEMA}"
        )
    profiles = document.get("profiles")
    if not isinstance(profiles, list):
        raise ProfileUnusable(f"the profile at {path} carries no profiles array")
    samples = 0
    for entry in profiles:
        if isinstance(entry, dict) and isinstance(entry.get("samples"), list):
            samples += len(entry["samples"])
    return {"samples": samples}


class PySpyProfileBackend:
    """``--profile sample``: py-spy sampling the action's whole process tree."""

    mode = "sample"
    #: py-spy handles SIGINT and nothing else: its termination path is the
    #: ``ctrlc`` crate, and a SIGTERM kills it with the speedscope unwritten
    #: (measured on sparky, probe ``f09402fe3ce8``: SIGTERM left no file and no
    #: exit status; SIGINT to the leader wrote the profile in 102 ms).  A
    #: killed action's profile depends on asking it the way it listens.
    flush_signal = signal.SIGINT
    flush_seconds = 3.0
    name = "py-spy"
    rate_hz = PROFILE_SAMPLE_RATE_HZ
    profile_suffix = "speedscope.json"
    #: py-spy samples the action's descendants, and the Docker daemon's
    #: children are not among them.  Declaring it makes the session consult
    #: the route marker the shim writes, so an attempted container workload
    #: is recorded as not covered rather than as a clean profile (#562).
    container_routes_unsupported = True

    def __init__(self) -> None:
        self._path: str | None = None
        self._version: str | None = None

    def bind(self, option: str | None) -> "PySpyProfileBackend":
        if option is not None:
            raise ProfileBackendUnavailable(
                f"the sample mode takes no option, and was given {option!r}"
            )
        return self

    def environment(self, *, profile_path: Path) -> dict[str, str]:
        """The guard and marker path the action's Docker shim reads.

        The shim refuses a container route under the guard and leaves the route
        name at the marker path first, so an action whose launcher swallows
        that refusal still cannot certify that its profile covered the
        workload.
        """

        return {
            PROFILE_SAMPLE_GUARD_ENV: "1",
            PROFILE_SAMPLE_MARKER_ENV: str(
                profile_container_route_path(profile_path)
            ),
        }

    def locate(self) -> str:
        """The py-spy this box will run, or a refusal naming where it looked.

        Beside the interpreter running the worker first, because that is the
        venv a box's ``worker_loop --python`` names and the one an operator can
        install into; ``PATH`` second, for a box whose worker inherits one.
        """

        if self._path is not None:
            return self._path
        # ``sys.executable`` unresolved on purpose: a venv's ``bin/python`` is
        # a symlink to the system interpreter, so resolving it walks out of the
        # venv and looks for py-spy in ``/usr/bin`` -- which is what happened
        # on dl380g10, where the tool was installed in ``pb-cpu`` all along.
        beside = Path(sys.executable).parent / "py-spy"
        candidates = [str(beside), "py-spy on PATH"]
        found = str(beside) if beside.is_file() else shutil.which("py-spy")
        if found is None:
            raise ProfileBackendUnavailable(
                "py-spy was not found; looked for " + " and ".join(candidates)
                + ".  Install it into the venv this box's worker_loop names "
                  "with --python (pip install py-spy), or put it on that "
                  "worker's PATH."
            )
        self._path = found
        return found

    @property
    def version(self) -> str:
        """What ``py-spy --version`` says, recorded beside the profile."""

        if self._version is None:
            completed = subprocess.run(
                [self.locate(), "--version"],
                capture_output=True, text=True, check=False,
            )
            self._version = (completed.stdout or completed.stderr).strip()
        return self._version

    def launch_argv(self, argv, *, profile_path: Path):
        return [
            self.locate(), "record",
            "--subprocesses",
            "--rate", str(self.rate_hz),
            "--format", "speedscope",
            "--output", str(profile_path),
            "--",
            *argv,
        ]

    def read_profile(self, path: Path) -> dict[str, object]:
        return read_speedscope(path)


#: The largest profile this fleet will file.  A trace is evidence, and
#: evidence that fills the disk is a cost the next action pays.  Measured
#: rather than guessed (action ``f09402fe3ce8`` on sparky, 2026-09-07): an nsys
#: CUDA+NVTX trace of a saturated matmul loop grew 666 kB, 2.28 MB and 8.80 MB
#: over runs of 1.94 s, 6.71 s and 25.69 s -- about 0.34 MB per second of
#: traced GPU work -- so this ceiling is a little under two hours of it.  An
#: action that needs longer asks for a window instead (``--profile nsys:600``).
PROFILE_BLOB_BUDGET_BYTES = 2 * 1024 ** 3


def read_chrome_trace(path: Path) -> dict[str, object]:
    """Open a Chrome/Perfetto trace and say how many events it holds.

    Written by the action itself under the torch contract, so this is the only
    place that finds out whether the action really honoured it.  Gzip first
    because that is what the contract asks for; a plain JSON document at the
    same path is accepted and recorded as uncompressed rather than refused,
    since it is the same trace and the reader opens both.

    The file and its decoded JSON each have the profile byte budget. Read at
    most one byte beyond the decoded limit before parsing: checking only the
    compressed size lets a small gzip allocate an arbitrarily large document.
    JSON's object allocations are additional to this byte budget.
    """

    raw = Path(path)
    compressed = False
    try:
        with raw.open("rb") as source:
            if os.fstat(source.fileno()).st_size > PROFILE_BLOB_BUDGET_BYTES:
                raise ProfileUnusable(
                    f"the trace exceeds the {PROFILE_BLOB_BUDGET_BYTES}-byte "
                    "profile budget. Export a shorter torch.profiler.schedule."
                )
            compressed = source.read(2) == b"\x1f\x8b"
            source.seek(0)
            if compressed:
                try:
                    with gzip.GzipFile(fileobj=source, mode="rb") as decoded:
                        blob = decoded.read(PROFILE_BLOB_BUDGET_BYTES + 1)
                except (OSError, EOFError, zlib.error) as exc:
                    raise ProfileUnusable(
                        f"the profile at {path} is truncated gzip: {exc}"
                    ) from exc
            else:
                blob = source.read(PROFILE_BLOB_BUDGET_BYTES + 1)
    except OSError as exc:
        raise ProfileUnusable(f"no profile was written to {path}: {exc}") from exc
    if len(blob) > PROFILE_BLOB_BUDGET_BYTES:
        raise ProfileUnusable(
            f"the decoded trace exceeds the {PROFILE_BLOB_BUDGET_BYTES}-byte "
            "profile budget. Export a shorter torch.profiler.schedule; "
            "gzip compression does not reduce the decoded trace size."
        )
    if not blob:
        raise ProfileUnusable(f"the profile at {path} is empty")
    try:
        document = json.loads(blob)
    except ValueError as exc:
        raise ProfileUnusable(
            f"the profile at {path} is not a JSON trace: {exc}"
        ) from exc
    if not isinstance(document, dict) or "traceEvents" not in document:
        raise ProfileUnusable(
            f"the profile at {path} has no traceEvents; a Chrome trace is "
            "what torch.profiler.export_chrome_trace writes"
        )
    events = document["traceEvents"]
    record: dict[str, object] = {
        "events": len(events) if isinstance(events, list) else None,
        "compressed": compressed,
        "decoded_bytes": len(blob),
    }
    for field in ("schemaVersion", "deviceProperties"):
        if field == "schemaVersion" and field in document:
            record["trace_schema_version"] = document[field]
    return record


# Optional extraction must leave room for the primary report and the ending.
PROFILE_SUMMARY_TIMEOUT_SECONDS = 5.0
_PROFILE_SUMMARY_REAP_GRACE_SECONDS = 0.5


class NsysProfileBackend:
    """Nsight Systems around the sealed argv: what the GPU actually did.

    CUPTI-backed, and priced accordingly -- this is the mode that answers "which
    kernels, how long, and what was the gap between them", which no sampler can
    answer.  CPU sampling is left off (``-s none``): ``--profile sample`` is
    the mode for that question, and every sample nsys takes is trace bytes it
    also has to write.
    """

    mode = "nsys"
    name = "nsys"
    profile_suffix = "nsys-rep"
    #: nsys finalizes its report when it is signalled, and needs longer than a
    #: sampler to do it: measured on sparky (action ``f09402fe3ce8``) a group
    #: SIGTERM 25 s into a traced run left a complete 5.99 MB ``.nsys-rep``
    #: after 3.1 s.  The reap gives it that time rather than SIGKILLing a
    #: report mid-write.  It has no flush signal of its own: SIGTERM is what
    #: it wants, and SIGTERM is what the reap sends.
    terminate_grace_seconds = 6.0
    def __init__(self, *, duration_s: int | None = None):
        self.duration_s = duration_s
        self._path: str | None = None
        self._version: str | None = None

    @property
    def exits_before_action(self) -> bool:
        return self.duration_s is not None

    def bind(self, option: str | None) -> "NsysProfileBackend":
        """A per-action copy carrying the sealed window, if there is one.

        The registry holds one instance per mode and an action must not be able
        to reconfigure it for the next one, so the option makes a copy.
        """

        if option is None:
            return self
        if not re.fullmatch(r"[1-9][0-9]{0,4}", option):
            raise ProfileBackendUnavailable(
                f"the nsys window must be whole seconds, 1 to 99999, not "
                f"{option!r}: --profile nsys:600 traces the first ten minutes"
            )
        bound = NsysProfileBackend(duration_s=int(option))
        bound._path, bound._version = self._path, self._version
        return bound

    #: Where Nsight Systems installs itself, checked after ``PATH``.  py-spy's
    #: lesson, in the one form that applies: the worker loop's ``PATH`` is not
    #: the operator's, and sparky's ``--profile sample`` refuses today for
    #: exactly that reason.  nsys is a system binary at a known place, so this
    #: mode does not have to inherit the same accident.
    INSTALL_CANDIDATES = (
        "/usr/local/bin/nsys",
        "/usr/local/cuda/bin/nsys",
        "/opt/nvidia/nsight-systems/bin/nsys",
    )

    def locate(self) -> str:
        if self._path is not None:
            return self._path
        found = shutil.which("nsys")
        if found is None:
            for candidate in self.INSTALL_CANDIDATES:
                if Path(candidate).is_file():
                    found = candidate
                    break
        if found is None:
            raise ProfileBackendUnavailable(
                "nsys was not found on PATH or at "
                + ", ".join(self.INSTALL_CANDIDATES)
                + ".  It ships with the CUDA toolkit as Nsight Systems; a box "
                "without a GPU toolchain has no business answering an nsys "
                "request."
            )
        self._path = found
        return found

    @property
    def version(self) -> str:
        if self._version is None:
            completed = subprocess.run(
                [self.locate(), "--version"],
                capture_output=True, text=True, check=False,
            )
            self._version = (completed.stdout or completed.stderr).strip()
        return self._version

    def check_environment(self, sealed: Mapping[str, str]) -> None:
        """Refuse a run whose intermediate would land in ``/tmp``.

        The report goes where ``-o`` says, under the action's own working
        directory, but the ``.qdstrm`` nsys writes while it traces follows
        ``TMPDIR`` and nothing else -- measured on sparky with a ``PATH``-only
        environment, where it went to ``/tmp``.  A trace can be gigabytes, and
        this fleet does not put gigabytes in ``/tmp``.  ``pbrun``'s default
        environment already sets ``TMPDIR``; only ``--no-default-env`` reaches
        this, and the fix is to seal one rather than to have PrismaBuild
        change the action's temporary directory underneath it.
        """

        if not (sealed.get("TMPDIR") or "").strip():
            raise LocalActionError(
                "the nsys profile mode needs TMPDIR in the action's sealed "
                "environment: nsys writes its intermediate trace there while "
                "it runs, and with no TMPDIR that is /tmp, which this fleet "
                "does not use for anything that can be gigabytes.  pbrun's "
                "default environment sets it; --no-default-env drops it, so "
                "seal one with --env TMPDIR=/home/rob/tmp."
            )

    def environment(self, *, profile_path: Path) -> dict[str, str]:
        # The daemon's container process is not a descendant of this Nsys
        # launcher. Carry the guard through arbitrary shell/Python launchers
        # to the Docker shim, which can refuse before starting untraced work.
        return {"PRISMABUILD_PROFILE_NSYS": "1"}

    def _report_base(self, profile_path: Path) -> Path:
        # ``-o`` names the report without its suffix, and nsys appends
        # ``.nsys-rep`` itself.
        return profile_path.with_suffix("")

    def launch_argv(self, argv, *, profile_path: Path):
        window: list[str] = []
        if self.duration_s is not None:
            # ``--kill none`` is load-bearing: nsys's default at the end of a
            # window is to SIGTERM the application, and a diagnostic that ends
            # the action it was asked to watch is not a diagnostic.
            window = ["--duration", str(self.duration_s), "--kill", "none"]
        return [
            self.locate(), "profile",
            "--output", str(self._report_base(profile_path)),
            "--force-overwrite", "true",
            "--trace", "cuda,nvtx",
            "--sample", "none",
            *window,
            "--",
            *argv,
        ]

    def read_profile(self, path: Path) -> dict[str, object]:
        report = Path(path)
        try:
            size = report.stat().st_size
        except OSError as exc:
            raise ProfileUnusable(
                f"nsys wrote no report at {report}: {exc}"
            ) from exc
        if size == 0:
            raise ProfileUnusable(f"the nsys report at {report} is empty")
        if size > PROFILE_BLOB_BUDGET_BYTES:
            raise ProfileUnusable(
                f"the nsys report is {size} bytes, over this fleet's "
                f"{PROFILE_BLOB_BUDGET_BYTES}-byte profile budget.  Ask for a "
                "window instead -- --profile nsys:600 traces the first ten "
                "minutes -- rather than tracing an action that long end to end."
            )
        record: dict[str, object] = {"report_bytes": size}
        if self.duration_s is not None:
            record["window_s"] = self.duration_s
            record["partial_window"] = True
        return record

    def extra_blobs(self, path: Path) -> list[tuple[str, Path]]:
        """The kernel-time table, which is the part an agent can read.

        A ``.nsys-rep`` needs Nsight Systems to open; the CSV summary is the
        answer to "where did the GPU time go" in a form a reader already has.
        Best-effort by design: a box whose nsys cannot run ``stats`` still
        files the report.

        A summary with no rows in it is not filed.  A partial report -- the
        one a killed run leaves -- can carry no completed kernels, and
        ``nsys stats`` answers that with an empty file or with a header and
        nothing under it; filing that produced a ``kernel_summary`` blob whose
        digest was ``e3b0c442``, the hash of no bytes at all, sitting on the
        record beside a real report as though the table had been read and had
        found nothing to say.  The reason goes on the ending instead, where a
        reader looking for the table finds out why it is not there.
        """

        self._summary_note = None
        base = Path(path).with_suffix("")
        summary = base.parent / f"{base.name}_cuda_gpu_kern_sum.csv"
        with _sigterm_unwinds_this_process():
            process = subprocess.Popen(
                [self.locate(), "stats", "--report", "cuda_gpu_kern_sum",
                 "--format", "csv", "--output", str(base), str(path)],
                stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True,
                start_new_session=True,
            )
            try:
                stdout, stderr = process.communicate(
                    timeout=PROFILE_SUMMARY_TIMEOUT_SECONDS
                )
            except subprocess.TimeoutExpired:
                # The leader may already have exited while its descendants
                # retain the pipes. Reap the owned group, not just the leader.
                _terminate_process_group(
                    process, grace_s=_PROFILE_SUMMARY_REAP_GRACE_SECONDS
                )
                self._summary_note = (
                    f"nsys stats timed out after {PROFILE_SUMMARY_TIMEOUT_SECONDS:g} "
                    "seconds; primary report retained"
                )
                return []
            except BaseException:
                _terminate_process_group(
                    process, grace_s=_PROFILE_SUMMARY_REAP_GRACE_SECONDS
                )
                raise
            finally:
                # Do not communicate again without a deadline: an unkillable
                # descendant can still hold a pipe. The broker owns the scope.
                process.stdout.close()
                process.stderr.close()
        if process.returncode != 0:
            self._summary_note = (
                f"nsys stats exited {process.returncode}: "
                + (stderr or stdout or "").strip()[-200:]
            )
            return []
        if not summary.is_file():
            self._summary_note = "nsys stats wrote no summary file"
            return []
        rows = self._summary_rows(summary)
        if rows == 0:
            self._summary_note = (
                "the CUDA kernel summary has no rows: this report records no "
                "completed kernel"
            )
            return []
        return [("kernel_summary", summary)]

    @staticmethod
    def _summary_rows(summary: Path) -> int:
        """Data rows under the CSV header, or 0 for a file that has none."""

        try:
            text = summary.read_text(errors="replace")
        except OSError:
            return 0
        lines = [line for line in text.splitlines() if line.strip()]
        return max(len(lines) - 1, 0)

    def extra_blob_notes(self) -> dict[str, object]:
        """Why a blob this backend usually files is missing, if it is."""

        note = getattr(self, "_summary_note", None)
        return {"kernel_summary_absent": note} if note else {}


class TorchProfileBackend:
    """The action profiles itself, and this says where to put the result.

    ``torch.profiler`` is in-process by construction: no outside process can
    turn it on, and this fleet will not monkeypatch an action's interpreter to
    pretend otherwise.  So the mode is a contract instead.  PrismaBuild names a
    path in ``PRISMABUILD_PROFILE_TORCH_OUT``; an action that asked for this
    mode exports its Chrome trace there
    (``tools/profile_torch.py`` in this repository is a copyable helper); and
    PrismaBuild validates, sizes, ingests and reports the file exactly as it
    does a profile it produced itself.

    An action that asks for the mode and then writes nothing **fails**.  It is
    tempting to report ``produced: false`` and publish the receipt anyway, but
    the receipt is what makes the key answerable: ``run_local_action`` returns a
    cache hit with no ``profile`` key at all, so a receipt filed for a run that
    produced no profile turns every later identical submission into a
    profile-less hit, with no reason attached, until somebody thinks to pass
    ``--recompute``.  A refusal is recoverable; a poisoned key is not.
    """

    mode = "torch"
    name = "torch.profiler"
    profile_suffix = "chrome-trace.json.gz"
    #: The action exports on SIGTERM if it installed the helper's handler, and
    #: that export is not instant: measured on sparky (action
    #: ``f09402fe3ce8``), 20 s of traced matmuls took 4.5 s to write 9.0 MB
    #: gzipped, 5.8 s from signal to exit.
    terminate_grace_seconds = 6.0
    #: There is nothing on the box to hash: the profiler is the action's own
    #: interpreter, and its version is the action's business.
    hashable = False

    #: The variable the action reads.  Named on every refusal, because the
    #: whole contract is one variable and one file.
    OUT_ENV = "PRISMABUILD_PROFILE_TORCH_OUT"

    def bind(self, option: str | None) -> "TorchProfileBackend":
        if option is not None:
            raise ProfileBackendUnavailable(
                f"the torch mode takes no option, and was given {option!r}"
            )
        return self

    def locate(self) -> str:
        # Backed on every box: the profiler travels in the action.
        return "in-process (torch.profiler, inside the action)"

    @property
    def version(self) -> str:
        return ""

    def environment(self, *, profile_path: Path) -> dict[str, str]:
        return {self.OUT_ENV: str(profile_path)}

    def launch_argv(self, argv, *, profile_path: Path):
        # Nothing wraps the action: the profiler is already inside it.
        return list(argv)

    def read_profile(self, path: Path) -> dict[str, object]:
        report = Path(path)
        if not report.exists():
            raise ProfileUnusable(
                f"the action never wrote a trace to {report}.  The torch mode "
                f"is a contract: the action reads {self.OUT_ENV} from its "
                "environment and exports its Chrome trace there "
                "(prof.export_chrome_trace(os.environ["
                f"{self.OUT_ENV!r}]), or copy tools/profile_torch.py).  An "
                "action that does not is not profiled, and a receipt filed "
                "for it would answer every later run of the same command with "
                "an unprofiled cache hit."
            )
        size = report.stat().st_size
        if size > PROFILE_BLOB_BUDGET_BYTES:
            raise ProfileUnusable(
                f"the trace is {size} bytes, over this fleet's "
                f"{PROFILE_BLOB_BUDGET_BYTES}-byte profile budget.  Export a "
                "schedule (torch.profiler.schedule) rather than the whole run."
            )
        return read_chrome_trace(report)


#: Mode to backend.  A tier adds its entry here and changes nothing else.
PROFILE_BACKENDS: dict[str, object] = {
    backend.mode: backend for backend in (
        PySpyProfileBackend(), NsysProfileBackend(), TorchProfileBackend(),
    )
}

#: What ``--profile`` accepts, in the order a help message should list it.
PROFILE_MODES: tuple[str, ...] = tuple(sorted(PROFILE_BACKENDS))

#: How a mode carries its one option.  ``nsys:600`` is the whole vocabulary:
#: a mode name, and a number the backend knows how to read.
PROFILE_MODE_SEPARATOR = ":"


def split_profile_mode(mode: str) -> tuple[str, str | None]:
    """``"nsys:600"`` into its mode and its option."""

    name, _, option = mode.partition(PROFILE_MODE_SEPARATOR)
    return name, (option or None)


def bind_profile_option(backend: object, mode: str, option: str | None):
    """Give a backend its sealed option, or refuse one it cannot take.

    ``bind`` is optional in the backend protocol: a mode with nothing to
    configure does not implement it, and is then refused an option rather than
    silently ignoring one somebody sealed into a key on purpose.
    """

    binder = getattr(backend, "bind", None)
    if binder is not None:
        return binder(option)
    if option is not None:
        raise ProfileBackendUnavailable(
            f"the {mode} mode takes no option, and was given {option!r}"
        )
    return backend


def parse_profile_mode(text: str) -> str:
    """Validate a ``--profile`` value at the client, before it is sealed.

    A mode that only this box's runtime rejects is a wasted submission and a
    confusing one; the same rule runs here and on the worker.
    """

    name, option = split_profile_mode(text)
    bind_profile_option(profile_backend_for(name), name, option)
    return text


def profile_backend_for(mode: str):
    """The backend for a sealed mode, or a refusal naming what is offered."""

    name, _option = split_profile_mode(mode)
    try:
        return PROFILE_BACKENDS[name]
    except KeyError:
        raise ProfileBackendUnavailable(
            f"unknown profile mode {name!r}; this runtime offers "
            + ", ".join(sorted(PROFILE_BACKENDS))
        ) from None


def describe_profile(profile) -> str:
    """One clause naming a profiled ending's blob, for every reader to print.

    Kept here rather than at each call site so ``pbrun`` and ``pbstatus`` say
    the same thing about the same record; a digest two tools abbreviate
    differently is a digest nobody can grep for.
    """

    if not isinstance(profile, dict):
        return ""
    digest = str(profile.get("blob_sha256") or "")
    if not digest:
        # A record with no blob is a record of a profile that did not survive,
        # and saying so is the point of having recorded it.  Returning "" here
        # printed nothing at all for a killed run, which reads as "no profile
        # was asked for" -- the one thing it does not mean.
        if not profile.get("mode"):
            return ""
        return (f"profile {profile.get('mode')} ({profile.get('backend')}) "
                "not produced: "
                + str(profile.get("reason") or "no reason recorded"))
    # A blob can be filed and still not be the evidence that was asked for:
    # a sampled action that tried a Docker route leaves a host-only speedscope
    # behind.  Printing its digest alone reads as coverage, so say what the
    # profile does not cover (#562).
    uncovered = ""
    if profile.get("produced") is False:
        uncovered = (", NOT covering the workload: "
                     + str(profile.get("reason") or "reason not recorded"))
    partial = " (partial: the action was stopped)" if profile.get("partial") \
        else ""
    absent = ""
    if profile.get("kernel_summary_absent"):
        absent = (", no kernel summary: "
                  + str(profile.get("kernel_summary_absent")))
    ignored = ""
    if profile.get("backend_status_ignored"):
        ignored = (f", profiler exited "
                   f"{profile.get('backend_returncode')} but profiled anyway")
    return (f"profile {profile.get('mode')} ({profile.get('backend')}) "
            f"{digest[:12]} {profile.get('bytes')}B at "
            f"{profile.get('blob_path') or '(path not recorded)'}"
            f"{uncovered}{partial}{ignored}{absent}")


#: The sealed param that asks for a profile.  Absent on every action that
#: does not want one, so an unprofiled key is byte-identical to what it was
#: before this tier existed.
PROFILE_PARAM = "profile"


class _ProfileSession:
    """One action's profiler: what to launch, and what it must leave behind.

    Kept in one class, beside one factory, because it is the whole of the
    launch-side change: ``_run_local_action`` asks for a session, launches what
    the session says to launch, and settles it afterwards.

    The profiler is the argv's *parent* rather than a process beside it, and
    the action's own exit status comes back through a relay file rather than
    through the profiler's exit code.  Both are measured facts about this
    fleet and this profiler; the block above records what was measured and why
    the obvious shapes do not work.
    """

    def __init__(self, *, mode: str, backend: object, directory: Path):
        self.mode = mode
        self.backend = backend
        self.directory = directory
        suffix = getattr(backend, "profile_suffix", "profile")
        self.profile_path = directory / f"profile.{suffix}"
        self.exit_status_path = directory / "exit_status"
        self.container_route_path = profile_container_route_path(self.profile_path)
        #: The profiler's own exit status, once it has one.  Reported rather
        #: than discarded: Tier 1 overwrote it with the action's.
        self.backend_returncode: int | None = None
        #: ``(name, path)`` a backend adds beside the profile -- a summary
        #: table, say -- ingested as its own blob and named on the record.
        self.extra_blobs: list[tuple[str, Path]] = []

    def _open(self) -> None:
        """Create the scratch directory, and not one moment earlier.

        ``preflight_action`` proves the materialized checkout is the sealed
        commit with a *clean* working tree, and ``git_checkout_identity``
        counts an untracked directory as dirt.  A scratch directory created
        before that proof refuses every profiled action; created after it,
        nothing looks at the tree's cleanliness again.

        A directory that cannot be created is a refusal with a reason, in the
        one exception class ``core.main`` catches.  Raw, it left the worker to
        traceback out of ``main``, skip the status write, and let the claim be
        reaped on the next attempt -- an unwritable checkout reported as a
        mystery instead of as itself.
        """

        try:
            self.directory.mkdir(parents=True, exist_ok=True)
        except OSError as exc:
            raise LocalActionError(
                f"the profile scratch directory could not be created at "
                f"{self.directory}: {exc}.  A profiled action needs somewhere "
                "inside its own working directory to write the profile, so "
                "this run failed before the action started."
            ) from exc
        if getattr(self.backend, "container_routes_unsupported", False):
            self._arm_container_route()

    def _write_container_route(self, document: Mapping[str, object]) -> None:
        """Replace the route marker atomically, through a fresh staging inode.

        ``mkstemp`` creates the staging file exclusively, so a symlink or FIFO
        planted at a predictable staging name is neither followed, overwritten
        nor blocked on; only the staging file this call created is removed on
        failure.  ``os.replace`` replaces a symlink at the destination rather
        than following it, so the record cannot be redirected through one.
        This is bookkeeping in the action's own scratch directory, not a
        security boundary: an action that tampers with its own scratch can
        defeat it, and such a run is unsupported.
        """

        payload = (json.dumps(dict(document), sort_keys=True) + "\n").encode()
        descriptor, staged = tempfile.mkstemp(
            prefix=f".{self.container_route_path.name}.",
            suffix=".tmp",
            dir=self.container_route_path.parent,
        )
        try:
            with os.fdopen(descriptor, "wb") as handle:
                handle.write(payload)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(staged, self.container_route_path)
        except BaseException:
            with suppress(OSError):
                os.unlink(staged)
            raise

    def _arm_container_route(self) -> None:
        """Pre-create the route marker in its armed state, or refuse the action.

        The shim's route record is the action's evidence that it tried a
        Docker route.  Arming the marker first makes its absence or its
        incomplete state negative evidence at settlement, so an unwritable or
        removed scratch path cannot silently stand in for "no container was
        used" when a launcher swallows the shim's refusal.
        """

        try:
            self._write_container_route({
                "schema": PROFILE_ROUTE_SCHEMA,
                "state": PROFILE_ROUTE_ARMED,
            })
        except OSError as exc:
            raise LocalActionError(
                "the sample profile could not arm its Docker route marker at "
                f"{self.container_route_path}: {exc}.  A sampled action that "
                "cannot record an attempted container route cannot say what "
                "its profile covers, so this run failed before the action "
                "started."
            ) from exc

    def close(self) -> None:
        with suppress(OSError):
            shutil.rmtree(self.directory)

    def environment(self, sealed: Mapping[str, str]) -> dict[str, str]:
        """Variables this mode adds to the action's own environment.

        The torch contract names its output; Nsys marks the launch so the
        Docker shim can refuse an unsupported profiling route. A variable
        the action already seals is a refusal rather than
        an overwrite -- silently replacing it would change what the action
        does under a diagnostic flag, which is the one thing this tier must
        not do.
        """

        check = getattr(self.backend, "check_environment", None)
        if check is not None:
            check(sealed)
        added = getattr(self.backend, "environment", None)
        if added is None:
            return {}
        variables = dict(added(profile_path=self.profile_path))
        clashes = sorted(set(variables) & set(sealed))
        if clashes:
            raise LocalActionError(
                f"the {self.mode} profile mode sets {', '.join(clashes)}, "
                "which this action's sealed environment already sets.  The "
                "mode cannot take the variable over without changing what the "
                "action does, so it refuses instead."
            )
        return variables

    def launch_argv(self, argv: Sequence[object]) -> list[str]:
        """What the worker launches instead of the sealed argv.

        The relay is wrapped here rather than inside each backend, so that a
        backend cannot forget it: every mode gets the same exit-status
        guarantee by construction, and a new backend's only job is to say how
        to run the argv it is handed.
        """

        self._open()
        relayed = profile_exit_status_relay(
            [str(item) for item in argv], self.exit_status_path
        )
        return [
            str(word)
            for word in self.backend.launch_argv(  # type: ignore[attr-defined]
                relayed, profile_path=self.profile_path,
            )
        ]

    def exit_status(self) -> dict[str, object]:
        """The relay's latest record, or a refusal saying why there is none.

        Read as a whole rather than field by field, because the timeout path
        wants the phase (did the action even start?) and the settle path wants
        the pid, while the ordinary path wants only the status.
        """

        try:
            raw = self.exit_status_path.read_text(encoding="utf-8").strip()
        except OSError as exc:
            raise ProfileUnusable(
                f"the profiled action left no exit status at "
                f"{self.exit_status_path}: {exc}"
            ) from exc
        try:
            record = json.loads(raw)
        except ValueError as exc:
            raise ProfileUnusable(
                f"the profiled action's exit status is malformed: {raw!r}"
            ) from exc
        if not isinstance(record, dict) or not isinstance(
            record.get("phase"), str
        ):
            raise ProfileUnusable(
                f"the profiled action's exit status is malformed: {raw!r}"
            )
        if record.get("schema") != PROFILE_EXIT_STATUS_SCHEMA:
            raise ProfileUnusable(
                f"the profiled action's exit status is not "
                f"{PROFILE_EXIT_STATUS_SCHEMA}: {raw!r}"
            )
        return record

    def action_returncode(self, process=None, *, deadline: float | None = None) -> int:
        """How the action ended, out of the relay the launch installed.

        In ``subprocess``'s own convention, so an unprofiled and a profiled run
        of the same dying action raise the same ``LocalActionError``: a
        signalled action is the negative signal number, and the caller derives
        ``signal`` from it exactly as it does without a profiler.

        A missing or unreadable relay is a broken profiled run, not a pass: it
        means nothing here knows what the action did.
        """

        record = self._settled_exit_status(process, deadline=deadline)
        phase = record["phase"]
        if phase == "launch_failed":
            # The unprofiled path calls this a worker verdict rather than an
            # action's ending, and so does this: no ``returncode`` reaches the
            # error, so nothing downstream reads a number the action never
            # produced.
            raise LocalActionError(
                f"action execution failed: {record.get('launch_error')}"
            )
        if phase == "launched":
            raise ProfileUnusable(
                f"the profiler exited while the action (pid "
                f"{record.get('child_pid')}) was still running, so how the "
                f"action ended was never recorded"
            )
        if phase != "ended":
            raise ProfileUnusable(
                f"the profiled action's exit status is malformed: {record!r}"
            )
        if deadline is not None:
            ended_monotonic = record.get("ended_monotonic")
            if (not isinstance(ended_monotonic, (int, float))
                    or isinstance(ended_monotonic, bool)
                    or not math.isfinite(ended_monotonic)):
                raise ProfileUnusable(
                    "the profiled action's ended record has no valid "
                    f"monotonic end timestamp: {record!r}"
                )
            if ended_monotonic > deadline:
                raise subprocess.TimeoutExpired(
                    "profiled action", max(0.0, deadline - time.monotonic())
                )
        code = record.get("returncode")
        if not isinstance(code, int) or isinstance(code, bool):
            raise ProfileUnusable(
                f"the profiled action's exit status is malformed: {record!r}"
            )
        if not -64 <= code <= 255:
            raise ProfileUnusable(
                f"the profiled action's exit status is out of range: {code}"
            )
        return code

    def _settled_exit_status(
        self, process=None, *, deadline: float | None = None
    ) -> dict[str, object]:
        """The relay's record, waiting out a profiler that exits first.

        Most profilers outlive what they profile, and for those this reads the
        file once.  ``nsys --duration`` does not: it stops tracing on its own
        clock and exits while the action runs on -- measured on sparky (action
        ``83d2530f3eda``), where a 2 s cap ended nsys at 3.3 s and the workload
        at 8.4 s.  A backend that can do that declares
        ``exits_before_action``, and the worker waits for the action itself
        rather than reporting an ending the action had not reached.  A profile
        window is diagnostic evidence, not an execution deadline: the caller's
        explicit deadline, or the pool's progress/deadline supervisor, remains
        the authority for a live relay.  A missing or dead relay is different:
        it cannot record the action's ending, so the owned group is stopped and
        the profiled run fails closed rather than waiting forever.
        """

        record = self.exit_status()
        if not getattr(self.backend, "exits_before_action", False):
            return record
        # The action outlives its profiler on this path, which makes every way
        # out of this wait a way to orphan it.  A pool deadline arriving here
        # signals *this* process, not the action's session, so without the
        # handler the worker would exit and leave the action holding the GPU
        # and its copy of the output lock; and a wait that simply expires would
        # do the same, quietly, on the way to raising.
        with _sigterm_unwinds_this_process():
            try:
                while record["phase"] == "launched":
                    if deadline is not None and time.monotonic() >= deadline:
                        if process is not None:
                            _terminate_process_group(process)
                        raise subprocess.TimeoutExpired(
                            "profiled action", max(0.0, deadline - time.monotonic())
                        )
                    relay_pid = record.get("relay_pid")
                    relay_start_ticks = record.get("relay_start_ticks")
                    if (not isinstance(relay_pid, int)
                            or isinstance(relay_pid, bool)
                            or relay_pid <= 0
                            or not isinstance(relay_start_ticks, int)
                            or isinstance(relay_start_ticks, bool)
                            or relay_start_ticks <= 0):
                        raced = self.exit_status()
                        if raced["phase"] != "launched":
                            return raced
                        if process is not None:
                            _terminate_process_group(process)
                        raise ProfileUnusable(
                            "the profiled action left no live relay identity "
                            "while its ending was still pending"
                        )
                    if not _profile_relay_is_live(relay_pid, relay_start_ticks):
                        raced = self.exit_status()
                        if raced["phase"] != "launched":
                            return raced
                        if process is not None:
                            _terminate_process_group(process)
                        raise ProfileUnusable(
                            f"the profiled action relay (pid {relay_pid}) is "
                            "no longer running, so its ending cannot be recorded"
                        )
                    sleep_seconds = _PROFILE_SETTLE_POLL_SECONDS
                    if deadline is not None:
                        sleep_seconds = min(
                            sleep_seconds, max(0.0, deadline - time.monotonic())
                        )
                    time.sleep(sleep_seconds)
                    record = self.exit_status()
            except BaseException:
                if process is not None:
                    _terminate_process_group(process)
                raise
        if record["phase"] == "launched" and process is not None:
            _terminate_process_group(process)
        return record

    def identity(self) -> dict[str, object]:
        """Which profiler ran, by name, version, path and digest.

        The path and the digest are here because "py-spy 0.4.2" is a claim
        about a box and not a fact about a file: two boxes can carry the same
        version string over different binaries, and an overhead number is only
        comparable against the binary it was measured on.  A backend that
        cannot be located records the reason instead -- this runs on the way
        out of a failure as well as a success.
        """

        record: dict[str, object] = {
            "mode": self.mode,
            "backend": str(getattr(self.backend, "name", self.mode)),
            "backend_version": str(getattr(self.backend, "version", "")),
            "rate_hz": getattr(self.backend, "rate_hz", None),
        }
        if not getattr(self.backend, "hashable", True):
            # The profiler is the action's own interpreter; there is no binary
            # on this box to name, and saying so is more honest than hashing
            # something that had nothing to do with it.
            record["backend_path"] = str(
                self.backend.locate()  # type: ignore[attr-defined]
            )
            if self.backend_returncode is not None:
                record["backend_returncode"] = self.backend_returncode
            return record
        try:
            path = Path(str(self.backend.locate()))  # type: ignore[attr-defined]
            # Through the symlink, the way the worker's own attestation
            # records an executable: ``/bin/sh`` and ``/usr/local/bin/nsys``
            # are both links, and a digest of a link is a digest of a name.
            resolved = path.resolve()
            digest, size = _file_identity(resolved, where="profile backend")
        except (ProfileBackendUnavailable, ActionContractError, OSError) as exc:
            record["backend_path_error"] = str(exc)
        else:
            record["backend_path"] = str(path)
            record["backend_resolved_path"] = str(resolved)
            record["backend_sha256"] = digest
            record["backend_bytes"] = size
        if self.backend_returncode is not None:
            record["backend_returncode"] = self.backend_returncode
        return record

    def container_route(self) -> str | None:
        """The Docker route this sampled action attempted, if any.

        ``None`` means the marker is armed and untouched: no container route
        was recorded, and the profile is a whole-action profile.  A route name
        means the shim refused that route after recording it.  Anything else
        -- a missing marker, a symlink, a nonregular file, an oversized or
        malformed record, an unknown state, an empty route -- is
        ``PROFILE_ROUTE_UNKNOWN``: unknown coverage must never read as none,
        because the shim's ``125`` can be swallowed by a launcher (#562).

        The read is bounded, no-follow and regular-file-only, so a FIFO or a
        symlink at the marker path cannot block or redirect the worker, and a
        marker that changes while it is read is negative rather than a partial
        answer.
        """

        if not getattr(self.backend, "container_routes_unsupported", False):
            return None
        try:
            raw = _read_regular_file_nofollow(
                self.container_route_path,
                where="the sample route marker",
                max_bytes=PROFILE_ROUTE_MAX_BYTES,
            )
            document = _decode_strict_json(raw, where="the sample route marker")
        except (PrismaBuildError, OSError):
            return PROFILE_ROUTE_UNKNOWN
        if not isinstance(document, dict):
            return PROFILE_ROUTE_UNKNOWN
        if document.get("schema") != PROFILE_ROUTE_SCHEMA:
            return PROFILE_ROUTE_UNKNOWN
        state = document.get("state")
        if state == PROFILE_ROUTE_ARMED:
            return None
        if state == PROFILE_ROUTE_RECORDED:
            route = document.get("route")
            if (isinstance(route, str) and 0 < len(route) <= 128
                    and route.strip() == route):
                return route
        return PROFILE_ROUTE_UNKNOWN

    def ingest(self, cas: "PrismaBuildCAS") -> dict[str, object]:
        """Read the profile back and publish it as a content-addressed blob.

        Through ``ingest_input``, which is how every other payload reaches this
        CAS: one staging copy, one hashed publication, no receipt.  A profile
        is evidence about a run, not a result of it.
        """

        read = self.backend.read_profile(self.profile_path)  # type: ignore[attr-defined]
        route = self.container_route()
        entry, _won = cas.ingest_input(
            self.profile_path, input_id="prismabuild.profile"
        )
        record = self.identity()
        record.update({
            "blob_sha256": entry["sha256"],
            "bytes": entry["bytes"],
            "blob_path": str(cas._blob_path(str(entry["sha256"]))),
            "produced": True,
        })
        record.update(read)
        if route is not None:
            # The host-side blob is filed as evidence of what was sampled, but
            # it is not the profile that was asked for: a container workload
            # ran, or could not be ruled out, outside the sampler's reach.
            # `produced` is the field a reader tests, so it is false even
            # though a blob exists (#562).
            if route == PROFILE_ROUTE_UNKNOWN:
                coverage = "unknown"
                attempted = (
                    "the sample route marker was missing, unreadable or "
                    "incomplete, so the action's Docker usage cannot be ruled "
                    "out"
                )
            else:
                coverage = "unsupported"
                attempted = (
                    f"the action attempted a Docker container route ({route})"
                )
            record.update({
                "produced": False,
                "workload_coverage": coverage,
                "container_route": route,
                "reason": (
                    f"{attempted} under --profile sample. py-spy samples the "
                    "action's own process tree, and a process the Docker daemon "
                    "starts is not in it, so this profile covers no container "
                    "workload. Run the workload as a native child, or omit the "
                    "mode and instrument inside the admitted container (for "
                    "PyTorch, --profile torch with PRISMABUILD_PROFILE_TORCH_OUT "
                    "forwarded and mounted)."
                ),
            })
        # Optional summary extraction/ingest can outlive the pool deadline.
        # The broker then kills this scope without Python cleanup: preserve
        # the primary blob's reference before starting that supplemental work.
        # This is evidence only; normal completion returns the richer record.
        checkpoint = {**record, "partial": True}
        with suppress(ProfileUnusable):
            checkpoint["action_phase"] = self.exit_status()["phase"]
        _write_action_status({"profile": checkpoint})
        extra_blobs = list(self.extra_blobs)
        with suppress(Exception):                     # noqa: BLE001
            extra_blobs += list(
                self.backend.extra_blobs(self.profile_path)  # type: ignore[attr-defined]
            )
        with suppress(Exception):                     # noqa: BLE001
            record.update(
                self.backend.extra_blob_notes()  # type: ignore[attr-defined]
            )
        for name, path in extra_blobs:
            with suppress(ActionContractError, CASTamperError, OSError):
                extra, _won = cas.ingest_input(
                    path, input_id="prismabuild.profile." + name
                )
                record[name + "_sha256"] = extra["sha256"]
                record[name + "_bytes"] = extra["bytes"]
                record[name + "_blob_path"] = str(
                    cas._blob_path(str(extra["sha256"]))
                )
        return record

    def note_backend_status(
        self, returncode: int, record: dict[str, object]
    ) -> None:
        """Say how the profiler itself ended, on a record that came back whole.

        Tier 1 threw this number away by assigning the action's over it.  It
        is worth reporting -- but it is not worth failing a run for on its own,
        and that was measured rather than assumed.  py-spy 0.4.2 on sparky
        exits 1 with ``Error: No child process (os error 10)`` from time to
        time, *having written a complete speedscope*: in one five-arm probe
        (action ``b6f2ab795ef6``, 2026-09-07) the arm that failed this way
        (``d_devnull``) still left a profile the reader could open, printing no
        sample count of its own; the arms that did print one -- including the
        arm after it, whose conditions were a strict superset -- left 249 and
        271 samples.  It is a race inside the profiler's own wait, not a fact
        about the action.

        So the rule is what was lost, not what was returned: a profiler that
        ends badly *and* leaves no usable profile, or leaves the action's
        ending unrecorded, fails the run through the paths that already refuse
        those.  One that ends badly with everything intact is recorded and
        marked, so a reader can see it without a good run being thrown away
        for a bug in the tool watching it.
        """

        self.backend_returncode = int(returncode)
        record["backend_returncode"] = int(returncode)
        if returncode == 0:
            return
        record["backend_status_ignored"] = True
        record["backend_status_note"] = (
            f"the profiler exited with status {returncode} but left a usable "
            "profile and a recorded action ending, so the run stands"
        )


#: How long the worker may spend turning a killed action into a profile.
#: The pool signals a launcher that overran its deadline and kills it
#: ``pool.TIMEOUT_GRACE_S`` -- 15 s -- later, so everything below has to fit
#: inside that: flush the profiler, reap the group, read the file back.  A
#: backend whose finalize is slower than its share of this loses the profile
#: rather than the worker losing its chance to record the ending.
PROFILE_SETTLE_BUDGET_SECONDS = 12.0


def _reap_and_settle(
    process: "subprocess.Popen[bytes] | None",
    profile: "_ProfileSession | None",
    cas: "PrismaBuildCAS | None",
) -> dict[str, object] | None:
    """Stop a running action, and keep whatever profile it had reached.

    The timed-out case is the one a profile is most wanted for, and Tier 1
    threw it away: the timeout raise came before the profile block, so an
    action that ran into its deadline -- the reason somebody profiled it --
    reported no profile at all.

    Order is the whole of it.  A profiler is asked to finish *before* the
    group is reaped, because the reap is what kills it: py-spy writes its
    speedscope on SIGINT and nothing on SIGTERM (measured, 0.4.2), so a
    SIGTERM-first settle is a settle with no profile in it.  Sending SIGINT
    to the profiler alone rather than the group leaves the action running for
    those few hundred milliseconds, which is the price of having a profile of
    it; the group reap immediately after ends it.

    Everything here is best-effort by construction.  The caller is on its way
    out with a worker verdict already decided, and a failure to profile a
    failure must never replace it.
    """

    if process is None:
        return None
    backend = getattr(profile, "backend", None)
    flush = getattr(backend, "flush_signal", None)
    if profile is not None and flush is not None:
        with suppress(OSError, ProcessLookupError):
            os.kill(process.pid, flush)
            deadline = time.monotonic() + float(
                getattr(backend, "flush_seconds", 3.0)
            )
            while process.poll() is None and time.monotonic() < deadline:
                time.sleep(_PROFILE_SETTLE_POLL_SECONDS)
    grace = float(
        getattr(backend, "terminate_grace_seconds", _PROCESS_GROUP_GRACE_SECONDS)
    )
    _terminate_process_group(process, grace_s=min(
        grace, PROFILE_SETTLE_BUDGET_SECONDS / 2.0
    ))
    if profile is None or cas is None:
        return None
    record: dict[str, object]
    try:
        record = profile.ingest(cas)
    except Exception as exc:                      # noqa: BLE001 - see above
        record = profile.identity()
        record["produced"] = False
        record["reason"] = f"{type(exc).__name__}: {exc}"
    record["partial"] = True
    with suppress(ProfileUnusable):
        status = profile.exit_status()
        record["action_phase"] = status["phase"]
    return record


def _partial_profile_note(record: Mapping[str, object] | None) -> str:
    """One clause about a killed run's profile, for the failure message."""

    if record is None:
        return ""
    if record.get("produced"):
        return (f"  Its partial {record.get('mode')} profile is CAS blob "
                f"{record.get('blob_sha256')} ({record.get('bytes')} bytes); "
                "it covers only the part of the run that happened before the "
                "action was stopped.")
    if record.get("workload_coverage"):
        return (f"  Its partial {record.get('mode')} profile is CAS blob "
                f"{record.get('blob_sha256')} ({record.get('bytes')} bytes), "
                "but it does not cover the action's workload: "
                f"{record.get('reason')}")
    return (f"  No partial {record.get('mode')} profile survived the stop: "
            f"{record.get('reason')}")


def _profile_session(
    action: Mapping[str, object], *, working_directory: Path
) -> _ProfileSession | None:
    """The session this action's sealed params ask for, or ``None``.

    Refusing here is the point of the tier: a box without the backend fails the
    action and names itself, because a profiled run that came back unprofiled
    is not the action that was requested and nothing downstream could tell.
    """

    params = action["params"]
    assert isinstance(params, Mapping)
    mode = params.get(PROFILE_PARAM)
    if mode is None:
        return None
    if not isinstance(mode, str):
        raise LocalActionError("action params.profile must be a string mode")
    name, option = split_profile_mode(mode)
    try:
        backend = bind_profile_option(
            profile_backend_for(mode), name, option
        )
    except ProfileBackendUnavailable as exc:
        raise LocalActionError(
            f"this runtime offers no profile mode {mode!r} on "
            f"{socket.gethostname()}: {exc}"
        ) from exc
    try:
        backend.locate()  # type: ignore[attr-defined]
    except ProfileBackendUnavailable as exc:
        raise LocalActionError(
            f"profile backend {getattr(backend, 'name', mode)!r} is not "
            f"installed on {socket.gethostname()}: {exc}"
        ) from exc
    return _ProfileSession(
        mode=name,
        backend=backend,
        directory=working_directory / PROFILE_SCRATCH_DIRNAME,
    )


@contextmanager
def _profile_scratch(session: "_ProfileSession | None"):
    """Own the profile's scratch directory for exactly the run's lifetime.

    On the same ``with`` as the output lock so every exit -- a timeout, an
    unwind, a refused closure -- removes it.  A ``--here`` run writes into the
    caller's live checkout, where a leftover directory is litter somebody else
    has to explain.
    """

    if session is None:
        yield None
        return
    try:
        yield session
    finally:
        session.close()


def _ingested_result_note(cas: "PrismaBuildCAS", output: Path) -> str:
    """Put the child's own result in the CAS and name it in a failure message.

    A profiled run that failed on its profiler still produced whatever the
    action produced, and that output is the evidence for diagnosing why.  It is
    ingested as a blob rather than published as a result: the action failed, so
    it has no receipt and must run again.
    """

    if not output.is_file():
        return ""
    try:
        entry, _won = cas.ingest_input(
            output, input_id="prismabuild.profile.failed-result"
        )
    except (ActionContractError, CASTamperError, OSError) as exc:
        return f"  The action's own result could not be ingested: {exc}"
    return (f"  The action's own result is ingested as CAS blob "
            f"{entry['sha256']} ({entry['bytes']} bytes) so the failure can be "
            "read.")


def _validate_execution_paths(
    checkout_root: Path, working_directory: str, result_path: str
) -> tuple[Path, Path]:
    """Resolve an action cwd and refuse traversal out of the checkout."""

    if checkout_root.is_symlink():
        raise LocalActionError(f"checkout root is a symlink: {checkout_root}")
    try:
        resolved_root = checkout_root.resolve(strict=True)
    except OSError as exc:
        raise LocalActionError(f"checkout root is unavailable: {checkout_root}") from exc
    cwd = (
        checkout_root
        if working_directory == "."
        else checkout_root / working_directory
    )
    try:
        resolved_cwd = cwd.resolve(strict=True)
        resolved_cwd.relative_to(resolved_root)
    except (OSError, ValueError) as exc:
        raise LocalActionError(
            f"declared working directory escapes or is unavailable: {cwd}"
        ) from exc
    if cwd.is_symlink() or not resolved_cwd.is_dir():
        raise LocalActionError(
            f"declared working directory is not a real directory: {cwd}"
        )
    return resolved_cwd, resolved_cwd / result_path


def _validate_result_containment(output: Path, cwd: Path) -> None:
    """Refuse result files reached through a symlinked parent or final link."""

    try:
        resolved = output.resolve(strict=True)
        resolved.relative_to(cwd)
    except (OSError, ValueError) as exc:
        raise LocalActionError(
            f"declared result escapes or is unavailable: {output}"
        ) from exc
    relative = output.relative_to(cwd)
    cursor = cwd
    for component in relative.parts:
        cursor = cursor / component
        try:
            mode = cursor.lstat().st_mode
        except OSError as exc:
            raise LocalActionError(
                f"cannot inspect declared result path: {cursor}"
            ) from exc
        if stat.S_ISLNK(mode):
            raise LocalActionError(
                f"declared result path traverses a symlink: {cursor}"
            )
    if not stat.S_ISREG(output.lstat().st_mode):
        raise LocalActionError(f"declared result is not a regular file: {output}")


def _refuse_existing_result_symlink_prefix(output: Path, cwd: Path) -> None:
    """Reject a pre-existing symlink in the declared output path."""

    relative = output.relative_to(cwd)
    cursor = cwd
    for component in relative.parts:
        cursor = cursor / component
        try:
            mode = cursor.lstat().st_mode
        except FileNotFoundError:
            return
        except OSError as exc:
            raise LocalActionError(
                f"cannot inspect declared result path: {cursor}"
            ) from exc
        if stat.S_ISLNK(mode):
            raise LocalActionError(
                f"declared result path traverses a symlink: {cursor}"
            )


def local_result_claim_body(
    action: Mapping[str, object], checkout: Path
) -> dict[str, object]:
    """Derive a live-checkout claim body without writing a claim or receipt.

    The caller supplies a validated action and an accessible checkout. Path
    resolution may read the filesystem; status consumers must bound this call.
    """

    task = action["task"]
    if not isinstance(task, Mapping):
        raise ActionContractError("validated action task is not an object")
    return {
        "schema": LOCAL_RESULT_CLAIM_SCHEMA_V1,
        "action_key": action["action_key"],
        "action_manifest_sha256": canonical_sha256(action),
        "checkout_root": str(checkout.resolve(strict=True)),
        "working_directory": task["working_directory"],
        "result_path": task["result_path"],
    }


def _local_result_claim_body(
    action: Mapping[str, object], checkout: Path
) -> dict[str, object]:
    """Compatibility entry point for existing claim producers."""
    return local_result_claim_body(action, checkout)


def _local_result_claim_path(
    cas: PrismaBuildCAS, action: Mapping[str, object], checkout: Path
) -> Path:
    body = _local_result_claim_body(action, checkout)
    digest = canonical_sha256(body)
    return (
        cas.root
        / "local-results"
        / "v1"
        / digest[:2]
        / f"{digest}.json"
    )


def _validate_local_result_claim(
    value: object,
    *,
    action: Mapping[str, object],
    checkout: Path,
) -> dict[str, object]:
    try:
        raw = _exact_mapping(
            value,
            keys=_LOCAL_RESULT_CLAIM_KEYS,
            where="local result claim",
        )
        expected = _local_result_claim_body(action, checkout)
        body = {key: raw[key] for key in _LOCAL_RESULT_CLAIM_BODY_KEYS}
        if body != expected:
            _fail("local result claim differs from the action and checkout")
        digest = _sha256(
            raw["claim_sha256"], where="local result claim.claim_sha256"
        )
        if digest != canonical_sha256(body):
            _fail("local result claim digest does not match its body")
        return {**body, "claim_sha256": digest}
    except ActionContractError as exc:
        raise CASTamperError(str(exc)) from exc


def _load_local_result_claim(
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    checkout: Path,
) -> dict[str, object] | None:
    path = _local_result_claim_path(cas, action, checkout)
    try:
        raw = _read_regular_file_nofollow(
            path, where="local result claim", require_readonly=True
        )
    except FileNotFoundError:
        return None
    value = _decode_strict_json(raw, where="local result claim")
    claim = _validate_local_result_claim(
        value, action=action, checkout=checkout
    )
    if raw != _canonical_file_bytes(claim):
        raise CASTamperError("local result claim is not canonical JSON")
    return claim


def _ensure_local_result_claim(
    cas: PrismaBuildCAS,
    action: Mapping[str, object],
    checkout: Path,
) -> dict[str, object]:
    body = _local_result_claim_body(action, checkout)
    claim = {**body, "claim_sha256": canonical_sha256(body)}
    path = _local_result_claim_path(cas, action, checkout)
    won = _atomic_publish(path, _canonical_file_bytes(claim))
    observed = _load_local_result_claim(cas, action, checkout)
    if observed is None:
        raise CASTamperError("local result claim vanished after publication")
    if observed != claim:
        raise CASTamperError(
            "local result claim publication raced with conflicting state"
        )
    if won and path.name != f"{claim['claim_sha256']}.json":
        raise AssertionError("local result claim address differs from its digest")
    return observed


def _reap_local_result_staging(
    cas: PrismaBuildCAS, claim: Mapping[str, object]
) -> int:
    """Remove bounded private staging leaves left by a killed claimed run."""

    namespace = _sha256(
        claim["claim_sha256"], where="local result claim.claim_sha256"
    )
    directory = cas.root / ".staging" / "local-results" / namespace
    try:
        directory_fd = _open_directory_nofollow(
            directory, where="local result staging directory"
        )
    except FileNotFoundError:
        return 0
    names: list[str] = []
    try:
        try:
            with os.scandir(directory_fd) as entries:
                for entry in entries:
                    name = entry.name
                    if not (name.startswith(".payload.") and name.endswith(".tmp")):
                        raise CASTamperError(
                            f"unexpected local result staging entry: {directory / name}"
                        )
                    names.append(name)
                    if len(names) > _MAX_LOCAL_RESULT_STAGING_FILES:
                        raise CASTamperError(
                            "local result staging file count exceeds the recovery bound"
                        )
        except OSError as exc:
            raise CASUnavailableError(
                f"cannot list local result staging directory: {directory}: {exc}"
            ) from exc
        for name in sorted(names):
            try:
                info = os.stat(name, dir_fd=directory_fd, follow_symlinks=False)
            except OSError as exc:
                raise CASTamperError(
                    f"local result staging entry changed during recovery: {directory / name}"
                ) from exc
            if not stat.S_ISREG(info.st_mode):
                raise CASTamperError(
                    f"local result staging entry is not regular: {directory / name}"
                )
            if info.st_uid != os.geteuid():
                raise CASTamperError(
                    f"local result staging entry has a foreign owner: {directory / name}"
                )
            try:
                os.unlink(name, dir_fd=directory_fd)
            except OSError as exc:
                raise CASUnavailableError(
                    f"cannot remove local result staging entry: {directory / name}: {exc}"
                ) from exc
        if names:
            os.fsync(directory_fd)
        _assert_directory_identity(
            directory_fd,
            directory,
            where="local result staging directory",
        )
        return len(names)
    finally:
        os.close(directory_fd)


def _remove_claimed_local_result(output: Path, cwd: Path) -> None:
    """Remove only a regular, contained result owned by a validated claim."""

    _validate_result_containment(output, cwd)
    _unlink_nofollow(output, where="claimed local result")
    if output.exists() or output.is_symlink():
        raise LocalActionError(
            f"claimed local result remained after deterministic recovery: {output}"
        )


def repair_local_result(
    action: object,
    *,
    cas_root: str | Path,
    checkout_root: str | Path,
) -> dict[str, object]:
    """Remove a crash-left declared result only under its immutable claim.

    This never removes an unclaimed path, a symlink, or a result whose action
    already has a canonical receipt.  The same output lock used by execution
    serializes repair with a live local producer.
    """

    normalized = validate_action(action)
    root = Path(checkout_root)
    if not root.is_absolute():
        raise ActionContractError("checkout_root must be absolute")
    cas = PrismaBuildCAS(cas_root)
    if cas.lookup(normalized) is not None:
        raise LocalActionError(
            "cannot repair a declared result after its action has a CAS receipt"
        )
    task = normalized["task"]
    if not isinstance(task, Mapping):
        raise ActionContractError("validated action task is not an object")
    cwd, output = _validate_execution_paths(
        root, str(task["working_directory"]), str(task["result_path"])
    )
    with _local_output_lock(cas, root, output):
        # The pre-lock lookup is only a fast refusal.  A producer can publish
        # while this repair waits for the shared output lock, so the decision
        # to unlink must be made from a fresh receipt lookup while exclusion
        # is held.
        if cas.lookup(normalized) is not None:
            raise LocalActionError(
                "cannot repair a declared result after its action has a CAS receipt"
            )
        claim = _load_local_result_claim(cas, normalized, root)
        if claim is None:
            raise LocalActionError(
                "declared result has no matching immutable recovery claim"
            )
        reaped_staging_files = _reap_local_result_staging(cas, claim)
        if output.exists() or output.is_symlink():
            _remove_claimed_local_result(output, cwd)
            status = "removed"
        else:
            _refuse_existing_result_symlink_prefix(output, cwd)
            status = "already_absent"
    return {
        "status": status,
        "action_key": normalized["action_key"],
        "claim_sha256": claim["claim_sha256"],
        "result_path": str(output),
        "reaped_staging_files": reaped_staging_files,
    }


@contextmanager
def _local_output_lock(cas: PrismaBuildCAS, checkout: Path, output: Path):
    """Serialize actions sharing one live-checkout result path.

    The yielded descriptor is the locked open-file description.  Local task
    processes inherit it explicitly so abrupt worker death cannot release the
    lock while the task (or an inherited descendant) can still write the
    declared output.

    The identity is the canonical physical output path and nothing else.  It
    used to hash the resolved checkout root as well, which made one file two
    locks: ``checkout_root=/repo`` with ``working_directory=sub`` and
    ``checkout_root=/repo/sub`` with ``working_directory=.`` both resolve to
    ``/repo/sub/result.bin``, so two concurrent actions each passed the
    absent-result check and one published the other's bytes under its own
    deterministic key.  ``checkout`` is still taken, because the caller's root
    is what names the output, but it is deliberately not part of the
    exclusion identity: what has to be exclusive is the file.
    """

    identity = hashlib.sha256(
        os.path.normpath(str(output)).encode("utf-8")
    ).hexdigest()
    directory = cas.root / ".worker-locks"
    path = directory / f"{identity}.lock"
    directory_fd = _open_directory_nofollow(
        directory, where="local action lock directory", create=True
    )
    flags = os.O_RDWR | os.O_CREAT | os.O_CLOEXEC | os.O_NOFOLLOW
    try:
        descriptor = os.open(path.name, flags, 0o600, dir_fd=directory_fd)
    except OSError as exc:
        os.close(directory_fd)
        raise LocalActionError(f"cannot open local action lock: {path}") from exc
    try:
        if not stat.S_ISREG(os.fstat(descriptor).st_mode):
            raise LocalActionError(
                f"local action lock is not a regular file: {path}"
            )
        _assert_directory_identity(
            directory_fd, directory, where="local action lock directory"
        )
        fcntl.flock(descriptor, fcntl.LOCK_EX)
        yield descriptor
    finally:
        # Closing releases the lock only after the final duplicate of this
        # open-file description closes.  Do not issue LOCK_UN: a task that
        # inherited the descriptor must retain exclusion if the worker
        # unwinds before that task can be reaped.
        os.close(descriptor)
        os.close(directory_fd)


def _process_group_has_live_members(pgid: int) -> bool:
    """Whether any process that has not exited still belongs to ``pgid``.

    ``os.killpg(pgid, 0)`` answers "is this group non-empty", and a zombie
    counts: a process that has exited stays a member of its group until its
    parent reaps it.  A worker that happens to be the nearest subreaper
    inherits an orphaned descendant's zombie and would then see a group that
    never empties.  So ``killpg`` is used only for the cheap "definitely
    empty" answer, and ``/proc`` decides the rest, skipping the exited states.
    """

    try:
        os.killpg(pgid, 0)
    except ProcessLookupError:
        return False
    except OSError:
        return True
    try:
        entries = os.listdir("/proc")
    except OSError:
        # Without a process table to read, the non-empty answer above stands.
        return True
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            with open(f"/proc/{entry}/stat", "rb") as handle:
                raw = handle.read()
        except OSError:
            continue
        # The command name is parenthesized and may itself contain spaces and
        # parentheses, so the fields are read from after its final ``)``:
        # state, then ppid, then the process group id.
        _, _, tail = raw.rpartition(b")")
        fields = tail.split()
        if len(fields) < 3 or fields[0] in {b"Z", b"X", b"x"}:
            continue
        try:
            if int(fields[2]) == pgid:
                return True
        except ValueError:
            continue
    return False


def _process_group_settled(
    process: subprocess.Popen[bytes] | subprocess.Popen[str], pgid: int
) -> bool:
    """Whether the leader is reaped and nothing else in its group is left."""

    if process.poll() is None:
        return False
    return not _process_group_has_live_members(pgid)


def _await_process_group_exit(
    process: subprocess.Popen[bytes] | subprocess.Popen[str],
    pgid: int,
    grace_s: float,
) -> bool:
    """Wait up to ``grace_s`` for the whole group to go, leader included."""

    deadline = time.monotonic() + grace_s
    while True:
        if _process_group_settled(process, pgid):
            return True
        remaining = deadline - time.monotonic()
        if remaining <= 0:
            return False
        interval = min(remaining, _PROCESS_GROUP_POLL_SECONDS)
        if process.poll() is None:
            try:
                process.wait(timeout=interval)
            except subprocess.TimeoutExpired:
                pass
        else:
            time.sleep(interval)


def _terminate_process_group(
    process: subprocess.Popen[bytes] | subprocess.Popen[str],
    *,
    grace_s: float = _PROCESS_GROUP_GRACE_SECONDS,
) -> None:
    """Signal a whole process group down: TERM, ``grace_s``, KILL, ``grace_s``.

    ``grace_s`` is a parameter because the leader of the group is not always
    the last thing that has to die.  A worker launcher relays the TERM into an
    action of its own before exiting, and a caller reaping *that* group has to
    outlast the relay or it SIGKILLs the launcher mid-reap and orphans the
    action -- see ``pool.PoolQueue.execute``.

    The protocol runs against the live group, not against the leader.  Leader
    exit is not proof the group is gone: a descendant only has to ignore
    SIGTERM while the leader accepts it, and the old early return then skipped
    SIGKILL and handed the caller a timeout while that descendant kept the
    compute and its inherited copy of the output lock.  Every branch, the
    leader-already-exited one included, now drives TERM, grace and KILL until
    the group has no live member or the bounded grace runs out.
    """

    pgid = process.pid
    if _process_group_settled(process, pgid):
        return
    try:
        os.killpg(pgid, signal.SIGTERM)
    except ProcessLookupError:
        # Nothing in the group is signallable; the leader may still need
        # reaping so it does not linger as a zombie of this worker.
        process.poll()
        return
    if _await_process_group_exit(process, pgid, grace_s):
        return
    try:
        os.killpg(pgid, signal.SIGKILL)
    except ProcessLookupError:
        process.poll()
        return
    _await_process_group_exit(process, pgid, grace_s)


@contextmanager
def _sigterm_unwinds_this_process():
    """Make SIGTERM and SIGINT unwind this worker so its action is reaped too.

    The action below runs in its own session on purpose, which is exactly what
    keeps it alive through a signal aimed at this worker -- and exactly what
    makes the default SIGTERM disposition wrong here.  Terminating where we
    stand skips the ``except BaseException`` reap, and the action keeps the
    GPU, the memory and the caller's ledger token with nothing left watching
    it.  Handling the signal turns termination into the unwind that already
    knows how to reap the action group.

    SIGINT is owned here for the same reason, and explicitly: Python installs
    its ``KeyboardInterrupt`` handler only when the interpreter starts with
    SIGINT at its default disposition.  A worker launched by a non-interactive
    shell's ``&``, by ``nohup``, or by any launcher that ignores SIGINT
    inherits ``SIG_IGN`` and is then not interruptible at all -- the fleet's
    dl380g10 loops ran that way, which is how the interruption gate could not
    certify its own property there (issue #25).  Whether an interruption
    reaps the action must be a fact about this worker, not about who exec'd
    it.

    The handler disarms itself before raising: a second signal landing while
    ``_terminate_process_group`` waits out its grace would raise straight
    through the reap and abandon it half-finished.
    """

    def _unwind(signum, frame):                       # noqa: ARG001
        signal.signal(signum, signal.SIG_IGN)
        raise SystemExit(128 + signum)

    def _interrupt(signum, frame):                    # noqa: ARG001
        signal.signal(signum, signal.SIG_IGN)
        raise KeyboardInterrupt

    try:
        previous_term = signal.signal(signal.SIGTERM, _unwind)
    except ValueError:
        # Not the main thread.  A library caller's signal disposition is not
        # this function's to set, and an in-process run has a live parent that
        # owns it; leave it alone rather than fail the action over it.
        yield
        return
    previous_int = signal.signal(signal.SIGINT, _interrupt)
    try:
        yield
    finally:
        signal.signal(signal.SIGINT, previous_int)
        signal.signal(signal.SIGTERM, previous_term)


def run_local_action(
    action: object,
    *,
    cas_root: str | Path,
    checkout_root: str | Path,
    timeout_seconds: float | None = None,
    recompute: bool = False,
    worker_launcher_identity: object | None = None,
    initial_miss_rendezvous: str | Path | None = None,
) -> dict[str, object]:
    """Execute one action locally and publish its declared file result."""

    normalized = validate_action(action)
    root = Path(checkout_root)
    if not root.is_absolute():
        raise ActionContractError("checkout_root must be absolute")
    cas = PrismaBuildCAS(cas_root)
    if recompute and initial_miss_rendezvous is not None:
        raise ActionContractError(
            "initial-miss rendezvous is incompatible with recompute"
        )
    initial_miss_receipt: dict[str, object] | None = None
    if not recompute:
        cached = cas.lookup(normalized)
        if cached is not None:
            verify_code_closure(normalized["code_closure"], root)
            return {
                "status": "cache_hit",
                "receipt": cached,
                "payload_path": str(cas._verified_receipt_result_path(cached)),
            }
        if initial_miss_rendezvous is not None:
            # This call is deliberately adjacent to the first authoritative
            # miss and precedes checkout/output resolution and its local lock.
            initial_miss_receipt = _run_initial_miss_rendezvous(
                manifest_path=initial_miss_rendezvous,
                cas=cas,
                action=normalized,
                worker_launcher_identity=worker_launcher_identity,
            )
    task = normalized["task"]
    environment = normalized["environment"]
    assert isinstance(task, Mapping)
    assert isinstance(environment, Mapping)
    cwd, output = _validate_execution_paths(
        root, str(task["working_directory"]), str(task["result_path"])
    )
    # Before the output lock and before any checkout is touched: a box that
    # cannot honour the profile the action asked for refuses here, having done
    # nothing.
    profile = _profile_session(normalized, working_directory=cwd)
    variables = environment["variables"]
    assert isinstance(variables, Mapping)
    recovered_declared_result = False
    reaped_staging_files = 0
    with _local_output_lock(cas, root, output) as output_lock_descriptor, \
            _profile_scratch(profile):
        # A concurrent producer may have filled the cache while this worker
        # waited for the checkout/output lock.
        if not recompute:
            cached = cas.lookup(normalized)
            if cached is not None:
                verify_code_closure(normalized["code_closure"], root)
                result: dict[str, object] = {
                    "status": "cache_hit",
                    "receipt": cached,
                    "payload_path": str(cas._verified_receipt_result_path(cached)),
                }
                if initial_miss_receipt is not None:
                    result["initial_miss_rendezvous"] = initial_miss_receipt
                return result
        attestation = preflight_action(
            normalized,
            cas_root=cas_root,
            checkout_root=root,
            worker_launcher_identity=worker_launcher_identity,
        )
        claim = _load_local_result_claim(cas, normalized, root)
        if claim is not None:
            reaped_staging_files = _reap_local_result_staging(cas, claim)
        if output.exists() or output.is_symlink():
            if claim is None:
                raise LocalActionError(
                    "declared result path must be absent before execution and "
                    f"has no matching recovery claim: {output}"
                )
            _remove_claimed_local_result(output, cwd)
            recovered_declared_result = True
        _refuse_existing_result_symlink_prefix(output, cwd)
        if claim is None:
            claim = _ensure_local_result_claim(cas, normalized, root)
        # The claim is durable before task argv. Recheck the owned path after
        # publication so an out-of-protocol checkout writer cannot silently
        # pre-populate the result in the claim-publication interval.
        if output.exists() or output.is_symlink():
            raise LocalActionError(
                f"declared result appeared before action execution: {output}"
            )
        _refuse_existing_result_symlink_prefix(output, cwd)
        process: subprocess.Popen[bytes] | None = None
        execution_deadline: float | None = None
        launch_argv = list(task["argv"])
        launch_environment = {
            str(key): str(value) for key, value in variables.items()
        }
        launch_environment.update(_progress_environment(normalized, launch_environment))
        launch_environment.update(_residency_environment(normalized, launch_environment))
        if profile is not None:
            launch_environment.update(profile.environment(launch_environment))
            # The sealed argv is exec'd verbatim underneath what this returns.
            # ``preflight_action`` attests ``task.argv[0]`` off the action, not
            # off this list, so the executable this action names is still the
            # one attested and rechecked after the run.
            launch_argv = profile.launch_argv(task["argv"])
        with _sigterm_unwinds_this_process():
            try:
                process = subprocess.Popen(
                    launch_argv,
                    cwd=cwd,
                    env=launch_environment,
                    shell=False,
                    stdin=subprocess.DEVNULL,
                    start_new_session=True,
                    # The action keeps exclusion alive if this worker is killed.
                    # ``pass_fds`` clears close-on-exec in the child while the
                    # parent's descriptor remains CLOEXEC for unrelated execs.
                    pass_fds=(output_lock_descriptor,),
                )
                if timeout_seconds is not None:
                    execution_deadline = time.monotonic() + timeout_seconds
                returncode = process.wait(timeout=timeout_seconds)
            except subprocess.TimeoutExpired as exc:
                partial = _reap_and_settle(process, profile, cas)
                raise LocalActionError(
                    f"action execution timed out: {exc}"
                    + _partial_profile_note(partial),
                    profile=partial,
                ) from exc
            except OSError as exc:
                _reap_and_settle(process, None, None)
                raise LocalActionError(f"action execution failed: {exc}") from exc
            except BaseException:
                # A handled signal (SIGINT/KeyboardInterrupt, and SIGTERM by
                # the context manager above) unwinds this process while its
                # new-session child keeps running.  Reap the entire action
                # group before the context manager closes its copy of the
                # descriptor shared with that child.  If the child cannot be
                # reaped, its duplicate continues to hold the lock.
                #
                # This -- not ``TimeoutExpired`` -- is where a pool deadline
                # actually lands: ``pool.worker_argv`` passes no
                # ``--timeout-seconds``, so the pool enforces its deadline by
                # signalling the launcher's session, which arrives here as the
                # ``SystemExit`` that ``_sigterm_unwinds_this_process`` raises.
                # ``main`` never sees a ``LocalActionError`` on this path, so
                # the partial profile is written to the status file here rather
                # than left to the handler that does not run.
                partial = _reap_and_settle(process, profile, cas)
                if partial is not None:
                    _write_action_status({"profile": dict(partial)})
                raise
        profile_record: dict[str, object] | None = None
        if profile is not None:
            # The profiler's own exit status is not the action's (py-spy exits
            # 0 whatever it ran), so both facts come out of the session.  The
            # profile is read back before the status is judged: a failing run's
            # profile is usually the reason somebody asked for one.
            action_status: int | None = None
            try:
                # Before the ingest, so the profiler's own status is on the
                # record this builds rather than added to it afterwards.
                profile.backend_returncode = returncode
                if getattr(profile.backend, "exits_before_action", False):
                    # The report is complete even though the action may still
                    # run. Contained deadlines kill the broker scope outright;
                    # no Python exception handler can save evidence afterwards.
                    # Checkpoint it before waiting, without publishing success.
                    profile_record = profile.ingest(cas)
                    checkpoint = {**profile_record, "partial": True}
                    with suppress(ProfileUnusable):
                        checkpoint["action_phase"] = profile.exit_status()["phase"]
                    _write_action_status({"profile": checkpoint})
                action_status = profile.action_returncode(
                    process, deadline=execution_deadline
                )
                if profile_record is None:
                    profile_record = profile.ingest(cas)
            except subprocess.TimeoutExpired as exc:
                partial = _reap_and_settle(process, profile, cas)
                raise LocalActionError(
                    f"action execution timed out: {exc}"
                    + _partial_profile_note(partial),
                    profile=partial,
                ) from exc
            except ProfileUnusable as exc:
                # An early profiler's unusable report can now refuse before
                # the relay wait. Its action still belongs to this attempt.
                if getattr(profile.backend, "exits_before_action", False):
                    _terminate_process_group(process)
                raise LocalActionError(
                    f"profile backend "
                    f"{getattr(profile.backend, 'name', profile.mode)!r} "
                    f"produced no usable profile: {exc}.  A profiled action "
                    "that leaves no profile is not the action that was "
                    "requested, so this run failed."
                    + f"  The profiler exited with status {returncode}."
                    + ("" if action_status is None else
                       f"  The action itself ended with status "
                       f"{action_status}.")
                    + "  The profiler's own message is on the action's own "
                    "stderr, which its result log captured."
                    + _ingested_result_note(cas, output)
                ) from exc
            except BaseException:
                # A windowed profiler can have exited while its action still
                # runs. A pool signal during that settle must retain the
                # completed report before _profile_scratch removes it, just
                # as a signal during process.wait does above.
                partial = _reap_and_settle(process, profile, cas)
                if partial is not None:
                    _write_action_status({"profile": dict(partial)})
                raise
            profile.note_backend_status(returncode, profile_record)
            returncode = action_status
        if returncode != 0:
            raise LocalActionError(
                f"action argv exited with status {returncode}"
                + (f"; its profile is CAS blob {profile_record['blob_sha256']}"
                   if profile_record is not None else ""),
                returncode=returncode,
                signal=-returncode if returncode < 0 else None,
                # The same reason the timed-out path carries one: a failing run
                # is the run somebody most wants a profile of.  Publication is
                # below this raise, so the refresh a successful run gets never
                # happens here, and without this the only profile left beside
                # the job is the in-flight checkpoint ``ingest`` wrote -- marked
                # partial, for a report that is complete.  The message already
                # names the blob; a reader should not have to scrape prose for
                # a record this frame is holding.
                profile=profile_record,
            )
        if profile_record is not None and profile_record.get("produced") is False:
            # A profile that does not cover the action's workload is not the
            # profile that was asked for, and the action's zero exit does not
            # change that.  Publishing the result would file a receipt whose
            # every later cache hit carries no profile at all, so the failure
            # is the honest ending -- with the host-side blob, its digest and
            # any negative-coverage metadata preserved on it and in the status
            # sidecar that ``ingest`` already checkpointed (#562, #372).
            raise LocalActionError(
                f"the {profile_record.get('mode')} profile does not cover the "
                "action's workload: "
                + str(profile_record.get("reason") or "no reason recorded")
                + ".  No receipt was published: a receipt filed for this key "
                "would answer every later submission of it with a cache hit "
                "that carries no profile."
                + _ingested_result_note(cas, output),
                profile=profile_record,
            )
        if not output.exists() and not output.is_symlink():
            raise LocalActionError(
                f"action succeeded without its declared result file: {output}"
            )
        # Preflight alone is insufficient: an action (or another checkout
        # writer) can change a closure member while argv is running.  Check
        # once before an expensive result copy, then again at the CAS receipt
        # commit point so copying a large artifact cannot reopen that gap.
        verify_code_closure(normalized["code_closure"], root)
        _verify_attested_executable_unchanged(attestation, normalized)
        _verify_attested_worker_runtime_unchanged(attestation, normalized)
        _validate_result_containment(output, cwd)

        def verify_publication_provenance() -> None:
            verify_code_closure(normalized["code_closure"], root)
            _verify_attested_executable_unchanged(attestation, normalized)

        receipt, won = cas.publish_result(
            normalized,
            output,
            attestation=attestation,
            precommit_verify=verify_publication_provenance,
            staging_namespace=str(claim["claim_sha256"]),
        )
    result = {
        "status": "published" if won else "canonical_result_reused",
        "receipt": receipt,
        # ``publish_result`` has already consumed or identity-proved the exact
        # canonical blob.  Returning its name must not trigger a fourth full
        # read of a large result; public lookups remain content-verifying.
        "payload_path": str(cas._verified_receipt_result_path(receipt)),
        "recovered_declared_result": recovered_declared_result,
        "reaped_staging_files": reaped_staging_files,
        "local_result_claim_sha256": claim["claim_sha256"],
    }
    if profile_record is not None:
        # Its own key, so a reader tests one field rather than parsing prose,
        # and so the pool can lift it into the ending without knowing anything
        # else about this dictionary.
        result["profile"] = profile_record
        # Result publication succeeded. Replace the in-flight checkpoint so
        # the pool's fallback has the same complete evidence if the final
        # stdout line is lost or interleaved with late payload output.
        _write_action_status({"profile": profile_record})
    if initial_miss_receipt is not None:
        result["initial_miss_rendezvous"] = initial_miss_receipt
    return result


def _read_json_mapping(path: Path, *, where: str) -> Mapping[str, object]:
    raw = _read_regular_file(path, where=where)
    value = _decode_strict_json(raw, where=where)
    if not isinstance(value, Mapping):
        raise ActionContractError(f"{where} root must be an object")
    return value


def _atomic_write_new_json(path: Path, value: Mapping[str, object]) -> None:
    if path.exists() or path.is_symlink():
        raise ActionContractError(f"output already exists: {path}")
    if not _atomic_publish(path, json.dumps(
        value,
        indent=2,
        sort_keys=True,
        ensure_ascii=False,
        allow_nan=False,
    ).encode("utf-8") + b"\n"):
        raise ActionContractError(f"output appeared concurrently: {path}")


def _require_slurm_initial_start(
    environment: Mapping[str, str] | None = None,
) -> None:
    """Refuse a requeued/admin-restarted batch process before task argv runs.

    PrismaBuild's Slurm adapter currently seals ``max_requeues=0`` and submits
    with ``--no-requeue``. Slurm nevertheless exposes the actual restart count
    to the launched process; this worker-side gate is the final defense if an
    administrator or site policy restarts the allocation anyway.
    """

    env = os.environ if environment is None else environment
    job_id = env.get("SLURM_JOB_ID")
    if type(job_id) is not str or re.fullmatch(r"[1-9][0-9]{0,19}", job_id) is None:
        raise ActionContractError(
            "Slurm worker requires a positive numeric SLURM_JOB_ID"
        )
    restart_count = env.get("SLURM_RESTART_COUNT", "0")
    if type(restart_count) is not str or re.fullmatch(
        r"(?:0|[1-9][0-9]{0,8})", restart_count
    ) is None:
        raise ActionContractError("SLURM_RESTART_COUNT is malformed")
    if int(restart_count) != 0:
        raise ActionContractError(
            "restarted Slurm allocation is not authorized to execute task argv"
        )


def _build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    commands = parser.add_subparsers(dest="command", required=True)
    closure = commands.add_parser("seal-closure")
    closure.add_argument("--root", required=True, type=Path)
    closure.add_argument("--file", action="append", required=True)
    closure.add_argument("--output", required=True, type=Path)
    seal = commands.add_parser("seal-action")
    seal.add_argument("--body", required=True, type=Path)
    seal.add_argument("--output", required=True, type=Path)
    key = commands.add_parser("key")
    key.add_argument("--action", required=True, type=Path)
    verify = commands.add_parser("verify")
    verify.add_argument("--action", required=True, type=Path)
    verify.add_argument("--cas-root", required=True, type=Path)
    ingest = commands.add_parser("ingest-input")
    ingest.add_argument("--source", required=True, type=Path)
    ingest.add_argument("--cas-root", required=True, type=Path)
    ingest.add_argument("--input-id", required=True)
    ingest.add_argument("--expected-sha256")
    ingest.add_argument("--expected-bytes", type=int)
    verify_input = commands.add_parser("verify-input")
    verify_input.add_argument("--input-contract", required=True, type=Path)
    verify_input.add_argument("--cas-root", required=True, type=Path)
    run = commands.add_parser("run-local")
    run.add_argument("--action", required=True, type=Path)
    run.add_argument("--cas-root", required=True, type=Path)
    run.add_argument("--checkout-root", required=True, type=Path)
    run.add_argument("--timeout-seconds", type=float)
    run.add_argument("--recompute", action="store_true")
    run.add_argument("--require-slurm-initial-start", action="store_true")
    run.add_argument("--initial-miss-rendezvous", type=Path)
    repair = commands.add_parser("repair-local-result")
    repair.add_argument("--action", required=True, type=Path)
    repair.add_argument("--cas-root", required=True, type=Path)
    repair.add_argument("--checkout-root", required=True, type=Path)
    preflight = commands.add_parser("preflight")
    preflight.add_argument("--action", required=True, type=Path)
    preflight.add_argument("--cas-root", required=True, type=Path)
    preflight.add_argument("--checkout-root", required=True, type=Path)
    return parser


def _record_action_status(error: LocalActionError) -> None:
    """Leave the action's own ending where the transport that asked can read it.

    This process exits 1 whatever the action did, so its exit status cannot
    carry the action's -- and it must not: the launcher's status is what every
    fleet reader means by ``detail.returncode``. The number goes beside the
    job's logs instead, and the caller decides what to do with it.

    Written only for an action that ran and ended by itself. A worker verdict
    -- a missing result, a timeout -- leaves no file, so that a transport
    reading one knows it is reading the action's ending and not a default.
    A file this cannot write is a diagnostic lost, never an ending changed, so
    every failure here is swallowed and the original error is raised on.
    """

    body: dict[str, object] = {}
    if error.returncode is not None:
        body["action_returncode"] = int(error.returncode)
        if error.signal is not None:
            body["action_signal"] = int(error.signal)
    if error.profile is not None:
        body["profile"] = dict(error.profile)
    _write_action_status(body)


def _write_action_status(body: Mapping[str, object]) -> None:
    """Merge fields into the action's status file, or lose them quietly.

    Merging rather than replacing, because two facts about one ending are
    written from two places: the action's own returncode comes out of
    ``main``'s handler, and a killed run's partial profile is written from the
    unwind itself, which that handler never reaches.  A last writer that
    replaced the file would drop whichever fact arrived first.
    """

    destination = os.environ.get(ACTION_STATUS_PATH_ENV) or ""
    if not destination or not body:
        return
    path = Path(destination)
    merged: dict[str, object] = {}
    try:
        existing = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        existing = None
    if isinstance(existing, dict):
        merged.update(existing)
    merged.update(body)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.parent / f".{path.name}.{os.getpid()}.tmp"
        tmp.write_text(
            json.dumps(merged, sort_keys=True) + "\n", encoding="utf-8"
        )
        os.replace(tmp, path)
    except OSError:
        pass


def validate_progress_policy(value: object, *, where: str = "action.params.progress") -> dict[str, object]:
    """Normalize the sealed no-progress policy, or refuse it.

    The phase list is *closed* on purpose.  A runtime record naming a phase
    the submitter did not declare is not advancement, which is what makes the
    total time an action may run without ever committing a unit a number a
    reader can compute -- ``sum(grace_s)``, each phase re-arming once -- rather
    than a fresh unexplained constant standing in for the one this contract
    exists to remove.  The phases are the workload's own: startup, capture,
    compile, the loop, finalization.  Declare what the work does and the bound
    follows from it.

    Optional ``cycle: true`` lets phases repeat. Each phase grants grace once
    between increases in the cumulative count, preserving that bound after
    the count stops. Old readers reject the extra field; placement requires
    the separate cyclic-watchdog capability.
    """

    if (not isinstance(value, Mapping)
            or set(value) not in ({"schema", "phases"}, {"schema", "phases", "cycle"})):
        _fail(f"{where} must declare schema and phases, with optional cycle")
    if value["schema"] != PROGRESS_POLICY_SCHEMA_V1:
        _fail(f"{where}.schema must be {PROGRESS_POLICY_SCHEMA_V1!r}")
    if "cycle" in value and type(value["cycle"]) is not bool:
        _fail(f"{where}.cycle must be a boolean")
    phases = value["phases"]
    if not isinstance(phases, Sequence) or isinstance(phases, (str, bytes)):
        _fail(f"{where}.phases must be a list of phases")
    if not phases:
        _fail(f"{where}.phases must name at least one phase")
    normalized: list[dict[str, object]] = []
    seen: set[str] = set()
    for index, phase in enumerate(phases):
        at = f"{where}.phases[{index}]"
        if not isinstance(phase, Mapping) or set(phase) != {"name", "grace_s"}:
            _fail(f"{at} must declare exactly name and grace_s")
        name = phase["name"]
        if (not isinstance(name, str) or not name or name.strip() != name
                or "\x00" in name):
            _fail(f"{at}.name must be a nonempty trimmed string")
        if name in seen:
            # Phase entry re-arms the allowance once.  A repeated name would
            # make ``sum(grace_s)`` stop being the bound it is reported as.
            _fail(f"{at}.name repeats an earlier phase: {name!r}")
        seen.add(name)
        grace = phase["grace_s"]
        try:
            finite = math.isfinite(grace)
        except (TypeError, OverflowError):
            finite = False
        if type(grace) not in (int, float) or not finite or grace <= 0:
            _fail(f"{at}.grace_s must be a positive finite number")
        normalized.append({"name": name, "grace_s": grace})
    if not math.isfinite(sum(float(phase["grace_s"]) for phase in normalized)):
        _fail(f"{where}.phases must have a finite total grace")
    result = {"schema": PROGRESS_POLICY_SCHEMA_V1, "phases": normalized}
    # Preserve the canonical bytes and keys of existing linear policies.
    if value.get("cycle"):
        result["cycle"] = True
    return result


def action_progress_policy(action: Mapping[str, object]) -> dict[str, object] | None:
    """The sealed progress policy of a validated action, if it declared one."""

    params = action["params"]
    assert isinstance(params, Mapping)
    declared = params.get(PROGRESS_PARAM)
    if declared is None:
        return None
    return validate_progress_policy(declared)


def _progress_environment(
    action: Mapping[str, object], sealed: Mapping[str, str]
) -> dict[str, str]:
    """The progress channel this action's own environment gains, if any.

    Nothing unless the sealed params declare the contract, so an action that
    does not is launched in byte-identical surroundings to before this existed.
    The values come from the worker that launched this launcher: the path is
    its queue's, the token is this launch's, and neither is a fact the sealed
    request could carry -- the request is the same bytes on every attempt.

    A sealed variable of the same name is a refusal rather than an overwrite,
    for the reason the profile contract gives: a diagnostic must not silently
    change what the action does.
    """

    if action["params"].get(PROGRESS_PARAM) is None:  # type: ignore[union-attr]
        return {}
    forwarded: dict[str, str] = {}
    for name in ACTION_PROGRESS_ENV:
        if name in sealed:
            raise ActionContractError(
                f"action seals {name}, which the progress contract must set"
            )
        value = os.environ.get(name)
        if value:
            forwarded[name] = value
    # The channel is the path and the token.  The phase list and the helper's
    # location are conveniences the action may use to report without importing
    # PrismaBuild (#488), and an older worker generation that sets neither
    # still launches a perfectly bounded run.
    if not all(name in forwarded
               for name in (ACTION_PROGRESS_PATH_ENV, ACTION_PROGRESS_TOKEN_ENV)):
        # Two ways to have less than a channel, and both end the same way.
        #
        # Half of one writes records nothing will accept, and saying so here
        # beats letting the watchdog report a stall the action never had.
        #
        # None of one is the dangerous case, because it is the quiet one.  A
        # launcher that provides no channel is a launcher with no watchdog:
        # this action was admitted on the promise that its own advancement
        # bounds it, and running it anyway would leave nothing bounding it at
        # all -- exactly the unbounded outcome #480's fifth point forbids.
        # The pull queue always sets both, so this is what refuses a transport
        # that seals the contract and cannot honour it (the SLURM lane, whose
        # ``--time`` is the submitter's explicit deadline and not a stall
        # policy) rather than trusting every future launcher to remember.
        missing = [
            name for name in (ACTION_PROGRESS_PATH_ENV, ACTION_PROGRESS_TOKEN_ENV)
            if name not in forwarded
        ]
        raise ActionContractError(
            "this action declares the progress contract, so the launcher must "
            f"set both {ACTION_PROGRESS_PATH_ENV} and "
            f"{ACTION_PROGRESS_TOKEN_ENV}; missing {', '.join(missing)}.  "
            "Nothing would bound this run"
        )
    return forwarded


def _residency_environment(
    action: Mapping[str, object], sealed: Mapping[str, str]
) -> dict[str, str]:
    """This action's own identity, and the staged copy of its inputs (#583).

    Two variables, both unsealed, both harmless to an action that ignores
    them.  ``ACTION_KEY_ENV`` is always set, because it is derived from the
    action in hand rather than forwarded from anywhere, and because the nodes
    that need it -- a movement node filing a receipt and holding tier tokens
    under its own key -- cannot take it as an argument without hashing the key
    into the argv the key is computed from.  ``RESIDENCY_MAP_ENV`` is
    forwarded only when the launcher set it, which it does for an item whose
    residency block names leads that have staged something.  The broker-owned
    attempt tuple plus helper root travel the same way, through
    :func:`_reader_identity_environment`: complete, shaped, and bound to
    this action, or not at all.

    A sealed variable of any of these names is a refusal rather than an
    overwrite, the rule the progress and profile contracts already keep: an
    action that thought it was setting its own identity would silently get
    somebody else's.
    """

    conflicting = [name for name in ACTION_RESIDENCY_ENV if name in sealed]
    if conflicting:
        raise ActionContractError(
            f"action seals {', '.join(conflicting)}, which the residency "
            "contract must set"
        )
    environment = {ACTION_KEY_ENV: str(action["action_key"])}
    forwarded = os.environ.get(RESIDENCY_MAP_ENV)
    if forwarded:
        environment[RESIDENCY_MAP_ENV] = forwarded
    environment.update(
        _reader_identity_environment(str(action["action_key"])))
    return environment


#: Attempt nonce shape minted by pool scope startup: 32 lowercase hex.
_ATTEMPT_NONCE_RE = re.compile(r"[0-9a-f]{32}")


def _executing_generation_root() -> Path | None:
    """This core module's own generation root, or None when unrecognizable.

    Mirrors the source/published layout rule without a repository import
    (this file is attested standalone): ``src/prismabuild/core.py`` in
    both checkout and sealed-generation layouts.  The resource_exec proxy
    names the same root from its own path, so equality below proves the
    helper is the executing generation rather than an older or unrelated
    tree that merely exists.
    """

    resolved = Path(__file__).resolve()
    directory = resolved.parent
    if directory.name != "prismabuild" or directory.parent.name != "src":
        return None
    return directory.parent.parent


def _reader_identity_environment(action_key: str) -> dict[str, str]:
    """The broker-owned attempt tuple plus helper root, or nothing.

    Forwards ``PRISMABUILD_ACTION_NONCE``/``SCOPE``/``READER_HELPER_ROOT``
    from the launcher environment -- the exact identity ``resource_exec``
    injected for this broker-owned attempt -- so strict readers bind pins
    to the live claim.  These values are launcher-owned, never sealed
    (sealed conflicts are refused by the caller).  The governing rule is
    that unbound identity is never fed to a payload:

    * none present: the legacy path, forward nothing (established
      behavior for uncontained and pre-reader actions);
    * any present without all three: refuse, because a partial bundle is
      a guessed identity;
    * nonce must be 32-hex and scope must be exactly this action's broker
      slice for it (wrong-action and wrong-nonce refuse);
    * helper root must be exactly this executing generation's root
      (canonical absolute path under the shared source/published layout
      rule -- never a symlink, never an older or unrelated tree, never
      a missing path).

    A foreign ambient tuple (post-deploy harnesses, nested local runs)
    therefore refuses rather than feeding an outer nonce into an
    unrelated synthetic action; standalone synthetic unit contexts stay
    isolated through their own test fixture, never through weakened
    production checks.

    The broker token and socket never cross this boundary: only these
    three names are read, so only they can arrive.  Binding beyond shape
    -- the live claim row -- stays the SDK's check at use.
    """

    nonce = os.environ.get(ACTION_NONCE_ENV)
    scope = os.environ.get(ACTION_SCOPE_ENV)
    helper = os.environ.get(READER_HELPER_ROOT_ENV)
    present = [name for name, value in (
        (ACTION_NONCE_ENV, nonce), (ACTION_SCOPE_ENV, scope),
        (READER_HELPER_ROOT_ENV, helper)) if value]
    if not present:
        return {}
    if len(present) != 3:
        raise ActionContractError(
            "launcher holds a partial reader-identity bundle "
            f"({', '.join(present)}); refusing rather than binding "
            "a strict identity from half of one")
    assert nonce is not None and scope is not None and helper is not None
    if _ATTEMPT_NONCE_RE.fullmatch(nonce) is None:
        raise ActionContractError(
            "launcher reader nonce is not a 32-character lowercase attempt "
            "identity; refusing rather than forwarding it")
    expected_scope = ("prismabuild-job"
                      + hashlib.sha256(
                          (action_key + nonce).encode()).hexdigest()[:32]
                      + ".slice")
    if scope != expected_scope:
        raise ActionContractError(
            "launcher reader scope is not this action's broker slice for "
            "its nonce; refusing rather than forwarding another attempt's "
            "identity")
    if ("\x00" in helper or not helper.startswith("/")
            or posixpath.normpath(helper) != helper):
        raise ActionContractError(
            "launcher reader helper root is not a canonical absolute path; "
            "refusing rather than binding a helper tree by a relative or "
            "escaping spelling")
    expected = _executing_generation_root()
    if expected is None or helper != str(expected):
        raise ActionContractError(
            "launcher reader helper root is not this executing generation; "
            "refusing rather than binding an older, unrelated, or missing "
            "tree as sealed helpers")
    return {ACTION_NONCE_ENV: nonce, ACTION_SCOPE_ENV: scope,
            READER_HELPER_ROOT_ENV: helper}


def report_action_progress(
    phase: str, units_completed: float, *, unit: str | None = None
) -> bool:
    """Report semantic advancement through the original public core API.

    Keep this compatibility writer self-contained: attested core cannot import
    the repository helper. Tests compare its wire record with progress.commit
    and retain the original explicit-phase, path-and-token-only contract.

    Call it after work is *committed* -- a durable checkpoint shard written, an
    anchor journalled, a unit published -- never on entering a loop iteration.
    The watchdog exists to tell a long run from a stuck one, and a counter that
    ticks on intent rather than on commitment cannot.

    ``units_completed`` must be monotone across the whole run, resuming from
    what a checkpoint already holds rather than restarting at zero, and a phase
    is entered at most once.  Neither is enforced here -- this side cannot see
    the sealed policy -- but a record that violates either is simply not
    accepted as advancement.

    Returns whether a record was written.  A no-op when the action was not
    admitted under the progress contract, so an application may call it
    unconditionally: the alternative is application code that has to know how
    it was launched.

    Writes the whole record rather than merging into one, and to a file of its
    own rather than the launcher's status sidecar.  The sidecar is an unlocked
    read-merge-write shared with ``_write_action_status``, and it is unlinked
    as it is read; both are fine for two facts written once at an ending, and
    neither survives a second writer ticking every few seconds.
    """

    destination = os.environ.get(ACTION_PROGRESS_PATH_ENV) or ""
    token = os.environ.get(ACTION_PROGRESS_TOKEN_ENV) or ""
    if not destination or not token:
        return False
    if (type(units_completed) not in (int, float)
            or (type(units_completed) is float and not math.isfinite(units_completed))
            or units_completed < 0):
        raise ValueError("units_completed must be a finite, non-negative number")
    record: dict[str, object] = {
        "schema": PROGRESS_RECORD_SCHEMA_V1,
        "token": token,
        "phase": str(phase),
        "units_completed": units_completed,
        "reported_unix": time.time(),
    }
    if unit is not None:
        record["unit"] = str(unit)
    path = Path(destination)
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        tmp = path.parent / f".{path.name}.{os.getpid()}.tmp"
        tmp.write_text(json.dumps(record, sort_keys=True) + "\n", encoding="utf-8")
        os.replace(tmp, path)
    except OSError:
        # Reporting is never worth failing an action for.  A report that does
        # not land is a stall to the watchdog, which is the honest reading of a
        # box that cannot write to its own queue directory.
        return False
    return True


def main(
    argv: Sequence[str] | None = None,
    *,
    worker_launcher_identity: object | None = None,
) -> int:
    args = _build_parser().parse_args(argv)
    if args.command == "run-local" and args.require_slurm_initial_start:
        if args.recompute:
            raise ActionContractError(
                "Slurm worker protocol does not permit recompute"
            )
        # This is deliberately before reading even the immutable action
        # request: a forced/admin-restarted allocation must reach no worker or
        # task-side input processing beyond argument parsing.
        _require_slurm_initial_start()
    if args.command == "seal-closure":
        closure = build_code_closure(args.root, args.file)
        _atomic_write_new_json(args.output, closure)
        print(args.output)
        return 0
    if args.command == "ingest-input":
        cas = PrismaBuildCAS(args.cas_root)
        entry, won = cas.ingest_input(
            args.source,
            input_id=args.input_id,
            expected_sha256=args.expected_sha256,
            expected_bytes=args.expected_bytes,
        )
        print(
            json.dumps(
                {
                    "status": "published" if won else "already_present",
                    "input": entry,
                    "payload_path": str(cas.input_path(entry)),
                },
                sort_keys=True,
            )
        )
        return 0
    if args.command == "verify-input":
        contract = _read_json_mapping(args.input_contract, where="input contract")
        cas = PrismaBuildCAS(args.cas_root)
        normalized = validate_input_contract(contract)
        print(
            json.dumps(
                {
                    "input": normalized,
                    "payload_path": str(cas.input_path(normalized)),
                },
                sort_keys=True,
            )
        )
        return 0
    action_path = args.action if hasattr(args, "action") else args.body
    if args.command == "run-local" and args.require_slurm_initial_start:
        raw_action = _read_regular_file_nofollow(
            action_path, where="action request", require_readonly=True
        )
        action_data_value = _decode_strict_json(raw_action, where="action request")
        if not isinstance(action_data_value, Mapping):
            raise ActionContractError("action request root must be an object")
        action_data = action_data_value
    else:
        action_data = _read_json_mapping(action_path, where="action")
    if args.command == "seal-action":
        sealed = seal_action(action_data)
        _atomic_write_new_json(args.output, sealed)
        print(args.output)
        return 0
    action = validate_action(action_data)
    if args.command == "run-local" and args.require_slurm_initial_start:
        cas = PrismaBuildCAS(args.cas_root)
        expected_request = (
            cas.root
            / "requests"
            / str(action["action_key"])[:2]
            / f"{action['action_key']}.json"
        )
        if action_path != expected_request:
            raise ActionContractError(
                "Slurm worker action path differs from its canonical CAS request"
            )
    if args.command == "key":
        print(action["action_key"])
        return 0
    if args.command == "preflight":
        result = preflight_action(
            action,
            cas_root=args.cas_root,
            checkout_root=args.checkout_root,
            worker_launcher_identity=worker_launcher_identity,
        )
        print(json.dumps(result, sort_keys=True))
        return 0
    if args.command == "repair-local-result":
        result = repair_local_result(
            action,
            cas_root=args.cas_root,
            checkout_root=args.checkout_root,
        )
        print(json.dumps(result, sort_keys=True))
        return 0
    cas = PrismaBuildCAS(args.cas_root)
    if args.command == "verify":
        receipt = cas.lookup(action)
        if receipt is None:
            raise PrismaBuildError("action is not present in the CAS")
        print(json.dumps(receipt, sort_keys=True))
        return 0
    try:
        result = run_local_action(
            action,
            cas_root=args.cas_root,
            checkout_root=args.checkout_root,
            timeout_seconds=args.timeout_seconds,
            recompute=args.recompute,
            worker_launcher_identity=worker_launcher_identity,
            initial_miss_rendezvous=args.initial_miss_rendezvous,
        )
    except LocalActionError as error:
        _record_action_status(error)
        raise
    print(json.dumps(result, sort_keys=True))
    return 0


__all__ = [
    "ACTION_SCHEMA_V1",
    "ACTION_SCHEMA_V2",
    "ACTION_KEY_ENV",
    "ACTION_PROGRESS_PATH_ENV",
    "ACTION_PROGRESS_TOKEN_ENV",
    "RESIDENCY_MAP_ENV",
    "ACTION_STATUS_PATH_ENV",
    "PROGRESS_PARAM",
    "PROGRESS_POLICY_SCHEMA_V1",
    "PROGRESS_RECORD_SCHEMA_V1",
    "PROGRESS_TAG",
    "PROGRESS_HELPER_TAG",
    "PROGRESS_CYCLE_TAG",
    "CONTAINER_IMAGE_TAG",
    "action_progress_policy",
    "report_action_progress",
    "validate_progress_policy",
    "CAS_RECEIPT_SCHEMA_V3",
    "CODE_CLOSURE_SCHEMA_V1",
    "INITIAL_MISS_RENDEZVOUS_ARRIVAL_SCHEMA_V1",
    "INITIAL_MISS_RENDEZVOUS_MANIFEST_SCHEMA_V1",
    "INITIAL_MISS_RENDEZVOUS_PROCESS_SCHEMA_V1",
    "INITIAL_MISS_RENDEZVOUS_READY_SCHEMA_V1",
    "INITIAL_MISS_RENDEZVOUS_RECEIPT_SCHEMA_V1",
    "DATA_MANIFEST_MAX_BYTES",
    "DATA_MANIFEST_MAX_ENTRIES",
    "DATA_MANIFEST_MAX_READS",
    "DATA_MANIFEST_SCHEMA_V1",
    "DATA_MANIFEST_SCHEMA_V2",
    "LOCAL_RESULT_CLAIM_SCHEMA_V1",
    "PBRUN_GENERATED_FINGERPRINT_HEX_LENGTH",
    "PBCAMPAIGN_DATA_MANIFEST_INPUT_ID",
    "PRODUCED_OUTPUT_TEMPLATE_INPUT_ID",
    "PRODUCED_OUTPUT_TEMPLATE_PARAM",
    "PRODUCED_OUTPUT_DECLARATION_SCHEMA_V1",
    "PRODUCED_OUTPUT_TEMPLATE_MAX_BYTES",
    "validate_produced_output_declaration",
    "PBRUN_CHECKOUT_SNAPSHOT_INPUT_ID",
    "PBRUN_CHECKOUT_SNAPSHOT_REF_NAME",
    "PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V1",
    "PBRUN_CHECKOUT_SNAPSHOT_SCHEMA_V2",
    "PBRUN_RESULT_PREFIX",
    "PROFILE_BACKENDS",
    "PROFILE_MODES",
    "PROFILE_EXIT_STATUS_SCHEMA",
    "read_chrome_trace",
    "split_profile_mode",
    "parse_profile_mode",
    "TorchProfileBackend",
    "NsysProfileBackend",
    "PROFILE_BLOB_BUDGET_BYTES",
    "PROFILE_PARAM",
    "PROFILE_SAMPLE_RATE_HZ",
    "PROFILE_SCRATCH_DIRNAME",
    "PROFILE_SPEEDSCOPE_SCHEMA",
    "PBRUN_STAMP_PREFIX",
    "WORKER_ATTESTATION_SCHEMA_V2",
    "SCONTROL_RETRY_DELAYS_S",
    "live_platform_toolchain_contract",
    "WORKER_RUNTIME_SCHEMA_V1",
    "ActionContractError",
    "CASConflictError",
    "CASTamperError",
    "CASUnavailableError",
    "InitialMissRendezvousError",
    "LocalActionError",
    "PrismaBuildCAS",
    "PrismaBuildError",
    "ProfileBackendUnavailable",
    "ProfileUnusable",
    "build_code_closure",
    "describe_profile",
    "executable_toolchain_contract",
    "find_git_worktree_marker",
    "git_checkout_identity",
    "identify_executable",
    "is_pbrun_generated_path",
    "load_data_manifest",
    "residency_descriptor",
    "residency_descriptor_binding",
    "RESIDENCY_DESCRIPTOR_SCHEMA_V1",
    "STORAGE_TIERS",
    "read_data_manifest",
    "main",
    "preflight_action",
    "profile_backend_for",
    "profile_exit_status_relay",
    "pbrun_git_exclude_patterns",
    "read_speedscope",
    "repair_local_result",
    "run_local_action",
    "seal_action",
    "validate_action",
    "validate_code_closure",
    "validate_data_manifest",
    "validate_input_contract",
    "validate_pbrun_checkout_snapshot",
    "validate_pbrun_snapshot_ref_name",
    "validate_worker_scope",
    "validate_worker_attestation",
    "verify_code_closure",
]


if __name__ == "__main__":
    raise SystemExit(
        main(worker_launcher_identity=dict(_LOADED_WORKER_CORE_IDENTITY))
    )
