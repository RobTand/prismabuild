"""Per-attempt kernel accounting and aggregate memory containment.

A narrow root broker puts direct processes and daemon-created Docker containers
under the same systemd slice. All counters below include both, without census
races or trusting a process name to establish ownership.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
import socket
import stat
import sys
import time
from typing import Any

BROKER_SOCKET = Path('/run/prismabuild/resources.sock')
#: The schema of the container settlement a holder sends before ``release``.
#: Mirrors ``resource_broker.SETTLEMENT_SCHEMA``; the broker refuses anything
#: else, so the two spellings are one contract.
CONTAINER_SETTLEMENT_SCHEMA = 'prismabuild.container-settlement.v1'
SCOPE_RE = re.compile(r'prismabuild-job[a-f0-9]{32}\.slice')
MAX_MESSAGE_BYTES = 65536


class ResourceUnavailable(OSError):
    """Broker deferred unstarted work for maintenance or a protocol upgrade."""


def broker_request(request: dict, *, socket_path: Path = BROKER_SOCKET) -> dict:
    with socket.socket(socket.AF_UNIX, socket.SOCK_STREAM) as client:
        client.settimeout(10)
        client.connect(str(socket_path))
        client.sendall(json.dumps(request, separators=(',', ':')).encode() + b'\n')
        data = bytearray()
        while b'\n' not in data:
            chunk = client.recv(min(4096, MAX_MESSAGE_BYTES + 1 - len(data)))
            if not chunk:
                raise OSError('resource broker closed without a response')
            data.extend(chunk)
            if len(data) > MAX_MESSAGE_BYTES:
                raise OSError('resource broker response exceeds 64 KiB')
    response = json.loads(data.split(b'\n', 1)[0])
    if (request.get('op') == 'create' and request.get('recovery_protocol') == 1
            and isinstance(response, dict) and response.get('ok') is False
            and response.get('error') == 'unknown request field'):
        feature = ('GPU memory budget' if 'gpu_memory_max_bytes' in request
                   else 'durable creation recovery')
        raise ResourceUnavailable(f'installed broker needs {feature} support')
    if (isinstance(response, dict) and response.get('ok') is False
            and response.get('maintenance') is True and response.get('retryable') is True):
        raise ResourceUnavailable(f'resource broker is in maintenance: {response}')
    if not isinstance(response, dict) or response.get('ok') is not True:
        raise OSError(f'resource broker refused request: {response}')
    return response


def read_cgroup(path: Path) -> dict[str, Any]:
    """Read hierarchical counters for the whole job, including its containers."""
    cpu = dict(line.split() for line in (path / 'cpu.stat').read_text().splitlines())
    events = dict(line.split() for line in (path / 'memory.events').read_text().splitlines())
    local_events = dict(line.split() for line in (path / 'memory.events.local').read_text().splitlines())
    counters = {
        'cpu_seconds': int(cpu['usage_usec']) / 1_000_000,
        'memory_current_bytes': int((path / 'memory.current').read_text()),
        'memory_peak_bytes': int((path / 'memory.peak').read_text()),
        'oom_kill': int(events.get('oom_kill', 0)),
        'oom_local': int(local_events['oom']),
    }
    # The kernel has always published the split; nothing read it, so an action
    # that spent its time in the kernel and one that spent it in user code
    # arrived at the receipt looking identical. Absent rather than zero on a
    # kernel that does not publish it: a missing split is not an idle kernel.
    for field, key in (('cpu_user_seconds', 'user_usec'),
                       ('cpu_system_seconds', 'system_usec')):
        if key in cpu:
            counters[field] = int(cpu[key]) / 1_000_000
    return counters


#: The ``/proc/<pid>/io`` counters worth carrying. ``rchar``/``wchar`` count
#: the bytes the process asked for, and are exact wherever the file lives;
#: ``read_bytes``/``write_bytes`` count what reached storage, and are zero on a
#: tmpfs for the same write. Both, because neither answers the other's
#: question.
IO_COUNTERS = ('rchar', 'wchar', 'syscr', 'syscw', 'read_bytes', 'write_bytes')


CGROUP_ROOT = Path('/sys/fs/cgroup')


def cgroup_membership(path: Path) -> str:
    """The scope as ``/proc/<pid>/cgroup`` spells it, for membership matching."""
    try:
        return '/' + str(Path(path).resolve().relative_to(CGROUP_ROOT))
    except ValueError:
        return ''


def procs_in_cgroup(membership: str, *, errors: list[str] | None = None) -> list[int]:
    """Every process whose own ``/proc`` entry names this scope or a leaf of it.

    A broker installed before #916 keeps the payload leaf ``drwx------ root
    root``, so the leaf the action actually runs in cannot be listed, entered
    or read by the worker that launched it -- and that leaf is where every one
    of its processes is.  A current broker makes it ``drwxr-xr-x``, but a host
    is not upgraded until its client upgrader rotates the broker.
    ``/proc/<pid>/cgroup`` is world-readable and says the same thing from the
    other side, so membership is read from the processes rather than from a
    directory this uid may not open.

    Optional diagnostics distinguish incomplete discovery from an empty
    scope. An unreadable record may belong to any scope; it does not prove
    that this action lost a member. Confirmed process departure is ordinary.
    """
    if errors is None:
        errors = []
    if not membership:
        errors.append('process discovery: resource scope has no cgroup membership path')
        return []
    found: list[int] = []
    try:
        entries = os.listdir('/proc')
    except OSError as exc:
        errors.append(f'process discovery: cannot enumerate /proc ({type(exc).__name__})')
        return []
    unreadable = 0
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            text = Path('/proc', entry, 'cgroup').read_text()
        except (FileNotFoundError, ProcessLookupError):
            continue  # the process exited between listdir and read
        except OSError:
            unreadable += 1
            continue
        for line in text.splitlines():
            parts = line.split(':', 2)
            if (len(parts) != 3 or parts[:2] != ['0', '']
                    or not parts[2].startswith('/')):
                continue
            where = parts[2]
            if where == membership or where.startswith(membership + '/'):
                found.append(int(entry))
            break
        else:
            unreadable += 1
    if unreadable:
        errors.append(f'process discovery: {unreadable} procfs membership record(s) '
                      'unreadable or malformed; scope membership unknown')
    return found


def scope_pids(path: Path, *, errors: list[str] | None = None) -> list[int]:
    """Every process in the scope, including the broker's payload leaf.

    The payload is a child of the root broker rather than of the pool worker,
    so no process tree from the worker reaches it. The cgroup is what both have
    in common, and it is hierarchical -- but only where it can be read. A
    subdirectory this uid cannot open is not an empty one, so the walk records
    that it was refused and the membership scan supplies what it could not see.
    """
    found: list[int] = []
    blocked = False
    stack = [Path(path)]
    while stack:
        group = stack.pop()
        try:
            entries = list(group.iterdir())
        except OSError:
            blocked = True
            continue
        for entry in entries:
            try:
                # is_dir() can turn an unreadable stat into False. Unknown
                # entry type may hide a payload leaf; use the same fallback
                # as an unreadable directory, without losing readable peers.
                if stat.S_ISDIR(entry.stat().st_mode):
                    stack.append(entry)
            except OSError:
                blocked = True
        try:
            text = (group / 'cgroup.procs').read_text()
        except OSError:
            blocked = True
            continue
        for line in text.split():
            try:
                pid = int(line)
            except ValueError:
                blocked = True
                continue
            if pid <= 0:
                blocked = True
                continue
            found.append(pid)
    if blocked:
        fallback = procs_in_cgroup(cgroup_membership(path), errors=errors)
        return sorted(set(found) | set(fallback))
    return found


def _process_in_scope(pid: int, path: Path | None) -> bool:
    """Recheck an omitted member; unreadable membership is not departure."""
    try:
        text = Path(f'/proc/{pid}/cgroup').read_text()
    except FileNotFoundError:
        return False
    membership = cgroup_membership(path) if path is not None else ''
    if not membership:
        raise ValueError('resource scope has no cgroup membership path')
    for line in text.splitlines():
        parts = line.split(':', 2)
        if len(parts) == 3 and parts[:2] == ['0', ''] and parts[2].startswith('/'):
            return parts[2] == membership or parts[2].startswith(membership + '/')
    raise ValueError(f'cannot parse process {pid} cgroup membership')


def read_process_io(pid: int) -> tuple[str, int, dict[str, int] | None] | None:
    """A process's identity, its parent, and its counters when readable.

    ``starttime`` from ``/proc/<pid>/stat`` is what makes the key exact: pids
    are recycled, and folding a new process's counters into an old one's
    accounting would silently invent I/O the action never did.

    The parent comes back because ``/proc/<pid>/io`` is not a per-process
    counter alone: on reap the kernel adds a child's totals into its parent's,
    exactly as ``RUSAGE_CHILDREN`` does. So a process whose parent is also in
    the scope keeps contributing through that parent after it exits, and adding
    its last reading to a retired total as well would count it twice. Measured
    on the fleet: a 64 MiB write reported as 129 MiB.

    Identity and counters are separate answers because they fail separately.
    ``/proc/<pid>/io`` needs ptrace-read access and a process this uid may not
    inspect refuses it while ``stat`` still answers. ``None`` for the counters
    means "here, but not readable"; ``None`` for the whole result means gone.
    An unreadable initial identity raises OSError or ValueError: the sampler
    must retain its prior reading rather than infer departure from an outage.
    """
    try:
        stat = Path(f'/proc/{pid}/stat').read_text()
    except FileNotFoundError:
        return None
    try:
        # The command field is parenthesised and may itself contain spaces, so
        # the fields after it are found from the last ')' rather than by split.
        fields = stat[stat.rindex(')') + 1:].split()
        parent, starttime = int(fields[1]), fields[19]
    except (ValueError, IndexError) as exc:
        raise ValueError(f'cannot parse process {pid} identity') from exc
    identity = f'{pid}:{starttime}'
    try:
        counters = dict(line.split(':', 1) for line in
                        Path(f'/proc/{pid}/io').read_text().splitlines() if ':' in line)
    except (OSError, ValueError):
        return identity, parent, None
    values: dict[str, int] = {}
    for name in IO_COUNTERS:
        try:
            values[name] = int(counters[name])
        except (KeyError, ValueError):
            return identity, parent, None
    # These are separate procfs reads: the original process may have exited
    # and its PID may now name another process. Never attach that successor's
    # counters to the identity read before collection. Ordinary state/comm
    # changes do not change the incarnation, so compare only starttime. Keep
    # the refreshed parent too: orphaning during these reads can turn a child
    # into a scope root whose counters must be retired when it disappears.
    try:
        after = Path(f'/proc/{pid}/stat').read_text()
        after_fields = after[after.rindex(')') + 1:].split()
        after_parent, after_starttime = int(after_fields[1]), after_fields[19]
    except FileNotFoundError:
        return None
    except (OSError, ValueError, IndexError):
        # Unknown is not departed: keep any earlier sample alive rather than
        # retiring a root and counting it again when reads recover.
        return identity, parent, None
    if after_starttime != starttime:
        return None
    return identity, after_parent, values


def _atomic_json(path: Path, record: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    temp = path.with_name(f'.{path.name}.{os.getpid()}.tmp')
    try:
        temp.write_text(json.dumps(record, sort_keys=True) + '\n')
        os.replace(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _sha256_file(path: Path) -> str:
    """Hex SHA-256 of one file, read in blocks."""

    digest = hashlib.sha256()
    with open(path, "rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


#: Where the fleet publishes immutable runtime generations. Read at call
#: time rather than bound at import, for the same reason
#: ``supervise.MIRROR`` is: it is the one name a test can repoint at a
#: fixture store.
RETAINED_GENERATION_STORE = Path(
    "/mnt/shared/prismabuild-fleet/runtime-generations")

#: The receipt every published generation carries. ``publish_runtime``,
#: ``supervise`` and ``upgrade_client`` all enforce this schema; the checks
#: below mirror ``supervise._published_generation`` (store child, receipt
#: names generation, manifest-covered supervisor bytes) and
#: ``publish_runtime._barrier_generation`` (sealed bits, commit shape,
#: member path safety, no symlinks, digest match).
RUNTIME_RECEIPT_SCHEMA = "prismaquant.prismabuild.runtime_version.v1"

#: The worker entry point every sealed publication names
#: (``seal_and_publish``, ``fleet_submit``, ``pbrun`` all publish
#: ``RUNTIME_ROOT / "tools" / "prismabuild_worker.py"``). The
#: ``tools/``-vs-``tools/fleet/`` layout rule mirrors
#: ``runtime_paths.generation_root``.
_WORKER_TAIL = ("tools", "prismabuild_worker.py")

#: Proxy candidates in one runtime, in the order searched. Published
#: generations carry both spellings with identical bytes (the
#: ``_publication_manifest`` dual entry); a checkout carries only the
#: ``tools/fleet/`` one. ``resource_exec`` imports its siblings lazily,
#: so the broker scope helper and the layout helper in the same
#: directory are proven with it.
_PROXY_CANDIDATES = ("tools/resource_exec.py", "tools/fleet/resource_exec.py")
_PROXY_DEPENDENCIES = ("resource_broker.py", "runtime_paths.py")
# resource_exec.main imports resource_scope through the package before it
# asks the broker to enter containment. __init__ eagerly imports core,
# progress and residency_map; the latter imports storage_tiers. Their bytes
# therefore need the same publication proof as the executable proxy.
_PROXY_PACKAGE_DEPENDENCIES = (
    "__init__.py", "resource_scope.py", "core.py", "progress.py",
    "residency_map.py", "storage_tiers.py",
)


class ResourceScope:
    """One exact key+nonce kernel slice; sampling never signals work.

    Call create before Popen, then wrap_argv (an unprivileged stdio proxy). sample atomically refreshes the
    telemetry file. Caller owns polling and must retain a reservation until
    children and owned containers are stopped and release succeeds.
    """
    def __init__(self, action_key: str, nonce: str, memory_max_bytes: int,
                 telemetry_path: Path, *, docker_owner: str | None = None,
                 shape_key: str | None = None, socket_path: Path = BROKER_SOCKET,
                 gpu_memory_max_bytes: int | None = None,
                 authority_path: Path | None = None):
        if not re.fullmatch('[a-f0-9]{64}', action_key) or not re.fullmatch('[a-f0-9]{32}', nonce):
            raise ValueError('resource scope needs an action key and 32-hex attempt nonce')
        if isinstance(memory_max_bytes, bool) or not isinstance(memory_max_bytes, int) or memory_max_bytes <= 0:
            raise ValueError('resource scope memory limit must be a positive integer')
        if gpu_memory_max_bytes is not None and (type(gpu_memory_max_bytes) is not int
                or not 0 < gpu_memory_max_bytes <= 2**63 - 1):
            raise ValueError('resource scope GPU memory limit must be positive integer bytes')
        self.action_key = action_key
        self.nonce = nonce
        self.memory_max_bytes = memory_max_bytes
        self.gpu_memory_max_bytes = memory_max_bytes if gpu_memory_max_bytes is None else gpu_memory_max_bytes
        self._explicit_gpu_budget = gpu_memory_max_bytes is not None
        self.telemetry_path = Path(telemetry_path)
        # The host-local record admission reads, written before the shared
        # ``telemetry_path`` copy that remote readers and the attempt's
        # evidence (termination, late-cleanup archive) keep using.
        self.authority_path = None if authority_path is None else Path(authority_path)
        self.socket_path = Path(socket_path)
        self.docker_owner = docker_owner
        self.shape_key = shape_key
        self.started = time.monotonic()
        self.unit: str | None = None
        self.cgroup_path: Path | None = None
        self.token: str | None = None
        self._last: dict[str, Any] = {}
        self._reason: str | None = None
        self._process_io: dict[str, Any] | None = None

    def _request(self, op: str, **extra) -> dict:
        request = {'op': op, 'action_key': self.action_key, 'nonce': self.nonce, **extra}
        if self.token is not None:
            request['token'] = self.token
        return broker_request(request, socket_path=self.socket_path)

    def create(self) -> dict:
        if self.token is not None:
            raise RuntimeError('resource scope is already created')
        extra = {'gpu_memory_max_bytes': self.gpu_memory_max_bytes} if self._explicit_gpu_budget else {}
        response = self._request('create', memory_max_bytes=self.memory_max_bytes, recovery_protocol=1, **extra)
        self._adopt_created_scope(response)
        return self.control_record()

    def recover_create(self) -> bool:
        """Recover authority or fence a missing attempt against delayed creation."""
        extra = {'gpu_memory_max_bytes': self.gpu_memory_max_bytes} if self._explicit_gpu_budget else {}
        response = self._request('recover_create', memory_max_bytes=self.memory_max_bytes, **extra)
        if response.get('missing') is True:
            expected = 'prismabuild-job' + hashlib.sha256((self.action_key + self.nonce).encode()).hexdigest()[:32] + '.slice'
            if response.get('scope_id') != expected:
                raise OSError('resource broker returned invalid creation absence evidence')
            return False
        self._adopt_created_scope(response)
        return True

    def _adopt_created_scope(self, response: dict) -> None:
        unit = response.get('scope_id', '')
        token = response.get('token', '')
        path = Path(response.get('cgroup_path', ''))
        expected = 'prismabuild-job' + hashlib.sha256((self.action_key + self.nonce).encode()).hexdigest()[:32] + '.slice'
        if (not isinstance(unit, str) or unit != expected
                or not isinstance(token, str) or re.fullmatch('[a-f0-9]{64}', token) is None
                or path != Path('/sys/fs/cgroup/prismabuild.slice') / unit):
            raise OSError('resource broker returned an invalid scope identity')
        acknowledged_gpu = response.get('gpu_memory_max_bytes')
        if (acknowledged_gpu is not None and (type(acknowledged_gpu) is not int
                                            or acknowledged_gpu != self.gpu_memory_max_bytes)
                or self._explicit_gpu_budget and acknowledged_gpu is None):
            raise OSError('resource broker did not acknowledge the exact GPU memory budget')
        self.unit, self.token, self.cgroup_path = unit, token, path

    def control_record(self) -> dict:
        """Lease metadata for exact-attempt recovery; retain with the reservation."""
        return {'action_key': self.action_key, 'nonce': self.nonce,
                'scope_id': self.unit, 'cgroup_path': str(self.cgroup_path),
                'token': self.token, 'socket_path': str(self.socket_path),
                'memory_max_bytes': self.memory_max_bytes,
                'gpu_memory_max_bytes': self.gpu_memory_max_bytes}

    def _verified_member(self, root: Path, rel: str,
                           files: dict) -> Path:
        """One manifest-covered sealed member, or raise ``OSError``.

        Mirrors ``publish_runtime._barrier_generation``: the spelling must
        be a safe relative path, the file must resolve to itself (no
        symlink escape), must not be writable by anyone (sealed
        generation), and its bytes must match the receipt's 64-hex
        digest. Anything else is an unverified tree, refused here rather
        than executed outside the action's contained slice.
        """

        if not rel or Path(rel).is_absolute() or any(
                part in (".", "..") for part in Path(rel).parts):
            raise OSError(f"unsafe generation member path: {rel!r}")
        expected = files.get(rel)
        if (not isinstance(expected, str)
                or re.fullmatch(r"[0-9a-f]{64}", expected) is None):
            raise OSError(f"generation receipt covers no sha256 for {rel}")
        path = root / rel
        try:
            if path.resolve(strict=True) != path or not path.is_file():
                raise OSError(f"generation member is a symlink: {rel}")
            if path.stat().st_mode & 0o222:
                raise OSError(f"generation member is not sealed: {rel}")
        except OSError as exc:
            raise OSError(f"unverified retained runtime member {rel}: "
                          f"{exc}") from exc
        if _sha256_file(path) != expected:
            raise OSError(f"retained runtime hash mismatch: {rel}")
        return path

    def _sealed_generation_proxy(self, root: Path, worker: Path) -> Path:
        """The proxy of a proven retained generation, or raise ``OSError``.

        Trust rule mirrors ``supervise._proven_roots`` plus
        ``supervise._published_generation``: the root must be a direct,
        non-staging child of this fleet's generation store carrying a
        receipt that names it, with a 40-hex commit and a manifest that
        covers the sealed worker, the proxy, and the proxy's own imports
        byte-for-byte. A directory that merely hashes its own files is
        not this fleet's runtime, and choosing its proxy would execute
        untrusted code outside the contained slice with the attempt's
        broker token on its argv -- so unknown/unverified roots refuse
        here instead of silently falling back to a mismatching proxy.
        """

        try:
            store = RETAINED_GENERATION_STORE.resolve(strict=True)
        except OSError as exc:
            raise OSError("retained generation store is unavailable; "
                          "refusing an unverifiable worker runtime") from exc
        try:
            resolved = root.resolve(strict=True)
        except OSError as exc:
            raise OSError("retained worker runtime is unavailable; "
                          "refusing") from exc
        if resolved != root:
            raise OSError("retained worker runtime resolves outside itself; "
                          "refusing a symlink escape")
        if (resolved.parent != store or root.name in ("", ".", "..")
                or root.name.startswith(".")):
            raise OSError(f"worker runtime {root} is not an authorized "
                          "sealed generation of this fleet; refusing")
        try:
            if root.stat().st_mode & 0o222:
                raise OSError(f"generation {root.name} is not sealed")
            receipt = json.loads(
                (root / "RUNTIME_VERSION.json").read_text())
        except (OSError, ValueError) as exc:
            raise OSError(f"generation {root.name} receipt is not readable; "
                          "this is not a generation to launch from") from exc
        if not isinstance(receipt, dict):
            raise OSError(f"generation {root.name} receipt is not an object; "
                          "refusing")
        files = receipt.get("files")
        if (receipt.get("schema") != RUNTIME_RECEIPT_SCHEMA
                or receipt.get("generation") != root.name
                or re.fullmatch(r"[0-9a-f]{40}",
                                str(receipt.get("commit", ""))) is None
                or not isinstance(files, dict)):
            raise OSError(f"generation {root.name} has an invalid published "
                          "runtime receipt; refusing")
        worker_rel = worker.relative_to(root).as_posix()
        if worker_rel != _WORKER_TAIL[0] + "/" + _WORKER_TAIL[1]:
            raise OSError(f"worker {worker} is not the generation's sealed "
                          "entry point; refusing")
        self._verified_member(root, worker_rel, files)
        for dependency in _PROXY_PACKAGE_DEPENDENCIES:
            self._verified_member(
                root, f"src/prismabuild/{dependency}", files)
        for proxy_rel in _PROXY_CANDIDATES:
            if proxy_rel not in files:
                continue  # this layout does not carry that spelling
            # Present but unverifiable refuses the whole generation --
            # falling through to another spelling would let one tampered
            # member hide behind an intact one.
            proxy = self._verified_member(root, proxy_rel, files)
            directory = proxy.parent
            for dependency in _PROXY_DEPENDENCIES:
                self._verified_member(
                    root,
                    (directory.relative_to(root) / dependency).as_posix(),
                    files)
            return proxy
        raise OSError(f"generation {root.name} carries no proven proxy with "
                      "its broker and layout dependencies; refusing")

    def _proven_retained_proxy(
            self, worker_script: str | Path | None) -> Path | None:
        """The proxy for the sealed worker runtime this launch executes.

        The pool carries its already-known sealed ``worker_script``
        explicitly -- ``_execute_in_checkout`` builds the worker argv from
        it, then wraps that argv (affinity-prefixed or not) for the same
        runtime -- so this never parses opaque command text for a root.
        Returns the executing generation's own proxy when the worker is
        this tree (the established contained path for dev checkouts), or
        the proven retained generation's proxy. Returns ``None`` only
        when ``worker_script`` names no runtime shape at all (dev stubs,
        relative paths, missing files), which keeps the current-runtime
        proxy. An unverified retained root raises ``OSError`` instead of
        silently choosing a proxy its older core would refuse.
        """

        if worker_script is None:
            return None
        script = Path(worker_script)
        if not script.is_absolute():
            return None
        try:
            resolved = script.resolve(strict=True)
        except OSError:
            return None
        if (len(resolved.parts) < 3
                or resolved.parts[-2:] != _WORKER_TAIL
                or not resolved.is_file()
                or resolved != script):
            return None
        root = resolved.parent.parent
        executing = Path(__file__).resolve().parents[2]
        if root == executing:
            proxy = executing / "tools" / "resource_exec.py"
            if proxy.is_file():
                return proxy
            return executing / "tools" / "fleet" / "resource_exec.py"
        return self._sealed_generation_proxy(root, resolved)

    def wrap_argv(self, argv: list[str],
                  *, worker_script: str | Path | None = None) -> list[str]:
        """Wrap ``argv`` in the stdio proxy of the runtime being launched.

        ``worker_script`` is the sealed worker this launch executes, as
        the pool item records it. The proxy comes from that same proven
        runtime -- retained or current -- so a later generation launching
        an earlier post-repair action (``--as-sealed-by`` and
        missing-receipt retries) no longer refuses on helper mismatch.
        The CPU-affinity ``taskset`` prefix, when present, stays inside
        the wrap untouched: the runtime is carried, never inferred from
        the command text. Callers without a sealed worker (health probes,
        qualification tools) keep the current-runtime proxy.
        """

        if self.token is None:
            raise RuntimeError('create the resource scope before launching')
        helper = self._proven_retained_proxy(worker_script)
        if helper is None:
            root = Path(__file__).resolve().parents[2]
            helper = root / 'tools/resource_exec.py'
            if not helper.is_file():
                helper = root / 'tools/fleet/resource_exec.py'
        return [sys.executable, str(helper), '--socket', str(self.socket_path),
                '--action-key', self.action_key, '--nonce', self.nonce,
                '--token', self.token, '--', *argv]

    def _prior_process_io(self) -> dict[str, Any]:
        """What an earlier sampler already accounted for *this* attempt.

        The telemetry file is the state, not this object: the pool builds one
        scope to launch the attempt and rebuilds another from the claim record
        to sample it after the child exits, and a total that restarted between
        the two would report the last two seconds as the whole run.

        Use configured host-local authority; the shared diagnostic copy can
        lag or fail after a successful local write. Missing local state never
        imports that copy. Callers without local authority use telemetry_path,
        including late cleanup into an attempt-specific archive.

        A file named for the action can contain a predecessor's readings
        when a retry on the same host starts. Only this attempt's nonce is this
        attempt's: anything else is a previous run, and adopting it would open
        attempt two with attempt one's retired bytes and retire attempt one's
        dead roots a second time.
        """
        if self._process_io is not None:
            return self._process_io
        prior = None
        try:
            path = self.authority_path if self.authority_path is not None else self.telemetry_path
            record = json.loads(path.read_text())
            if record.get('nonce') == self.nonce:
                prior = record.get('process_io')
        except (OSError, ValueError, AttributeError):
            prior = None
        self._process_io = prior if isinstance(prior, dict) else {}
        return self._process_io

    def sample_process_io(self) -> dict[str, Any]:
        """Sum the scope's processes now, keeping what departed ones earned.

        ``/proc/<pid>/io`` disappears the moment a process is reaped, so this
        has to run while the work is alive; the finish path is already too
        late. A process that both starts and ends between two samples is
        therefore not counted, and ``processes_observed`` says how many were.

        Departure is not the same as loss. The kernel adds a reaped child's
        totals into its parent's, so a process whose parent is also in the
        scope goes on being counted through a surviving sampled ancestor and
        must not be added to a retired total as well. If the whole observed
        ancestry departed between samples, no fresh ancestor reading contains
        that transfer: retire each member's last counters instead. Unobserved
        final I/O remains unavailable; this is not an exact exit-time census.
        """
        prior = self._prior_process_io()
        live_before = dict(prior.get('live') or {})
        retired = {name: int((prior.get('retired') or {}).get(name, 0))
                   for name in IO_COUNTERS}
        observed = int(prior.get('processes_observed') or 0)
        members = {int(pid) for pid in (prior.get('members') or [])}
        errors: list[str] = []
        if self.cgroup_path is None:
            errors.append('resource scope is not created')
            pids: list[int] = []
        else:
            pids = scope_pids(self.cgroup_path, errors=errors)
        members |= set(pids)
        live: dict[str, dict[str, Any]] = {}
        unreadable = 0
        # A cgroup walk or its procfs fallback may omit a live process. Check
        # previously sampled members individually before interpreting absence
        # as departure: retiring a surviving root counts it again on recovery.
        missing = {int(identity.split(':', 1)[0]) for identity in live_before} - set(pids)
        for pid in sorted(missing):
            try:
                if _process_in_scope(pid, self.cgroup_path):
                    pids.append(pid)
            except (OSError, ValueError):
                unreadable += 1
                live.update((identity, counters) for identity, counters
                            in live_before.items()
                            if identity.startswith(f'{pid}:'))
        for pid in pids:
            try:
                entry = read_process_io(pid)
            except (OSError, ValueError):
                # Membership was observed, but incarnation is unknown. Keep
                # this PID's prior reading without accepting any new bytes or
                # inventing an identity. A later readable sample distinguishes
                # the surviving process from PID reuse.
                unreadable += 1
                live.update((identity, counters) for identity, counters
                            in live_before.items()
                            if identity.startswith(f'{pid}:'))
                continue
            if entry is None:
                continue  # exited between the scan and the read
            identity, parent, counters = entry
            if identity not in live_before:
                observed += 1
            if counters is None:
                # Present, and this uid may not inspect it. Keep whatever it
                # was last seen using -- retiring it here would count it twice
                # the moment it becomes readable again.
                unreadable += 1
                previous = live_before.get(identity) or {}
                live[identity] = {'ppid': parent,
                                  **{name: int(previous.get(name, 0))
                                     for name in IO_COUNTERS}}
                continue
            live[identity] = {'ppid': parent, **counters}
        if unreadable:
            errors.append(f'{unreadable} live process(es) in the scope '
                          f'could not be inspected')
        # Historical PID membership cannot prove a transfer: the parent may
        # have departed in the same interval, or its PID may now be reused.
        # Follow the previously observed ancestry to an identical surviving
        # incarnation. A surviving grandparent can absorb both a parent and
        # child, so looking only for a live direct parent would double count.
        previous_by_pid = {int(identity.split(':', 1)[0]): identity
                           for identity in live_before}
        for identity, counters in live_before.items():
            if identity in live:
                continue
            ancestor = identity
            visited = {identity}
            inherited = False
            while True:
                parent = previous_by_pid.get(int(live_before[ancestor].get('ppid', 0)))
                if parent is None or parent in visited:
                    break
                if int(parent.split(':', 1)[1]) > int(ancestor.split(':', 1)[1]):
                    break  # a newer incarnation cannot be this process's parent
                if parent in live:
                    inherited = True
                    break
                visited.add(parent)
                ancestor = parent
            if inherited:
                continue
            for name in IO_COUNTERS:
                retired[name] += int(counters.get(name, 0))
        record: dict[str, Any] = {'source': 'proc_io'}
        for name in IO_COUNTERS:
            record[name] = retired[name] + sum(
                int(counters.get(name, 0)) for counters in live.values())
        record['processes_observed'] = observed
        record['processes_live'] = len(live)
        record['processes_unreadable'] = unreadable
        record['retired'] = retired
        record['live'] = live
        # Retained for diagnostic/schema compatibility only. PID membership
        # does not establish that a surviving process inherited departed I/O.
        record['members'] = sorted(members)[-4096:]
        if errors:
            record['errors'] = errors[-8:]
        self._process_io = record
        return record

    def sample(self) -> dict[str, Any]:
        errors: list[str] = []
        try:
            if self.cgroup_path is None:
                raise OSError('resource scope is not created')
            direct = read_cgroup(self.cgroup_path)
            self._last = direct
        except (OSError, ValueError, KeyError) as exc:
            errors.append(str(exc))
            direct = self._last or dict(cpu_seconds=0.0, memory_current_bytes=0,
                                        memory_peak_bytes=0, oom_kill=0, oom_local=0)
        # Sampling I/O must not be able to cost the attempt its telemetry --
        # and, because the pool samples outside a guard of its own, must not be
        # able to cost the attempt its verdict either. Collecting a measurement
        # never decides whether the action passed, so every exception it can
        # raise, including a TypeError from a malformed prior record, is
        # recorded here rather than left to the worker loop.
        try:
            process_io = self.sample_process_io()
        except Exception as exc:
            process_io = {'source': 'proc_io',
                          'errors': [f'{type(exc).__name__}: {exc}']}
        record = {
            'action_key': self.action_key, 'nonce': self.nonce,
            'host': socket.gethostname(), 'scope_unit': self.unit,
            'sampled_unix': time.time(), 'wall_seconds': time.monotonic() - self.started,
            **direct, 'memory_max_bytes': self.memory_max_bytes,
            'gpu_memory_max_bytes': self.gpu_memory_max_bytes,
            'process_io': process_io,
            'complete': not errors, 'errors': errors,
        }
        if self.shape_key:
            record['shape_key'] = self.shape_key
        if self._reason:
            record['termination_reason'] = self._reason
        self.write_telemetry(record)
        return record

    def write_telemetry(self, record: dict) -> None:
        """Refresh the host-local authority first, then the shared copy."""
        if self.authority_path is not None:
            _atomic_json(self.authority_path, record)
        _atomic_json(self.telemetry_path, record)

    def terminate_owned(self, reason: str) -> dict:
        """Broker kills the exact attempt's whole cgroup and audits the reason."""
        self._reason = reason
        result = self._request('stop', reason=reason)
        _atomic_json(self.telemetry_path.with_suffix('.termination.json'),
                     {'scope_unit': self.unit, 'reason': reason, 'result': result})
        return result

    def settle_containers(self, evidence: dict) -> dict:
        """Tell the broker this attempt's Docker transaction is closed.

        Sent before ``release`` and carrying the same attempt token. When a
        container ticket was never resolved -- an ordinary nonzero ``docker``
        exit is enough -- ``release`` keeps an empty frozen parent so a late
        container cannot land anywhere else. This is what lets the broker's
        inventory pass eventually remove that parent instead of keeping it
        until the host reboots (#486).

        Housekeeping, and never worth losing an action over: a broker that
        refuses or never hears this leaves exactly the behaviour that was here
        before it, which is the tombstone retained.
        """
        return self._request('settle', evidence=evidence)

    def release(self) -> dict:
        """Release only after the broker proves the aggregate job scope empty."""
        return self._request('release')

    def export_stopped_verdict(self) -> dict:
        """Read-only broker verdict for containment export (token-gated).

        Called after ``release`` with the same attempt token: reports
        stopped/empty/released/retired/settled plus ticket disposition
        without mutating authority.  The pool cleanup persists this
        verdict (never the release reply) as the reader-containment
        attestation for the attempt.
        """
        return self._request('export_stopped')
