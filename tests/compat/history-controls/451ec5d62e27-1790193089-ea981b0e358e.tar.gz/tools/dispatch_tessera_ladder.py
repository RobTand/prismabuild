"""Seal and enqueue the Tessera rate-band probe, one action per input shard.

What this buys, and why it is a separate stage from the export: the completion
axis is embedded, so ONE encode per Linear prices the whole band
``[rung/arity, cap/arity]`` bpp instead of one encode per rate point.  At rung 4
that is four rate points from one Viterbi -- the fan-out the DP needs to choose
a per-Linear allocation, at a quarter of the encodes.

It is a *generator*, not a shipping path.  Measured 2026-09-01 on a real GLM
expert: truncation costs 1.03x-1.28x, but choosing a low rung to widen the band
costs up to 2.15x at equal bpp.  So the band is priced by truncation and the
selected point is re-encoded natively -- surrogates generate, real measurement
selects, applied to the encoder itself.

``task_class`` is ``generation`` even though the receipt is a cost table: the
probe emits only deterministic encoder SSE, so its result is host-independent
and portable, and PrismaBuild reserves ``measurement`` for claims about a
machine (which it requires be keyed to one).
"""
import argparse
import hashlib
import os
import tempfile
import sys
from pathlib import Path

SH = Path("/mnt/shared/prismabuild-fleet")
sys.path.insert(0, str(Path(__file__).resolve(strict=True).parent))
from runtime_paths import generation_root  # noqa: E402
RUNTIME_ROOT = generation_root(__file__)
sys.path.insert(0, str(RUNTIME_ROOT / "src"))
from prismabuild import core as pb  # noqa: E402
import fleet_submit  # noqa: E402

CHECKOUT = SH / "checkout"
SOURCE = "/mnt/shared/models/GLM-5.3-Flash-BF16"
PYTHON = "/home/rob/dq-runs/venvs/prismaquant-cu130/bin/python"
WRAPPER = "tessera_ladder_probe.py"


#: How many shards the ladder probe is cut into. Bound into every action's
#: ``of_shards``, so a number outside 1..120 names no work at all.
#: Duplicated in the other Tessera dispatcher rather than shared, the way
#: ``closure_files`` already is: each dispatcher declares the shape of its own
#: run, and a ladder probe that is later cut differently must not silently
#: move the export's domain with it.
OF_SHARDS = 120

# One GPU driver, with native CPU work bounded to one thread below.
RESOURCE_DEMAND = {"cpu": 1, "gpu": 1, "mem_gb": 12}


def shard_range(text):
    """``N`` or ``LO-HI``, inclusive, within ``1..OF_SHARDS``.

    A bare ``int()`` after ``parse_args`` raised a ``ValueError`` traceback at
    an operator who typed a range wrong, and accepted ``0``, ``500`` and
    ``9-4`` without complaint: the first two seal actions for shards that do
    not exist and the third seals nothing while reporting success. argparse
    prints an ``ArgumentTypeError`` as a usage error, so the domain is stated
    once and every wrong value gets it.
    """

    domain = f"a shard number or an inclusive LO-HI range within 1-{OF_SHARDS}"
    low, separator, high = text.partition("-")
    # ``1-`` is a half-typed range, not shard 1: taking the low end as the
    # high end would run one shard where the operator asked for many.
    if separator and not high:
        raise argparse.ArgumentTypeError(f"expected {domain}, got {text!r}")
    high = high or low
    if not (low.isdigit() and high.isdigit()):
        raise argparse.ArgumentTypeError(f"expected {domain}, got {text!r}")
    low, high = int(low), int(high)
    if not 1 <= low <= high <= OF_SHARDS:
        raise argparse.ArgumentTypeError(
            f"expected {domain}, got {text!r}: "
            f"{low}-{high} is empty or names a shard that does not exist")
    return range(low, high + 1)


def closure_files(wrapper=WRAPPER):
    files = [wrapper]
    for path in sorted((CHECKOUT / "tessera").rglob("*.py")):
        files.append(str(path.relative_to(CHECKOUT)))
    return files


def build_action(shard, closure, rung, calibrate_every, *, wrapper=None):
    result_path = f"results/glm53-tessera-ladder/rung{rung}/shard-{shard:05d}.json"
    body = {
        "schema": pb.ACTION_SCHEMA_V2,
        "task": {
            "definition_id": "tessera/glm53-ladder-probe",
            "definition_version": "v1",
            # NOT "measurement", though it is tempting.  PrismaBuild refuses
            # a portable measurement, and it is right to: a measurement is a
            # claim about a machine and must be keyed to one.  This probe emits
            # only deterministic encoder/decoder SSE -- no timing, no power, no
            # residency reaches the receipt -- so it is host-independent and
            # genuinely portable, which makes it a generation.  Keying it to a
            # platform to satisfy the enum would be a lie that also throws away
            # the free cross-box re-enqueue.
            "task_class": "generation",
            # The encoder is deterministic on these boxes (measured
            # byte-identical cross-box, 2026-09-01); a decode adds no entropy.
            "determinism": "deterministic",
            "artifact_family": "generic",
            "artifact_kind": "tessera-rate-band",
            "argv": [
                PYTHON, wrapper["staged_path"] if wrapper else WRAPPER,
                "--shard", str(shard),
                "--source", SOURCE,
                "--rung", str(rung),
                "--calibrate-every", str(calibrate_every),
                "--result", result_path,
            ],
            "working_directory": ".",
            "result_path": result_path,
        },
        "inputs": [],
        "code_closure": closure,
        "params": {
            "demand": dict(RESOURCE_DEMAND),
            "source_model": SOURCE,
            "grid": "E2M1_K2",
            "rung": rung,
            "calibrate_every": calibrate_every,
            "shard": shard,
            "of_shards": OF_SHARDS,
        },
        "environment": {
            "variables": {
                "PATH": "/usr/local/bin:/usr/bin:/bin",
                "HOME": "/home/rob",
                "LANG": "C.UTF-8",
                "OMP_NUM_THREADS": "1",
                "MKL_NUM_THREADS": "1",
                "OPENBLAS_NUM_THREADS": "1",
                # Relative to the tree this action runs in: see the same
                # entry in ``dispatch_tessera_shards``.  An absolute path
                # into the submitter's checkout escapes the sealed snapshot
                # the SLURM lane materializes.
                "PYTHONPATH": "tessera/src",
                "TMPDIR": "/home/rob/tmp",
                "TRITON_CACHE_DIR": "/home/rob/.triton-cache",
            },
            "toolchain": pb.executable_toolchain_contract(PYTHON),
        },
        "execution_scope": {
            "portability": "portable",
            "platform_key": None,
            "host_class": None,
        },
    }
    if wrapper is not None:
        body["params"]["wrapper_source"] = wrapper
    return pb.seal_action(body)


def prepare_wrapper(source: Path, *, dry_run: bool):
    """Read once, record provenance, and never replace another dispatch's bytes."""
    source = source.resolve(strict=True)
    payload = source.read_bytes()
    digest = hashlib.sha256(payload).hexdigest()
    relative = f"prismabuild-wrappers/{digest}/{WRAPPER}"
    provenance = {"source_path": str(source), "sha256": digest,
                  "staged_path": relative}
    # Construct the same manifest for previews and submissions from the bytes
    # read above. A dry run needs no staged file, even on a new submitting box.
    encoder_files = closure_files(relative)[1:]
    entries = (pb.build_code_closure(CHECKOUT, encoder_files)["files"]
               if encoder_files else [])
    entries.append({"path": relative, "sha256": digest, "bytes": len(payload)})
    body = {"schema": pb.CODE_CLOSURE_SCHEMA_V1,
            "files": sorted(entries, key=lambda entry: entry["path"])}
    closure = pb.validate_code_closure(
        {**body, "closure_sha256": pb.canonical_sha256(body)})
    if not dry_run:
        destination = CHECKOUT / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.parent.resolve().is_relative_to(CHECKOUT.resolve()):
            raise ValueError("wrapper staging directory escapes the checkout")
        # Link a complete file into its final name exclusively. Concurrent
        # identical submissions converge; a different source gets another path.
        with tempfile.NamedTemporaryFile(dir=destination.parent) as scratch:
            scratch.write(payload)
            scratch.flush()
            os.fsync(scratch.fileno())
            try:
                os.link(scratch.name, destination)
            except FileExistsError:
                pass
        if destination.is_symlink() or destination.read_bytes() != payload:
            raise ValueError(f"staged wrapper digest mismatch: {destination}")
        # Re-read the staged bytes through the ordinary closure builder too.
        if pb.build_code_closure(CHECKOUT, closure_files(relative)) != closure:
            raise ValueError("wrapper or encoder changed while staging")
    return provenance, closure


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument(
        "--shards", required=True, type=shard_range,
        help=f"which shards to probe: one number, or an inclusive LO-HI range, "
             f"within 1-{OF_SHARDS} (e.g. 1 or 1-{OF_SHARDS})")
    ap.add_argument("--rung", type=int, default=4,
                    help="body rate per code; one encode prices the whole "
                         "[rung/arity, cap/arity] bpp band, so a lower rung "
                         "widens the band and costs accuracy at equal bpp")
    ap.add_argument("--calibrate-every", type=int, default=32,
                    help="every Nth unit also gets native encodes, so the "
                         "truncation bias in the band is measured rather "
                         "than assumed")
    ap.add_argument("--wrapper", type=Path,
                    help="probe source file; defaults to tessera_ladder_probe.py "
                         "in the shared checkout; bytes and source path are sealed "
                         "into the action, with a content-addressed staged copy")
    ap.add_argument("--dry-run", action="store_true",
                    help="preview the chosen wrapper and action keys without "
                         "staging files or enqueueing work")
    fleet_submit.add_transport_argument(ap)
    args = ap.parse_args()

    shards = args.shards

    try:
        wrapper, closure = prepare_wrapper(args.wrapper or CHECKOUT / WRAPPER,
                                           dry_run=args.dry_run)
    except (OSError, ValueError, pb.ActionContractError) as exc:
        sys.stderr.write(f"ladder wrapper: {exc}\n")
        return 1

    cas = pb.PrismaBuildCAS(SH / "cas")

    print(f"closure {closure['closure_sha256'][:16]} over "
          f"{len(closure['files'])} files   rung {args.rung}   "
          f"transport {args.transport}")
    published = 0
    for shard in shards:
        action = build_action(shard, closure, args.rung, args.calibrate_every,
                              wrapper=wrapper)
        key = str(action["action_key"])
        if args.dry_run:
            print(f"  shard {shard:>3}  {key[:16]}  (dry run)")
            continue
        request = cas.publish_action_request(action)
        # One submit path for every producer, so no tool keeps a dispatcher of
        # its own: after the cutover a direct publish queues these probes where
        # no worker drains them, and it succeeds, so nothing says so.
        submission = fleet_submit.submit(
            action,
            cas=cas,
            request_path=request,
            transport=args.transport,
            # Passed on both transports.  The pull queue carries it on the
            # queue item; the lane seals it as the snapshot the node
            # materializes, which is a different action key and the one
            # the submission reports.
            checkout_root=str(CHECKOUT),
            worker_script=str(RUNTIME_ROOT / "tools" / "prismabuild_worker.py"),
            tags=["gb10"],
            needs_gpu=True,
            # A probe holds one weight plus its forests, and re-decodes in
            # place -- lighter than an export shard, which streams a whole
            # file.  Re-measure before trusting this if the rung changes: a
            # lower rung means a wider descendant table.
            resources=dict(RESOURCE_DEMAND),
        )
        published += 1
        # The submitted key, not the sealed one: under SLURM the lane
        # seals the checkout into the action, and the key moves with it.
        print(f"  shard {shard:>3}  {submission.action_key[:16]}  "
              f"{submission.describe()}")
    print(f"published {published} action(s)")


if __name__ == "__main__":
    raise SystemExit(main())
