"""Pre-execution decomposition: one logical request, many ordinary children.

A producer that wants ten thousand small measurements has two bad options in
an ordinary fleet.  It can submit ten thousand actions, and pay one cold
process -- model load, calibration residency, kernel warmup -- per measurement.
Or it can submit one action per box and shard the work itself, which makes the
producer a second scheduler: it picks hosts, it decides worker counts, it
rebalances, and every one of those decisions is invisible to PrismaBuild's
admission, retry and receipt machinery.

This module is the third option.  The producer declares *logical tasks* and the
measured cost inputs that say what it costs to set a residency up and what each
task costs once it is up.  PrismaBuild owns the partition: a deterministic,
versioned batcher turns the roster into the smallest batches that still amortize
setup, and every batch becomes an ordinary sealed action that claims, retries,
caches and receipts exactly like any other.  The producer never names a host, a
worker count or a shard.

Three properties make that safe, and this module exists to hold them:

* **The plan is frozen before the first child is published.**  A partition that
  can be re-derived is a partition that can change under a retry, and a retry
  that changes membership makes two children that both claim to have measured
  the same task.  So the plan's bytes are published first, under the parent's
  own key, and recovery reuses them rather than re-deriving them.
* **The partition is a pure function of sealed bytes.**  Not of the live offer
  count, not of what is idle right now.  Queue the smallest sensible units and
  let ordinary admission distribute them as capacity changes.
* **Refusal, never a fallback.**  If the roster and the policy admit no exact
  cover, decomposition says so and names the run, the task range and the two
  limits.  It does not emit one oversized opaque child, and it does not quietly
  relax a limit the producer declared.

The partitioner is arithmetic over the roster. Record helpers read the
caller's CAS namespace and preserve the frozen membership used on recovery.

Estimates are planning hints bound into the plan's identity, not measured speed
claims.  Qualification measures what the resulting execution actually costs.
"""
from __future__ import annotations

from collections.abc import Mapping, Sequence
import hashlib
import json
from pathlib import Path
from typing import Any, NamedTuple

from . import core as pb
from . import data_manifest as manifest_codec
from . import immutable_files
from .submission_types import common_fields, request_options
from .core import ActionContractError, canonical_sha256
# The two sealed variables that carry container ownership.  Named here so the
# frozen half a parent is keyed on can refuse to contain them: ownership is a
# property of one running action, not of what its siblings share.
from .pool import CONTAINER_MARKER_ENV, CONTAINER_OWNER_ENV

__all__ = [
    "ActionContractError",
    "BATCH_ENVELOPE_SCHEMA_V1",
    "CHILD_RESULT_MANIFEST_SCHEMA_V1",
    "DECOMPOSITIONS",
    "FROZEN_COMMON_SCHEMA_V1",
    "GROUP_RECEIPT_SCHEMA_V1",
    "LOGICAL_BATCH_PARAM",
    "LOGICAL_BATCH_SCHEMA_V1",
    "LOGICAL_REQUEST_SCHEMA_V1",
    "LOGICAL_TASK_ROSTER_SCHEMA_V1",
    "PARENT_IDENTITY_SCHEMA_V1",
    "PARTITION_ALGORITHM_VERSION",
    "PLAN_SCHEMA_V1",
    "PUBLICATION_INDEX_SCHEMA_V1",
    "RESULT_MANIFEST_INPUT_ID",
    "MissingChildResult",
    "RecordError",
    "ChildResult",
    "DataPlans",
    "TASK_BATCH_INPUT_ID",
    "ROSTER_BATCH_POLICY_SCHEMA_V1",
    "TASK_BATCH_PLACEHOLDER",
    "batch_envelope",
    "child_result_manifest_path",
    "document_bytes",
    "record_dir",
    "read_membership",
    "read_child_request",
    "child_result",
    "child_result_for_key",
    "document_sha256",
    "write_document",
    "build_plan",
    "complete_group",
    "freeze_common",
    "freeze_plan",
    "logical_batch_param",
    "parent_key",
    "partition_roster",
    "publish_children",
    "resolve_task_batch",
    "validate_batch_policy",
    "validate_common_spec",
    "validate_frozen_common",
    "validate_logical_request",
    "validate_roster",
    "verify_exact_cover",
]

DECOMPOSITIONS = "decompositions"
_MAX_CHILD_RESULT_BYTES = 1024 * 1024

LOGICAL_REQUEST_SCHEMA_V1 = "prismabuild.logical_request.v1"
LOGICAL_TASK_ROSTER_SCHEMA_V1 = "prismabuild.logical_task_roster.v1"
ROSTER_BATCH_POLICY_SCHEMA_V1 = "prismabuild.roster_batch_policy.v1"
PARENT_IDENTITY_SCHEMA_V1 = "prismabuild.logical_parent_identity.v1"
FROZEN_COMMON_SCHEMA_V1 = "prismabuild.frozen_common.v1"
PLAN_SCHEMA_V1 = "prismabuild.decomposition_plan.v1"
BATCH_ENVELOPE_SCHEMA_V1 = "prismabuild.task_batch.v1"
LOGICAL_BATCH_SCHEMA_V1 = "prismabuild.logical_batch.v1"
PUBLICATION_INDEX_SCHEMA_V1 = "prismabuild.decomposition_publication.v1"
CHILD_RESULT_MANIFEST_SCHEMA_V1 = "prismabuild.child_result_manifest.v1"
GROUP_RECEIPT_SCHEMA_V1 = "prismabuild.group_receipt.v1"
TASK_DATA_MANIFEST_SCHEMA_V1 = "prismabuild.task_data_manifest.v1"
TASK_DATA_POLICY_PARAM = "logical_task_data_policy"

#: The sealed ``params`` key under which a child carries its membership.  A
#: child is an ordinary action in every other respect, so what makes it a
#: member of a plan has to be in the bytes its key hashes.
LOGICAL_BATCH_PARAM = "logical_batch"

#: The input ids a child carries beyond an ordinary action's: the frozen
#: roster every child of a parent shares, and the one batch envelope that
#: is only this child's.  Separate inputs rather than one, because the
#: roster's digest is the same across a campaign and the CAS stores it once.
TASK_ROSTER_INPUT_ID = "prismabuild.logical-task-roster"
TASK_BATCH_INPUT_ID = "prismabuild.task-batch"
RESULT_MANIFEST_INPUT_ID = "prismabuild.child-result-manifest"

#: Bumping this changes every ``plan_key`` while leaving parent identity alone,
#: which is the point: a better batcher must not look like a different
#: campaign, and a re-planned campaign must not silently reuse the old plan's
#: children.
PARTITION_ALGORITHM_VERSION = "contiguous-residency-exact-cover.v1"

#: The reserved whole-argument placeholder.  It is replaced, before sealing,
#: with the CAS path of the child's own batch input -- an exact argv element
#: match and nothing else.  It is deliberately not shell expansion, not
#: interpolation inside a larger string, and not a variable a producer can
#: redefine: the batch a child measures has to be a fact about its action key,
#: not about what its command line happened to evaluate to on some worker.
TASK_BATCH_PLACEHOLDER = "{pb.task_batch}"

_TASK_KEYS = frozenset(
    {"id", "payload", "residency_key", "estimated_seconds", "estimate_evidence",
     "output_id"}
)
_ROSTER_KEYS = frozenset({"schema", "tasks"})
_RESIDENCY_KEYS = frozenset({"key", "setup_seconds", "setup_evidence"})
_POLICY_KEYS = frozenset(
    {"schema", "residencies", "max_setup_fraction", "max_estimated_wall_seconds"}
)
_REQUIRED_COMMON_KEYS = frozenset({
    "argv", "cwd", "demand", "gpu_memory_gb", "data_manifest", "env",
})
_COMMON_KEYS = common_fields()

_REQUEST_KEYS = frozenset({"schema", "common", "roster", "batch_policy"})
_FROZEN_COMMON_KEYS = frozenset({"schema", "argv", "action_common"})
#: The half of a sealed action that a decomposition does not vary.  Exactly
#: these, because a child's body has exactly these plus its own command, its
#: own batch input and its own membership -- so a parent keyed on this record
#: binds everything its children share and nothing they do not.
_ACTION_COMMON_KEYS = frozenset(
    {"task", "params", "inputs", "code_closure", "environment",
     "execution_scope"}
)
_PLAN_KEYS = frozenset(
    {"schema", "parent_key", "algorithm_version", "partitions", "plan_key"})
_PUBLICATION_KEYS = frozenset(
    {"schema", "parent_key", "plan_key", "batch_input_sha256",
     "child_action_keys"})
_MANIFEST_KEYS = frozenset(
    {"schema", "parent_key", "plan_key", "child_ordinal", "results"}
)
_RESULT_KEYS = frozenset({"task_id", "output_id", "value_sha256"})


# --------------------------------------------------------------------------
# Validators
#
# Every one of these refuses unknown fields.  A decomposition's identity is the
# hash of exactly these bytes, so a field PB does not understand is a field a
# producer believes is binding and PB would silently drop.
# --------------------------------------------------------------------------


def _finite_positive(value: object, *, where: str) -> float:
    """A duration the batcher can add up: finite, real and strictly positive."""

    if type(value) is bool or not isinstance(value, (int, float)):
        pb._fail(f"{where} must be a number")
    number = float(value)
    if number != number or number in (float("inf"), float("-inf")):
        pb._fail(f"{where} must be finite")
    if not number > 0.0:
        pb._fail(f"{where} must be greater than zero")
    return number


def _finite_nonnegative(value: object, *, where: str) -> float:
    if type(value) is bool or not isinstance(value, (int, float)):
        pb._fail(f"{where} must be a number")
    number = float(value)
    if number != number or number in (float("inf"), float("-inf")):
        pb._fail(f"{where} must be finite")
    if number < 0.0:
        pb._fail(f"{where} must not be negative")
    return number


def validate_roster(value: object) -> dict[str, Any]:
    """Canonicalize the producer's declared task list.

    Order is meaningful and preserved: the batcher only ever cuts a contiguous
    run, so the roster order is the producer's statement about which tasks
    share a residency and may therefore share a process.
    """

    roster = pb._exact_mapping(value, keys=_ROSTER_KEYS, where="task roster")
    if roster["schema"] != LOGICAL_TASK_ROSTER_SCHEMA_V1:
        pb._fail(f"task roster schema must be {LOGICAL_TASK_ROSTER_SCHEMA_V1!r}")
    raw_tasks = roster["tasks"]
    if not isinstance(raw_tasks, Sequence) or isinstance(raw_tasks, (str, bytes)):
        pb._fail("task roster tasks must be an array")
    if not raw_tasks:
        pb._fail("task roster must declare at least one task")
    tasks: list[dict[str, Any]] = []
    seen_ids: set[str] = set()
    seen_outputs: set[str] = set()
    for index, raw in enumerate(raw_tasks):
        where = f"task roster tasks[{index}]"
        task = pb._exact_mapping(raw, keys=_TASK_KEYS, where=where)
        identity = pb._text(task["id"], where=f"{where}.id", pattern=pb._ID_RE)
        output_id = pb._text(
            task["output_id"], where=f"{where}.output_id", pattern=pb._ID_RE
        )
        if identity in seen_ids:
            pb._fail(f"{where}.id repeats an earlier task id: {identity!r}")
        if output_id in seen_outputs:
            pb._fail(f"{where}.output_id repeats an earlier output id: {output_id!r}")
        seen_ids.add(identity)
        seen_outputs.add(output_id)
        tasks.append({
            "id": identity,
            "payload": pb._normalize_json_value(
                task["payload"], where=f"{where}.payload"
            ),
            "residency_key": pb._text(
                task["residency_key"],
                where=f"{where}.residency_key",
                pattern=pb._ID_RE,
            ),
            "estimated_seconds": _finite_positive(
                task["estimated_seconds"], where=f"{where}.estimated_seconds"
            ),
            "estimate_evidence": pb._text(
                task["estimate_evidence"], where=f"{where}.estimate_evidence"
            ),
            "output_id": output_id,
        })
    return {"schema": LOGICAL_TASK_ROSTER_SCHEMA_V1, "tasks": tasks}


def validate_batch_policy(value: object) -> dict[str, Any]:
    """Canonicalize the limits that decide where a batch may be cut.

    Both limits and both kinds of evidence are required.  A default invented
    here would be PrismaBuild deciding how much of a producer's GPU hour may go
    to setup, which is exactly the judgment the producer measured and declared.
    """

    policy = pb._exact_mapping(value, keys=_POLICY_KEYS, where="batch policy")
    if policy["schema"] != ROSTER_BATCH_POLICY_SCHEMA_V1:
        pb._fail(f"batch policy schema must be {ROSTER_BATCH_POLICY_SCHEMA_V1!r}")
    raw_residencies = policy["residencies"]
    if (not isinstance(raw_residencies, Sequence)
            or isinstance(raw_residencies, (str, bytes))):
        pb._fail("batch policy residencies must be an array")
    if not raw_residencies:
        pb._fail("batch policy must declare at least one residency")
    residencies: list[dict[str, Any]] = []
    seen: set[str] = set()
    for index, raw in enumerate(raw_residencies):
        where = f"batch policy residencies[{index}]"
        entry = pb._exact_mapping(raw, keys=_RESIDENCY_KEYS, where=where)
        key = pb._text(entry["key"], where=f"{where}.key", pattern=pb._ID_RE)
        if key in seen:
            pb._fail(f"{where}.key repeats an earlier residency: {key!r}")
        seen.add(key)
        residencies.append({
            "key": key,
            "setup_seconds": _finite_nonnegative(
                entry["setup_seconds"], where=f"{where}.setup_seconds"
            ),
            "setup_evidence": pb._text(
                entry["setup_evidence"], where=f"{where}.setup_evidence"
            ),
        })
    fraction = policy["max_setup_fraction"]
    if type(fraction) is bool or not isinstance(fraction, (int, float)):
        pb._fail("batch policy max_setup_fraction must be a number")
    fraction = float(fraction)
    if not 0.0 < fraction <= 1.0:
        # Zero is refused rather than accepted-and-empty: it admits no batch
        # with any setup at all, so it is a refusal wearing a policy's clothes,
        # and a producer that means "never amortize" should say so by putting
        # one task in each residency run.
        pb._fail("batch policy max_setup_fraction must be in (0, 1]")
    return {
        "schema": ROSTER_BATCH_POLICY_SCHEMA_V1,
        "residencies": residencies,
        "max_setup_fraction": policy["max_setup_fraction"],
        "max_estimated_wall_seconds": _finite_positive(
            policy["max_estimated_wall_seconds"],
            where="batch policy max_estimated_wall_seconds",
        ),
    }


def _validate_batch_argv(value: object, *, where: str) -> list[str]:
    """A command with exactly one whole-argument slot for a batch."""

    if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
        pb._fail(f"{where} must be an array")
    if not value:
        pb._fail(f"{where} must not be empty")
    argv = [
        pb._text(part, where=f"{where}[{index}]", allow_control=True)
        for index, part in enumerate(value)
    ]
    # Embedding is checked first.  An embedded placeholder does not count as
    # one, so the arity check would otherwise answer "you have none of these"
    # to a producer who wrote one and chose the wrong shape -- the diagnosis
    # they need last rather than first.
    for index, part in enumerate(argv):
        if TASK_BATCH_PLACEHOLDER in part and part != TASK_BATCH_PLACEHOLDER:
            pb._fail(
                f"{where}[{index}] embeds {TASK_BATCH_PLACEHOLDER} in a larger "
                "argument; it is a whole-argument placeholder, not string "
                "interpolation"
            )
    if argv.count(TASK_BATCH_PLACEHOLDER) != 1:
        # Exactly one, because a child that cannot say which batch it measured
        # is an opaque action wearing a plan's identity, and two placeholders
        # would give one child two answers to that question.
        pb._fail(
            f"{where} must carry {TASK_BATCH_PLACEHOLDER} exactly once as a "
            "whole argument; a command without the declared batch input "
            "protocol stays an ordinary action"
        )
    return argv


_COMMON_BOOLEAN_POLICY_KEYS = frozenset(option.name for option in request_options()
    if option.kind == "switch" and option.name in _COMMON_KEYS)
_COMMON_LIST_POLICY_KEYS = frozenset(option.name for option in request_options()
    if option.kind == "repeat" and option.name in _COMMON_KEYS)


def _validate_common_policies(common: Mapping[str, object]) -> dict[str, Any]:
    """Keep optional policies structurally compatible with campaign rows.

    pbcampaign invokes its existing row-shape and submittable-row checks
    before it freezes or publishes a logical request. This library deliberately
    leaves placement, progress, profile and retry semantics to that boundary,
    while refusing values that cannot become row flags at all.
    """

    policies: dict[str, Any] = {}
    for key in _COMMON_BOOLEAN_POLICY_KEYS:
        if key in common:
            value = common[key]
            if not isinstance(value, bool):
                pb._fail(f"common spec {key} must be true or false")
            policies[key] = value
    for key in _COMMON_LIST_POLICY_KEYS:
        if key not in common:
            continue
        value = common[key]
        if not isinstance(value, Sequence) or isinstance(value, (str, bytes)):
            pb._fail(f"common spec {key} must be an array of non-empty strings")
        policies[key] = [
            pb._text(entry, where=f"common spec {key}[{index}]")
            for index, entry in enumerate(value)
        ]
    if "timeout_s" in common:
        policies["timeout_s"] = _finite_positive(
            common["timeout_s"], where="common spec timeout_s"
        )
    if "profile" in common:
        policies["profile"] = pb._text(
            common["profile"], where="common spec profile"
        )
    if "host_class" in common:
        policies["host_class"] = pb._text(
            common["host_class"], where="common spec host_class"
        )
    for key in ("max_attempts", "gpu_capacity"):
        if key in common:
            policies[key] = pb._nonnegative_integer(
                common[key], where=f"common spec {key}"
            )
    for key in common.keys() - _REQUIRED_COMMON_KEYS - policies.keys():
        policies[key] = pb._normalize_json_value(common[key], where=f"common spec {key}")
    return policies


def validate_common_spec(value: object) -> dict[str, Any]:
    """Canonicalize what every child of this parent executes identically.

    This is the half of a child's action that decomposition does not vary, so
    it is also the half that has to be frozen once: a later recovery seals its
    missing children from these bytes, never from a checkout that has moved on.
    """

    # Exact validation still rejects unknown fields and missing base fields.
    # Only optional policy keys actually supplied become required here.
    present = set(value) if isinstance(value, Mapping) else set()
    common = pb._exact_mapping(
        value, keys=_REQUIRED_COMMON_KEYS | (present & _COMMON_KEYS),
        where="common spec",
    )
    argv = _validate_batch_argv(common["argv"], where="common spec argv")
    demand = pb._normalize_json_value(common["demand"], where="common spec demand")
    if not isinstance(demand, Mapping) or not demand:
        pb._fail("common spec demand must be a non-empty object")
    for name, amount in demand.items():
        pb._nonnegative_integer(amount, where=f"common spec demand[{name!r}]")
    env = pb._normalize_json_value(common["env"], where="common spec env")
    if not isinstance(env, Mapping):
        pb._fail("common spec env must be an object")
    for name, text in env.items():
        pb._text(name, where="common spec env key", pattern=pb._ENV_RE)
        pb._text(text, where=f"common spec env[{name!r}]",
                 allow_empty=True, allow_control=True)
    gpu_memory_gb = common["gpu_memory_gb"]
    if gpu_memory_gb is not None:
        gpu_memory_gb = _finite_positive(
            gpu_memory_gb, where="common spec gpu_memory_gb"
        )
    data_manifest = common["data_manifest"]
    if data_manifest is not None:
        data_manifest = pb._text(data_manifest, where="common spec data_manifest")
    return {
        "argv": argv,
        "cwd": pb._text(common["cwd"], where="common spec cwd"),
        "demand": dict(demand),
        "env": dict(env),
        "gpu_memory_gb": gpu_memory_gb,
        "data_manifest": data_manifest,
        **_validate_common_policies(common),
    }


#: The reader's declaration (#909), both optional: a policy without them
#: validates, and freezes its parent identity, exactly as before.
_TASK_DATA_READER_KEYS = frozenset({"prefetch_depth_gib", "read_mb_s"})


def validate_task_data_policy(value: object) -> dict[str, Any]:
    declared = (_TASK_DATA_READER_KEYS & set(value)
                if isinstance(value, Mapping) else set())
    policy = pb._exact_mapping(value, keys={
        "schema", "payload_field", "mount_prefix", "residency_tier",
        "residency_ram", "mover_readers", "mover_mem_gb", *declared},
        where="task data manifest policy")
    if policy["schema"] != TASK_DATA_MANIFEST_SCHEMA_V1:
        pb._fail("unsupported task data manifest policy schema")
    field = pb._text(policy["payload_field"], where="task data payload field", pattern=pb._ID_RE)
    tier = policy["residency_tier"]
    if tier is not None:
        tier = pb._text(tier, where="task data residency tier")
    ram = policy["residency_ram"]
    if ram not in ("auto", "off"):
        pb._fail("task data residency_ram must be auto or off")
    readers = pb._nonnegative_integer(policy["mover_readers"], where="task data mover readers")
    memory = pb._nonnegative_integer(policy["mover_mem_gb"], where="task data mover memory")
    if readers < 1 or memory < 1:
        pb._fail("task data mover CPU/readers and memory must be positive")
    prefix = pb._text(policy["mount_prefix"], where="task data mount prefix")
    # Delegate path and manifest normalization to the ordinary data contract.
    manifest_codec.validate_data_manifest({"schema": manifest_codec.DATA_MANIFEST_SCHEMA_V1,
        "produced_by": {}, "annotations": {}, "mount_prefix": prefix,
        "entries": [{"path": prefix + "/validation", "offset": 0, "bytes": 1, "sha256": None}],
        "entry_count": 1, "total_bytes": 1})
    # Each child's consumer declares its reading as pbrun's
    # --residency-prefetch-depth-gib and --residency-read-mb-s would.
    reader = {}
    if "prefetch_depth_gib" in policy:
        reader["prefetch_depth_gib"] = pb._nonnegative_integer(
            policy["prefetch_depth_gib"], where="task data prefetch depth")
    if "read_mb_s" in policy:
        reader["read_mb_s"] = pb._nonnegative_integer(
            policy["read_mb_s"], where="task data read rate")
        if reader["read_mb_s"] < 1:
            pb._fail("task data read rate must be positive")
    return {"schema": TASK_DATA_MANIFEST_SCHEMA_V1, "payload_field": field,
            "mount_prefix": prefix, "residency_tier": tier, "residency_ram": ram,
            "mover_readers": readers, "mover_mem_gb": memory, **reader}


def task_data_manifest(policy: Mapping[str, Any], envelope: Mapping[str, Any]) -> dict[str, Any] | None:
    """Project only the assigned tasks, preserving first-read order.

    Repeated identical physical entries are staged once for this whole-batch
    residency phase. Conflicting declarations for one path/offset refuse.
    This projects a PB-frozen task partition; it never chooses membership.
    """
    policy = validate_task_data_policy(policy)
    entries, seen = [], {}
    for task in envelope["tasks"]:
        payload = task["payload"]
        if not isinstance(payload, Mapping):
            pb._fail("task data projection needs an object payload")
        reads = payload.get(policy["payload_field"])
        if not isinstance(reads, list):
            pb._fail(f"task {task['id']} needs an explicit declared reads array")
        if not reads:
            continue  # A receipt-only task explicitly declares no bulk reads.
        expanded = []
        for entry in reads:
            if isinstance(entry, Mapping):
                path = entry.get("path")
                if isinstance(path, str) and not path.startswith("/"):
                    entry = {**entry, "path": policy["mount_prefix"] + "/" + path}
            expanded.append(entry)
        checked = manifest_codec.validate_data_manifest({
            "schema": manifest_codec.DATA_MANIFEST_SCHEMA_V1, "produced_by": {}, "annotations": {},
            "mount_prefix": policy["mount_prefix"], "entries": expanded,
            "entry_count": len(reads),
            "total_bytes": sum(entry.get("bytes", 0) for entry in reads
                               if isinstance(entry, Mapping) and type(entry.get("bytes")) is int)})
        for entry in checked["entries"]:
            identity = (entry["path"], entry["offset"])
            if identity in seen:
                if seen[identity] != entry:
                    pb._fail("conflicting task reads name one physical entry")
                continue
            seen[identity] = entry
            entries.append(entry)
    total = sum(entry["bytes"] for entry in entries)
    if not entries:
        return None
    return manifest_codec.validate_data_manifest({
        "schema": manifest_codec.DATA_MANIFEST_SCHEMA_V1,
        "produced_by": {"tool": "prismabuild.decomposition",
                        "parent_key": envelope.get("parent_key"),
                        "plan_key": envelope.get("plan_key"),
                        "child_ordinal": envelope.get("child_ordinal")},
        "annotations": {"phases": [{"name": "batch", "cumulative_bytes": total}]},
        "mount_prefix": policy["mount_prefix"], "entries": entries,
        "entry_count": len(entries), "total_bytes": total})


def validate_logical_request(value: object) -> dict[str, Any]:
    """Canonicalize a whole request and check the two halves agree.

    The cross-check that matters is residency membership: a task naming a
    residency the policy does not price has no setup cost, and a batcher with
    no setup cost has no reason to put anything in the same process.  Refusing
    here means the producer hears about it before a parent record exists.
    """

    optional = {"task_data_manifest"} if isinstance(value, Mapping) and "task_data_manifest" in value else set()
    request = pb._exact_mapping(value, keys=_REQUEST_KEYS | optional, where="logical request")
    if request["schema"] != LOGICAL_REQUEST_SCHEMA_V1:
        pb._fail(f"logical request schema must be {LOGICAL_REQUEST_SCHEMA_V1!r}")
    common = validate_common_spec(request["common"])
    roster = validate_roster(request["roster"])
    policy = validate_batch_policy(request["batch_policy"])
    priced = {entry["key"] for entry in policy["residencies"]}
    for index, task in enumerate(roster["tasks"]):
        if task["residency_key"] not in priced:
            pb._fail(
                f"task roster tasks[{index}].residency_key "
                f"{task['residency_key']!r} is not priced by the batch policy; "
                f"it prices {sorted(priced)}"
            )
    result = {
        "schema": LOGICAL_REQUEST_SCHEMA_V1,
        "common": common,
        "roster": roster,
        "batch_policy": policy,
    }
    if optional:
        if common["data_manifest"] is not None:
            pb._fail("task data projection and a shared data_manifest are mutually exclusive")
        projected = validate_task_data_policy(request["task_data_manifest"])
        task_data_manifest(projected, {"tasks": roster["tasks"]})
        result["task_data_manifest"] = projected
    return result


# --------------------------------------------------------------------------
# Identity
# --------------------------------------------------------------------------


def validate_action_common(value: object) -> dict[str, Any]:
    """Re-check the sealed half a parent is keyed on.

    Shape only: these bytes came from ``pbrun``'s own frozen template and are
    re-checked here because a parent record read back off the shared mount is
    the one thing recovery trusts without re-reading a tree.  The two refusals
    are the two ways the half could stop being *common*: a command in it would
    make every child restate one, and a container variable in it would make
    ownership -- which is per action -- part of what the siblings share.

    The key set is exact, so a section added to ``pbrun``'s template arrives
    here as a refusal rather than as a silent addition to every parent key.
    That is deliberate: adding it to :data:`_ACTION_COMMON_KEYS` says it is
    shared, adding it to ``pbrun._TEMPLATE_SUBMITTER_KEYS`` says it is the
    submitter's own, and the refusal is what makes somebody choose.
    """

    common = pb._exact_mapping(
        pb._normalize_json_value(value, where="action common"),
        keys=_ACTION_COMMON_KEYS,
        where="action common",
    )
    params = common["params"]
    if not isinstance(params, Mapping):
        pb._fail("action common params must be an object")
    if "command" in params:
        pb._fail(
            "action common must not carry a command; it is the half of an "
            "action every child of one parent shares, and each child resolves "
            "its own batch into its own"
        )
    for name in ("cwd", "demand", "placement", "retry_policy",
                 "checkout_snapshot"):
        if name not in params:
            pb._fail(f"action common params must carry {name!r}")
    environment = common["environment"]
    if not isinstance(environment, Mapping):
        pb._fail("action common environment must be an object")
    variables = environment.get("variables")
    if not isinstance(variables, Mapping):
        pb._fail("action common environment variables must be an object")
    for name in (CONTAINER_OWNER_ENV, CONTAINER_MARKER_ENV):
        if name in variables:
            pb._fail(
                f"action common must not carry {name}; container ownership is "
                "a property of one running action, and siblings that shared it "
                "would reap each other's payloads"
            )
    return common


def freeze_common(
    common: Mapping[str, Any],
    *,
    action_common: Mapping[str, Any],
) -> dict[str, Any]:
    """Replace the submitter's declaration with the bytes it actually sealed.

    A logical request names its source and its data by *path*, because that is
    what a producer can type.  A path is not an identity: the same
    ``/home/rob/project`` is a different tree after every commit, and two
    worktrees of one commit are the same tree under two names.  Hashing the
    declaration would therefore make a parent that recovery resumes against a
    tree that has moved on, and make two parents out of one campaign run from
    two checkouts.

    So the parent is keyed on what ``pbrun``'s Stage A actually froze: the
    snapshot digest, the ingested manifest, the logical cwd, the placement, the
    retry policy, the timeout, the profiler mode, the resolved environment and
    the local toolchain -- the whole half of a child's body that decomposition
    does not vary, taken by subtraction so a field nobody thought about here is
    bound rather than dropped.  The declared ``argv`` rides alongside because
    it is the one shared thing the sealed half deliberately excludes: each
    child carries its own resolved command, and the placeholder-bearing
    original is what says they are resolutions of one campaign.

    What is checked is that the declaration and the seal agree about the three
    things a producer could otherwise watch PrismaBuild silently drop.
    """

    common = validate_common_spec(common)
    shared = validate_action_common(action_common)
    params, variables = shared["params"], shared["environment"]["variables"]

    declared = common["data_manifest"]
    if (declared is None) != (params.get("data_manifest") is None):
        # Freezing is the only place the two halves can be compared, and a
        # mismatch means the parent would be keyed on data nobody ingested, or
        # on ingested data no child was told to read.
        pb._fail(
            f"common spec declares a data manifest at {declared!r} but the "
            "sealed action "
            + ("carries one" if declared is None else "carries none")
        )
    budget = common["gpu_memory_gb"]
    if budget is not None and params.get("gpu_memory_gb") != budget:
        # A GPU budget only reaches the sealed params when the demand asks for
        # a GPU.  Declared and dropped, it would bound nothing and bind
        # nothing, which is the quietest way to lose a producer's limit.
        pb._fail(
            f"common spec declares gpu_memory_gb {budget!r} but the sealed "
            f"action carries {params.get('gpu_memory_gb')!r}; a GPU memory "
            "budget needs a GPU in the demand to take effect"
        )
    for name, text in common["env"].items():
        if variables.get(name) != text:
            pb._fail(
                f"common spec declares env[{name!r}]={text!r} but the sealed "
                f"action carries {variables.get(name)!r}"
            )
    return {
        "schema": FROZEN_COMMON_SCHEMA_V1,
        "argv": list(common["argv"]),
        "action_common": shared,
    }


def validate_frozen_common(value: object) -> dict[str, Any]:
    """Re-check a frozen common read back from storage."""

    frozen = pb._exact_mapping(
        value, keys=_FROZEN_COMMON_KEYS, where="frozen common"
    )
    if frozen["schema"] != FROZEN_COMMON_SCHEMA_V1:
        pb._fail(f"frozen common schema must be {FROZEN_COMMON_SCHEMA_V1!r}")
    return {
        "schema": FROZEN_COMMON_SCHEMA_V1,
        "argv": _validate_batch_argv(frozen["argv"], where="frozen common argv"),
        "action_common": validate_action_common(frozen["action_common"]),
    }


def parent_key(
    frozen_common: Mapping[str, Any],
    roster: Mapping[str, Any],
    batch_policy: Mapping[str, Any],
) -> str:
    """The identity of the work, before anybody decides how to cut it.

    Deliberately free of the algorithm version: a better batcher reorganizes a
    campaign, it does not make it a different campaign.
    """

    return canonical_sha256({
        "schema": PARENT_IDENTITY_SCHEMA_V1,
        "common": validate_frozen_common(frozen_common),
        "roster": validate_roster(roster),
        "batch_policy": validate_batch_policy(batch_policy),
    })


def build_plan(
    request: Mapping[str, Any], frozen_common: Mapping[str, Any]
) -> dict[str, Any]:
    """Freeze one partition of one request, and give it a key.

    Takes the frozen common rather than deriving identity from the request's
    paths, so the plan cannot exist before the tree it will run against does.

    The blueprint holds task *ids* rather than batch digests, and the batch
    envelopes reference the plan key rather than the other way round.  That
    ordering is what keeps the hashes acyclic: blueprint, then envelopes, then
    the ordinary child actions that carry both.
    """

    validated = validate_logical_request(request)
    frozen = validate_frozen_common(frozen_common)
    if frozen["argv"] != validated["common"]["argv"]:
        pb._fail(
            "frozen common argv differs from the request's; the plan would be "
            "keyed on a command no child runs"
        )
    if (frozen["action_common"]["params"].get(TASK_DATA_POLICY_PARAM)
            != validated.get("task_data_manifest")):
        pb._fail("task data projection policy must be sealed in the frozen parent")
    partitions = partition_roster(
        validated["roster"], validated["batch_policy"]
    )
    blueprint = {
        "schema": PLAN_SCHEMA_V1,
        "parent_key": parent_key(
            frozen, validated["roster"], validated["batch_policy"]
        ),
        "algorithm_version": PARTITION_ALGORITHM_VERSION,
        "partitions": partitions,
    }
    return {**blueprint, "plan_key": canonical_sha256(blueprint)}


def _validate_plan(value: object) -> dict[str, Any]:
    """Re-check a plan read back from storage, key included.

    Recovery reuses published plan bytes instead of re-deriving a partition, so
    the one thing that must not be taken on trust is that those bytes are the
    plan their key names.
    """

    plan = pb._exact_mapping(value, keys=_PLAN_KEYS, where="decomposition plan")
    if plan["schema"] != PLAN_SCHEMA_V1:
        pb._fail(f"decomposition plan schema must be {PLAN_SCHEMA_V1!r}")
    raw_partitions = plan["partitions"]
    if (not isinstance(raw_partitions, Sequence)
            or isinstance(raw_partitions, (str, bytes))):
        pb._fail("decomposition plan partitions must be an array")
    if not raw_partitions:
        pb._fail("decomposition plan must contain at least one batch")
    partitions: list[list[str]] = []
    for ordinal, raw in enumerate(raw_partitions):
        where = f"decomposition plan partitions[{ordinal}]"
        if not isinstance(raw, Sequence) or isinstance(raw, (str, bytes)):
            pb._fail(f"{where} must be an array of task ids")
        if not raw:
            pb._fail(f"{where} is empty; every batch covers at least one task")
        partitions.append([
            pb._text(entry, where=f"{where}[{index}]", pattern=pb._ID_RE)
            for index, entry in enumerate(raw)
        ])
    blueprint = {
        "schema": PLAN_SCHEMA_V1,
        "parent_key": pb._sha256(
            plan["parent_key"], where="decomposition plan parent_key"
        ),
        "algorithm_version": pb._text(
            plan["algorithm_version"],
            where="decomposition plan algorithm_version",
        ),
        "partitions": partitions,
    }
    recorded = pb._sha256(plan["plan_key"], where="decomposition plan plan_key")
    if canonical_sha256(blueprint) != recorded:
        pb._fail("decomposition plan plan_key does not match its blueprint")
    return {**blueprint, "plan_key": recorded}


def document_bytes(value: object) -> bytes:
    """The one on-disk spelling of a decomposition document.

    A plan, an envelope and a manifest are each hashed twice in two different
    senses: ``canonical_sha256`` over the value binds it into a key, and the
    CAS addresses the *file* by the digest of its bytes.  Those two differ by
    a trailing newline, which is exactly the kind of difference that reads as
    a tampered blob rather than as a formatting choice.  So there is one
    writer, and ``document_sha256`` is what it will produce.
    """

    return pb._canonical_file_bytes(value)


def document_sha256(value: object) -> str:
    """The digest the CAS will give these bytes, known before they are written."""

    return hashlib.sha256(document_bytes(value)).hexdigest()


def write_document(path: str | Path, value: object) -> str:
    """Write one decomposition document and return the digest it now has."""

    Path(path).write_bytes(document_bytes(value))
    return document_sha256(value)


def child_result_manifest_path(child_ordinal: int) -> str:
    """Where a child writes what it measured, relative to its working tree.

    A decomposed child's declared result is its manifest, not the tee'd log:
    the log says the process exited, and the merge needs to know which tasks
    it answered.  The name has to be agreed rather than discovered, because
    the action that declares it is sealed before the child that writes it
    runs -- so it is derived from the ordinal here, carried in the batch
    envelope the child is handed, and sealed as the child's ``result_path``.
    Every action gets its own private checkout, so two children of one parent
    never contend for the name.
    """

    if not isinstance(child_ordinal, int) or isinstance(child_ordinal, bool):
        pb._fail("child ordinal must be an integer")
    if child_ordinal < 0:
        pb._fail(f"child ordinal must not be negative: {child_ordinal}")
    return f"pb-child-{child_ordinal:05d}.result-manifest.json"


def resolve_task_batch(
    argv: Sequence[str], *, batch_path: str | Path
) -> list[str]:
    """Put one child's batch file where the producer reserved a slot for it.

    Substitution, not expansion: the placeholder is a whole argument and is
    replaced by a whole argument, so a path with a space, a quote or a ``$``
    in it reaches the child as one argument and never as shell text.  The
    producer's own command is otherwise untouched.
    """

    resolved = [
        str(batch_path) if part == TASK_BATCH_PLACEHOLDER else part
        for part in argv
    ]
    if sum(part == TASK_BATCH_PLACEHOLDER for part in argv) != 1:
        pb._fail(
            f"command must carry {TASK_BATCH_PLACEHOLDER} exactly once as a "
            "whole argument before a batch can be resolved into it"
        )
    return resolved


class PreparedBatches:
    """One validated request's immutable identities, computed once per seal.

    The synchronous decomposer owns request/plan for this object's lifetime;
    callers must not mutate them. It removes repeated whole-roster hashing and
    indexing without changing membership, serialization or any identity bytes.
    """
    def __init__(self, request: Mapping[str, Any], plan: Mapping[str, Any]):
        self.request, self.plan = request, plan
        self.by_id = {task["id"]: task for task in request["roster"]["tasks"]}
        self.roster_sha256 = canonical_sha256(request["roster"])
        self.batch_policy_sha256 = canonical_sha256(request["batch_policy"])

    def require_bound(self, request, plan):
        if self.request is not request or self.plan is not plan:
            pb._fail("prepared batch identities belong to another request or plan")

    def membership(self, child_ordinal: int) -> dict[str, Any]:
        # The path helper owns the ordinal type/range-independent validation.
        child_result_manifest_path(child_ordinal)
        if child_ordinal >= len(self.plan["partitions"]):
            pb._fail("child ordinal is outside the frozen plan")
        return {"schema": LOGICAL_BATCH_SCHEMA_V1,
                "parent_key": self.plan["parent_key"], "plan_key": self.plan["plan_key"],
                "roster_sha256": self.roster_sha256,
                "batch_policy_sha256": self.batch_policy_sha256,
                "child_ordinal": child_ordinal,
                "ordered_task_ids": list(self.plan["partitions"][child_ordinal])}

    def envelope(self, child_ordinal: int) -> dict[str, Any]:
        membership = self.membership(child_ordinal)
        return {"schema": BATCH_ENVELOPE_SCHEMA_V1,
                **{key: membership[key] for key in ("parent_key", "plan_key", "roster_sha256",
                                                     "batch_policy_sha256", "child_ordinal")},
                "result_manifest_path": child_result_manifest_path(child_ordinal),
                "tasks": [self.by_id[task_id] for task_id in membership["ordered_task_ids"]]}


def batch_envelope(
    request: Mapping[str, Any], plan: Mapping[str, Any], *, child_ordinal: int
) -> dict[str, Any]:
    """The immutable file one child reads to learn exactly what it measures."""
    return PreparedBatches(request, plan).envelope(child_ordinal)


def logical_batch_param(
    request: Mapping[str, Any], plan: Mapping[str, Any], *, child_ordinal: int
) -> dict[str, Any]:
    """The existing sealed membership; use PreparedBatches across many children."""
    return PreparedBatches(request, plan).membership(child_ordinal)


def _publication_index(
    plan: Mapping[str, Any],
    *,
    batch_input_digests: Sequence[str],
    child_action_keys: Sequence[str],
) -> dict[str, Any]:
    """Bind the frozen plan to the exact children it authorizes.

    Written before the first child is published, so a crash halfway through
    leaves a record that says which keys were meant to exist. Recovery fills
    the missing ones; it never asks the batcher for a fresh opinion.
    """

    count = len(plan["partitions"])
    if len(batch_input_digests) != count or len(child_action_keys) != count:
        pb._fail(
            f"publication index must carry one batch digest and one child key "
            f"per batch: plan has {count}, got {len(batch_input_digests)} "
            f"digests and {len(child_action_keys)} keys"
        )
    return {
        "schema": PUBLICATION_INDEX_SCHEMA_V1,
        "parent_key": plan["parent_key"],
        "plan_key": plan["plan_key"],
        "batch_input_sha256": [
            pb._sha256(digest, where=f"publication index batch_input_sha256[{position}]")
            for position, digest in enumerate(batch_input_digests)
        ],
        "child_action_keys": [
            pb._sha256(key, where=f"publication index child_action_keys[{position}]")
            for position, key in enumerate(child_action_keys)
        ],
    }


def _validate_publication_index(value: object, plan: Mapping[str, Any] | None = None) -> dict[str, Any]:
    """Re-check a publication index read back from storage (#1666).

    Recovery and the coordinator's stall watch reuse published bytes instead
    of re-deriving membership, so the one thing that must not be taken on
    trust is that those bytes name this plan's children in order. With a
    plan, the index must name its parent and plan keys and carry one child
    key per partition; the ordinal of a child is its zero-based position in
    ``child_action_keys``, and the plan carries no ordinal field.
    """

    index = pb._exact_mapping(
        value, keys=_PUBLICATION_KEYS, where="decomposition publication index")
    if index["schema"] != PUBLICATION_INDEX_SCHEMA_V1:
        pb._fail(
            "decomposition publication index schema must be "
            f"{PUBLICATION_INDEX_SCHEMA_V1!r}")
    parent_key = pb._sha256(
        index["parent_key"], where="decomposition publication index parent_key")
    plan_key = pb._sha256(
        index["plan_key"], where="decomposition publication index plan_key")
    raw_digests = index["batch_input_sha256"]
    if (not isinstance(raw_digests, Sequence)
            or isinstance(raw_digests, (str, bytes))):
        pb._fail("decomposition publication index batch_input_sha256 must be an array")
    digests = [
        pb._sha256(digest, where=f"decomposition publication index batch_input_sha256[{position}]")
        for position, digest in enumerate(raw_digests)]
    raw_keys = index["child_action_keys"]
    if (not isinstance(raw_keys, Sequence)
            or isinstance(raw_keys, (str, bytes))):
        pb._fail("decomposition publication index child_action_keys must be an array")
    keys = [
        pb._sha256(key, where=f"decomposition publication index child_action_keys[{position}]")
        for position, key in enumerate(raw_keys)]
    if len(digests) != len(keys):
        pb._fail(
            "decomposition publication index must carry one batch digest per "
            f"child key: {len(digests)} digests, {len(keys)} keys")
    result = {
        "schema": PUBLICATION_INDEX_SCHEMA_V1,
        "parent_key": parent_key, "plan_key": plan_key,
        "batch_input_sha256": digests, "child_action_keys": keys}
    if plan is not None:
        if parent_key != plan["parent_key"]:
            pb._fail(
                "decomposition publication index names parent "
                f"{parent_key[:12]}, not this plan's {str(plan['parent_key'])[:12]}")
        if plan_key != plan["plan_key"]:
            pb._fail(
                "decomposition publication index names plan "
                f"{plan_key[:12]}, not {str(plan['plan_key'])[:12]}")
        if len(keys) != len(plan["partitions"]):
            pb._fail(
                "decomposition publication index names "
                f"{len(keys)} children for a plan with {len(plan['partitions'])} batches")
    return result


def record_dir(cas_root: str | Path, parent_key: str) -> Path:
    """The retained plan and publication namespace for one logical parent."""
    return Path(cas_root) / DECOMPOSITIONS / parent_key[:2] / parent_key


class ChildResult(NamedTuple):
    receipt: Mapping[str, object]
    manifest: Mapping[str, object]


class RecordError(Exception):
    """A retained decomposition record cannot be read or adopted."""


class MissingChildResult(RecordError):
    """A group cannot close while this child has no durable result."""

    def __init__(self, ordinal: int, count: int):
        self.ordinal = ordinal
        self.count = count
        super().__init__(f"child {ordinal} of {count} has no receipt")


def _stored_record(path: Path) -> object | None:
    try:
        raw = path.read_bytes()
    except FileNotFoundError:
        return None
    except OSError as exc:
        raise RecordError(f"cannot read {path}: {exc}") from None
    try:
        return json.loads(raw.decode("utf-8"))
    except ValueError as exc:
        raise RecordError(
            f"{path} is published but is not JSON: {exc}.  It is immutable, "
            f"so this is damage rather than drift; move it aside deliberately "
            f"before re-running this campaign"
        ) from None


def _validate_data_plans(stored, plan, children):
    if (not isinstance(stored, dict) or set(stored) != {"schema", "parent_key", "plan_key", "children"}
            or stored["schema"] != "prismabuild.decomposed_data_plans.v1"
            or stored["parent_key"] != plan["parent_key"] or stored["plan_key"] != plan["plan_key"]
            or not isinstance(stored["children"], list) or len(stored["children"]) != len(children)):
        raise RecordError("decomposed data-plan record is corrupt or belongs to another plan")
    for child, row in zip(children, stored["children"]):
        if not isinstance(row, dict) or set(row) != {"action_key", "plan"} or row["action_key"] != child["action_key"]:
            raise RecordError("decomposed data-plan child identity differs from the frozen publication")
        yield child, row


class DataPlans:
    """One immutable decomposition data-plan record and its recovery protocol."""

    def __init__(self, cas_root: str | Path, plan: Mapping[str, Any]):
        self.path = record_dir(cas_root, plan["parent_key"]) / "data-plans.json"
        self.plan = plan

    def capture(self):
        return _stored_record(self.path)

    def freeze(self, rows):
        proposed = {"schema": "prismabuild.decomposed_data_plans.v1",
                    "parent_key": self.plan["parent_key"], "plan_key": self.plan["plan_key"],
                    "children": rows}
        if immutable_files.publish_immutable(self.path, document_bytes(proposed)):
            return proposed
        return _stored_record(self.path)

    def rows_for_children(self, stored, children):
        return _validate_data_plans(stored, self.plan, children)


def freeze_plan(request, frozen_common, *, cas_root: str | Path) -> dict:
    """Read first, derive only if absent, and adopt the first valid writer."""

    key = parent_key(
        frozen_common, request["roster"], request["batch_policy"])
    path = record_dir(cas_root, key) / "plan.json"
    stored = _stored_record(path)
    if stored is None:
        plan = build_plan(request, frozen_common)
        if not immutable_files.publish_immutable(path, document_bytes(plan)):
            stored = _stored_record(path)
        else:
            return plan
    plan = _validate_plan(stored)
    if plan["parent_key"] != key:
        raise RecordError(
            f"the plan published at {path} is keyed on parent "
            f"{plan['parent_key'][:12]}, not on {key[:12]}"
        )
    return plan


def publish_children(
    plan: Mapping[str, Any], *, cas_root: str | Path,
    batch_input_digests: Sequence[str], child_action_keys: Sequence[str],
) -> None:
    """Freeze this plan's authorized children, refusing a different first writer."""

    index = _publication_index(
        plan, batch_input_digests=batch_input_digests,
        child_action_keys=child_action_keys)
    path = record_dir(cas_root, plan["parent_key"]) / "publication.json"
    raw = document_bytes(index)
    stored = _stored_record(path)
    if stored is None:
        if immutable_files.publish_immutable(path, raw):
            return
        stored = _stored_record(path)
    if document_bytes(stored) != raw:
        raise RecordError(
            f"the publication index at {path} names different children than "
            f"this run sealed.  The index is a function of the plan and the "
            f"roster, so nothing that can legitimately vary produced this; "
            f"read both before touching either"
        )


def _publish_group_receipt(receipt, *, cas, parent_key: str) -> Path:
    path = record_dir(cas.root, parent_key) / "group.json"
    raw = document_bytes(receipt)
    stored = _stored_record(path)
    if stored is None:
        if immutable_files.publish_immutable(path, raw):
            return path
        stored = _stored_record(path)
    if document_bytes(stored) != raw:
        raise RecordError(
            f"the group receipt at {path} is not the one this run verified.  "
            f"It is a function of the plan and of immutable child receipts, so "
            f"nothing that can legitimately vary produced this; read both "
            f"before touching either"
        )
    return path


def complete_group(request, plan, children, *, cas) -> tuple[dict, Path]:
    """Verify the frozen group's exact cover and publish its one receipt."""

    if len(children) != len(plan["partitions"]):
        raise RecordError(
            f"the plan names {len(plan['partitions'])} children, but "
            f"the group carries {len(children)} sealed actions"
        )
    index_path = record_dir(cas.root, plan["parent_key"]) / "publication.json"
    index = _stored_record(index_path)
    child_keys = [str(child["action_key"]) for child in children]
    if (not isinstance(index, dict)
            or index.get("parent_key") != plan["parent_key"]
            or index.get("plan_key") != plan["plan_key"]
            or index.get("child_action_keys") != child_keys):
        raise RecordError(
            f"the group children do not match the frozen publication "
            f"index at {index_path}"
        )
    index = _validate_publication_index(index, plan)
    manifests = []
    child_evidence = []
    prepared_batches = PreparedBatches(request, plan)
    for ordinal, child in enumerate(children):
        expected_batch = prepared_batches.membership(ordinal)
        params = child.get("params")
        if (not isinstance(params, dict)
                or params.get(LOGICAL_BATCH_PARAM) != expected_batch):
            raise RecordError(
                f"child {ordinal} does not seal the plan's exact batch "
                f"membership and identity"
            )
        document = _read_child_result_document(cas, child)
        if document is None:
            raise MissingChildResult(ordinal, len(children))
        child_receipt, manifest = document
        if manifest is None:
            raise MissingChildResult(ordinal, len(children))
        checked = _validate_child_result_manifest(manifest)
        if checked["child_ordinal"] != ordinal:
            raise RecordError(
                f"child {ordinal}'s receipt carries a result manifest for "
                f"ordinal {checked['child_ordinal']}"
            )
        manifests.append(manifest)
        child_evidence.append({
            "action_key": child_keys[ordinal],
            "receipt_sha256": document_sha256(child_receipt),
        })
    receipt = {
        **verify_exact_cover(request, plan, manifests),
        "children": child_evidence,
    }
    path = _publish_group_receipt(
        receipt, cas=cas, parent_key=plan["parent_key"])
    return receipt, path


def read_membership(
        cas_root: object, *, parent_key: str, plan_key: str,
        stop_after_invalid_plan: bool = False,
) -> dict[str, object]:
    """The stored plan and publication this batch must match (#1666).

    Read from the coordinator's CAS beside the sealed requests, through
    the native plan and publication validators: the ordinal of a child
    is its position in ``child_action_keys``, and its task set is the
    plan's partition there. A missing or unreadable store refuses the
    credit rather than guessing membership from queue rows. The reporter
    stops after a refused plan; queue diagnosis still captures both documents.
    """

    if not isinstance(cas_root, (str, Path)) or not str(cas_root):
        return {"plan": None, "publication": None,
                "unreadable": ["the coordinator's claim names no CAS"]}
    root = Path(str(cas_root))
    unreadable: list[str] = []
    plan_doc: Mapping[str, object] | None = None
    index: Mapping[str, object] | None = None
    for name in ("plan.json", "publication.json"):
        if name == "publication.json" and stop_after_invalid_plan:
            if plan_doc is None:
                return {"plan": None, "publication": None, "unreadable": unreadable}
            if (str(plan_doc.get("parent_key")) != parent_key
                    or str(plan_doc.get("plan_key")) != plan_key):
                return {"plan": None, "publication": None,
                        "unreadable": ["the stored plan names another parent or plan"]}
        path = record_dir(root, parent_key) / name
        try:
            raw = path.read_bytes()
        except FileNotFoundError:
            unreadable.append(f"{name} is missing at {path}")
            continue
        except OSError as exc:
            unreadable.append(f"{name} is unreadable: {exc!r}")
            continue
        try:
            value = json.loads(raw.decode("utf-8"))
        except (UnicodeDecodeError, ValueError) as exc:
            unreadable.append(f"{name} is not JSON: {exc!r}")
            continue
        if name == "plan.json":
            try:
                plan_doc = _validate_plan(value)
            except (ValueError, pb.ActionContractError) as exc:
                unreadable.append(f"plan.json is invalid: {exc}")
        else:
            try:
                index = _validate_publication_index(value)
            except (ValueError, pb.ActionContractError) as exc:
                unreadable.append(f"publication.json is invalid: {exc}")
    if plan_doc is not None:
        if (str(plan_doc.get("parent_key")) != parent_key
                or str(plan_doc.get("plan_key")) != plan_key):
            unreadable.append(
                "the stored plan names another parent or plan")
            plan_doc = None
    if index is not None:
        if (str(index.get("parent_key")) != parent_key
                or str(index.get("plan_key")) != plan_key):
            unreadable.append(
                "the stored publication names another parent or plan")
            index = None
        elif (plan_doc is not None and len(index.get("child_action_keys") or ())  # type: ignore[union-attr]
                != len(plan_doc.get("partitions") or ())):  # type: ignore[union-attr]
            unreadable.append(
                "the stored publication covers another child count "
                "than the stored plan")
            index = None
    if plan_doc is None or index is None:
        if not unreadable:
            unreadable.append("the stored plan or publication did not read")
        return {"plan": None, "publication": None, "unreadable": unreadable}
    return {"plan": plan_doc, "publication": index, "unreadable": []}


def child_result_for_key(
    cas, child_key: str, *, parent_key: str, plan_key: str,
    supplied_requests: Mapping[str, Mapping[str, Any]],
) -> dict[str, Any] | None:
    """Read an expected child's native request, bound membership, and result."""

    try:
        request = cas.read_action_request(child_key)
    except (OSError, ValueError):
        return None
    supplied = supplied_requests.get(child_key)
    if supplied is not None and supplied != request:
        return None
    if request is None:
        return None
    if str(request.get("action_key") or "") != child_key:
        return None
    params = request.get("params")
    batch = (params.get("logical_batch")
             if isinstance(params, Mapping) else None)
    if (not isinstance(batch, Mapping)
            or batch.get("parent_key") != parent_key
            or batch.get("plan_key") != plan_key):
        return None
    try:
        membership = read_membership(
            cas.root, parent_key=parent_key, plan_key=plan_key,
            stop_after_invalid_plan=True)
    except AttributeError:
        return None
    if membership["unreadable"]:
        return None
    plan_doc, index = membership["plan"], membership["publication"]
    try:
        result = child_result(
            cas, request, child_key=child_key,
            plan=plan_doc, publication=index)
    except Exception:  # noqa: BLE001 -- unreadable or tampered CAS is not durable
        return None
    if result is None:
        return None
    return dict(result.manifest)


def read_child_request(
        child_key: str, *, cas_root: object,
        parent_key: str, plan_key: str,
        plan: Mapping[str, object],
        publication: Mapping[str, object],
) -> tuple[dict[str, object] | None, str]:
    """The child's sealed request when it carries the exact membership."""

    if (len(child_key) != 64
            or any(ch not in "0123456789abcdef" for ch in child_key)):
        return None, "not an action key"
    if not isinstance(cas_root, (str, Path)) or not str(cas_root):
        return None, "the coordinator's claim names no CAS"
    path = Path(str(cas_root)) / "requests" / child_key[:2] / f"{child_key}.json"
    try:
        raw = immutable_files.read_stable_file(path, where="child action request")
        request = pb.validate_action(
            pb.digest_primitives.decode_strict_json(raw, where="child action request"),
        )
    except FileNotFoundError:
        return None, "no sealed request in the coordinator's CAS"
    except (OSError, ValueError, RecursionError, pb.ActionContractError,
            pb.CASTamperError, pb.CASUnavailableError) as exc:
        return None, f"request unreadable: {type(exc).__name__}"
    params = request.get("params")
    batch = (params.get("logical_batch")  # type: ignore[union-attr]
             if isinstance(params, Mapping) else None)
    if not isinstance(batch, Mapping):
        return None, "its sealed params carry no logical_batch"
    if (request.get("action_key") != child_key
            or batch.get("parent_key") != parent_key
            or batch.get("plan_key") != plan_key):
        return None, "its sealed logical_batch names another batch"
    ordinal = batch.get("child_ordinal")
    if (not isinstance(ordinal, int) or isinstance(ordinal, bool)
            or not isinstance(batch.get("ordered_task_ids"), list)):
        return None, "its sealed logical_batch carries no ordinal membership"
    keys = publication.get("child_action_keys")
    partitions = plan.get("partitions")
    if not isinstance(keys, list) or not isinstance(partitions, list):
        return None, "the stored publication names no children"
    if not 0 <= ordinal < len(keys) or keys[ordinal] != child_key:
        return None, (
            "its sealed ordinal is not its position in the stored "
            "publication")
    if not 0 <= ordinal < len(partitions):
        return None, "its sealed ordinal is outside the stored plan"
    if list(partitions[ordinal]) != list(batch.get("ordered_task_ids")):  # type: ignore[union-attr]
        return None, (
            "its sealed task set differs from the stored plan's "
            "partition")
    return request, ""


def _read_child_result_document(
    cas, request: Mapping[str, object],
) -> tuple[Mapping[str, object], object] | None:
    """Read a native receipt and its bounded, strictly decoded JSON value."""

    receipt = cas._lookup_receipt_only(pb.validate_action(request))
    if receipt is None:
        return None
    result = receipt["result"]
    assert isinstance(result, Mapping)
    payload = cas.read_declared_blob(
        result, max_bytes=_MAX_CHILD_RESULT_BYTES, where="child result manifest")
    return (receipt, pb.digest_primitives.decode_strict_json(
        payload,
        where="child result manifest",
    ))


def child_result(
        cas, request: Mapping[str, object], *,
        child_key: str,
        plan: Mapping[str, object],
        publication: Mapping[str, object],
) -> ChildResult | None:
    """Verify one child's durable result through the native CAS (#1666).

    Verifies the receipt, the result blob digest and manifest membership:
    the receipt names this action, the blob digest matches its name, the
    manifest validates and carries this child's exact membership. Exact
    means all four hold: the manifest names the sealed request's parent
    and plan, its ordinal equals the child's position in the publication's
    ``child_action_keys``, and its task set equals the plan's partition at
    that ordinal. A child with several tasks still counts one unit.
    Returns the verified receipt and manifest, or ``None`` when the child has
    no verified durable result. A receipted JSON null is an invalid manifest
    and raises the native ActionContractError. Unreadable or tampered bytes
    retain their native CAS failures.
    """

    document = _read_child_result_document(cas, request)
    if document is None:
        return None
    receipt, value = document
    key = child_key
    manifest = _validate_child_result_manifest(value)
    params = request.get("params")
    batch = (params.get("logical_batch")  # type: ignore[union-attr]
             if isinstance(params, Mapping) else None)
    if not isinstance(batch, Mapping):
        return None
    if (manifest["parent_key"] != batch.get("parent_key")
            or manifest["plan_key"] != batch.get("plan_key")):
        return None
    if (not key or not isinstance(batch.get("child_ordinal"), int)
            or isinstance(batch.get("child_ordinal"), bool)):
        return None
    if manifest["child_ordinal"] != batch.get("child_ordinal"):
        return None
    tasks = batch.get("ordered_task_ids")
    if (not isinstance(tasks, list) or not tasks
            or any(not isinstance(entry, str) for entry in tasks)):
        return None
    try:
        checked_plan = _validate_plan(plan)
        checked_index = _validate_publication_index(
            publication, checked_plan)
    except (ValueError, pb.ActionContractError):
        return None
    if (manifest["parent_key"] != checked_plan["parent_key"]
            or manifest["plan_key"] != checked_plan["plan_key"]):
        return None
    ordinal = int(batch.get("child_ordinal"))
    if not 0 <= ordinal < len(checked_index["child_action_keys"]):
        return None
    if checked_index["child_action_keys"][ordinal] != key:
        return None
    if list(checked_plan["partitions"][ordinal]) != list(tasks):
        return None
    manifest_tasks = [entry["task_id"] for entry in manifest["results"]]
    if sorted(manifest_tasks) != sorted(tasks) or len(set(manifest_tasks)) != len(tasks):
        return None
    return ChildResult(receipt, manifest)


# --------------------------------------------------------------------------
# The partitioner
# --------------------------------------------------------------------------


class PartitionRefused(ActionContractError):
    """No exact cover exists under the declared limits.

    Its own type because the caller's response is different in kind: a schema
    error is a producer typo, while this one is a statement about the limits
    the producer measured, and the operator needs the numbers to change them.
    """


def _runs(tasks: Sequence[Mapping[str, Any]]) -> list[tuple[int, int, str]]:
    """Split the roster into maximal contiguous same-residency runs."""

    runs: list[tuple[int, int, str]] = []
    start = 0
    for index in range(1, len(tasks) + 1):
        if (index == len(tasks)
                or tasks[index]["residency_key"] != tasks[start]["residency_key"]):
            runs.append((start, index, tasks[start]["residency_key"]))
            start = index
    return runs


def _partition_run(
    tasks: Sequence[Mapping[str, Any]],
    *,
    begin: int,
    end: int,
    residency_key: str,
    setup_seconds: float,
    max_setup_fraction: float,
    max_wall_seconds: float,
) -> list[list[int]]:
    """Cut one same-residency run into the most batches that stay feasible.

    A greedy packer is wrong here and the reason is the remainder: filling each
    batch to the wall bound can leave a final group too small to amortize its
    own setup, when a rebalanced partition of the same run has no such group.
    So this is a dynamic program over suffixes, in three passes.

    The two limits are a band, not a ceiling.  Rearranged, the setup-fraction
    bound says each batch must carry at least ``min_work`` seconds of useful
    work, and the wall bound says it may carry at most ``max_work``; a batch is
    feasible exactly when its estimate lands between them.

    Pass one maximizes the batch count, which is the design's "smallest
    sensible units".  Pass two, among partitions achieving that count,
    minimizes the largest estimated batch wall -- a max is monotone in its
    parts, so the optimal suffix of an optimal partition is optimal and the
    recursion is sound.  Pass three walks forward taking the earliest cut that
    still reaches both optima, which is the lexicographically smallest cut
    sequence among the winners.

    All arithmetic is prefix-sum differences in roster order.  The partition
    has to be a pure function of the sealed bytes on every box, and floating
    point only gives that when the operations are the same ones in the same
    order.
    """

    count = end - begin
    prefix = [0.0] * (count + 1)
    for index in range(count):
        prefix[index + 1] = prefix[index] + tasks[begin + index]["estimated_seconds"]

    max_work = max_wall_seconds - setup_seconds
    # setup / (setup + work) <= f  <=>  work >= setup * (1 - f) / f
    min_work = setup_seconds * (1.0 - max_setup_fraction) / max_setup_fraction

    def refuse(reason: str) -> None:
        raise PartitionRefused(
            f"no exact cover for residency {residency_key!r} over roster tasks "
            f"[{begin}, {end}) ({count} tasks, "
            f"{prefix[count]:.6g}s estimated): {reason}. "
            f"Each batch must carry at least {min_work:.6g}s of useful work "
            f"(setup {setup_seconds:.6g}s at max_setup_fraction "
            f"{max_setup_fraction:.6g}) and at most {max_work:.6g}s "
            f"(max_estimated_wall_seconds {max_wall_seconds:.6g}s). "
            "Change a limit or the roster; decomposition does not emit an "
            "oversized child and does not relax a declared limit."
        )

    if max_work <= 0.0:
        refuse(
            f"setup alone meets or exceeds the wall ceiling, so no batch of "
            f"this residency can run"
        )
    if min_work > max_work:
        refuse(
            "the setup-fraction floor is above the wall ceiling, so the two "
            "limits admit no batch at all"
        )
    for index in range(count):
        seconds = tasks[begin + index]["estimated_seconds"]
        if seconds > max_work:
            refuse(
                f"task {tasks[begin + index]['id']!r} alone estimates "
                f"{seconds:.6g}s, past the ceiling"
            )

    def window(start: int) -> tuple[int, int]:
        """The half-open range of batch ends that are feasible from ``start``.

        Work is nondecreasing in the end position, so both edges are a
        bisection rather than a scan; without this the DP is quadratic in a
        roster that can hold tens of thousands of tasks.
        """

        base = prefix[start]
        low, high = start + 1, count + 1
        first = high
        while low < high:                                  # first end >= min_work
            middle = (low + high) // 2
            if prefix[middle] - base >= min_work:
                first, high = middle, middle
            else:
                low = middle + 1
        low, high = start + 1, count + 1
        last = start                                       # last end <= max_work
        while low < high:
            middle = (low + high) // 2
            if prefix[middle] - base <= max_work:
                last, low = middle, middle + 1
            else:
                high = middle
        return first, last + 1

    unreachable = -1
    batches = [unreachable] * (count + 1)
    batches[count] = 0
    for start in range(count - 1, -1, -1):
        first, stop = window(start)
        best = unreachable
        for finish in range(first, min(stop, count + 1)):
            if batches[finish] != unreachable and batches[finish] + 1 > best:
                best = batches[finish] + 1
        batches[start] = best
    if batches[0] == unreachable:
        refuse("no contiguous partition of the run satisfies both limits")

    infinite = float("inf")
    walls = [infinite] * (count + 1)
    walls[count] = 0.0
    for start in range(count - 1, -1, -1):
        if batches[start] == unreachable:
            continue
        first, stop = window(start)
        best = infinite
        for finish in range(first, min(stop, count + 1)):
            if batches[finish] != batches[start] - 1:
                continue
            candidate = max(
                setup_seconds + (prefix[finish] - prefix[start]), walls[finish]
            )
            if candidate < best:
                best = candidate
        walls[start] = best

    ceiling = walls[0]
    partition: list[list[int]] = []
    start = 0
    while start < count:
        first, stop = window(start)
        for finish in range(first, min(stop, count + 1)):
            if batches[finish] != batches[start] - 1:
                continue
            wall = setup_seconds + (prefix[finish] - prefix[start])
            if wall <= ceiling and walls[finish] <= ceiling:
                partition.append(list(range(begin + start, begin + finish)))
                start = finish
                break
        else:                                      # pragma: no cover - unreachable
            refuse(
                "plan reconstruction found no cut reaching the optimum it just "
                "computed; this is a batcher defect, not a limits problem"
            )
    return partition


def partition_roster(
    roster: Mapping[str, Any], policy: Mapping[str, Any]
) -> list[list[str]]:
    """Cut a validated roster into the plan's ordered batches of task ids.

    Runs of different residency keys are never mixed: two tasks that need
    different resident state in one process would pay both setups, which is the
    cost this whole mechanism exists to avoid.
    """

    tasks = roster["tasks"]
    setup_by_key = {
        entry["key"]: entry["setup_seconds"] for entry in policy["residencies"]
    }
    fraction = float(policy["max_setup_fraction"])
    wall = float(policy["max_estimated_wall_seconds"])
    partitions: list[list[str]] = []
    for begin, end, residency_key in _runs(tasks):
        for indices in _partition_run(
            tasks,
            begin=begin,
            end=end,
            residency_key=residency_key,
            setup_seconds=setup_by_key[residency_key],
            max_setup_fraction=fraction,
            max_wall_seconds=wall,
        ):
            partitions.append([tasks[index]["id"] for index in indices])
    return partitions


# --------------------------------------------------------------------------
# Exact-cover verification
# --------------------------------------------------------------------------


def _validate_child_result_manifest(value: object) -> dict[str, Any]:
    """Canonicalize what one child says it measured.

    The child's declared result is this manifest, not its log: a launcher log
    says a process ran, and what the group receipt needs to know is which
    roster tasks now have an answer.
    """

    manifest = pb._exact_mapping(
        value, keys=_MANIFEST_KEYS, where="child result manifest"
    )
    if manifest["schema"] != CHILD_RESULT_MANIFEST_SCHEMA_V1:
        pb._fail(
            f"child result manifest schema must be "
            f"{CHILD_RESULT_MANIFEST_SCHEMA_V1!r}"
        )
    raw_results = manifest["results"]
    if not isinstance(raw_results, Sequence) or isinstance(raw_results, (str, bytes)):
        pb._fail("child result manifest results must be an array")
    if not raw_results:
        pb._fail("child result manifest must carry at least one result")
    results: list[dict[str, Any]] = []
    for index, raw in enumerate(raw_results):
        where = f"child result manifest results[{index}]"
        entry = pb._exact_mapping(raw, keys=_RESULT_KEYS, where=where)
        results.append({
            "task_id": pb._text(
                entry["task_id"], where=f"{where}.task_id", pattern=pb._ID_RE
            ),
            "output_id": pb._text(
                entry["output_id"], where=f"{where}.output_id", pattern=pb._ID_RE
            ),
            "value_sha256": pb._sha256(
                entry["value_sha256"], where=f"{where}.value_sha256"
            ),
        })
    return {
        "schema": CHILD_RESULT_MANIFEST_SCHEMA_V1,
        "parent_key": pb._sha256(
            manifest["parent_key"], where="child result manifest parent_key"
        ),
        "plan_key": pb._sha256(
            manifest["plan_key"], where="child result manifest plan_key"
        ),
        "child_ordinal": pb._nonnegative_integer(
            manifest["child_ordinal"], where="child result manifest child_ordinal"
        ),
        "results": results,
    }


def verify_exact_cover(
    request: Mapping[str, Any],
    plan: Mapping[str, Any],
    manifests: Sequence[Mapping[str, Any]],
) -> dict[str, Any]:
    """Prove the children between them answered the roster exactly once.

    Closed on every way that can fail: a missing child, a child answering for a
    task that is not in its own batch, a task answered twice, a task not
    answered, a manifest from another plan.  An incomplete or failed set is
    never a group success, so this returns the group receipt only when the
    cover is exact.
    """

    roster_tasks = request["roster"]["tasks"]
    partitions = plan["partitions"]
    if len(manifests) != len(partitions):
        pb._fail(
            f"exact cover needs one result manifest per batch: the plan has "
            f"{len(partitions)}, {len(manifests)} were given"
        )
    output_by_task = {task["id"]: task["output_id"] for task in roster_tasks}
    answered: dict[str, int] = {}
    validated: list[dict[str, Any]] = []
    for manifest in manifests:
        checked = _validate_child_result_manifest(manifest)
        ordinal = checked["child_ordinal"]
        if not 0 <= ordinal < len(partitions):
            pb._fail(
                f"child result manifest names ordinal {ordinal}, outside the "
                f"plan's {len(partitions)} batches"
            )
        if checked["parent_key"] != plan["parent_key"]:
            pb._fail(
                f"child {ordinal} reports parent {checked['parent_key'][:12]}, "
                f"not this plan's {str(plan['parent_key'])[:12]}"
            )
        if checked["plan_key"] != plan["plan_key"]:
            pb._fail(
                f"child {ordinal} reports plan {checked['plan_key'][:12]}, "
                f"not {str(plan['plan_key'])[:12]}"
            )
        validated.append(checked)
    by_ordinal: dict[int, dict[str, Any]] = {}
    for checked in validated:
        ordinal = checked["child_ordinal"]
        if ordinal in by_ordinal:
            pb._fail(f"two result manifests claim child ordinal {ordinal}")
        by_ordinal[ordinal] = checked
    for ordinal, batch in enumerate(partitions):
        checked = by_ordinal.get(ordinal)
        if checked is None:
            pb._fail(f"no result manifest for child ordinal {ordinal}")
        membership = set(batch)
        for entry in checked["results"]:
            task_id = entry["task_id"]
            if task_id not in membership:
                pb._fail(
                    f"child {ordinal} reports task {task_id!r}, which is not in "
                    "its own batch"
                )
            if output_by_task[task_id] != entry["output_id"]:
                pb._fail(
                    f"child {ordinal} reports task {task_id!r} under output id "
                    f"{entry['output_id']!r}, not the roster's "
                    f"{output_by_task[task_id]!r}"
                )
            if task_id in answered:
                pb._fail(
                    f"task {task_id!r} is answered by child {answered[task_id]} "
                    f"and again by child {ordinal}"
                )
            answered[task_id] = ordinal
        missing = [task_id for task_id in batch if task_id not in answered]
        if missing:
            pb._fail(
                f"child {ordinal} left {len(missing)} of its {len(batch)} tasks "
                f"unanswered, beginning with {missing[0]!r}"
            )
    unanswered = [task["id"] for task in roster_tasks if task["id"] not in answered]
    if unanswered:
        pb._fail(
            f"{len(unanswered)} roster tasks have no result, beginning with "
            f"{unanswered[0]!r}"
        )
    return {
        "schema": GROUP_RECEIPT_SCHEMA_V1,
        "parent_key": plan["parent_key"],
        "plan_key": plan["plan_key"],
        "task_count": len(roster_tasks),
        "child_count": len(partitions),
        "merged_result_sha256": canonical_sha256([
            [entry["task_id"], entry["output_id"], entry["value_sha256"]]
            for ordinal in range(len(partitions))
            for entry in by_ordinal[ordinal]["results"]
        ]),
    }
