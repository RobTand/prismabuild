"""One prelaunch-resident pass per tier over live declared units (#1594).

The tier loop drives these functions once per tier per cycle. They turn
live declared consumers into reservation units, reserve one atomic group
per unit, bind published chunks to their movers, and release what no live
unit owns. Each function takes the queue, plain values or a snapshot.
No function imports the tier loop.
"""
from __future__ import annotations

from prismabuild import funding

import json
import math
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Mapping, Sequence



from prismabuild import pool  # noqa: E402
from prismabuild import prelaunch_group  # noqa: E402
from prismabuild import residency_plan  # noqa: E402
from prismabuild import window_credit  # noqa: E402
from prismabuild import tier_holdings

__all__ = [
    "Unit",
    "declared_units",
    "reserve_pass",
    "intent_chunks",
    "publish_declared",
    "obligations",
    "is_admitted",
    "declared_leg_keys",
    "is_prelaunch_leg",
    "dangling",
    "release_terminal",
]

#: A gang group that names more than one tier reserves on none of them.
UNSUPPORTED_MULTI_TIER = "multi-tier"


@dataclass
class Unit:
    """One prelaunch reservation unit: a consumer or one gang group."""

    #: The representative consumer action key, the first member's.
    key: str = ""
    #: Every member consumer key, in queue read order.
    keys: list[str] = field(default_factory=list)
    #: The consumer key, or the gang group id for a merged unit.
    unit: str = ""
    #: The one stage tier this unit reserves on.
    tier_id: str = ""
    #: The deterministic group holder for this unit and tier.
    holder: str = ""
    #: The representative filed plan, the first member's.
    plan: dict = field(default_factory=dict)
    #: The declared prelaunch phase names, in plan order.
    phase_names: list[str] = field(default_factory=list)
    #: The retained prefix tokens still to reserve.
    demand_gib: int = 0
    #: The retained prefix plus the largest suffix overlap.
    peak_gib: int = 0
    #: The declared stage legs in read order, with their plan rows.
    legs: list[dict] = field(default_factory=list)
    #: Each member key with its ready or claimed state.
    consumer_state: dict = field(default_factory=dict)
    #: The representative member's priority, for the unit order.
    priority: int = 0
    #: The representative member's publish time, for the unit order.
    published_unix: float = 0.0
    #: Where this unit's group receipts live.
    receipt_dir: Path | None = None
    #: Why this unit reserves nothing, or None when it reserves.
    unsupported: str | None = None


def _unit_member(queue, tiers, consumer) -> dict | None:
    """One consumer's declared plan and rank, or None with no claim."""
    if not isinstance(consumer, Mapping):
        return None
    key = consumer.get("action_key")
    if not isinstance(key, str) or not key:
        return None
    names = residency_plan.filed_prelaunch_phases(queue, key)
    if not names:
        return None
    plan, _ = residency_plan.read_filed(queue, key)
    if not isinstance(plan, Mapping):
        return None
    tier_id = plan.get("tier_id")
    record = tiers.get(tier_id) if isinstance(tiers, Mapping) else None
    if not isinstance(record, Mapping) or str(record.get("tier")) != "stage":
        return None
    item = consumer.get("item")
    group = None
    if isinstance(item, Mapping):
        gang = item.get("gang")
        if isinstance(gang, Mapping):
            group = gang.get("group")
    unit = group if isinstance(group, str) and group else key
    return {"key": key, "unit": unit, "tier_id": str(tier_id),
            "plan": dict(plan), "phase_names": [str(name) for name in names],
            "state": consumer.get("state"), "item": item}


def _leg_rows(phase: Mapping[str, object], mover_key: str) -> tuple:
    """One leg's mover and egress rows, chunked or whole."""
    chunks = phase.get("stage_chunks")
    if isinstance(chunks, list):
        for chunk in chunks:
            if not isinstance(chunk, Mapping):
                continue
            mover_row = chunk.get("mover_row")
            if (isinstance(mover_row, Mapping)
                    and str(mover_row.get("action_key")) == mover_key):
                return (mover_row, chunk.get("egress_row"))
    return (phase.get("mover_row"), phase.get("egress_row"))


def _declared_legs(plan: Mapping[str, object]) -> list[dict]:
    """The declared stage legs in read order, with their plan rows."""
    legs = []
    phases = plan.get("phases")
    if not isinstance(phases, list):
        return legs
    for phase in phases:
        if not isinstance(phase, Mapping):
            continue
        if phase.get("resident_before_launch") is not True:
            continue
        for leg in residency_plan.prelaunch_stage_legs(phase):
            mover_row, egress_row = _leg_rows(phase, leg["mover_key"])
            legs.append({**leg, "mover_row": mover_row,
                         "egress_row": egress_row})
    return legs


def _mover_live(queue, mover_key: str) -> bool:
    """True when one mover row stands ready or claimed now."""
    try:
        return (bool(
            pool.record_store.value_or_raise(
                queue.records.item_presence(pool.record_store.READY, mover_key),
            ),
        )
                or bool(
                    pool.record_store.value_or_raise(
                        queue.records.item_presence(pool.record_store.CLAIMED, mover_key),
                    ),
                ))
    except OSError:
        return False


def _owned_by_others(queue, mover_keys: Sequence[str]) -> frozenset:
    """Declared leg movers whose range a live shared mover already owns.

    The check reads the shared registry through
    ``share_namespace_of`` (which parses the mover index beside the
    registry) and ``read_shared_range`` (which names the registered
    mover). A leg counts owned only when the registered mover stands
    live. A leg the registry cannot answer counts unowned, so the
    runtime peak never drops below what the evidence proves. No
    registry means no sharing, so the set stays empty.
    """
    try:
        if not residency_plan.shared_ranges_present(queue):
            return frozenset()
    except OSError:
        return frozenset()
    owned: set[str] = set()
    for mover_key in set(mover_keys):
        try:
            namespace = residency_plan.share_namespace_of(queue, mover_key)
        except (OSError, ValueError, pool.PoolContractError,
                residency_plan.ResidencyPlanError):
            continue
        if namespace is None:
            continue
        try:
            record = residency_plan.read_shared_range(queue, namespace)
        except (OSError, ValueError, pool.PoolContractError,
                residency_plan.ResidencyPlanError):
            continue
        if not isinstance(record, Mapping):
            continue
        shared = record.get("mover_action_key")
        # A leg whose registered owner is its own mover is not owned by
        # others: the unit's demand must not drop when it publishes.
        if (isinstance(shared, str) and shared and shared != mover_key
                and _mover_live(queue, shared)):
            owned.add(mover_key)
    return frozenset(owned)


def _union(entries: Sequence[dict], owned: frozenset,
           ) -> tuple[list[dict], int, int]:
    """Merged legs and peak over members; shared ranges count once.

    The merge follows ``gang_prelaunch_demand``: legs deduplicate by
    share namespace, and the suffix step sums one adjacent-pair peak
    per member. Legs a live shared mover owns never count, so the
    runtime peak stays under the submission peak.
    """
    seen: set[str] = set()
    legs: list[dict] = []
    retained = 0
    step = 0
    for entry in entries:
        plan = entry["plan"]
        member_tier = entry["tier_id"]
        manifest = str(plan.get("manifest_sha256") or "")
        kept: list[dict] = []
        for leg in _declared_legs(plan):
            if leg["mover_key"] in owned:
                continue
            namespace = residency_plan.share_namespace(
                manifest, member_tier, int(leg["start_bytes"]),
                int(leg["end_bytes"]))
            if namespace in seen:
                continue
            seen.add(namespace)
            kept.append(leg)
            legs.append(leg)
        retained += sum(int(leg["stage_gib"]) for leg in kept)
        suffix_sizes: list[int] = []
        phases = plan.get("phases")
        if isinstance(phases, list):
            for phase in phases:
                if (not isinstance(phase, Mapping)
                        or phase.get("resident_before_launch") is True):
                    continue
                size = 0
                for leg in residency_plan.prelaunch_stage_legs(phase):
                    if leg["mover_key"] in owned:
                        continue
                    namespace = residency_plan.share_namespace(
                        manifest, member_tier, int(leg["start_bytes"]),
                        int(leg["end_bytes"]))
                    if namespace in seen:
                        continue
                    seen.add(namespace)
                    size += int(leg["stage_gib"])
                suffix_sizes.append(size)
        step += residency_plan.prelaunch_peak_gib([], suffix_sizes)[
            "suffix_gib"]
    return (legs, retained, retained + step)


def _rank(item: object) -> tuple[int, float]:
    """One member's priority and publish time, defaulted, finite."""
    priority = 0
    published = 0.0
    if isinstance(item, Mapping):
        try:
            priority = int(item.get("priority", 0))  # type: ignore[arg-type]
        except (TypeError, ValueError):
            priority = 0
        try:
            published = float(item.get("published_unix", 0.0))  # type: ignore[arg-type]
        except (TypeError, ValueError):
            published = 0.0
    if not math.isfinite(published):
        published = 0.0
    return (priority, published)


def _hold_filed(queue, unit_id: str, tier_id: str, entries: Sequence[dict],
                legs: list[dict], demand: int, peak: int,
                ) -> tuple[list[dict], int, int]:
    """The legs and demand a group's standing intent already names.

    A filed intent is immutable and the ledger counts it, so a later cycle
    must not rebuild a different demand from evidence that has moved: a
    shared mover that went live, a range that landed.  With no readable
    intent, or one this plan cannot rebuild, the computed values stand.
    """
    standing = prelaunch_group.standing_intent(queue, unit_id, tier_id)
    if standing is None:
        return legs, demand, peak
    try:
        filed = int(standing["demand_gib"])
        movers = [str(chunk["mover_action_key"])
                  for chunk in standing["chunks"]]
    except (KeyError, TypeError, ValueError):
        return legs, demand, peak
    wanted = set(movers)
    kept = [leg for leg in _union(entries, frozenset())[0]
            if leg["mover_key"] in wanted]
    if [leg["mover_key"] for leg in kept] != movers:
        return legs, demand, peak
    return kept, filed, max(int(peak), filed)


def _merge(queue, unit_id: str, entries: Sequence[dict],
           owned: frozenset) -> Unit:
    """One unit from its member consumers, merged on a gang group."""
    first = entries[0]
    tier_id = first["tier_id"]
    unsupported = (None if all(entry["tier_id"] == tier_id for entry in entries)
                   else UNSUPPORTED_MULTI_TIER)
    phase_names = list(first["phase_names"])
    holder = prelaunch_group.holder_name(unit_id, tier_id, phase_names)
    if len(entries) == 1 and unit_id == first["key"]:
        legs = _declared_legs(first["plan"])
        bound = residency_plan.prelaunch_bound(first["plan"], owned)
        assert bound is not None
        demand, peak = bound["retained_gib"], bound["peak_gib"]
    else:
        legs, demand, peak = _union(entries, owned)
    legs, demand, peak = _hold_filed(queue, unit_id, tier_id, entries, legs,
                                     demand, peak)
    priority, published = _rank(first["item"])
    return Unit(
        key=first["key"], keys=[entry["key"] for entry in entries],
        unit=unit_id, tier_id=tier_id, holder=holder, plan=first["plan"],
        phase_names=phase_names, demand_gib=int(demand),
        peak_gib=int(peak), legs=legs,
        consumer_state={entry["key"]: entry["state"] for entry in entries},
        priority=priority, published_unix=published,
        receipt_dir=prelaunch_group.group_dir(queue, unit_id, tier_id),
        unsupported=unsupported)


def declared_units(queue, tiers, consumers) -> list[Unit]:
    """The live declared consumers as reservation units, best-ranked first.

    A consumer joins when its filed plan declares a prefix and names a
    stage tier in ``tiers``. Members of one gang group merge into one
    unit with the union of their legs. A group across tiers keeps one
    tier and returns ``unsupported`` as ``multi-tier``. Units sort by
    priority, then publish time, then unit id.
    """
    members: dict[str, list[dict]] = {}
    for consumer in consumers or []:
        entry = _unit_member(queue, tiers, consumer)
        if entry is None:
            continue
        members.setdefault(entry["unit"], []).append(entry)
    if not members:
        return []
    owned = _owned_by_others(
        queue, [leg["mover_key"] for entries in members.values()
                for entry in entries
                for leg in _declared_legs(entry["plan"])])
    units = [_merge(queue, unit_id, entries, owned)
             for unit_id, entries in members.items()]
    units.sort(key=lambda found: (-found.priority, found.published_unix,
                                  found.unit))
    return units


def intent_chunks(unit: Unit) -> list[dict]:
    """The write-ahead chunk entries for one unit's declared legs."""
    digest = residency_plan.plan_sha256(unit.plan)
    consumer = str(unit.plan.get("consumer_action_key"))
    return [{"mover_action_key": leg["mover_key"],
             "start_bytes": int(leg["start_bytes"]),
             "end_bytes": int(leg["end_bytes"]),
             "stage_gib": int(leg["stage_gib"]),
             "plan_sha256": digest, "consumer_action_key": consumer}
            for leg in unit.legs]


def _intent_chunks(unit: Unit) -> list[dict]:
    """The write-ahead chunk entries for one unit's declared legs."""
    return intent_chunks(unit)


def _unit_event(unit: Unit, tier_id: str, name: str, **fields) -> dict:
    """One tier-loop event naming the unit it belongs to."""
    event = {"event": name, "unit": unit.unit, "consumer": unit.key,
             "tier_id": tier_id}
    event.update(fields)
    return event


def reserve_pass(queue, tier_id: str, units: Sequence[Unit], *, admitted,
                 writer_is_me: bool = True) -> tuple[list[dict], dict]:
    """File each unit's intent, then reconcile the admitted ones.

    ``admitted`` is the caller's gate: it takes a unit and answers true
    when the unit may reserve now. A unit the gate refuses still files
    its intent, then waits with no ledger change unless it already
    holds tokens or receipts. Units on another tier and unsupported
    units stay untouched. Returns the events with the authority map.
    """
    events: list[dict] = []
    authority: dict[str, bool] = {}
    for unit in units or []:
        if unit.tier_id != tier_id or unit.unsupported is not None:
            continue
        movers = [leg["mover_key"] for leg in unit.legs]
        prelaunch_group.file_intent(queue, unit.unit, unit.holder, tier_id,
                                    unit.demand_gib, _intent_chunks(unit))
        if not admitted(unit) and not prelaunch_group.has_holdings(
                queue, unit.unit):
            events.append(_unit_event(unit, tier_id, "prelaunch-waiting"))
            authority[unit.unit] = False
            continue
        outcome = prelaunch_group.reconcile(
            queue, tier_id, unit.unit, unit.holder, unit.demand_gib, movers,
            writer_is_me=writer_is_me)
        if (outcome.decline_reason is not None
                and outcome.need_gib is not None
                and "prelaunch-begin-declined" in outcome.events):
            prelaunch_group.record_decline(
                queue, unit.unit, tier_id, outcome.need_gib,
                outcome.decline_reason)
        for name in outcome.events:
            fields: dict = {"state": outcome.state}
            if outcome.need_gib is not None and name in (
                    "prelaunch-group-begun", "prelaunch-begin-declined",
                    "prelaunch-group-topped-up"):
                fields["need_gib"] = outcome.need_gib
            if (outcome.decline_reason is not None and name in (
                    "prelaunch-begin-declined",)):
                fields["reason"] = outcome.decline_reason
                fields["declined"] = bool(outcome.declined)
            events.append(_unit_event(unit, tier_id, name, **fields))
        authority[unit.unit] = bool(outcome.authority)
    return (events, authority)

def _live_mover_row(queue, mover_key: str) -> tuple[dict | None, bool]:
    """One published mover row, preferring ready over claimed."""
    observation = queue.records.bindable_mover(mover_key)
    if isinstance(observation, pool.record_store.Unknown):
        return None, True
    return pool.record_store.value_or_raise(observation), False


def publish_declared(queue, tier_id: str, unit: Unit,
                     publish_rows: Sequence[Mapping[str, object]]) -> list[dict]:
    """Bind the group fence behind the rows the window just published.

    ``publish_rows`` names the window rows to fund this pass. Each
    named leg whose mover row stands calls ``publish_chunk`` with the
    row's own publish time. A leg with no row yet skips with no error.
    Returns one event per chunk handoff.
    """
    wanted: set[str] = set()
    for row in publish_rows or []:
        if isinstance(row, Mapping):
            mover = row.get("mover_action_key")
            if isinstance(mover, str) and mover:
                wanted.add(mover)
    events: list[dict] = []
    for leg in unit.legs:
        mover = leg["mover_key"]
        if mover not in wanted:
            continue
        row, unreadable = _live_mover_row(queue, mover)
        if unreadable:
            events.append(_unit_event(unit, tier_id,
                                      "prelaunch-unknown-evidence",
                                      mover=mover))
            continue
        if row is None:
            continue
        try:
            published = float(row.get("published_unix"))  # type: ignore[arg-type]
        except (TypeError, ValueError):
            events.append(_unit_event(unit, tier_id,
                                      "prelaunch-unknown-evidence",
                                      mover=mover))
            continue
        funding = {"mover_action_key": mover,
                   "start_bytes": int(leg["start_bytes"]),
                   "end_bytes": int(leg["end_bytes"]),
                   "stage_gib": int(leg["stage_gib"])}
        outcome = queue.funding.bind_chunk(
             tier_id, unit.unit, unit.holder, unit.plan, funding,
            published)
        for name in outcome.events:
            events.append(_unit_event(unit, tier_id, name, mover=mover,
                                      status=outcome.status,
                                      moved=outcome.moved))
    return events


def _held_count(held: Mapping[str, Mapping[str, int]], holder: str,
                kind: str) -> int:
    """Tokens one holder owns of one kind, or zero when unknown."""
    per_kind = held.get(holder) if isinstance(held, Mapping) else None
    if not isinstance(per_kind, Mapping):
        return 0
    try:
        return max(0, int(per_kind.get(kind, 0)))  # type: ignore[arg-type]
    except (TypeError, ValueError):
        return 0


def obligations(units: Sequence[Unit], held: Mapping[str, Mapping[str, int]],
                kind: str) -> tuple[dict[str, int], dict[str, dict]]:
    """The admitted declared windows' peak obligations per tier.

    A unit obliges when its holder or one of its leg movers owns
    tokens now, or its committed receipt stands: its peak minus all it
    owns, never below zero. A committed unit that lost every token
    still obliges its whole peak while its group recovers (#1637).
    Units that own nothing and never committed oblige nothing yet.
    Returns the per-tier sums with one detail record per obliging unit
    for the logs.
    """
    totals: dict[str, int] = {}
    detail: dict[str, dict] = {}
    for unit in units or []:
        if unit.unsupported is not None:
            continue
        owns_holder = _held_count(held, unit.holder, kind) > 0
        owns_chunk = any(_held_count(held, leg["mover_key"], kind) > 0
                         for leg in unit.legs)
        if not owns_holder and not owns_chunk and not _committed(unit):
            continue
        owned = residency_plan.prelaunch_owned_gib(unit.plan, held,
                                                   unit.holder, kind)
        due = window_credit.prelaunch_obligation_gib(unit.peak_gib, owned)
        totals[unit.tier_id] = totals.get(unit.tier_id, 0) + due
        detail[unit.unit] = {"unit": unit.unit, "consumer": unit.key,
                             "tier_id": unit.tier_id, "holder": unit.holder,
                             "peak_gib": unit.peak_gib, "owned_gib": owned,
                             "obligation_gib": due}
    return (totals, detail)


def _committed(unit: Unit) -> bool:
    """True when the unit's committed receipt stands and names its holder."""
    if unit.receipt_dir is None:
        return False
    try:
        raw = (unit.receipt_dir / "committed.json").read_bytes()
    except OSError:
        return False
    try:
        body = json.loads(raw)
    except ValueError:
        return False
    return isinstance(body, Mapping) and str(body.get("holder")) == unit.holder


def is_admitted(unit: Unit, held: Mapping[str, Mapping[str, int]], kind: str,
                published_movers: Sequence[str]) -> bool:
    """True when one unit is no newcomer: it holds tokens, it published
    a chunk, or its committed receipt stands.
    """
    if _held_count(held, unit.holder, kind) > 0:
        return True
    published = set(published_movers or [])
    if any(leg["mover_key"] in published for leg in unit.legs):
        return True
    return _committed(unit)


def declared_leg_keys(units: Sequence[Unit]) -> frozenset:
    """Every declared leg mover key of every live unit, for retention.

    The eviction paths spare these movers: a live declared prefix
    stays resident to its consumer's end.
    """
    return frozenset(leg["mover_key"] for unit in units or []
                     for leg in unit.legs)


def is_prelaunch_leg(leg_keys: frozenset, mover_key: str) -> bool:
    """True when one mover belongs to a live declared prefix."""
    return mover_key in leg_keys


def _intent_for_holder(queue, holder: str) -> tuple[dict | None, str]:
    """The receipt naming one holder: unit, tier and movers, or a reason.

    The holder name carries digests only, so the mapping comes from the
    receipt directory whose intent names it.
    """
    try:
        entries = list((queue.root / prelaunch_group.GROUP_DIR).iterdir())
    except FileNotFoundError:
        return (None, "no group receipts stand")
    except OSError as exc:
        return (None, f"receipt census unreadable: {exc!r}")
    for entry in entries:
        if not entry.is_dir():
            continue
        try:
            raw = (entry / "intent.json").read_bytes()
        except OSError:
            continue
        try:
            record = json.loads(raw)
        except ValueError:
            continue
        if (not isinstance(record, Mapping)
                or str(record.get("holder")) != holder):
            continue
        try:
            unit = str(record["unit"])  # type: ignore[index]
            tier_id = str(record["tier_id"])  # type: ignore[index]
            chunks = record["chunks"]  # type: ignore[index]
            if not isinstance(chunks, list):
                raise ValueError("intent chunks must be a list")
            movers = [str(entry["mover_action_key"])  # type: ignore[index]
                      for entry in chunks]
            if not unit or not tier_id or not all(movers):
                raise ValueError("intent names nobody")
        except (KeyError, TypeError, ValueError):
            return (None, "intent names no usable unit")
        return ({"unit": unit, "tier_id": tier_id, "movers": movers}, "")
    return (None, "no intent names this holder")


def _shared_fences(queue, movers: Sequence[str]) -> set[str]:
    """Bound movers a co-owner may still need, kept past this unit's end.

    A mover with a share namespace stays with the mover settlement.
    A namespace that will not read also stays: unreadable evidence
    retains.
    """
    try:
        if not residency_plan.shared_ranges_present(queue):
            return set()
    except OSError:
        return set(movers)
    shared: set[str] = set()
    for mover in movers:
        try:
            namespace = residency_plan.share_namespace_of(queue, mover)
        except (OSError, ValueError, pool.PoolContractError,
                residency_plan.ResidencyPlanError):
            shared.add(mover)
            continue
        if namespace is not None:
            shared.add(mover)
    return shared


def dangling(queue, tier_id: str, ledger: tier_holdings.TierLedger, live_units: Sequence[Unit], *,
             complete_census: bool) -> list[dict]:
    """Release group holders no live unit owns on one tier.

    Without a complete census this pass releases nothing and files
    nothing. Else every ``prelaunch-`` holder that names no live
    unit's holder releases through ``release_unit``, unless its unit
    still lives or its evidence will not read.
    """
    if not complete_census:
        return []
    live = list(live_units or [])
    live_holders = {unit.holder for unit in live
                    if unit.tier_id == tier_id}
    live_ids = {unit.unit for unit in live}
    try:
        names = ledger.holders()
    except (OSError, ValueError, pool.PoolContractError) as exc:
        return [{"event": "prelaunch-dangling-retained", "unit": None,
                 "consumer": None, "holder": None, "tier_id": tier_id,
                 "reason": f"tier ledger census unreadable: {exc!r}"}]
    events: list[dict] = []
    for name in sorted(str(holder) for holder in names):
        if (not name.startswith(prelaunch_group.HOLDER_PREFIX)
                or name in live_holders):
            continue
        info, reason = _intent_for_holder(queue, name)
        if info is None:
            events.append({"event": "prelaunch-dangling-retained",
                           "unit": None, "consumer": None, "holder": name,
                           "tier_id": tier_id, "reason": reason})
            continue
        if info["unit"] in live_ids or info["tier_id"] != tier_id:
            events.append({"event": "prelaunch-dangling-retained",
                           "unit": info["unit"], "consumer": info["unit"],
                           "holder": name, "tier_id": tier_id,
                           "reason": "unit still lives"})
            continue
        inner = prelaunch_group.release_unit(
            queue, tier_id, info["unit"], name, info["movers"],
            terminal=True, shared_owned=_shared_fences(queue, info["movers"]))
        events.append({"event": "prelaunch-dangling-released",
                       "unit": info["unit"], "consumer": info["unit"],
                       "holder": name, "tier_id": tier_id, "events": inner})
    return events


def release_terminal(queue, tier_id: str, units_ended: Sequence[Unit], *,
                     shared_owned: Sequence[str] = frozenset()) -> list[dict]:
    """Release every ended unit's unsplit remainder and unconsumed fences.

    A bound mover whose copy still runs keeps its charge, and a fence a
    co-owner still needs stays with the mover. Unsupported units own
    nothing and stay untouched.
    """
    shared = {str(key) for key in shared_owned or []}
    events: list[dict] = []
    for unit in units_ended or []:
        if unit.unsupported is not None:
            continue
        movers = [leg["mover_key"] for leg in unit.legs]
        inner = prelaunch_group.release_unit(
            queue, tier_id, unit.unit, unit.holder, movers, terminal=True,
            shared_owned=shared)
        for name in inner:
            events.append(_unit_event(unit, tier_id, name))
    return events
