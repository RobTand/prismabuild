"""Whole-directory resident sets, distinct from rolling residency windows.

The immutable body names bytes. The lease journal is append-only. Mutable
copy records describe each host, never an action admission requirement.
"""
from __future__ import annotations

from collections.abc import Mapping
import json
import math
import os
from pathlib import Path
import re
import stat
import tempfile
import time

from . import core, posix_lock
from . import data_manifest as manifest_codec
from . import immutable_files

SET_SCHEMA = "prismabuild.resident_set.v1"
COPY_SCHEMA = "prismabuild.resident_copy.v1"
MOVEMENT_SCHEMA = "prismabuild.resident_movements.v1"
POLICY_SCHEMA = "prismabuild.local_tier_policy.v1"
DEFAULT_RENEWAL_CEILING_S = 14 * 24 * 60 * 60
COPY_STATES = frozenset({"absent", "copying", "resident", "evicting"})


def _resident_name(value, where):
    if not isinstance(value, str) or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", value):
        raise ValueError(f"{where} must be a safe nonempty name")
    return value


def _set_id(value):
    if not isinstance(value, str) or not re.fullmatch(r"[0-9a-f]{64}", value):
        raise ValueError("set_id must be a sha256 digest")
    return value



def fsync_directory(path):
    fd = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(fd)
    finally:
        os.close(fd)


def write_record(path, value):
    """Durable replace for mutable records; never used for the set body."""
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix="." + path.name, dir=path.parent)
    try:
        with os.fdopen(fd, "wb") as stream:
            stream.write(core.compact_ascii_json_bytes(value) + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(tmp, path)
        fsync_directory(path.parent)
    finally:
        Path(tmp).unlink(missing_ok=True)


def validate_lease(value, *, now):
    if not isinstance(value, Mapping) or set(value) not in ({"until", "hard_max"}, {"campaign", "hard_max"}):
        raise ValueError("lease requires until or campaign and hard_max")
    maximum = value["hard_max"]
    if type(maximum) not in (int, float) or not math.isfinite(maximum) or maximum <= now:
        raise ValueError("lease hard_max must be a finite future timestamp")
    out = dict(value)
    if "until" in out:
        until = out["until"]
        if type(until) not in (int, float) or not math.isfinite(until) or not now < until <= maximum:
            raise ValueError("lease until must be in the future and no later than hard_max")
    else:
        _resident_name(out["campaign"], "campaign")
    return out


def directory_files(root):
    """Names and sizes without hashing; symlinks and special files are unsafe."""
    root = Path(root)
    if not root.is_absolute() or root.is_symlink() or not root.is_dir():
        raise ValueError("canonical_root must be an absolute regular directory")
    found = {}
    def walk(directory):
        with os.scandir(directory) as entries:
            for entry in entries:
                info = entry.stat(follow_symlinks=False)
                if stat.S_ISDIR(info.st_mode):
                    walk(Path(entry.path))
                elif stat.S_ISREG(info.st_mode):
                    found[str(Path(entry.path).relative_to(root))] = info.st_size
                else:
                    raise ValueError(f"directory contains symlink or special file: {entry.path}")
    walk(root)
    return found


def validate_set_manifest(manifest, canonical_root):
    normalized = manifest_codec.validate_data_manifest(manifest)
    root = Path(canonical_root)
    if not root.is_absolute() or str(root) != canonical_root or root == Path("/"):
        raise ValueError("canonical_root must be a normalized absolute directory")
    wanted = {}
    for entry in normalized["entries"]:
        path = Path(entry["path"])
        if not path.is_relative_to(root) or path == root:
            raise ValueError("manifest path is outside canonical_root")
        relative = str(path.relative_to(root))
        if relative in wanted or entry["offset"] != 0:
            raise ValueError("resident set requires one whole-file entry per path")
        if entry["sha256"] is None:
            raise ValueError("resident set requires real sha256 on every entry")
        wanted[relative] = entry["bytes"]
    if directory_files(root) != wanted:
        raise ValueError("manifest must cover the whole canonical directory with matching sizes")
    return normalized


def _renewal_ceiling(value):
    if type(value) not in (int, float) or not math.isfinite(value) or value <= 0:
        raise ValueError("renewal_ceiling_s must be a positive finite ceiling")
    return value



def read_policy(path):
    policy = json.loads(Path(path).read_text())
    if not isinstance(policy, dict) or set(policy) not in ({"schema", "hosts"}, {"schema", "hosts", "renewal_ceiling_s"}) or policy["schema"] != POLICY_SCHEMA or not isinstance(policy["hosts"], dict):
        raise ValueError("invalid local_tier_policy")
    policy["renewal_ceiling_s"] = _renewal_ceiling(policy.get("renewal_ceiling_s", DEFAULT_RENEWAL_CEILING_S))
    for host, spec in policy["hosts"].items():
        _resident_name(host, "host")
        if not isinstance(spec, dict) or set(spec) != {"root", "maximum_gib", "floor_fraction", "docker_allowance_gib"}:
            raise ValueError("local tier host policy requires root, maximum, floor and docker allowance")
        if not isinstance(spec["root"], str) or not Path(spec["root"]).is_absolute() or Path(spec["root"]) == Path("/"):
            raise ValueError("local tier root must be an absolute non-root directory")
        for key in ("maximum_gib", "docker_allowance_gib", "floor_fraction"):
            if type(spec[key]) not in (int, float) or not math.isfinite(spec[key]) or spec[key] < 0:
                raise ValueError(f"invalid local tier {key}")
        if not .05 <= spec["floor_fraction"] < 1:
            raise ValueError("local tier floor_fraction must preserve at least five percent")
    return policy


class ResidentSets:
    def __init__(self, queue_root):
        self.queue_root = Path(queue_root)
        self.root = self.queue_root / "resident-sets"

    def set_path(self, set_id):
        return self.root / _set_id(set_id) / "body.json"

    def copy_path(self, set_id, host):
        return self.set_path(set_id).parent / "copies" / (_resident_name(host, "host") + ".json")

    def movement_path(self, set_id, host):
        return self.set_path(set_id).parent / "movements" / (_resident_name(host, "host") + ".json")

    def read_movements(self, set_id, host):
        try:
            record = json.loads(self.movement_path(set_id, host).read_text())
        except FileNotFoundError:
            return {}
        if (not isinstance(record, dict) or record.get("schema") != MOVEMENT_SCHEMA
                or record.get("set_id") != set_id or record.get("host") != host
                or not isinstance(record.get("rows"), dict)):
            raise ValueError("invalid resident movement descriptor record")
        rows = record["rows"]
        if set(rows) - {"copy", "evict", "adopt"} or any(not isinstance(row, dict) for row in rows.values()):
            raise ValueError("invalid resident movement descriptor rows")
        return rows

    def update_movements(self, set_id, host, rows):
        """Merge operator descriptors without reading or writing mover state."""
        if (not isinstance(rows, Mapping) or set(rows) - {"copy", "evict", "adopt"}
                or any(not isinstance(row, Mapping) for row in rows.values())):
            raise ValueError("invalid resident movement descriptor rows")
        with self.lock(set_id):
            if host not in self.read(set_id)["hosts"]:
                raise ValueError("host is not declared by resident set")
            merged = self.read_movements(set_id, host)
            merged.update({operation: dict(row) for operation, row in rows.items()})
            write_record(self.movement_path(set_id, host), {"schema": MOVEMENT_SCHEMA,
                "set_id": set_id, "host": host, "rows": merged})
        return merged

    def read_lease_log(self, set_id):
        path = self.set_path(set_id).parent / "lease.jsonl"
        return [json.loads(line) for line in path.read_text().splitlines()]

    def effective_lease(self, set_id):
        """Return (lease, released) after validating and folding the journal."""
        lease = None
        released = False
        for event in self.read_lease_log(set_id):
            if not isinstance(event, dict) or event.get("manifest_sha256") != set_id:
                raise ValueError("lease journal manifest disagrees")
            kind = event.get("event")
            if kind not in ("published", "renewed", "released"):
                raise ValueError("invalid lease journal event")
            unix = event.get("unix")
            if type(unix) not in (int, float) or not math.isfinite(unix):
                raise ValueError("lease journal event requires a finite timestamp")
            if not isinstance(event.get("by"), str) or not event["by"].strip():
                raise ValueError("lease journal event requires by")
            if lease is None and kind != "published":
                raise ValueError("resident set has no published lease journal")
            if kind in ("published", "renewed"):
                lease = validate_lease(event.get("lease"), now=unix)
                if kind == "renewed":
                    ceiling = _renewal_ceiling(event.get("renewal_ceiling_s"))
                    if lease["hard_max"] > unix + ceiling:
                        raise ValueError("renewed hard_max exceeds the renewal policy ceiling")
                released = False
            else:
                released = True
        if lease is None:
            raise ValueError("resident set has no published lease journal")
        return lease, released


    def lock(self, set_id):
        return posix_lock.held(self.set_path(set_id).parent / ".record.lock")

    def read(self, set_id):
        record = json.loads(self.set_path(set_id).read_text())
        if record.get("schema") != SET_SCHEMA or record.get("set_id") != set_id or record.get("immutable") is not True:
            raise ValueError("invalid resident set body")
        if core.raw_sha256(core.compact_ascii_json_bytes(record["manifest"])) != set_id:
            raise ValueError("resident set manifest digest mismatch")
        return record

    def _append_lease(self, set_id, row):
        row = {**row, "manifest_sha256": set_id}
        path = self.set_path(set_id).parent / "lease.jsonl"
        with path.open("ab") as stream:
            stream.write(core.compact_ascii_json_bytes(row) + b"\n")
            stream.flush()
            os.fsync(stream.fileno())
        fsync_directory(path.parent)

    def publish(self, *, manifest, canonical_root, hosts, lease, created_by, now=None):
        now = time.time() if now is None else now
        manifest = validate_set_manifest(manifest, canonical_root)
        lease = validate_lease(lease, now=now)
        if not isinstance(hosts, list) or not hosts or len(set(hosts)) != len(hosts):
            raise ValueError("hosts must be a nonempty unique list")
        hosts = sorted(_resident_name(host, "host") for host in hosts)
        if not isinstance(created_by, str) or not created_by.strip():
            raise ValueError("created_by is required")
        set_id = core.raw_sha256(core.compact_ascii_json_bytes(manifest))
        record = {"schema": SET_SCHEMA, "set_id": set_id, "manifest": manifest,
                  "canonical_root": canonical_root, "hosts": hosts, "lease": lease,
                  "immutable": True, "created_by": created_by, "created_unix": now}
        with self.lock(set_id):
            path = self.set_path(set_id)
            if path.exists():
                existing = self.read(set_id)
                if any(existing[key] != record[key] for key in ("manifest", "canonical_root", "hosts")):
                    raise ValueError("resident set immutable body conflicts with publication")
                raise ValueError("resident set already published; its body cannot be rewritten")
            from . import local_tier, pool
            queue = pool.PoolQueue(self.queue_root)
            acquired = local_tier.reserve(queue, set_id, hosts, manifest["total_bytes"])
            try:
                immutable_files.publish_immutable(path, core.compact_ascii_json_bytes(record) + b"\n")
                self._append_lease(set_id, {"event": "published", "lease": lease, "unix": now, "by": created_by})
                for host in hosts:
                    self.write_copy(set_id, host, {"state": "absent", "local_root": None,
                        "verification": [], "bytes": 0, "completed_unix": None})
            except BaseException:
                # Once the immutable body exists, recovery owns its reservations.
                if not path.exists():
                    for ledger in acquired:
                        ledger.release(set_id)
                raise
        return record

    def write_copy(self, set_id, host, record):
        if record.get("state") not in COPY_STATES:
            raise ValueError("invalid resident copy state")
        if host not in self.read(set_id)["hosts"]:
            raise ValueError("host is not declared by resident set")
        write_record(self.copy_path(set_id, host), {**record, "schema": COPY_SCHEMA, "set_id": set_id, "host": host})

    def read_copy(self, set_id, host):
        record = json.loads(self.copy_path(set_id, host).read_text())
        if (record.get("schema") != COPY_SCHEMA or record.get("set_id") != set_id
                or record.get("host") != host or record.get("state") not in COPY_STATES):
            raise ValueError("invalid resident copy record")
        return record

    def status(self, set_id=None):
        if set_id is None:
            if not self.root.exists():
                return []
            return [self.status(path.name) for path in sorted(self.root.iterdir())
                    if path.is_dir() and (path / "body.json").exists()]
        record = self.read(set_id)
        record["lease_log"] = self.read_lease_log(set_id)
        record["copies"] = {host: self.read_copy(set_id, host) for host in record["hosts"]}
        record["movements"] = {host: self.read_movements(set_id, host) for host in record["hosts"]}
        return record

    def release(self, set_id, *, by, now=None):
        with self.lock(set_id):
            self.read(set_id)
            self._append_lease(set_id, {"event": "released", "unix": time.time() if now is None else now, "by": by})
        return self.status(set_id)

    def close_campaign(self, name, *, by, now=None):
        name = _resident_name(name, "campaign")
        if not isinstance(by, str) or not by.strip():
            raise ValueError("by is required")
        now = time.time() if now is None else now
        if type(now) not in (int, float) or not math.isfinite(now):
            raise ValueError("close timestamp must be finite")
        result = {"released": [], "errors": {}}
        try:
            directories = sorted(self.root.iterdir())
        except FileNotFoundError:
            return result
        for directory in directories:
            set_id = directory.name
            try:
                if not directory.is_dir():
                    continue
                with self.lock(set_id):
                    try:
                        self.read(set_id)
                    except FileNotFoundError:
                        continue
                    lease, released = self.effective_lease(set_id)
                    if not released and lease.get("campaign") == name:
                        self._append_lease(set_id, {"event": "released", "unix": now, "by": by})
                        result["released"].append(set_id)
            except Exception as error:
                result["errors"][set_id] = f"{type(error).__name__}: {error}"
        return result

    def renew(self, set_id, lease, *, by, now=None, renewal_ceiling_s=DEFAULT_RENEWAL_CEILING_S):
        now = time.time() if now is None else now
        lease = validate_lease(lease, now=now)
        ceiling = _renewal_ceiling(renewal_ceiling_s)
        if lease["hard_max"] > now + ceiling:
            raise ValueError("renewed hard_max exceeds the renewal policy ceiling")
        with self.lock(set_id):
            self.read(set_id)
            self._append_lease(set_id, {"event": "renewed", "lease": lease, "unix": now, "by": by, "renewal_ceiling_s": ceiling})
        return self.status(set_id)
