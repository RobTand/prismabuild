"""Host CPU admission from measured headroom and attributed action consumption.

CPU affinity tokens remain physical. A reservation may borrow an occupied CPU
only after fresh, complete attribution proves idle demand; memory/GPU tokens
are never discounted. The local lock serializes budget decisions, not queue
ownership (which still uses NFS rename).
"""
from __future__ import annotations
from prismabuild import output_contract as oc

from collections.abc import Callable
from contextlib import contextmanager
import contextlib
import fcntl
import hashlib
import json
import math
import os
from pathlib import Path
import socket
import stat
import statistics
import sys
import time
import uuid

from . import adaptive_snapshot
from . import flock_owner
from .holder_census import CPU_METADATA, HolderCensus
from .storage_tiers import RAM_HOST_MEMORY_PREFIX
from .control_cpu import attributed_ticks, boot_ticks, control_plane_counters

#: A CPU is treated as idle for admission corroboration when it was busy for
#: at most this fraction of the fresh sampling interval.  Small on purpose: a
#: pinned neighbour sits at ~1.0, so this separates "nobody ran here" from
#: "someone ran here", not "lightly used" from "heavily used".
IDLE_BUSY_FRACTION = .05

MAX_SAMPLE_AGE_S = 5.0
MIN_INTERVAL_S = 1.0
MAX_INTERVAL_S = 60.0
MAX_ACTIONS = 256
METADATA = CPU_METADATA
#: ``decision`` has not been told the item's :func:`dependent_owner`.
_UNREAD = object()


def read_json(path):
    try:
        value = json.loads(Path(path).read_text())
        return value if isinstance(value, dict) else {}
    except (OSError, ValueError):
        return {}


def write_json(path, value):
    from . import immutable_files
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    immutable_files.write_json_atomic(Path(path), value)


def action_identity(item):
    """Exact executable shape; variable inputs still distinguish unlike work.

    Action keys themselves include result names and therefore do not generalize
    over repetitions. Code, argv, environment, input dimensions and demand do.
    Unknown/custom launchers have no shape and may never borrow.
    """
    from . import core
    key = str(item['action_key'])
    path = Path(str(item['cas_root'])) / 'requests' / key[:2] / f'{key}.json'
    raw = read_json(path)
    # Remembered whatever it held, an unreadable request included, so the
    # #985 lookups that follow never read the same path a second time.
    _LAST_REQUEST[0] = (str(path), None)
    if not raw:
        return None, False
    try:
        action = core.validate_action(raw)
    except (ValueError, TypeError, KeyError):
        return None, False
    if action['action_key'] != key:
        return None, False
    _LAST_REQUEST[0] = (str(path), action)
    # Exclude only destination/provenance, never normalize arbitrary command
    # arguments or caller parameters into an unrelated workload.
    shape = {name: action.get(name) for name in ('task', 'code_closure', 'inputs', 'environment')}
    task = dict(shape['task'])
    task.pop('result_path', None)
    shape['task'] = task
    shape['resources'] = item.get('resources')
    shape['params'] = action.get('params')
    if task.get('definition_id') == 'fleet/pbrun':
        params = action.get('params', {})
        snapshot = params.get('checkout_snapshot', {})
        files = action.get('code_closure', {}).get('files', [])
        # pbrun's stamp CONTENT is the full checkout identity (including dirty
        # bytes). Its generated filename and bundle/result names include the
        # command's bookkeeping fingerprint, which is not workload shape.
        if (isinstance(params.get('command'), list) and files
                and snapshot.get('schema') == 'prismaquant.prismabuild.pbrun_checkout_snapshot.v2'
                and all(str(f.get('path', '')).startswith('.pbrun-closure.') for f in files)):
            environment = dict(action['environment'])
            environment['variables'] = {k: v for k, v in environment['variables'].items()
                                        if k not in ('PRISMABUILD_CONTAINER_OWNER',
                                                     'PRISMABUILD_CONTAINER_MARKER')}
            shape = {'task': {k: v for k, v in task.items() if k != 'argv'},
                     'command': params['command'], 'cwd': params.get('cwd'),
                     'resources': item.get('resources'), 'environment': environment,
                     'code': [{k: f[k] for k in ('sha256', 'bytes')} for f in files],
                     'inputs': [i for i in action['inputs'] if i['id'] != 'pbrun.checkout-snapshot'],
                     'params': {k: v for k, v in params.items()
                                if k not in ('command', 'cwd', 'checkout_snapshot')}}
    digest = hashlib.sha256(json.dumps(shape, sort_keys=True).encode()).hexdigest()
    return digest, task.get('task_class') == 'measurement'


def shape_key(item):
    return action_identity(item)[0]


#: A produced-output producer's export allowance (#985).  Every producer
#: whose sealed environment configures a local spool reserves, at claim and
#: with its own reservation, room for ``slots`` concurrent spool exports of
#: :data:`EXPORT_DEMAND` each.  Its exports are admitted against that
#: allowance, never the free pool: a foreign action cannot take the room, and
#: host pressure the producer creates on its own CPUs cannot refuse them.
#: Spelled here, the lowest layer, because ``produced_spool`` imports the pool.
SPOOL_ROOT_ENV = 'PRISMABUILD_PRODUCED_SPOOL_ROOT'
EXPORT_SLOTS_ENV = 'PRISMABUILD_PRODUCED_SPOOL_EXPORT_SLOTS'
#: What ``ProducedSpool.submit_group`` seals for one export.
EXPORT_DEMAND = {'cpu': 1, 'mem_gb': 1}
#: The slot count when nothing is measured yet (#999): one export at a time,
#: labelled ``unmeasured`` in the allowance.  Measured, the count is derived
#: by :func:`export_slots`; declared, ``EXPORT_SLOTS_ENV`` wins and
#: ``EXPORT_SLOTS_ENV=0`` opts out.
DEFAULT_EXPORT_SLOTS = 1
#: Measured export landings and group spacing per produced-output template
#: (#999), or per the family a template declares (#1126), host-local beside
#: ``profiles.json`` and learned the same way.
EXPORT_RATES = 'export-rates.json'
#: How many landings and gaps a key keeps: the memory ``profiles`` keeps of
#: completions.
EXPORT_RATE_MEMORY = 32
#: The prefix of a declared family's key in :data:`EXPORT_RATES` (#1126).
#: A template's key is its 64-hex digest, which cannot carry it, so no
#: template's entry and no family's are ever the same entry.
EXPORT_RATE_FAMILY_PREFIX = 'family:'


def export_rate_key(template_sha256, family=None):
    """The :data:`EXPORT_RATES` key a producer's exports learn and read under.

    ``family`` is the ``export_rate_family`` the producer's produced-output
    template declares (#1126): every template of a family shares its entry,
    ``family:<name>``, so a Stage B row -- its own template -- inherits what
    the family's earlier rows measured.  ``None`` means none is declared, and
    the key is the template's digest, as #999 keyed every producer.  A family
    that is not an identifier (``output_contract.validate_export_rate_family``)
    or, undeclared, a digest that is not a key has no key: nothing is learned
    or read under it, so no malformed value lands on another producer's entry.
    """
    if family is None:
        return template_sha256 if _is_key(template_sha256) else None
    try:
        return EXPORT_RATE_FAMILY_PREFIX + oc.validate_export_rate_family(family)
    except oc.ProducedOutputError:
        return None


def export_rate_names(ref):
    """``(template_sha256, family)`` a producer's ``produced_output`` reference
    names, or ``None`` when it declares a family that is not an identifier.

    ``PoolQueue.publish`` projects the reference from the validated template,
    and carries ``export_rate_family`` only when the template declares it
    (#1126); ``family`` is then ``None``.  A declared family the reader cannot
    use is refused rather than read as undeclared: falling back to the
    template would learn and size under a key the producer did not name.
    """
    if not isinstance(ref, dict):
        return None, None
    template = ref.get('template_sha256')
    if 'export_rate_family' not in ref:
        return template, None
    family = ref['export_rate_family']
    if not isinstance(family, str) or export_rate_key(template, family) is None:
        return None
    return template, family


def export_slots(rates, template_sha256, family=None):
    """``(slots, basis)`` for a producer of ``template_sha256`` (#999), or of
    the ``family`` its template declares (#1126).

    Little's law with both sides taken at their worst: exports in flight are
    at most the longest landing over the shortest group spacing, so
    ``slots = ceil(max landing_s / min spacing_s)``, never below one.  Both
    come from this host's own completed exports under the producer's
    :func:`export_rate_key` (:func:`learn_export`): the family's, whichever of
    its templates they were, or the template's own.  With either side
    unmeasured the count is :data:`DEFAULT_EXPORT_SLOTS` and the basis says
    ``unmeasured``; it names ``export_rate_family`` when one is declared.
    """
    key = export_rate_key(template_sha256, family)
    entry = rates.get(key) if isinstance(rates, dict) and key else None
    entry = entry if isinstance(entry, dict) else {}
    landings = [v for v in entry.get('landing_s', []) if type(v) in (int, float) and v > 0]
    gaps = [v for v in entry.get('spacing_s', []) if type(v) in (int, float) and v > 0]
    names = {'template_sha256': template_sha256}
    if family is not None:
        names['export_rate_family'] = family
    if not landings or not gaps:
        return DEFAULT_EXPORT_SLOTS, {'basis': 'unmeasured', **names,
                                      'landings': len(landings), 'spacings': len(gaps)}
    landing, spacing = max(landings), min(gaps)
    return max(1, math.ceil(landing / spacing)), {
        'basis': 'measured', 'rule': 'ceil(max landing_s / min spacing_s)',
        **names, 'landing_s': round(landing, 3),
        'spacing_s': round(spacing, 3), 'landings': len(landings), 'spacings': len(gaps)}


#: The last sealed request :func:`action_identity` read, as ``(path, action)``
#: (``action`` is ``None`` when it was unreadable).  The claim path reads each candidate's request once, for
#: its identity, and the #985 facts about the same candidate -- the producer an
#: export serves, a producer's allowance -- come from those bytes rather than a
#: second read.  A request is content-addressed, so a hit is never stale.
_LAST_REQUEST = [None]


def _sealed_request(item):
    """The item's validated sealed request, or ``None`` if unreadable."""
    from . import core
    try:
        key = str(item['action_key'])
        path = Path(str(item['cas_root'])) / 'requests' / key[:2] / f'{key}.json'
    except (KeyError, TypeError):
        return None
    last = _LAST_REQUEST[0]
    if last is not None and last[0] == str(path):
        return last[1]
    raw = read_json(path)
    if not raw:
        return None
    try:
        action = core.validate_action(raw)
    except (ValueError, TypeError, KeyError):
        return None
    return action if action['action_key'] == key else None


def _is_key(value):
    return (isinstance(value, str) and len(value) == 64
            and all(c in '0123456789abcdef' for c in value))


def dependent_owner(item):
    """The producer this item's sealed request says it serves, or ``None``.

    A producer's spool exports run on its host, and its progress is counted
    when they land (#982, #985).  ``produced_spool.ProducedSpool.submit_group``
    seals each export with ``params.produced_spool.owner``, the action key of
    the producer that owns the spool.  The key is content-addressed over the
    whole request, so the link is as trustworthy as the request itself.  Only
    a ``generation`` action can be a dependent: a measurement never runs beside
    another holder.  Anything unreadable is no link.
    """
    action = _sealed_request(item)
    if action is None or action['task'].get('task_class') != 'generation':
        return None
    link = action.get('params', {}).get('produced_spool')
    owner = link.get('owner') if isinstance(link, dict) else None
    return owner if _is_key(owner) else None


def producer_allowance(item, rates=None):
    """The export allowance this item's sealed environment declares, or ``None``.

    ``{'slots': k, 'cpu': k, 'mem_gb': k, 'basis': {...}}`` for a producer
    whose sealed environment names a spool root (#985), ``None`` for
    everything else, for ``EXPORT_SLOTS_ENV=0`` and for anything unreadable or
    malformed, a malformed ``export_rate_family`` included (#1126).  ``k`` is
    the sealed ``EXPORT_SLOTS_ENV`` when declared, else :func:`export_slots`
    over ``rates`` (the host's ``EXPORT_RATES``) for the row's produced-output
    template, or the family it declares; ``basis`` says which (#999).
    """
    action = _sealed_request(item)
    if action is None:
        return None
    variables = action.get('environment', {}).get('variables', {})
    if not isinstance(variables, dict) or not variables.get(SPOOL_ROOT_ENV):
        return None
    raw = variables.get(EXPORT_SLOTS_ENV)
    if raw is None:
        names = export_rate_names(item.get('produced_output') if isinstance(item, dict) else None)
        if names is None:
            return None
        template, family = names
        slots, basis = export_slots(rates, template if isinstance(template, str) else None,
                                    family)
    else:
        if not isinstance(raw, str) or not raw.isascii() or not raw.isdigit() or int(raw) <= 0:
            return None
        slots, basis = int(raw), {'basis': 'declared', 'env': EXPORT_SLOTS_ENV}
    return {'slots': slots, **{kind: need * slots for kind, need in EXPORT_DEMAND.items()},
            'basis': basis}


def counters(cpus):
    """Raw busy/total and observed IRQ jiffies; guest is included in user."""
    values = {}
    interrupts = {}
    try:
        for line in Path('/proc/stat').read_text().splitlines():
            fields = line.split()
            if not fields or not fields[0].startswith('cpu') or not fields[0][3:].isdigit():
                continue
            cpu = int(fields[0][3:])
            if cpu not in cpus:
                continue
            ticks = [int(x) for x in fields[1:9]]
            if len(ticks) != 8:
                return None
            total = sum(ticks)
            values[str(cpu)] = [total - ticks[3] - ticks[4], total]
            interrupts[str(cpu)] = [ticks[5], ticks[6]]
        # Only "some" exists for the CPU resource at the system level: the
        # kernel records FULL for CPU under a cgroup, never for psi_system
        # (kernel/sched/psi.c -- "the FULL state doesn't exist for the CPU
        # resource at the system level", and the state mask at the system
        # root omits PSI_CPU_FULL).  Reading it here would compare a value the
        # kernel never advances, so the pressure gate is corroborated with
        # occupancy instead.
        try:
            psi = next(line for line in Path('/proc/pressure/cpu').read_text().splitlines()
                       if line.startswith('some '))
        except StopIteration:
            return None
        pressure = int(dict(part.split('=') for part in psi.split()[1:])['total'])
    except (OSError, ValueError, StopIteration):
        return None
    if len(values) != len(cpus):
        return None
    return {'cpus': values, 'irq_cpus': interrupts,
            'psi_total': pressure, 'sampled_unix': time.time()}


def _irq_ticks(previous, current, busy):
    """Only complete, non-reset IRQ/softirq interval evidence earns credit."""
    result = dict.fromkeys(busy, 0)
    if (not isinstance(previous, dict) or not isinstance(current, dict)
            or set(previous) != set(busy) or set(current) != set(busy)):
        return result
    for cpu in busy:
        old, now = previous[cpu], current[cpu]
        if (not isinstance(old, (list, tuple)) or not isinstance(now, (list, tuple))
                or len(old) != 2 or len(now) != 2
                or any(type(value) is not int or value < 0 for value in (*old, *now))):
            continue
        deltas = [end - start for start, end in zip(old, now)]
        if all(value >= 0 for value in deltas) and sum(deltas) <= busy[cpu]:
            result[cpu] = sum(deltas)
    return result


class AdmissionBusy(RuntimeError):
    """Another loop on this box is inside the admission decision right now.

    Raised instead of waiting.  A caller that sees this has learned something
    true about the box -- admission is occupied -- and its correct response is
    to come back on its own schedule, not to sit in the kernel until the
    holder is done.  ``holder`` is the pid still in there when that could be
    verified from the holder record, and ``None`` when it could not; a missing
    holder is "unknown", never "nobody".
    """

    def __init__(self, holder=None):
        self.holder = holder
        super().__init__(
            f'PrismaBuild admission is held by pid {holder} on this box'
            if holder is not None else
            'PrismaBuild admission is held by another loop on this box')


#: Where a box keeps the host-local state its loops share.  An attribute
#: rather than a literal inside ``box_state`` so the test guard can repoint it
#: at the test's own ``tmp_path``: the identity below is keyed on the queue
#: root, every test builds its own queue under a fresh ``tmp_path``, and the
#: lock file for each is created and never unlinked -- so the suite minted a
#: permanent file per test into the directory the *fleet* uses.  dl380g10 had
#: accumulated 3780 of them against sparky's 2, 874 of those in one 20-minute
#: run.  Nothing read them and nothing broke, but a box's own admission state
#: lived in a directory the suite was filling.
#:
#: Unlinking is not the alternative.  A file here can be held by a live loop
#: that this process cannot see, and there is no way to test "unheld" and
#: unlink it without a window in which a sibling opens the path and ends up
#: holding an inode nobody else can reach -- which is a lapse of the mutual
#: exclusion the file exists for.  Not writing them is the fix; the ones
#: already on a box are cleared by the reboot that clears ``/tmp``.
#: Env-backed as well as an attribute, because the attribute alone reaches
#: only the modules already imported in *this* process.  The suite runs real
#: workers and real ``pbrun`` invocations as child processes, and each of those
#: imports this module fresh, past any ``monkeypatch``: with the attribute
#: repoint alone, one suite run still left three ``.sweep`` markers in the
#: fleet's directory (measured on sparky, 2026-09-06, against 132 files for the
#: same suite with neither).  ``LOCAL_CHECKOUT_ROOT`` is env-backed for exactly
#: this reason and says so.
BOX_STATE_ROOT = Path(os.environ.get('PRISMABUILD_BOX_STATE_ROOT')
                      or Path('/tmp') / f'prismabuild-admission-{os.getuid()}')


#: Digest suffixes this module and its callers own under the box-state root.
BOX_STATE_SUFFIXES = ('.lock', '.origin.json', '.adaptive-cpu-v1',
                      '.measurement-reader-v1', '.measurement-reader-v1.guard',
                      '.measurement-reader-v1.writing',
                      '.preemption', '.sweep')
#: Lock-family paths require an unheld probe before maintenance removal.
BOX_STATE_LOCK_SUFFIXES = ('.lock', '.preemption', '.sweep', '.guard')


def box_state(base):
    """Return ``(directory, digest)`` naming host-local state for ONE box.

    The loops of a single box have to agree about a few things -- who holds
    admission, when the queue was last swept -- and the pool they share is on
    NFS.  Coordinating through the pool would put an NFS round trip in front
    of every answer, which is the cost this identity exists to avoid, so the
    rendezvous is a host-local directory keyed by the ledger the loops share.
    Two boxes serving the same pool hash differently and never meet here;
    two generations on one box hash identically and do.

    ``/tmp`` is cleared on some of these hosts.  Every user of this directory
    must therefore treat a missing file as "no information", never as a fact:
    the lock re-creates its inode (a cleared directory can only lapse mutual
    exclusion between a live loop and a new one, which is the pre-existing
    behaviour of this path), and the sweep marker below simply sweeps once
    more than it had to.
    """

    directory = Path(BOX_STATE_ROOT)
    directory.mkdir(parents=True, mode=0o700, exist_ok=True)
    info = directory.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        # Not a directory, or not ours.  Nothing this process can do makes it
        # safe, so this is the honest refusal and it stays one.
        raise RuntimeError('unsafe PrismaBuild admission lock directory')
    if info.st_mode & 0o077:
        # Ours, and too permissive: set it right rather than refuse.  What the
        # check wants is that the directory be private to this uid; we own it,
        # so `chmod` is an answer and refusing is a way of not giving one.
        #
        # Refusing took a box out of service for as long as the mode survived.
        # The raise leaves `claim` into `serve_once`, where the worker loop
        # counts it among the consecutive failures it tolerates for a bad
        # ITEM -- but every poll re-reads the same directory and gets the same
        # answer, so the count only runs up.  Announcing happens earlier in the
        # same poll, so the box kept publishing a fresh offer at full capacity
        # while claiming nothing: live to everything watching, and useless.
        # Worse, the same raise reaches `pool.cleanup_action_containers`, which
        # is the gate that returns tokens; `RuntimeError` is in neither of its
        # `except` tuples, so it escapes after `scope.release()` and before the
        # claim is finished, and an action that had already run lost its lease.
        #
        # Measured on sparky, 2026-09-06: mode 0770, thirteen minutes, three
        # actions pinned to it sitting in `ready` with no passes recorded;
        # `chmod 700` by hand and the queue drained in eighteen seconds.  It
        # happened again on dl380g10 within the hour.
        #
        # The origin was ours -- a test that chmodded the very path
        # `box_state` handed it -- and that is fixed at source in #265, so this
        # is not the only thing standing between the fleet and that outage.  It
        # is here because the mode arrives from outside this process and a box
        # must not be removable from the fleet by a permission bit it is
        # entitled to set.
        directory.chmod(0o700)
        info = directory.lstat()
        if info.st_mode & 0o077:
            # The chmod did not take.  Now there is nothing left to try.
            raise RuntimeError('unsafe PrismaBuild admission lock directory')
    digest = box_identity(base)
    _record_box_origin_if_new(directory, digest, base)
    return directory, digest


def _record_box_origin_if_new(directory, digest, base):
    """File ``<digest>.origin.json`` once, with ``O_EXCL``, naming the writer.

    The record names the resolved queue root, hostname, pid, ``argv[0]``,
    and creation time. Only bounded work runs here: one origin probe,
    then one probe per owned sibling path, never a directory scan. The
    admission directory holds tens of thousands of entries, and this
    path runs on every admission call, so a scan here taxes every
    claim. The full census belongs to the maintenance survey only.

    A second call for the same digest keeps the first record: the
    origin is who first created the entry, not who last touched it.
    An entry that already owns state when the code first sees it
    keeps no record: it is a legacy entry, and nothing invents its
    origin. A missing file elsewhere stays "no information".

    Returns ``'recorded'``, ``'present'``, ``'legacy'`` or
    ``'unavailable'``. ``'unavailable'`` (an unreadable probe or a
    failed write) files nothing and refuses nothing: origin evidence
    never gates admission.
    """
    path = Path(directory) / (digest + '.origin.json')
    try:
        if os.path.lexists(path):
            return 'present'
    except OSError:
        return 'unavailable'
    for suffix in BOX_STATE_SUFFIXES:
        if suffix == '.origin.json':
            continue
        try:
            if os.path.lexists(os.path.join(directory, digest + suffix)):
                return 'legacy'
        except OSError:
            return 'unavailable'
    try:
        descriptor = os.open(path, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_NOFOLLOW, 0o600)
    except FileExistsError:
        return 'present'
    except OSError:
        return 'unavailable'
    try:
        try:
            resolved = str(Path(base).resolve())
        except OSError:
            resolved = str(base)
        record = {'schema': 'prismabuild.box_origin.v1', 'digest': digest,
                  'queue_root': resolved, 'hostname': socket.gethostname(),
                  'pid': os.getpid(), 'argv0': sys.argv[0] if sys.argv else '',
                  'created_unix': time.time()}
        # Read back with ``json.loads`` only; nothing hashes these bytes, so
        # the literal's key order is enough and no canonical encoding is owed.
        raw = json.dumps(record).encode()
        written = 0
        while written < len(raw):
            count = os.write(descriptor, raw[written:])
            if count <= 0:
                raise OSError('short write of the box origin record')
            written += count
        os.fsync(descriptor)
    except OSError:
        with contextlib.suppress(OSError):
            os.close(descriptor)
        with contextlib.suppress(OSError):
            os.unlink(path)
        return 'unavailable'
    os.close(descriptor)
    return 'recorded'


def read_box_origin(directory, digest):
    """The origin record for ``digest``, or ``None`` for a legacy entry.

    ``None`` also answers an unreadable or foreign record: a legacy entry
    and a damaged one both carry no attribution, and neither invents one.
    """
    try:
        raw = (Path(directory) / (digest + '.origin.json')).read_bytes()
    except OSError:
        return None
    try:
        record = json.loads(raw.decode())
    except (ValueError, UnicodeError):
        return None
    if not isinstance(record, dict):
        return None
    if record.get('schema') != 'prismabuild.box_origin.v1':
        return None
    if record.get('digest') != digest:
        return None
    for name in ('queue_root', 'hostname', 'argv0'):
        if not isinstance(record.get(name), str) or not record[name]:
            return None
    if type(record.get('pid')) is not int or record['pid'] <= 0:
        return None
    if type(record.get('created_unix')) not in (int, float):
        return None
    return record


def census_box_origins(directory):
    """Group every digest under ``directory`` by its origin record.

    Returns ``(origins, legacy)``: ``origins`` maps each origin record's
    stable identity ``(queue_root, hostname, argv0)`` to its digests;
    ``legacy`` holds the digests with no readable record. Names only.
    """
    directory = Path(directory)
    try:
        names = sorted(entry.name for entry in os.scandir(directory))
    except OSError:
        return {}, []
    digests = set()
    for name in names:
        if name.endswith('.origin.json'):
            stem = name[:-len('.origin.json')]
            if len(stem) == 64 and all(char in '0123456789abcdef' for char in stem):
                digests.add(stem)
            continue
        for suffix in ('.measurement-reader-v1', '.adaptive-cpu-v1', '.preemption', '.sweep', '.lock'):
            if name.endswith(suffix):
                stem = name[:-len(suffix)]
                break
        else:
            continue
        if len(stem) == 64 and all(char in '0123456789abcdef' for char in stem):
            digests.add(stem)
    origins = {}
    legacy = []
    for stem in sorted(digests):
        record = read_box_origin(directory, stem)
        if record is None:
            legacy.append(stem)
            continue
        key = (record['queue_root'], record['hostname'], record['argv0'])
        origins.setdefault(key, []).append(stem)
    return origins, legacy


def box_identity(base):
    """The digest that names ONE box's host-local state for the ledger at ``base``.

    Every loop of a box names the same ledger and so the same digest; two boxes
    serving one pool hash differently.  Host-local state kept outside
    ``box_state``'s directory is keyed by it too (``local_scratch``'s spool
    offer), so the two cannot disagree about which box they describe.
    """

    identity = f'{Path(base).resolve()}:{socket.gethostname()}'
    return hashlib.sha256(identity.encode()).hexdigest()


class AdmissionUnavailable(RuntimeError):
    """Host exclusion identity could not be established; no capacity claim."""


class AdmissionGate:
    """Lock-only exclusion for capacity claimants, independent of CPU policy.

    Shares the existing permanent inode and nonblocking flock with Controller.
    Construction performs no sampling, adaptive-state writes or publication.
    """

    def __init__(self, ledger):
        self.ledger = ledger

    @contextmanager
    def locked(self):
        descriptor = None
        try:
            try:
                directory, digest = box_state(self.ledger.base)
                descriptor = os.open(directory / (digest + '.lock'),
                                     os.O_CREAT | os.O_RDWR | os.O_NOFOLLOW, 0o600)
                info = os.fstat(descriptor)
                if not stat.S_ISREG(info.st_mode) or info.st_uid != os.getuid() or info.st_nlink != 1:
                    raise RuntimeError('unsafe PrismaBuild admission lock file')
                try:
                    fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
                except BlockingIOError:
                    raise AdmissionBusy(holder=flock_owner.holder_pid(descriptor)) from None
            except AdmissionBusy:
                raise
            except (OSError, RuntimeError) as exc:
                raise AdmissionUnavailable(str(exc)) from exc
            flock_owner.record_holder(descriptor)
            yield
        finally:
            if descriptor is not None:
                os.close(descriptor)


def local_state_base(base):
    """CPU learning is local authority, never restored from diagnostic copies."""
    directory, digest = box_state(base)
    state = directory / (digest + '.adaptive-cpu-v1')
    state.mkdir(mode=0o700, exist_ok=True)
    info = state.lstat()
    if not stat.S_ISDIR(info.st_mode) or info.st_uid != os.getuid():
        raise RuntimeError('unsafe PrismaBuild adaptive CPU state directory')
    if info.st_mode & 0o077:
        # As with the owning box-state directory, repair our own permissions
        # instead of taking admission down for an owner-correctable mode.
        state.chmod(0o700)
        if state.lstat().st_mode & 0o077:
            raise RuntimeError('unsafe PrismaBuild adaptive CPU state directory')
    return state

#: How long an idle digest waits before maintenance may remove it. Seven
#: days: seven times the longest worker-loop ceiling of 86,400 s. A live
#: loop writes ``cpu-sample.json`` on every claim pass, so a live entry is
#: never this old.
PRUNE_IDLE_AFTER_S = 7 * 24 * 3600.0
#: Most entries one prune pass removes. A count bound, not a safety proof:
#: age and liveness select candidates, the bound only sizes the pass.
PRUNE_MAX_ENTRIES_PER_PASS = 100
#: Most digests one prune pass removes when the root holds too many. The
#: oldest idle entry goes first, never a fresh one.
PRUNE_HARD_CAP_ENTRIES = 5000


class PruneRefused(RuntimeError):
    """Maintenance-only removal refused: the box is not provably idle."""


def _box_state_digest_of(name):
    """Every ``<digest>.*`` sibling belongs to the same admission entry."""
    stem, separator, _suffix = name.partition('.')
    if separator and len(stem) == 64 and all(char in '0123456789abcdef' for char in stem):
        return stem
    return None


def _box_state_entry_mtime(entry):
    """Return the newest mtime, or ``None`` for unreadable or unsafe state."""
    try:
        info = entry.lstat()
        if stat.S_ISREG(info.st_mode):
            return info.st_mtime
        if not stat.S_ISDIR(info.st_mode):
            return None
        newest = info.st_mtime
        with os.scandir(entry) as children:
            for child in children:
                stamp = _box_state_entry_mtime(Path(child.path))
                if stamp is None:
                    return None
                newest = max(newest, stamp)
    except OSError:
        return None
    return newest


def _served_box_state_digests(queue_roots):
    """``(digests, complete, errors)`` for the queue roots this box serves.

    Each entry names a queue root (the directory that holds ``ready/``
    and ``claimed/``). Production hashes the host ledger base
    ``<queue>/reservations/<host>`` through :func:`box_identity`
    (``pool.py``), one digest per reservation host present. A bare
    queue root alone protects nothing: its own hash names no ledger.

    An absent roots list is incomplete evidence. Missing or unreadable
    evidence is reported, never hidden: a missing queue root, an unreadable
    ``reservations/`` listing, or a partial host census yields
    ``complete`` false with the cause in ``errors``. An empty
    ``reservations/`` directory that lists cleanly is complete
    evidence of zero hosts. The survey keeps every entry and the
    apply refuses while evidence is incomplete.
    """
    found = set()
    errors = []
    roots_seen = False
    for root in queue_roots or ():
        roots_seen = True
        try:
            queue = Path(root)
        except (TypeError, ValueError) as exc:
            errors.append('%r: queue root unreadable: %s' % (root, exc))
            continue
        try:
            queue_stat = queue.lstat()
        except FileNotFoundError:
            errors.append('%s: queue root missing' % queue)
            continue
        except OSError as exc:
            errors.append('%s: queue root unreadable: %s' % (queue, exc))
            continue
        if not stat.S_ISDIR(queue_stat.st_mode):
            errors.append('%s: queue root is not a directory' % queue)
            continue
        reservations = queue / 'reservations'
        try:
            ledger_stat = reservations.lstat()
        except FileNotFoundError:
            errors.append('%s: reservations missing' % queue)
            continue
        except OSError as exc:
            errors.append('%s: reservations unreadable: %s' % (queue, exc))
            continue
        if not stat.S_ISDIR(ledger_stat.st_mode):
            errors.append('%s: reservations is not a directory' % queue)
            continue
        try:
            with os.scandir(reservations) as iterator:
                hosts = sorted(entry.name for entry in iterator)
        except OSError as exc:
            errors.append('%s: reservations unreadable: %s' % (queue, exc))
            continue
        for host in hosts:
            if host.startswith('.') or '/' in host or host in ('.', '..'):
                continue
            try:
                found.add(box_identity(reservations / host))
            except (OSError, ValueError) as exc:
                errors.append('%s: host %r unreadable: %s' % (queue, host, exc))
                continue
    if not roots_seen:
        errors.append('served queue roots absent')
    return found, not errors, errors


def _held_lock_digest(path):
    """Whether ``path`` names a lock file a live loop holds right now.

    Returns ``True`` (held), ``False`` (free) or ``None`` (unknown).
    A missing name is free: no file names no holder. Any error while
    opening, locking or closing the file is unknown, and the caller
    keeps the entry. Unknown state never reads as idle.
    """
    try:
        descriptor = os.open(path, os.O_RDONLY | os.O_NOFOLLOW)
    except FileNotFoundError:
        return False
    except OSError:
        return None
    held = None
    try:
        try:
            fcntl.flock(descriptor, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            held = True
        except OSError:
            held = None
        else:
            held = False
    finally:
        try:
            os.close(descriptor)
        except OSError:
            held = None
    return held


def survey_box_state(directory=None, *, queue_roots=(), older_than_s=PRUNE_IDLE_AFTER_S,
                     max_entries=PRUNE_HARD_CAP_ENTRIES, now=None):
    """Sort every digest under the box-state root into keep or candidate.

    Returns ``{'candidates': [...], 'kept': {digest: reason}}``, plus
    ``'queue_evidence': {'complete': bool, 'errors': [...]}``. A digest
    is a candidate only when every file under its entry is older than
    ``older_than_s`` and no live evidence names it: a digest of a
    served queue root, a held admission lock, a held preemption lock,
    any census fence (the final marker, its guard lock, or a partial
    publication write), or an unreadable census. Missing, partial or
    unreadable evidence keeps, never removes. Age and count only
    select; neither permits unsafe removal. Queue roots name queue
    directories; protection derives from their reservation hosts.

    An entry includes every ``<digest>.*`` sibling, with or without an
    adaptive CPU directory. A ``.sweep`` marker or permanent lock file
    does not establish activity; its age joins the entry's age. Every
    lock-family file must be unheld. Obsolete entries leave only inside
    a proven-quiet maintenance window. Incomplete queue evidence keeps
    every entry: every digest reads ``'unresolved queue evidence'``.
    """
    root = Path(directory) if directory is not None else Path(BOX_STATE_ROOT)
    moment = time.time() if now is None else float(now)
    live, queue_complete, queue_errors = _served_box_state_digests(queue_roots)
    queue_evidence = {'complete': queue_complete, 'errors': list(queue_errors)}
    try:
        names = sorted(entry.name for entry in os.scandir(root))
    except OSError:
        return {'candidates': [], 'kept': {}, 'queue_evidence': queue_evidence}
    by_digest = {}
    for name in names:
        digest = _box_state_digest_of(name)
        if digest is not None:
            by_digest.setdefault(digest, []).append(name)
    kept = {}
    if not queue_complete:
        for digest in sorted(by_digest):
            kept[digest] = 'unresolved queue evidence'
        return {'candidates': [], 'kept': kept, 'queue_evidence': queue_evidence}
    candidates = []
    for digest in sorted(by_digest):
        names = by_digest[digest]
        if digest in live:
            kept[digest] = 'served queue root'
            continue
        for name in names:
            if not name.endswith(BOX_STATE_LOCK_SUFFIXES):
                continue
            held = _held_lock_digest(root / name)
            if held is None:
                kept[digest] = 'unreadable state'
                break
            if held:
                if name.endswith('.lock'):
                    kept[digest] = 'held admission lock'
                elif name.endswith('.preemption'):
                    kept[digest] = 'held preemption lock'
                else:
                    kept[digest] = 'held state lock'
                break
        if digest in kept:
            continue
        stamps = [_box_state_entry_mtime(root / name) for name in names]
        if any(stamp is None for stamp in stamps):
            kept[digest] = 'unreadable state'
            continue
        newest = max(stamps)
        if moment - newest < older_than_s:
            kept[digest] = 'fresh activity'
            continue
        try:
            reader_names = [name for name in names
                            if name.startswith(digest + '.measurement-reader-v1')]
            reader_exists = any(os.path.lexists(root / name) for name in reader_names)
        except OSError:
            kept[digest] = 'unreadable state'
            continue
        if reader_exists:
            kept[digest] = 'unresolved census reader'
            continue
        candidates.append((newest, digest))
    candidates.sort()
    if len(by_digest) > max_entries:
        over = len(by_digest) - max_entries
        aged = [digest for _stamp, digest in candidates[:over]]
        rest = [digest for _stamp, digest in candidates[over:]]
        return {'candidates': aged, 'kept': kept, 'over_cap': rest,
                'queue_evidence': queue_evidence}
    return {'candidates': [digest for _stamp, digest in candidates], 'kept': kept,
            'queue_evidence': queue_evidence}


def prove_box_quiescent(directory=None, *, queue_roots=(), proc_root='/proc'):
    """Prove the box is quiet, or return the reason it is not.

    Returns ``{'quiet': True}`` only when every check passes: no live
    worker loop of this box, no claim not yet resolved on any served
    queue, no live resource scope, and every ``.lock``, ``.preemption``,
    ``.sweep`` and ``.guard`` file under the root is unheld. Each
    non-blocking ``flock`` probe releases at once. Partial or unreadable
    evidence counts as "not quiet": an unknown box never reads as idle. A supplied
    queue whose ``ready/``, ``claimed/`` or ``reservations/``
    evidence is missing or unreadable is "not quiet": a missing
    queue never reads as an empty queue. The function changes
    nothing; it only reports.
    """
    root = Path(directory) if directory is not None else Path(BOX_STATE_ROOT)
    try:
        names = sorted(entry.name for entry in os.scandir(root))
    except OSError as exc:
        return {'quiet': False, 'reason': 'box-state root unreadable: %s' % exc}
    for name in names:
        if _box_state_digest_of(name) is None:
            continue
        if name.endswith(BOX_STATE_LOCK_SUFFIXES):
            held = _held_lock_digest(root / name)
            if held is None:
                return {'quiet': False, 'reason': 'lock probe unreadable: %s' % name}
            if held:
                return {'quiet': False, 'reason': 'lock held: %s' % name}
    _served, queue_complete, queue_errors = _served_box_state_digests(queue_roots)
    if not queue_complete:
        return {'quiet': False, 'reason': 'queue evidence incomplete: %s' % queue_errors[0]}
    for queue in queue_roots or ():
        try:
            queue_path = Path(queue)
        except (TypeError, ValueError) as exc:
            return {'quiet': False, 'reason': 'queue root unreadable: %s' % exc}
        for state in ('ready', 'claimed'):
            try:
                entries = sorted(entry.name for entry in os.scandir(queue_path / state))
            except FileNotFoundError:
                return {'quiet': False,
                        'reason': 'queue %s missing: %s' % (state, queue_path / state)}
            except OSError as exc:
                return {'quiet': False, 'reason': 'queue %s unreadable: %s' % (state, exc)}
            live = [entry for entry in entries if entry.endswith('.json')]
            if live:
                return {'quiet': False, 'reason': 'unresolved %s claim: %s' % (state, live[0])}
        try:
            leases = [entry.name for entry in os.scandir(queue_path / 'claimed')
                      if entry.name.endswith('.lease')]
        except FileNotFoundError:
            return {'quiet': False,
                    'reason': 'queue claimed missing: %s' % (queue_path / 'claimed')}
        except OSError as exc:
            return {'quiet': False, 'reason': 'queue leases unreadable: %s' % exc}
        if leases:
            return {'quiet': False, 'reason': 'unresolved claim lease: %s' % leases[0]}
    scopes = _live_resource_scopes(proc_root=proc_root)
    if scopes is None:
        return {'quiet': False, 'reason': 'resource scope census unreadable'}
    if scopes:
        return {'quiet': False, 'reason': 'live resource scope: %s' % scopes[0]}
    loops = _live_worker_loops(proc_root=proc_root)
    if loops is None:
        return {'quiet': False, 'reason': 'worker loop census unreadable'}
    if loops:
        return {'quiet': False, 'reason': 'live worker loop: pid %s' % loops[0]}
    return {'quiet': True}


def _live_worker_loops(proc_root='/proc'):
    """Pids of live worker loops, or ``None`` when the census is incomplete.

    A loop is any process whose command line names ``worker_loop.py``,
    ``worker.py`` or ``prewarm_loop.py``. Unreadable process evidence
    (other than a process that exited mid-census) makes the census
    incomplete, never empty.
    """
    try:
        entries = sorted(os.listdir(proc_root))
    except OSError:
        return None
    found = []
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            with open(os.path.join(proc_root, entry, 'cmdline'), 'rb') as stream:
                raw = stream.read(65536)
        except FileNotFoundError:
            continue
        except OSError:
            return None
        try:
            parts = [part for part in raw.decode('utf-8', 'replace').split('\x00') if part]
        except (ValueError, UnicodeError):
            return None
        for part in parts:
            name = part.rsplit('/', 1)[-1]
            if name in ('worker_loop.py', 'worker.py', 'prewarm_loop.py'):
                found.append(int(entry))
                break
    return found


def _live_resource_scopes(proc_root='/proc'):
    """Live PrismaBuild scopes, or ``None`` when the census is incomplete.

    A scope is any process whose cgroup names ``prismabuild.slice``.
    Unreadable membership evidence (other than an exited process) makes
    the census incomplete, never empty.
    """
    try:
        entries = sorted(os.listdir(proc_root))
    except OSError:
        return None
    found = []
    for entry in entries:
        if not entry.isdigit():
            continue
        try:
            with open(os.path.join(proc_root, entry, 'cgroup'), 'r') as stream:
                text = stream.read(65536)
        except FileNotFoundError:
            continue
        except OSError:
            return None
        if 'prismabuild.slice' in text:
            found.append(int(entry))
    return found

def prune_box_state(*, queue_roots=(), older_than_s=PRUNE_IDLE_AFTER_S,
                    max_entries_per_pass=PRUNE_MAX_ENTRIES_PER_PASS,
                    max_entries=PRUNE_HARD_CAP_ENTRIES, apply=False,
                    directory=None, maintenance_held=False, now=None,
                    proc_root='/proc'):
    """Remove idle admission state under acknowledged maintenance, or survey it.

    The default is a dry run: it returns the survey and changes nothing.
    With ``apply`` it removes each eligible entry directly under the same
    acknowledgement, after the quiescence proof below. No rename of a
    held inode ever happens: the module's own rule stays that unlinking
    under a live loop can split exclusion, so removal runs only inside
    a proven-quiet window, and any failed probe leaves the entry.

    ``maintenance_held`` must be true: the operator acknowledges the
    maintenance window, with every worker loop stopped and no new opener
    able to enter, in the style of ``pb_gc.py`` (``--apply`` default
    off plus an acknowledged quiescent store). The flag alone proves
    nothing: apply still refuses unless :func:`prove_box_quiescent`
    proves the box quiet first. Partial or unreadable evidence counts
    as "not quiet". The prohibition on deletion while workers run
    stays: apply without the hold, or inside a noisy box, is refused,
    never queued.
    """
    root = Path(directory) if directory is not None else Path(BOX_STATE_ROOT)
    survey = survey_box_state(root, queue_roots=queue_roots,
                              older_than_s=older_than_s,
                              max_entries=max_entries, now=now)
    if not apply:
        return {'dry_run': True, 'candidates': list(survey['candidates']),
                'kept': dict(survey['kept']),
                'queue_evidence': dict(survey['queue_evidence'])}
    if not maintenance_held:
        raise PruneRefused(
            'prune apply needs the maintenance acknowledgement: stop every '
            'worker loop and bar new openers first; deletion while workers '
            'run stays prohibited')
    proof = prove_box_quiescent(root, queue_roots=queue_roots, proc_root=proc_root)
    if not proof.get('quiet'):
        raise PruneRefused(
            'prune apply refused: the box is not provably quiet: %s'
            % proof.get('reason', 'unknown'))
    removed = []
    for digest in survey['candidates'][:max_entries_per_pass]:
        try:
            names = [entry.name for entry in os.scandir(root)
                     if _box_state_digest_of(entry.name) == digest]
        except OSError:
            continue
        if not names:
            continue
        proof = prove_box_quiescent(root, queue_roots=queue_roots, proc_root=proc_root)
        if not proof.get('quiet'):
            break
        gone = True
        for name in sorted(names):
            target = root / name
            try:
                if target.is_dir() and not target.is_symlink():
                    import shutil
                    shutil.rmtree(target)
                else:
                    target.unlink()
            except FileNotFoundError:
                continue
            except OSError:
                gone = False
                continue
        if gone:
            removed.append(digest)
    return {'dry_run': False, 'removed': removed,
            'candidates': list(survey['candidates']),
            'kept': dict(survey['kept']),
            'queue_evidence': dict(survey['queue_evidence'])}


def local_telemetry_path(base, action_key):
    """Where the executing box records a holder's live telemetry; admission reads only this.

    The record is written by this host's own sampler for this host's own
    action, and read under this host's own admission lock, so it is host-local
    in meaning. The copy under ``reservations/<host>/telemetry/`` on the shared
    mount is the same record written for remote readers (``pbmetrics``) and is
    never consulted for credit: a stale or edited copy there changes nothing.

    ``local_state_base`` resolves ``base`` (stats on the mount), so the
    controllers read from their own cached ``base`` inside the lock and only
    the scope owner, once per scope, derives the path through this function.
    """
    return local_state_base(base) / 'telemetry' / f'{action_key}.json'


#: The host's own idle history (#997), host-local beside ``cpu-sample.json``.
IDLE_BASELINE = 'idle-baseline.json'
IDLE_BASELINE_SCHEMA = 'prismabuild.idle_baseline.v1'
#: What an idle sample carries, and what a measurement is judged on.
IDLE_FIELDS = ('busy_cpus', 'psi_some')
#: How many idle samples a host keeps.  A storage bound, not a decision
#: threshold: the rule below compares a sample with the largest idle sample
#: in the window, so on a box whose idle load is stationary a truly idle
#: sample is refused with probability ``1 / (IDLE_WINDOW + 1)`` (the chance
#: that it is the largest of ``IDLE_WINDOW + 1`` exchangeable draws), 0.4%
#: here, and a refused measurement is judged again on the next pass.  The
#: file is rewritten under the admission lock once per new idle sample, so
#: the bound also keeps that write to a few kilobytes.
IDLE_WINDOW = 256

#: Provisional seeding gate (#1185): holder-free samples an empty window's
#: prior refuses still join, flagged provisional, and the window measures
#: once PROVISIONAL_MIN_SAMPLES of them span PROVISIONAL_MIN_SPAN_S.
#: Without this a host that boots under foreign load never seeds (#1014
#: drops the refused seed) and stays ``basis: unmeasured`` forever.
#: Derived from sparklina's 2026-09-28 probe series (15 live samples over
#: 650 s at ~43 s cadence, evidence.json ``issue_1185_probe_series``):
#: ambient lag-1 autocorrelation 0.673, so rho < 0.2 at ~4 lags ~= 175 s,
#: hence the 180 s span; depth 5 covers the span at loaded cadence plus
#: one.  An admitted seed still measures at once, as before -- only
#: refused seeds wait out the gate, and the window judges ``unmeasured``
#: (the prior still refuses) until it does.
PROVISIONAL_MIN_SAMPLES = 5
PROVISIONAL_MIN_SPAN_S = 180.0
#: The per-CPU foreign line for a measurement's own CPUs (#1185): the same
#: series' ambient per-CPU foreign peaks at 0.080 while the incident's
#: loaded CPUs read 0.14-0.28, so 0.10 clears both populations.
#: Sparklina-derived; per-host learning is follow-up work.  PSI stays
#: window-relative (stable at 0.0029 +/- 0.0003 ambient, and the idle gate
#: already judges it) -- only per-CPU foreign moves to the absolute line,
#: which is where the box-wide sum was the defect.
PER_CPU_FOREIGN_MAX = 0.10


def _idle_statistics(samples, field):
    values = [float(s[field]) for s in samples]
    mean = sum(values) / len(values)
    top = max(values)
    return {'mean': round(mean, 6), 'max': round(top, 6), 'margin': round(top - mean, 6),
            'stdev': round(statistics.pstdev(values), 6) if len(values) > 1 else 0.}


def _judge_idle(verdict, reference, current, fields, prior_rule):
    """Whether ``current`` is above ``reference``'s maximum on any field.

    With no reference there is no measurement of this host's idle state, and
    ``prior_rule`` -- the caller's pre-#997 fixed line -- decides, labelled
    ``basis: unmeasured`` (#997 ruling, as for the unmeasured export slots of
    #999).  Without a prior rule an unmeasured sample exceeds.
    """
    verdict['samples'] = len(reference)
    verdict['current'] = current
    if reference:
        verdict['basis'] = 'measured'
        verdict['span_s'] = round(reference[-1]['sampled_unix'] - reference[0]['sampled_unix'], 3)
        for field in fields:
            verdict[field] = _idle_statistics(reference, field)
        return any(current[field] > verdict[field]['max'] for field in fields)
    verdict['basis'] = 'unmeasured'
    if prior_rule is None:
        return True
    verdict['prior'] = prior_rule.__doc__ or getattr(prior_rule, '__name__', 'prior')
    return bool(prior_rule(current))


def _idle_samples(state, fields=IDLE_FIELDS):
    """The window's remembered samples, filtered exactly as `idle_judgement` keeps them."""
    return [s for s in state.get('samples', []) if isinstance(s, dict)
            and all(type(s.get(k)) in (int, float) and math.isfinite(s[k])
                    for k in ('sampled_unix',) + tuple(fields))]


def _idle_reference(samples, *, now, excursion_unix):
    """The samples one idle sample is judged against, and its excursion run.

    The no-holder half of #997's rule: every sample before this one, less an
    ongoing excursion's own run (a run that has outlived what the window
    remembers reads as unexceptional again, so the excursion is over).
    Pure, so `Controller.idle` can cache the very reference a verdict used
    and #1233's re-judgement cannot drift from `idle_judgement`'s choice.
    """

    prior = [s for s in samples if s['sampled_unix'] < now]
    run = excursion_unix
    run = float(run) if type(run) in (int, float) and math.isfinite(run) else None
    if run is not None:
        before = [s for s in prior if s['sampled_unix'] < run]
        # From the oldest remembered sample to when the run started, not
        # between the remembered samples themselves: that is zero with a
        # single one of them, which read every run as having already
        # outlived the window on its very first pass (#1014).
        span = (run - before[0]['sampled_unix']) if before else 0.
        if before and now - run < span:
            return before, run
        return prior, None
    return prior, None


def idle_judgement_with_reference(
        state, sample, *, holders, identity, fields=IDLE_FIELDS,
        interval_s=None, prior_rule=None):
    """Judge one host sample against the host's own idle history (#997).

    Returns ``(verdict, state, reference)``: ``verdict['exceeds']`` is
    whether the sample is outside what this host has been observed doing
    while PrismaBuild ran nothing, with the evidence a refusal records,
    ``state`` is the history to persist (unchanged when ``state is`` the
    returned one), and ``reference`` is the baseline window the verdict was
    actually judged against -- the whole remembered window less unlatched
    provisional seeds -- and ``None`` where the verdict judged against
    nothing at all: a forced holder tail, or the fresh empty window an
    identity reset judges against (empty, not None -- the reset state
    carries no samples to re-derive, #1233 review).  The reference is an
    answer, never a field of the verdict, which is serialized into refusal
    evidence.

    * An **idle sample** is a fresh one taken with no holder on the host and
      no holder seen since its interval began: a sample whose interval
      overlaps a holder's tail measures that holder, not the host.
    * The **baseline** is every idle sample kept before this one, less an
      ongoing excursion: a run of consecutive idle samples each above the
      baseline's maximum.  The run is judged against the samples before it
      began, so a sustained foreign load is refused for as long as it runs,
      not only on its first pass.  Its span is measured from the *oldest*
      remembered sample to the run's own start, not between the remembered
      samples themselves -- that span is zero with only one of them, which
      would let any run "outlive" the window at once (#1014).  A run that has
      lasted as long as that span has outlived what the window remembers of
      the host's earlier state, and the host's idle state is taken to have
      changed: the whole window becomes its baseline.
    * A sample **exceeds** when any of ``fields`` (default :data:`IDLE_FIELDS`)
      is above the
      baseline's maximum.  No multiplier: the maximum is the largest load
      this host has shown while idle, and ``margin`` (maximum less mean) is
      recorded beside the standard deviation so a reader sees it in units of
      the host's own variation.
    * With no idle history nothing about this host is measured, and
      ``prior_rule`` (the caller's pre-#997 fixed line) judges the sample,
      labelled ``basis: unmeasured``.  A holder-free sample the rule refuses
      joins as a provisional seed (#1185), excluded from judgement until
      PROVISIONAL_MIN_SAMPLES span PROVISIONAL_MIN_SPAN_S.  The completing
      pass promotes the provisional window to measured evidence; one refused
      seed cannot make its own load the next pass's measured maximum (#1014).
      A sample the rule does not refuse seeds the firm window immediately.
      Without a prior rule there is no rule to have refused the sample, so it
      exceeds and still seeds -- the window has to start somewhere, and
      nothing here can tell that sample apart from a genuinely idle one.
    * With holders present the sample is judged against the whole window
      (``state: holders_present``) but never joins it: it measures the
      holders too, so exceeding says the host is not idle, and not exceeding
      leaves the holders to refuse an exclusive claim themselves.
    * Eligible holder-free samples join the window, bounded by
      :data:`IDLE_WINDOW`; an empty baseline's refused seed remains
      provisional until the depth/span gate above completes.  An excursion
      sample joins even though it exceeds an established baseline, so it can
      later become the baseline itself.  Holders and holder-tail intervals
      never seed either window.

    ``interval_s`` is how far back the sample's reading reaches, when the
    sample does not say (the GPU broker's PSI fields are the kernel's 10 s
    averages).
    """
    state = dict(state) if isinstance(state, dict) else {}
    if state.get('schema') != IDLE_BASELINE_SCHEMA or state.get('identity') != identity:
        # A changed CPU topology or device is a different host for this purpose.
        state = {'schema': IDLE_BASELINE_SCHEMA, 'identity': identity, 'samples': []}
    samples = _idle_samples(state, fields)
    firm = [s for s in samples if not s.get('provisional')]
    pending = [s for s in samples if s.get('provisional')]
    now = sample.get('sampled_unix')
    seen = state.get('holders_seen_unix')
    seen = float(seen) if type(seen) in (int, float) and math.isfinite(seen) else None
    verdict = {'window_bound': IDLE_WINDOW}
    current = {field: float(sample[field]) for field in fields}
    if holders:
        verdict['state'] = 'holders_present'
        # Provisional seeds judge nothing here either (#1185): they are the
        # same refused load the main path holds out of its reference, and
        # comparing against them would let that load mask itself as "not
        # exceeding" whenever a holder is present.
        verdict['exceeds'] = _judge_idle(verdict, firm, current, fields, prior_rule)
        if type(now) in (int, float) and (seen is None or now > seen):
            state['holders_seen_unix'] = now
        return verdict, state, firm
    started = now - (sample['interval_s'] if interval_s is None else interval_s)
    if seen is not None and started <= seen:
        verdict.update(state='holder_tail', exceeds=True, holders_seen_unix=seen,
                       interval_start_unix=started)
        # A forced tail judged against nothing: handing back a reference here
        # would let #1233's re-judgement read a holder's own tail as foreign
        # load and starve the measurement (#1236 review).
        return verdict, state, None
    if firm:
        completes = False
        reference, run = _idle_reference(firm, now=now,
                                         excursion_unix=state.get('excursion_unix'))
    else:
        # No measured history: provisional samples judge nothing until the
        # gate passes (#1185).  ``pending[0]`` is the oldest -- samples
        # append in time order -- so the span is now less the first
        # provisional seed; a lone first seed spans nothing and cannot
        # complete the gate on its own.
        completes = (len(pending) + 1 >= PROVISIONAL_MIN_SAMPLES
                       and bool(pending)
                       and type(now) in (int, float)
                       and now - pending[0]['sampled_unix'] >= PROVISIONAL_MIN_SPAN_S)
        reference, run = (list(pending), None) if completes else ([], None)
    verdict['state'] = 'idle'
    exceeds = verdict['exceeds'] = _judge_idle(verdict, reference, current, fields, prior_rule)
    if run is not None and exceeds:
        verdict['excursion_s'] = round(now - run, 3)
    # A sample an empty baseline's prior_rule refuses is foreign load, not
    # firm idle evidence, and must not seed the measured reference: doing so
    # makes it the only (and therefore maximum) sample, so the same load reads as
    # its own baseline and is admitted on the very next pass (#1014). Without
    # a prior_rule there was no rule to have refused it -- the unmeasured
    # default always exceeds, and still seeds, since the window has to start
    # somewhere.
    refused_seed = verdict['basis'] == 'unmeasured' and exceeds and prior_rule is not None
    if completes:
        # The gate just passed: every seed becomes measured evidence at
        # once.  The strip lives here, above the branch split, because a
        # completing pass takes the first branch below (its reference is
        # non-empty, so the sample is not a refused seed) -- keying the
        # strip to the refused-seed branch left the earlier flags in place
        # forever and the baseline at one sample (#1310 review).
        for s in samples:
            s.pop('provisional', None)
    if not refused_seed and all(s['sampled_unix'] != now for s in samples):
        samples.append({'sampled_unix': now, **current})
        state['samples'] = samples[-IDLE_WINDOW:]
        if exceeds and reference:
            state['excursion_unix'] = run if run is not None else now
        else:
            state.pop('excursion_unix', None)
    elif refused_seed and all(s['sampled_unix'] != now for s in samples):
        # A refused seed still joins, flagged provisional (#1185): dropping
        # it leaves a host that boots under load unmeasured forever.  The
        # gate above keeps it out of every reference until enough of them
        # span long enough; the strip above fires when the gate completes,
        # so the load they record becomes the measured baseline at once.
        samples.append({'sampled_unix': now, **current, 'provisional': True})
        state['samples'] = samples[-IDLE_WINDOW:]
        if not completes:
            state.pop('excursion_unix', None)
    return verdict, state, reference


def idle_judgement(state, sample, *, holders, identity, fields=IDLE_FIELDS,
                   interval_s=None, prior_rule=None):
    """:func:`idle_judgement_with_reference` as the historical pair.

    Every pre-#1233 caller wants ``(verdict, state)``; the reference the
    verdict judged against is :func:`idle_judgement_with_reference`'s third
    answer, kept out of the verdict dict, which is serialized into refusal
    evidence.
    """

    verdict, state, _reference = idle_judgement_with_reference(
        state, sample, holders=holders, identity=identity, fields=fields,
        interval_s=interval_s, prior_rule=prior_rule)
    return verdict, state


class Controller:
    def __init__(self, ledger, tiers, *,
                 sampler: Callable[[], dict[str, object]] | None = None):
        self.ledger = ledger
        self.tiers = tiers
        self.cpus = list(tiers['preferred']) + list(tiers['fallback'])
        self.base = local_state_base(ledger.base)
        self._host_sample = None
        self._idle = None
        # The (sampled_unix, {cpu: [pids]}) foreign-PID census, recomputed
        # at most once per sample (#1185): it names the suspects in a
        # measurement_foreign_ambient refusal, never a decision input.
        self._foreign_pid_cache = None
        self._sampler = sampler

    def idle(self, sample, holders):
        """This pass's :func:`idle_judgement`, persisted host-local (#997).

        Under the admission lock, like every other file in ``self.base``.  One
        judgement per sample and holder state: a pass that decides several
        candidates reads the history once and writes it at most once.
        """
        key = (sample.get('sampled_unix'), bool(holders))
        if self._idle is not None and self._idle[0] == key:
            return self._idle[1]
        state = read_json(self.base / IDLE_BASELINE)
        cpus = len(self.cpus)

        def prior_rule(current):
            # The pre-#997 lines, applied only while this host has no idle
            # history to judge against.
            return current['busy_cpus'] > .05 * cpus or current['psi_some'] >= .10
        prior_rule.__doc__ = f'busy_cpus > {.05 * cpus:g} (.05 x {cpus} CPUs) or psi_some >= .10'
        verdict, updated, reference = idle_judgement_with_reference(
            state, sample, holders=bool(holders), identity=cpus,
            prior_rule=prior_rule)
        if updated != state:
            self.write_state(IDLE_BASELINE, updated)
        # The reference THIS verdict judged against, taken from the
        # judgement itself and never re-derived here, so #1233's
        # re-judgement cannot drift from the window's own choice -- not for
        # a forced holder tail nor after an identity reset, which judge
        # against nothing and hand back None (#1236 review).
        self._idle = (key, verdict, reference, prior_rule)
        return verdict

    def _measurement_idle_refusal(self, sample, idle, ambient):
        """Classify idle evidence without granting resources or isolation."""
        if not idle['exceeds']:
            return None
        if ambient is not None and ambient['exceeds']:
            return 'measurement_foreign_ambient'
        if ambient is not None and ambient['clear'] and self._idle is not None:
            reference, prior_rule = self._idle[2:]
            # Clear assigned CPUs supersede aggregate CPU busy, not PSI.
            # Project PSI against THIS cached window; never reread/reseed it.
            # None is a forced holder tail, not an empty unmeasured reference.
            if reference is not None and not _judge_idle(
                    {}, reference, {'busy_cpus': 0., 'psi_some': sample['psi_some']},
                    ('psi_some',), prior_rule):
                return None
        return 'measurement_host_not_idle'

    def _held_cpus(self, holders) -> set:
        """The CPUs this host's own rows hold, from the same ledger rows
        the admission path holds and releases (#1185)."""
        held = set()
        for holder in holders or []:
            allocation = self.ledger.cpu_allocation(holder.name, self.tiers)
            held.update(allocation['preferred'] + allocation['fallback'])
        return held

    def _foreign_pids(self, cpus, sampled_unix) -> dict:
        """Up to four foreign PIDs per CPU, for refusal evidence only.

        Reads each numeric ``/proc`` entry's main-thread current CPU (stat
        field 39) once per sample; anything unreadable or vanished is
        skipped, and an empty map means the census found nobody, never
        that the CPUs are clean.  Never consulted by the verdict -- the
        per-CPU busy numbers in the sample decide, this only names
        suspects for the operator.  (#1185)"""
        key = (sampled_unix, tuple(sorted(cpus)))
        if self._foreign_pid_cache is not None and self._foreign_pid_cache[0] == key:
            return self._foreign_pid_cache[1]
        found: dict = {}
        try:
            entries = os.listdir('/proc')
        except OSError:
            entries = []
        for entry in entries:
            if not entry.isdigit():
                continue
            try:
                with open(f'/proc/{entry}/stat', 'rb') as fh:
                    fields = fh.read().split(b')')[-1].split()
                cpu = int(fields[36])
            except (OSError, ValueError, IndexError):
                continue
            if cpu in cpus and len(found.setdefault(cpu, [])) < 4:
                found[cpu].append(int(entry))
                if all(len(found.get(c, ())) >= 4 for c in cpus):
                    break
        self._foreign_pid_cache = (key, found)
        return found

    def _measurement_foreign_ambient(self, sample, holders, declared):
        """The typed per-CPU ambient check for a measurement (#1185).

        Returns ``None`` when the question cannot be asked on this sample
        (stale sample, no per-CPU attribution, or the demand's CPUs
        unknowable); the caller then falls through to the conservative
        host_not_idle path. Otherwise ``{'exceeds': bool, 'clear': bool,
        'evidence': {...}}``. Clear requires a complete valid prediction;
        exceeds is true only when a foreign busy reading on
        one of the measurement's own predicted CPUs tops
        :data:`PER_CPU_FOREIGN_MAX`.  Held (PB-owned) busy on those CPUs
        is ours and never fires this; load anywhere else never fires this.
        PSI stays window-relative and is not consulted here."""
        if type(sample.get('sampled_unix')) not in (int, float):
            return None
        # The attribution rides top-level on the observation
        # (``Controller.sample`` returns the observation dict itself).
        foreign = sample.get('foreign_per_cpu_busy')
        if not isinstance(foreign, dict) or not foreign:
            return None
        predicted = self._predicted_cpus(declared) if declared else None
        if not predicted:
            return None
        held = self._held_cpus(holders)
        readings = {}
        for cpu in predicted:
            value = foreign.get(cpu, foreign.get(str(cpu)))
            if type(value) in (int, float) and math.isfinite(value):
                readings[cpu] = value
        if not readings:
            return None
        excess = sorted(cpu for cpu, value in readings.items()
                        if cpu not in held and value > PER_CPU_FOREIGN_MAX)
        evidence = {'predicted_cpus': list(predicted),
                    'per_cpu_foreign_busy': {cpu: round(readings[cpu], 6)
                                             for cpu in sorted(readings)},
                    'per_cpu_foreign_max': PER_CPU_FOREIGN_MAX,
                    'held_cpus': sorted(held),
                    'foreign_cpus': excess}
        if excess:
            # String keys: this evidence is read back through the CAS JSON
            # denial record, where int dict keys do not survive.  Every
            # excess CPU is present; an empty list means the census found
            # nobody there, never that the CPU is clean.
            census = self._foreign_pids(set(excess), sample.get('sampled_unix'))
            evidence['foreign_pids'] = {str(cpu): list(census.get(cpu, []))
                                        for cpu in excess}
        complete = (len(readings) == len(predicted)
                    and all(0 <= value <= 1 for value in readings.values()))
        return {'exceeds': bool(excess), 'clear': complete and not excess,
                'evidence': evidence}

    def write_state(self, name, value):
        write_json(self.base / name, value)

    def _predicted_cpus(self, need: int, *, eligible_cpus=None) -> list[int] | None:
        """The CPUs this claim's tokens would represent, by the ledger's rule.

        ``ResourceLedger.begin_acquire`` takes the first ``need`` eligible free
        ``cpu-*`` tokens in sorted-name order and maps each token ordinal to
        ``(preferred + fallback)[ordinal]``.  The ordinal is a token index,
        never a CPU ID, so this asks the ledger for that same answer instead of
        keeping a second copy of the selection rule here.  ``None`` means the
        question cannot be answered -- fewer free tokens than the demand, or an
        ordinal outside the configured topology -- and the caller treats that
        as unknown rather than as idle.
        """
        return self.ledger.free_cpu_allocation(need, self.tiers, eligible_cpus=eligible_cpus)

    @contextmanager
    def locked(self):
        """Hold box admission for the block, or raise ``AdmissionBusy`` at once.

        The acquisition is non-blocking, and that is the whole point.  What
        this lock guards is the box's headroom decision, not the claim that
        follows it.  ``_claim`` takes it for its capacity prelude, and then
        per candidate for the adaptive and GPU decisions through
        ``begin_acquire`` -- the point at which the tokens leave ``free/``
        and every sibling's ``decision`` and ``available`` can see them
        reserved, and at which ``admitted`` records the borrow that decision
        spent.  The record rename, the lease write and the token renames that
        follow run outside it, and nothing reacquires it after them.

        Even so the holder's time inside is not purely local: CPU samples,
        profiles, interval/borrowing state, holder telemetry and GPU probe
        state are host-local, but ``decision`` reads every holder's token
        metadata on the shared mount and ``begin_acquire`` renames there.  So
        the holder's time inside is still bounded by a filesystem another
        machine controls, and a blocking ``LOCK_EX`` made every other loop on
        the box wait for it.

        That is not a worst case, it is a measurement.  On 2026-09-06 one
        client was slow to return an NFS read delegation; the holder sat in
        ``__break_lease`` against a 45-second ``lease-break-time``, and 15 of
        dl380g10's 16 loops were in ``locks_lock_inode_wait`` behind it.  The
        box announced nothing for the duration -- offer age climbed past
        ``OFFER_TIMEOUT_S`` -- so a box that was merely waiting was
        indistinguishable, to everything watching, from a box that was gone.

        Refusing instead of waiting keeps every loser on its own poll cadence,
        which is where announcing lives, so the box keeps saying what it is
        while one loop is slow.  There is no timeout here and no deadline
        constant: the poll interval already is the retry.

        The cost is fairness.  A refused loop loses its place -- the kernel's
        FIFO wait queue was the only ordering these loops had -- so under
        steady contention the same fast poller can win repeatedly.  Per-box
        admission throughput is unchanged either way, since it is one critical
        section wide in both designs; what changes is that nobody is ever
        parked in the kernel for a remote filesystem's lease timer.

        Refusing fast is not the same as being narrow, and #351 is the
        difference: while this lock still enclosed the whole of ``_claim``,
        one loop stalled on the mount refused every sibling for the length of
        the stall, and the box claimed nothing at all with ready work waiting
        and its tokens free.  A refusal that arrives instantly is still a
        refusal.  Keep the block short and host-local; anything on the mount
        that does not have to be exclusive between this box's loops belongs
        outside it.
        """

        acquired = False
        try:
            with AdmissionGate(self.ledger).locked():
                acquired = True
                yield
        finally:
            # Diagnostic publication belongs to adaptive policy, not exclusion.
            # The shared gate is released before this advisory operation.
            if acquired:
                adaptive_snapshot.publish(self.base, self.ledger.base / 'adaptive')

    def sample(self):
        if self._sampler is not None:
            return self._sampler()
        path = self.base / 'cpu-sample.json'
        previous = read_json(path)
        # No proc census for each candidate inside the same sampling interval.
        if 0 <= time.time() - previous.get('sampled_unix', 0) < MIN_INTERVAL_S:
            return previous.get('observation', {})
        control_before = control_plane_counters(set(self.cpus))
        current = counters(set(self.cpus))
        if current is None:
            return {}
        current['control_threads'] = control_plane_counters(set(self.cpus))
        # Read after the host counters, on the boot clock a process's start is
        # measured in, and kept with the sample: the next interval's newborn
        # control processes are exactly those that start after it.  Not derived
        # from wall-clock stamps, which a clock step would misalign (#1581).
        current['boot_ticks'] = boot_ticks()
        elapsed = current['sampled_unix'] - previous.get('sampled_unix', 0)
        if 0 <= elapsed < MIN_INTERVAL_S:
            return previous.get('observation', {})
        observation = {}
        if MIN_INTERVAL_S <= elapsed <= MAX_INTERVAL_S and previous.get('cpus', {}).keys() == current['cpus'].keys():
            deltas = [(value[0] - previous['cpus'][key][0],
                       value[1] - previous['cpus'][key][1]) for key, value in current['cpus'].items()]
            psi_delta = current['psi_total'] - previous.get('psi_total', current['psi_total'])
            if all(0 <= busy <= total and total > 0 for busy, total in deltas) and psi_delta >= 0:
                observation = {'sampled_unix': current['sampled_unix'],
                               'busy_cpus': sum(busy / total for busy, total in deltas),
                               'psi_some': min(1., psi_delta / (elapsed * 1e6)),
                               'cpu_count': len(self.cpus), 'interval_s': elapsed,
                               'per_cpu_busy': {key: busy / total for key, (busy, total)
                                                in zip(current['cpus'], deltas)}}
                raw_busy = {key: busy for key, (busy, _) in zip(current['cpus'], deltas)}
                prior_threads = previous.get('control_threads', {})
                born_after = previous.get('boot_ticks')
                if type(born_after) is not int or born_after < 0:
                    born_after = None
                control = attributed_ticks(prior_threads, control_before, raw_busy, kind='control',
                                           born_after=born_after)
                kernel = attributed_ticks(prior_threads, control_before, raw_busy, kind='kernel')
                irq = _irq_ticks(previous.get('irq_cpus'), current.get('irq_cpus'), raw_busy)
                # Thread and IRQ accounting need not be disjoint. Their max
                # is a proven union lower bound, not an invented threshold.
                # Reject incoherent kernel+control credit, retaining the
                # independently valid pre-existing control attribution.
                threaded = {key: control[key] + kernel[key]
                            if control[key] + kernel[key] <= raw_busy[key] else control[key]
                            for key in raw_busy}
                excluded = {key: max(threaded[key], irq[key]) for key in raw_busy}
                observation['control_plane_busy'] = {
                    key: control[key] / total for key, (_, total) in zip(current['cpus'], deltas)}
                observation['kernel_thread_busy'] = {
                    key: kernel[key] / total for key, (_, total) in zip(current['cpus'], deltas)}
                observation['irq_busy'] = {
                    key: irq[key] / total for key, (_, total) in zip(current['cpus'], deltas)}
                observation['system_baseline_busy'] = {
                    key: (excluded[key] - control[key]) / total
                    for key, (_, total) in zip(current['cpus'], deltas)}
                observation['foreign_per_cpu_busy'] = {
                    key: (busy - excluded[key]) / total
                    for key, (busy, total) in zip(current['cpus'], deltas)}
        current['observation'] = observation
        self.write_state('cpu-sample.json', current)
        return observation

    def _funding(self, owner, holders, demand, census):
        """Whether ``owner``'s export allowance covers this dependent (#985).

        Returns ``(funded, None)`` -- the allowance CPUs and memory this
        dependent runs on -- or ``(None, why)``.  Read under the admission
        lock from the holders' metadata, which the holder loop reads anyway;
        a slot is in use while any holder, committed or still acquiring, names
        ``owner`` in ``funded_by``.
        """
        if set(demand) - set(EXPORT_DEMAND) or not int(demand.get('cpu', 0)):
            return None, 'demand_outside_allowance'
        meta_of_owner = census.cpu(owner).metadata
        allowance = meta_of_owner.get('dependent_allowance')
        if not isinstance(allowance, dict):
            return None, 'owner_holds_no_allowance'
        cpus, mem, slots = allowance.get('cpus'), allowance.get('mem_gb'), allowance.get('slots')
        if (not isinstance(cpus, list) or not all(type(c) is int for c in cpus)
                or type(mem) is not int or type(slots) is not int or slots <= 0):
            return None, 'owner_allowance_malformed'
        used, in_use = set(), 0
        for holder in holders:
            if holder.name == owner:
                continue
            meta = census.cpu(holder.name).metadata
            if meta.get('measurement'):
                return None, 'measurement_holder'
            if meta.get('funded_by') == owner:
                in_use += 1
                used.update((meta.get('funded') or {}).get('cpus') or [])
        if in_use >= slots:
            return None, 'allowance_in_use'
        need_cpu, need_mem = int(demand.get('cpu', 0)), int(demand.get('mem_gb', 0))
        spare = [cpu for cpu in cpus if cpu not in used]
        if need_cpu > len(spare) or need_cpu > len(cpus) // slots or need_mem > mem // slots:
            return None, 'demand_exceeds_allowance'
        return {'cpus': spare[:need_cpu], 'mem_gb': need_mem,
                'owner_measurement': bool(meta_of_owner.get('measurement'))}, None

    def decision(self, item, demand, *, identity=None, owner=_UNREAD, allowance=None,
                 foreign_load_exempt=False):
        """Decide under admission; callers may pre-read sealed action identity.

        ``owner`` is the producer a dependent serves, when the caller knows it
        (the pool reads it from the sealed request, outside this lock); left unread it is
        read only if a measurement holds the host (#982).  ``allowance`` is the
        export allowance a producer's claim reserves with itself (#985).
        """
        funding_refusal = None
        measurement_drain = {}
        self.last_decision = {"reason": "not_evaluated"}
        if self._host_sample is None:
            self._host_sample = self.sample()
        sample = self._host_sample
        now = time.time()
        def refuse(reason, **values):
            # The claimant publishes this exact decision after it releases
            # admission.  Do not sample or reread state for diagnostics.
            # A dependent's refusal names its producer, and why its allowance
            # did not cover it, so a starved producer's evidence reads in one
            # place (#985).
            extra = {}
            if owner is not _UNREAD:
                extra['dependent_of'] = owner
            if funding_refusal is not None:
                extra['allowance'] = funding_refusal
            self.last_decision = {"reason": reason, "sample": sample,
                                  **measurement_drain, **extra, **values}
            return None
        fresh = (0 <= now - sample.get('sampled_unix', 0) <= MAX_SAMPLE_AGE_S
                 and sample.get('cpu_count') == len(self.cpus)
                 and all(isinstance(sample.get(key), (float, int)) and math.isfinite(sample[key])
                         for key in ('busy_cpus', 'psi_some', 'interval_s')))
        # There is no system-wide CPU FULL to corroborate "some" with: the
        # kernel records FULL for CPU only under a cgroup, never for
        # psi_system (kernel/sched/psi.c: "the FULL state doesn't exist for the
        # CPU resource at the system level"; the system root's state mask omits
        # PSI_CPU_FULL).  So the corroboration is the occupancy the sampler
        # already keeps per CPU.  The host-wide saturation gate is unchanged and
        # stands alone; what follows only decides whether a high "some" reading
        # is this action's problem or a pinned neighbour's local contention.
        # A RAM fill's host memory hold (#1222) is a mirror of tmpfs bytes, not
        # an action: it holds ``mem_gb`` tokens, which the ledger already
        # counts, and runs nothing on a CPU.  Read as a holder it has no
        # declared CPU and non-empty content, so it refused every row on the
        # storage host as ``holder_reservation_unknown`` (#1260).
        census = HolderCensus(self.ledger.held_dir, read_json)
        holders = list(census.non_mirror_holders)
        # Resolved once, before the pressure decision reads the demand.  The
        # caller may have pre-read the sealed identity, and the measurement and
        # ownership paths below all need the same answer rather than a second
        # read of the same CAS record.
        shape, measurement = action_identity(item) if identity is None else identity
        declared = int(demand.get('cpu', 0))
        unbounded_cpu = not declared
        # Measurements, unbounded demand and full-width reservations need the
        # host idle.  "Idle" is judged against the host's own idle history
        # (#997), which every fresh decision feeds, not a fixed fraction of
        # the CPUs that housekeeping alone can cross.
        idle = (self.idle(sample, holders) if fresh else
                {'state': 'sample_not_fresh', 'exceeds': True})
        exclusive_need = measurement or unbounded_cpu or declared == len(self.cpus)
        ambient = (self._measurement_foreign_ambient(sample, holders, declared)
                   if measurement and fresh else None)
        if ambient is not None and ambient['clear']:
            # Affirmative, complete attribution can retire a historical
            # foreign-load veto. Missing/stale/partial readings cannot.
            measurement_drain = {'measurement_pool_drain': {
                'foreign_clear': True, 'sampled_unix': sample['sampled_unix'],
                **ambient['evidence']}}
        if isinstance(owner, str) and not measurement:
            # A dependent runs on the room its producer reserved (#985).  Host
            # pressure is not its gate: its CPUs are reserved, so nothing the
            # pool admits runs there, and the pressure its producer makes on
            # its own CPUs is the producer's.  No free token is taken.
            funded, funding_refusal = self._funding(owner, holders, demand, census)
            if funded is not None:
                serves_measurement = funded.pop('owner_measurement')
                self.last_decision = {"reason": "admitted_on_allowance", "sample": sample,
                                      "dependent_of": owner}
                return {'declared_cpu': int(demand.get('cpu', 0)),
                        'cost': float(int(demand.get('cpu', 0))), 'shape': shape,
                        'unbounded_cpu': False, 'measurement': False,
                        'serves_measurement': owner if serves_measurement else None,
                        'funded_by': owner, 'funded': funded, 'admitted_unix': now,
                        'preferred_borrow': 0, 'sampled_unix': sample.get('sampled_unix', 0),
                        'borrowing': False, 'host_busy_cpus': sample.get('busy_cpus'),
                        'host_psi_some': sample.get('psi_some'),
                        'active_cpu_cost': 0., 'pending_cpu_cost': 0., 'borrowable_cpus': []}
        if fresh and sample['busy_cpus'] >= .95 * len(self.cpus):
            return refuse("host_pressure", fresh=fresh)
        # True only when a high "some" was believed because the CPUs this
        # claim would actually be given are idle.  It keeps the proof and the
        # claim's real selection in step: the lending path below can hand a
        # claim a *held* CPU, which that proof never saw.
        pressure_override = False
        eligible_cpus = None
        # The exclusive needs are judged on PSI by the idle baseline below,
        # which carries ``psi_some``: a pinned neighbour's local contention, or
        # the host's own housekeeping, is not a reason to refuse them unless it
        # is above what this host shows while idle (#997).
        full_width = declared == len(self.cpus) and not measurement and not unbounded_cpu
        if fresh and sample['psi_some'] >= .10 and (
                not exclusive_need or (full_width and holders)):
            # System-wide CPU PSI "some" counts any task anywhere waiting for a
            # CPU, so one job pinned to a few cores with more runnable threads
            # than cores holds it high while most of the box is idle (measured:
            # 0.63 with 6.7 of 80 cores busy).  It is believed only when the
            # CPUs this claim would actually be given are not idle.
            #
            # "Would actually be given" is the ledger's own rule, not a count:
            # ``begin_acquire`` takes the first ``need`` eligible free tokens
            # in ledger order, and ``cpu_allocation`` maps a token
            # ordinal through ``preferred + fallback`` -- the ordinal is NOT a
            # CPU ID, so tiers such as preferred [8, 10] / fallback [2, 4] make
            # token 0 CPU 8.  Held CPUs come from ``cpu_allocation`` as well,
            # which is what carries a borrowed allocation recorded in the
            # holder's metadata.  Anything unreadable or out of range is
            # unknown, and unknown refuses rather than being read as idle.
            per_cpu = sample.get('per_cpu_busy')
            if (not isinstance(per_cpu, dict)
                    or set(per_cpu) != {str(cpu) for cpu in self.cpus}
                    or any(type(busy) not in (int, float) or not math.isfinite(busy)
                           or busy < 0 or busy > 1 for busy in per_cpu.values())):
                return refuse("host_pressure_unproven", fresh=fresh)
            if full_width:
                # Beside holders the baseline cannot say what is foreign, so
                # a full-width reservation keeps the pre-#997 refusal under
                # pressure; a learned cheap cost and an all-zero reading do
                # not reopen it.
                return refuse("host_pressure", fresh=fresh)
            # Raw occupancy remains the saturation/projected-cost gate. Only
            # verified control-thread work is not *foreign* load (#1210).
            # Old samples have no attribution and retain their conservative
            # raw interpretation during a rolling upgrade.
            foreign_cpu = sample.get('foreign_per_cpu_busy', per_cpu)
            if (not isinstance(foreign_cpu, dict) or set(foreign_cpu) != set(per_cpu)
                    or any(type(value) not in (int, float) or not math.isfinite(value)
                           or not 0 <= value <= per_cpu[cpu] for cpu, value in foreign_cpu.items())):
                return refuse('host_pressure_unproven', fresh=fresh)
            held = set()
            for holder in holders:
                allocation = self.ledger.cpu_allocation(holder.name, self.tiers)
                held.update(allocation['preferred'] + allocation['fallback'])
            # A verified publication canary crosses foreign load (#1239):
            # its verdict is correctness-only -- receipts, envelopes, bitwise
            # equality -- so foreign CPU load cannot corrupt it, only delay
            # it, and that delay is the boundary loss.  Held CPUs stay
            # ineligible either way: a held CPU is token accounting, not
            # load, and the canary still needs its free tokens.
            eligible_cpus = [cpu for cpu in self.cpus if cpu not in held
                             and (foreign_load_exempt
                                  or foreign_cpu[str(cpu)] <= IDLE_BUSY_FRACTION)]
            predicted = self._predicted_cpus(declared, eligible_cpus=eligible_cpus)
            eligible_proven = predicted is not None
            if predicted is None:
                # Keep the existing held/foreign denial evidence when there
                # isn't enough eligible room. Never wait on the first busy
                # token when a later idle one can satisfy this whole claim.
                predicted = self._predicted_cpus(declared)
            if predicted is None:
                return refuse("host_pressure_unproven", fresh=fresh)
            # Held and foreign are recorded apart (#1160): a CPU a pool holder
            # holds is cleared by that holder draining, which the claim path
            # may withhold the box for; a busy CPU no holder holds is load the
            # pool does not own, which no drain clears.
            held_busy = sorted(cpu for cpu in predicted if cpu in held)
            foreign_busy = sorted(cpu for cpu in predicted if cpu not in held
                                  and foreign_cpu[str(cpu)] > IDLE_BUSY_FRACTION)
            if foreign_load_exempt:
                # #1239: the exemption's own half.  The foreign split stays
                # in the evidence, but only held CPUs refuse the exempted
                # probe; every other gate above -- raw saturation, unproven
                # evidence, the GPU side -- already stood.
                busy = held_busy
            else:
                busy = sorted(held_busy + foreign_busy)
            if busy:
                return refuse("host_pressure", fresh=fresh, cpus=busy[:8],
                              held_cpus=held_busy, foreign_cpus=foreign_busy)
            if not eligible_proven:
                return refuse('host_pressure_unproven', fresh=fresh)
            pressure_override = True
        # With holders present the sample measures them too: above the
        # host's idle history it refuses here, as the fixed line did, and
        # otherwise the holder loop below refuses the measurement
        # ``measurement_holder`` (naming ``isolated_by``, #982).
        if measurement and not fresh:
            # Unknown telemetry is not idle, foreign load, or evidence that
            # PB's holders prevent the measurement. Refuse the measurement
            # without reserving a drain for sampler silence (#1317).
            return refuse("measurement_sampler_unknown", fresh=False, baseline=idle,
                          sample_max_age_s=MAX_SAMPLE_AGE_S)
        if measurement:
            idle_refusal = self._measurement_idle_refusal(sample, idle, ambient)
            if idle_refusal is not None:
                evidence = (ambient['evidence']
                            if idle_refusal == 'measurement_foreign_ambient'
                            and ambient is not None else {})
                return refuse(idle_refusal, fresh=fresh, baseline=idle, **evidence)
        if full_width and fresh and not holders and idle['exceeds']:
            # A reservation of every CPU needs the host idle too.
            return refuse("host_pressure", fresh=fresh, baseline=idle)
        if len(holders) >= MAX_ACTIONS:
            return refuse("max_actions", holders=len(holders))
        # Legacy producers sometimes reserved only GPU/memory. Their children
        # inherit the whole worker affinity, so zero tokens are unknown CPU
        # use, never evidence of zero use. Keep that historical demand intact
        # but serialize it on a freshly idle host until the producer declares
        # an enforceable CPU allocation.
        if unbounded_cpu and (holders or not fresh or idle['exceeds']):
            return refuse("unbounded_cpu_not_exclusive", holders=len(holders), fresh=fresh,
                          baseline=idle)
        profiles = read_json(self.base / 'profiles.json')
        recent = read_json(self.base / 'jobs.json')
        next_recent = {}
        serves = None
        pending = 0.
        lendable = False
        lending_cpus = set()
        protected_cpus = set()
        active_cost = 0.
        for holder in holders:
            reservation = census.cpu(holder.name)
            meta = reservation.metadata
            physical = reservation.physical_cpu_count
            reserved = meta.get('declared_cpu', physical)
            if not reserved:
                if meta or reservation.has_contents:
                    return refuse("holder_reservation_unknown", holder=holder.name)
                continue
            if measurement:
                # ``isolated_by`` names a measurement already holding the host,
                # if any: the claim path must not withhold the box against
                # that measurement's own dependents (#982).
                isolated = holder.name if meta.get('measurement') else next(
                    (other.name for other in holders
                     if census.cpu(other.name).metadata.get('measurement')), None)
                return refuse("measurement_holder", holder=holder.name,
                              isolated_by=isolated, fresh=fresh)
            if meta.get('measurement'):
                # A measurement's own spool exports run under its isolation;
                # everything else waits (#982).  Read only here, where a
                # measurement holds the host: this path used to refuse every
                # sibling, so the one CAS read it adds under the lock is paid
                # only while nothing else could be admitted anyway.
                if owner is _UNREAD:
                    owner = dependent_owner(item)
                if owner != holder.name:
                    return refuse("measurement_holder", holder=holder.name,
                                  isolated_by=holder.name)
                serves = holder.name
            # ``self.base`` rather than ``local_telemetry_path``: that helper
            # resolves the ledger path, which is three stats on the mount per
            # call, and this loop runs once per holder under the lock.
            record = read_json(self.base / 'telemetry' / f'{holder.name}.json')
            valid = (record.get('complete') is True
                     and 0 <= now - record.get('sampled_unix', 0) <= MAX_SAMPLE_AGE_S
                     and record.get('sampled_unix', 0) >= meta.get('admitted_unix', now)
                     and record.get('action_key', holder.name) == holder.name
                     and all(type(record.get(k)) in (int, float) and math.isfinite(record[k]) and record[k] >= 0
                             for k in ('cpu_seconds', 'wall_seconds')))
            previous = recent.get(holder.name, {})
            if (previous.get('nonce') != record.get('nonce')
                    or previous.get('sampled_unix', 0) < meta.get('admitted_unix', now)):
                previous = {}
            cpu = None
            if valid:
                wall_delta = record['wall_seconds'] - previous.get('wall_seconds', record['wall_seconds'])
                cpu_delta = record['cpu_seconds'] - previous.get('cpu_seconds', record['cpu_seconds'])
                if MIN_INTERVAL_S <= wall_delta <= MAX_INTERVAL_S and cpu_delta >= 0:
                    cpu = cpu_delta / wall_delta
                    record['_cpu'] = cpu
                    next_recent[holder.name] = record
                    # Measurements are never learned from (``record_completion``);
                    # one is read here only beside its own dependents (#982).
                    if meta.get('shape') and not meta.get('measurement'):
                        old = profiles.get(meta['shape'], {})
                        # Decay slowly; increases apply immediately. A changed
                        # phase must promptly undo a previous cheap estimate.
                        profiles[meta['shape']] = {**old, 'cpu': max(cpu * 1.25, old.get('cpu', cpu) * .98),
                                                   'sampled_unix': now,
                                                   'samples': min(1000, old.get('samples', 0) + 1),
                                                   'memory_peak_bytes': max(record.get('memory_peak_bytes', 0),
                                                                            old.get('memory_peak_bytes', 0))}
                elif 0 <= wall_delta < MIN_INTERVAL_S and previous:
                    next_recent[holder.name] = previous
                    if 0 <= now - previous.get('sampled_unix', 0) <= MAX_SAMPLE_AGE_S:
                        cpu = previous.get('_cpu')
                else:
                    next_recent[holder.name] = record
            cost = float(reserved) if cpu is None else max(.05, cpu * 1.25)
            # Pass the metadata already read; an absent or unreadable file keeps
            # the ledger's own read and its own refusal on a torn record.
            allocation = self.ledger.cpu_allocation(holder.name, self.tiers, metadata=meta or None)
            assigned = set(allocation['preferred'] + allocation['fallback'])
            # A measurement's CPUs are never lent, not even to its own
            # dependents (#982): they are admitted beside it, on free tokens.
            # Nor are CPUs a dependent runs on from its producer's allowance
            # (#985): they are the producer's reservation, not idle credit.
            if (cpu is not None and meta.get('shape') and not meta.get('measurement')
                    and not meta.get('funded_by') and cost < reserved):
                lending_cpus.update(assigned)
            else:
                protected_cpus.update(assigned)
            active_cost += cost
            # Host busy already includes samples ending before this reading.
            # Charge startup/unknown attribution in full to avoid spending the
            # same headroom in concurrent admissions.
            if cpu is None:
                pending += cost
            elif (meta.get('shape') and not meta.get('measurement')
                  and not meta.get('funded_by') and cost < reserved):
                lendable = True
        self.write_state('jobs.json', next_recent)
        profiles = dict(sorted(profiles.items(), key=lambda x: x[1].get('sampled_unix', 0))[-512:])
        self.write_state('profiles.json', profiles)
        learned = profiles.get(shape, {}) if shape else {}
        learned_valid = (learned.get('samples', 0) >= 3
                         and 0 <= now - learned.get('sampled_unix', 0) < 86400)
        cost = (float(len(self.cpus)) if unbounded_cpu else
                max(.05, min(float(declared), learned['cpu'])) if learned_valid else float(declared))
        # A solitary full-width reservation must not wait forever for every
        # background daemon to consume exactly zero CPU. The fresh idle-host
        # test permits only incidental activity, never real foreign load or a
        # competing reservation; PSI pressure was refused before this point.
        full_width_idle = (fresh and not holders and declared == len(self.cpus)
                           and not idle['exceeds'])
        # Unbounded legacy work already proved the same exclusive idle host.
        if (fresh and not unbounded_cpu and not full_width_idle
                and max(sample['busy_cpus'] + pending, active_cost) + cost > len(self.cpus) + .01):
            return refuse("projected_cpu_cost", pending_cpu_cost=pending,
                          active_cpu_cost=active_cost, requested_cpu_cost=cost)
        available = self.ledger.available().get('cpu', 0)
        borrowable = lending_cpus - protected_cpus
        can_borrow = fresh and shape and not measurement and lendable
        preferred_borrow = (min(max(0, declared - self.ledger.free_preferred(self.tiers)),
                                len(borrowable & set(self.tiers['preferred'])))
                            if can_borrow else 0)
        borrowing = available < declared or preferred_borrow > 0
        if pressure_override:
            # The override above was earned by the CPUs this claim's own free
            # tokens map to.  A borrowed CPU is different evidence: it is a
            # *held* reservation judged idle from its holder's telemetry, not
            # from the fresh sample that proof read, so the proof does not
            # cover it -- and a borrowed CPU can be busy right now while its
            # holder's average still reads cheap.  Rather than extend the proof
            # to a CPU it never saw, the lending path is closed for this one
            # decision: the claim is still admitted when ordinary free tokens
            # cover its demand.  Ordinary borrowing, taken when no pressure
            # override is in play, is unchanged.
            if available < declared:
                return refuse("pressure_override_no_borrow",
                              available_cpu=available, declared_cpu=declared)
            can_borrow, preferred_borrow = False, 0
            borrowable = set()
            borrowing = False
        if borrowing:
            last = read_json(self.base / 'last-borrow.json').get('sampled_unix', 0)
            authorized = (fresh and shape and not measurement and lendable
                          and len(borrowable) >= declared - available
                          and sample['sampled_unix'] > last)
            if not authorized and available >= declared:
                # A preferred borrow is a placement preference, not a need:
                # free tokens already cover the demand.  When the borrow cannot
                # be authorized -- most often because this sample's one borrow
                # was already spent -- the claim takes its free tokens instead
                # of being refused.  Where those land on fallback CPUs, the
                # claim path's bounded ``deferred_for_preferred_cpu`` decides
                # whether to wait for a preferred one; a refusal here cost one
                # sample interval per item for nothing (#924).
                preferred_borrow, borrowing = 0, False
            elif not authorized:
                return refuse("borrow_evidence_unavailable", fresh=fresh, shape=shape,
                              lendable=lendable, available_cpu=available,
                              declared_cpu=declared, borrowable_cpus=len(borrowable),
                              last_borrow_sampled_unix=last)
        self.last_decision = {"reason": "admitted", "sample": sample, **measurement_drain}
        return {'declared_cpu': declared, 'cost': cost, 'shape': shape,
                'unbounded_cpu': unbounded_cpu,
                'measurement': measurement, 'serves_measurement': serves,
                'dependent_allowance': dict(allowance) if allowance else None,
                # What an exclusive admission was judged idle against, so
                # measurements can be compared on the baselines they ran on.
                'idle_baseline': idle if exclusive_need and fresh else None,
                'admitted_unix': now,
                'preferred_borrow': preferred_borrow,
                'eligible_cpus': eligible_cpus,
                'sampled_unix': sample.get('sampled_unix', 0), 'borrowing': borrowing,
                'host_busy_cpus': sample.get('busy_cpus'), 'host_psi_some': sample.get('psi_some'),
                'active_cpu_cost': active_cost, 'pending_cpu_cost': pending,
                'borrowable_cpus': sorted(borrowable, key=lambda c: sample.get('per_cpu_busy', {}).get(str(c), 0.))}

    def admitted(self, metadata):
        """Spend the sample's borrow freshness; answer what it replaced."""
        if not metadata.get('borrowing'):
            return None
        previous = read_json(self.base / 'last-borrow.json')
        metadata['borrow_id'] = uuid.uuid4().hex
        self.write_state('last-borrow.json', {
            'sampled_unix': metadata['sampled_unix'], 'borrow_id': metadata['borrow_id']})
        return previous

    def withdrew(self, metadata, previous):
        """Give the freshness back when the claim it was spent on never happened.

        A borrowing decision is spent at the decision, not at the rename, so a
        claimant that loses the rename has already consumed the sample.  It
        never used it: its tokens went back and no borrowed CPU was ever
        occupied, so keeping the record would refuse the retry that the lost
        race is supposed to allow.

        Only while the record is still this decision's own.  A newer borrow
        that landed in between owns it now, and writing an older sample over
        that one would let the newer sample authorize a second borrow -- the
        one thing ``admitted`` exists to prevent.  So this is a
        compare-and-set, and it belongs under the same lock as ``admitted``.
        """
        if not metadata.get('borrowing'):
            return
        # A host sample can be returned and borrowed again. Its timestamp is
        # not the owner of that later borrow. Retire this caller's authority
        # before I/O too: a write followed by an exception is still a return.
        borrow_id = metadata.pop('borrow_id', None)
        if not borrow_id:
            return
        current = read_json(self.base / 'last-borrow.json')
        if (current.get('borrow_id') != borrow_id
                or current.get('sampled_unix') != metadata.get('sampled_unix')):
            return
        self.write_state('last-borrow.json', previous or {})


def learn_export(ledger, template_sha256, owner, published_unix, landing_s, family=None):
    """Remember one landed export of ``template_sha256`` (#999), under the
    ``family`` its template declares when it declares one (#1126).

    ``landing_s`` is the export's own wall time; ``published_unix`` its row's
    publication, whose gap from the same producer's previous export is one
    group spacing.  Kept per :func:`export_rate_key`, ``EXPORT_RATE_MEMORY``
    of each, under the admission lock and never waited for: a busy box learns
    it next time.  Nothing is learned without a key.
    """
    key = export_rate_key(template_sha256, family)
    if (key is None or not _is_key(owner)
            or not all(type(v) in (int, float) and math.isfinite(v) and v > 0
                       for v in (published_unix, landing_s))):
        return False
    tiers = read_json(ledger.base / 'cpu-map.json')
    if not tiers:
        return False
    controller = Controller(ledger, tiers)
    try:
        with controller.locked():
            rates = read_json(controller.base / EXPORT_RATES)
            entry = dict(rates.get(key) or {})
            last = dict(entry.get('last_published') or {})
            previous = last.get(owner)
            if type(previous) in (int, float) and published_unix <= previous:
                return False
            if type(previous) in (int, float):
                entry['spacing_s'] = (list(entry.get('spacing_s', []))
                                      + [published_unix - previous])[-EXPORT_RATE_MEMORY:]
            entry['landing_s'] = (list(entry.get('landing_s', []))
                                  + [landing_s])[-EXPORT_RATE_MEMORY:]
            last[owner] = published_unix
            entry['last_published'] = dict(sorted(last.items(), key=lambda x: x[1])[-EXPORT_RATE_MEMORY:])
            entry['learned_unix'] = time.time()
            rates[key] = entry
            rates = dict(sorted(rates.items(), key=lambda x: x[1].get('learned_unix', 0))[-512:])
            controller.write_state(EXPORT_RATES, rates)
    except AdmissionBusy:
        return False
    return True


def record_completion(ledger, item, telemetry):
    """Learn short actions from final attributed totals before they disappear.

    The scope owner calls this with its final complete sample. This path never
    grants a reservation; live admission still requires fresh host headroom and
    a fully attributed donor. Failure to attribute produces no learned credit.
    """
    now = time.time()
    if (telemetry.get('complete') is not True
            or telemetry.get('action_key') != item.get('action_key')
            or not 0 <= now - telemetry.get('sampled_unix', 0) <= MAX_SAMPLE_AGE_S
            or telemetry.get('sampled_unix', 0) < item.get('claimed_unix', 0)
            or not all(type(telemetry.get(k)) in (int, float)
                       and math.isfinite(telemetry[k]) and telemetry[k] >= 0
                       for k in ('cpu_seconds', 'wall_seconds', 'memory_peak_bytes'))
            or telemetry['wall_seconds'] <= 0):
        return False
    shape, measurement = action_identity(item)
    tiers = read_json(ledger.base / 'cpu-map.json')
    if not shape or measurement or not tiers:
        return False
    controller = Controller(ledger, tiers)
    # Learning a shape is worth having and never worth waiting for.  This runs
    # on a scope owner that has just finished its action, so blocking here
    # would hold that process open on another loop's NFS latency -- and this
    # function's own contract already covers the outcome: failure to attribute
    # produces no learned credit.  A busy box learns this shape the next time
    # an action of it completes.
    #
    # The whole read-modify-write stays inside the lock; nothing within it
    # locks again, so the handler can only be catching this box's own refusal
    # to wait.
    try:
        with controller.locked():
            profiles = read_json(controller.base / 'profiles.json')
            previous = profiles.get(shape, {})
            completion_id = hashlib.sha256(json.dumps([item['action_key'], telemetry.get('nonce', item.get('claimed_unix'))]).encode()).hexdigest()
            completed = previous.get('completions', [])
            if completion_id in completed:
                return False
            cpu = telemetry['cpu_seconds'] / telemetry['wall_seconds']
            profiles[shape] = {'completions': (completed + [completion_id])[-32:], 'cpu': max(cpu * 1.25, previous.get('cpu', cpu) * .98),
                               'sampled_unix': now,
                               'samples': min(1000, previous.get('samples', 0) + 1),
                               'memory_peak_bytes': max(telemetry['memory_peak_bytes'],
                                                        previous.get('memory_peak_bytes', 0))}
            profiles = dict(sorted(profiles.items(), key=lambda x: x[1].get('sampled_unix', 0))[-512:])
            controller.write_state('profiles.json', profiles)
    except AdmissionBusy:
        return False
    return True
