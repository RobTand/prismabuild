"""Advance credits: fenced room for one admissible next step per window.

A window holds its current ranges (pinned) and waits on its next ranges.  Two
windows that each fit alone can wedge jointly: the second current lands in the
room the first advance needed, and no eviction, claim, or sweep relieves it
(see the hold-and-wait fixture).  Ordinary admission control cannot fix this
at publish time alone either: a publish reserves nothing, so unrelated claims
can steal the room a protected advance was counted on between its retire and
its claim.

An advance credit is that room made real: tokens for one next step, held in
the EXISTING tier ``ResourceLedger`` under a deterministic grant key, then
transferred to the next mover with the existing ``transfer`` when its row
publishes.  No second scheduler, no capacity database, no new ledger: holds,
ready grants, and pins are all read off the one ledger every cycle, and the
single writer per tier (the tier loop owning that ``tier_id``) is the only
boundary -- per-consumer transition locks keep their existing file-transition
role and never fence shared obligations.

Lifecycle (see the design note's state table): UNFUNDED (gate alone) ->
RESERVED (``acquire`` under the grant key, bound to tier/consumer/plan/mover/
range/generation/publication) -> TRANSFERRING (fence moved under the mover
without a free interval) -> CONSUMED (the mover's claim counted it toward its
demand and fused the binding shut) or RELEASED.  A funded claim takes only
the remainder from free, so exact-fit advances fence and stay protected from
stealers -- there is no gate-only exception and no double charge.  Replenish
reads safe-retire evidence (staged-held or egress-done predecessors), never
the progress counter.  Unknown ledger/ready/pin evidence defers new grants
with the unreadable record named.

Explicit funding-record state table (``tier-funding/<mover>.<tier>.json``,
one generation per file, binding immutable per generation -- only ``state``
advances, via compare-and-swap on ``generation``):

================  ============================================================
state             meaning / who may move it
================  ============================================================
``reserved``      Fence held under the ``advance-`` grant key; coordinator
                  owns it.  May advance to ``transferring`` (fence moved
                  under the mover, no free interval) or ``released``.  A
                  fresh reservation never edits one: it mints a new
                  generation instead, so a verifying claim's pin cannot be
                  pulled out from under it.
``transferring``  Fence held under the mover key, awaiting its claim.  Only
                  this state authorizes the claim path to subtract named
                  tokens (verified by name, kind prefix, tier, mover,
                  ``published_unix``, sealed residency range, and live
                  consumer/plan digest).  May advance to ``consumed`` (the
                  claim persisted, then fused the binding shut) or
                  ``released``.
``consumed``      Terminal: the claim counted this fence.  Never advances,
                  never authorizes a second subtraction.  A later need
                  fences afresh under a new generation.
``released``      Terminal: the fence went home (cancel, supersede,
                  terminal mover, stale binding).  Never advances.
================  ============================================================

Claim durability ordering (the partial-failure rule): the claim verifies
every funding pre-persistence (read-only, against the renamed record) and
marks ``consumed`` only after the claim and lease are durable.  Marking
tier1 then failing tier2 -- or failing persistence itself -- leaves every
record ``transferring`` for the next attempt to re-verify: a recoverable
entitlement, never consumed-but-no-executable-claim stranded credit.  A
mark left ``transferring`` under an already-executable claim is closed by
the mover-terminal settle on finish, never by a second subtraction.

Fairness reuses claim-poll order (the queue's own scan order); the key
tiebreak is determinism only.  No unbounded starvation-freedom claim.
"""

from __future__ import annotations

from collections import deque
from collections.abc import Iterable, Mapping
import hashlib
import math

#: Grant holder prefix.  Never ``claiming.*`` (transfer refuses those) and
#: never 64-hex (cannot collide with content-hashed action keys).
GRANT_PREFIX = "advance-"

#: Typed reasons on gated/stalled decisions.  ``joint-fit-oversize`` is
#: permanent (``unsupported-workset`` semantics); the rest are transient waits
#: naming what must retire.
REASON_STALL = "joint-fit-stall"
REASON_OVERSIZE = "joint-fit-oversize"
REASON_UNFUNDED = "advance-credit-unfunded"
REASON_DEFER_UNKNOWN = "advance-deferred-unknown-evidence"
#: A newcomer whose read footprint does not fit beside what the tier has
#: already committed to its admitted windows (#907).  Transient: it waits
#: for those windows to finish, and no eviction can admit it.
REASON_COMMITMENT = "joint-commitment-stall"
#: A declared consumer whose prelaunch group is not held yet waits for room
#: (#1594).  Transient: the group lands, then the window publishes.
REASON_PRELAUNCH_WAIT = "prelaunch_waiting_for_room"


def prelaunch_obligation_gib(peak_gib: int, owned_gib: int) -> int:
    """Tokens an admitted declared window still obliges on one tier (#1594).

    Peak minus owned, never below zero.  Owned falls as suffix chunks
    retire, so the room the next suffix phase needs stays reserved.
    Refuses negative inputs.
    """

    if peak_gib < 0 or owned_gib < 0:
        raise ValueError(
            f"prelaunch GiB must not be negative: {peak_gib!r}, {owned_gib!r}")
    return max(0, peak_gib - owned_gib)


def prelaunch_footprint_gib(peak_gib: int, owned_gib: int) -> int:
    """Tokens a declared newcomer still needs to reserve on one tier (#1594).

    The same remainder as the obligation: the peak minus what the unit
    already owns.  The gate counts it beside admitted obligations.
    Refuses negative inputs.
    """

    if peak_gib < 0 or owned_gib < 0:
        raise ValueError(
            f"prelaunch GiB must not be negative: {peak_gib!r}, {owned_gib!r}")
    return max(0, peak_gib - owned_gib)


#: The note on a decision that counted no produced-output obligation.  The
#: tier loop counts a producer's unheld window (``produced_output.
#: unheld_window_gib``) only when it runs with ``--output-windows`` (#747);
#: otherwise the obligation is zero and every decision carries this note.
#: Never an estimate.
OUTPUT_UNENFORCED_NOTE = "output-scope-unenforced"


def grant_key(consumer_action_key: str, tier_id: str, leg: str,
              phase: str, chunk_index: int | None = None) -> str:
    """Deterministic fence holder for one consumer's next advance on one tier.

    ``leg`` is the mover role (``mover_row``/``ram_mover_row``).  The phase
    digest keeps arbitrary manifest phase names out of holder directory names.
    """

    digest = hashlib.sha256(str(phase).encode("utf-8")).hexdigest()[:12]
    key = (f"{GRANT_PREFIX}{str(consumer_action_key)[:16]}-"
           f"{str(tier_id).split(':')[0][:24]}-{str(leg)}-{digest}")
    if chunk_index is not None:
        key += f"-c{int(chunk_index)}"
    return key


def gate_newcomer(*, held_gib: int, ready_gib: int, output_gib: int,
                  capacity_gib: int | None, cur_min_gib: int,
                  next_min_gib: int | None,
                  existing_min_next_gib: int,
                  output_enforced: bool = False) -> dict[str, object]:
    """Whether a window's first step may publish against shared room.

    ``held_gib`` counts every held token on the tier (movers, grants, pins --
    one ledger, no exceptions); ``ready_gib`` counts queued-but-unclaimed
    tier demands that will commit on claim.  Minimum admission covers the
    lead (``cur_min_gib``) AND the protected next (``next_min_gib``) under
    their actual overlapping lifetime, plus the already-admitted minimum
    next: a second current may not land in the room the first advance was
    promised.  A final window (``next_min_gib=None``) needs no future credit.
    ``capacity_gib=None`` is unknown capacity and always defers.  A minimum
    that exceeds capacity with no unrelated obligations held, queued, owed,
    or protected is permanent (nothing can retire into room); any obligation
    keeps the stall transient.  ``output_gib`` is the produced-output
    obligation nobody holds yet; ``output_enforced`` says it was counted,
    and clears the unenforced note on the decision.
    """

    note = "" if output_enforced else OUTPUT_UNENFORCED_NOTE
    if capacity_gib is None:
        return {"admit": False, "reason": REASON_DEFER_UNKNOWN,
                "permanent": False, "output_note": note}
    if cur_min_gib > capacity_gib:
        return {"admit": False, "reason": REASON_OVERSIZE, "permanent": True,
                "output_note": note}
    total = (held_gib + ready_gib + output_gib + cur_min_gib
             + (next_min_gib or 0) + existing_min_next_gib)
    if total <= capacity_gib:
        return {"admit": True, "reason": "", "output_note": note}
    if (held_gib + ready_gib + output_gib + existing_min_next_gib == 0
            and cur_min_gib + (next_min_gib or 0) > capacity_gib):
        # Permanent unsupported workset, not an endless transient: nothing
        # is held, queued, owed, or protected that any retirement could
        # return, so the minimum overlapping lifetime (lead plus protected
        # next under it) can never fit however long the window waits.  Any
        # unrelated obligation at all keeps the transient stall instead.
        return {"admit": False, "reason": REASON_OVERSIZE, "permanent": True,
                "output_note": note}
    return {"admit": False, "reason": REASON_STALL, "permanent": False,
            "output_note": note}


def gate_commitment(*, committed_gib: int, growth_gib: int,
                    capacity_gib: int, lone: bool) -> dict[str, object]:
    """Whether a newcomer's read footprint fits beside the tier's commitments (#907).

    ``committed_gib`` is what the tier has promised already: every token
    nothing can evict, queued new money, the unheld produced-output windows,
    and each admitted window's growth from what it holds to its read
    footprint.  ``growth_gib`` is the newcomer's own growth.  Admitted when
    the two fit ``capacity_gib``.

    Otherwise admitted only ``lone``: when nothing else on the tier will
    ever ask it for more room -- no other admitted window, no owed output,
    no other queued demand.  What remains committed then is holders that
    never grow, so the newcomer contends only with itself: its window runs
    short of its footprint, as every window did before this gate, and a
    refusal would be one no later cycle could lift.  The joint-fit gate
    still decides whether it fits at all.
    """

    if committed_gib + growth_gib <= capacity_gib:
        return {"admit": True, "reason": "", "lone": False}
    if lone:
        return {"admit": True, "reason": "", "lone": True}
    return {"admit": False, "reason": REASON_COMMITMENT, "permanent": False,
            "lone": False}


def joint_need_gib(needs: Mapping[str, int],
                   reach: Mapping[str, Iterable[str]],
                   caps: Mapping[str, int]) -> int:
    """The most tier GiB some windows can want at once, over shared ranges (#1093).

    ``needs`` is each window's most at once (the larger of its read
    footprint and its holding), ``reach`` the ranges each can still hold
    (every leg of a phase it has still to read), and ``caps`` each range's
    GiB.  At any moment each window holds at most its need, of ranges it
    can reach, and a range held by several windows is one copy; so what
    they hold between them is a flow from windows to ranges under both
    bounds, and this is the maximum such flow.

    Windows that share no range get the sum of their needs, capped by what
    each can reach.  Windows that share every range they can reach get at
    most those ranges once.  Ranges with the same readers are merged first,
    so the network has one node per window and one per distinct reader set,
    and a plural readers' plan collapses to a few nodes however many
    phases it has.
    """

    members = [key for key in sorted(needs) if int(needs[key]) > 0]
    readers: dict[str, set[str]] = {}
    for key in members:
        for item in reach.get(key, ()):
            readers.setdefault(str(item), set()).add(key)
    groups: dict[tuple[str, ...], int] = {}
    for item, keys in readers.items():
        cap = max(0, int(caps.get(item, 0)))
        if cap:
            signature = tuple(sorted(keys))
            groups[signature] = groups.get(signature, 0) + cap
    if not groups:
        return 0
    # Nodes: 0 source, 1 sink, then one per window, then one per group.
    node = {key: 2 + offset for offset, key in enumerate(members)}
    residual: list[dict[int, int]] = [
        {} for _ in range(2 + len(members) + len(groups))]

    def edge(tail: int, head: int, cap: int) -> None:
        residual[tail][head] = residual[tail].get(head, 0) + cap
        residual[head].setdefault(tail, 0)

    unbounded = sum(int(needs[key]) for key in members) + 1
    for key in members:
        edge(0, node[key], int(needs[key]))
    for offset, (signature, cap) in enumerate(sorted(groups.items())):
        group = 2 + len(members) + offset
        edge(group, 1, cap)
        for key in signature:
            edge(node[key], group, unbounded)
    flow = 0
    while True:
        parent: dict[int, int] = {0: 0}
        frontier = deque([0])
        while frontier and 1 not in parent:
            tail = frontier.popleft()
            for head, cap in residual[tail].items():
                if cap > 0 and head not in parent:
                    parent[head] = tail
                    frontier.append(head)
        if 1 not in parent:
            return flow
        push, head = unbounded, 1
        while head:
            push = min(push, residual[parent[head]][head])
            head = parent[head]
        head = 1
        while head:
            tail = parent[head]
            residual[tail][head] -= push
            residual[head][tail] += push
            head = tail
        flow += push


#: A claimed consumer whose next range waits behind an older claim on a tier
#: whose joint commitment is past its capacity (#1011).  Transient: the
#: consumers ranked ahead of it are served first, one head a cycle.
REASON_CLAIM_ORDER = "held-by-claim-order"

#: The standings :func:`claim_order` gives a claimed consumer.
CLAIM_SATISFIED = "satisfied"
CLAIM_GRANTED = "granted"
CLAIM_HEAD = "head"
CLAIM_HELD_BACK = "held-back"


def claim_order(claims, *, free_gib: int) -> dict[str, object]:
    """Rank a tier's claimed consumers for its room (#1011).

    Used only on a stage tier whose joint commitment (#907) is past its
    capacity, where the claimed consumers cannot all have their horizons and
    each waits on the others' reading.  ``claims`` holds one mapping per
    claimed consumer: ``consumer`` (its key), ``claimed_unix`` (when its
    claim was recorded), ``need_gib`` (the GiB its window takes from free
    next, 0 when it needs nothing), ``blocked`` (whether that range is the
    one it is reading, so it cannot progress without it) and, for a blocked
    one, ``blocked_since_unix`` (when it became blocked).

    The rank is blocked first.  A consumer blocked on its own reading range
    comes before any consumer's read-ahead, because a read-ahead range buys
    latency while a blocked range is the only thing between a GPU and its
    next unit of work.  Among blocked consumers the one blocked longest is
    served first (``blocked_since_unix``, falling back to the claim time
    when it is absent), and among the rest the older claim; the claim time
    and then the key break ties, the key for determinism only.  Ranking
    blocked consumers by claim time instead starves the younger one (#1022
    review): the older claim, granted, reads its range and blocks again,
    and is again the older claim.  By the time it blocked, the younger one
    has been blocked longer, so it goes first.

    The walk spends ``free_gib`` in rank order.  A consumer whose need fits
    what is left is ``granted``; the first whose need does not fit is the
    ``head``, and every consumer ranked after it with a need is
    ``held-back``: it publishes nothing until the head is served, and its
    record names the consumer ranked just ahead of it (``ahead``) and the
    head (``waiting_on``).  A consumer with no need is ``satisfied``.

    Returns ``{"entries": [...], "head": key or None, "target_free_gib":
    int}``.  ``target_free_gib`` is the free the tier must reach for every
    granted consumer and the head to take their needs at once; with no head
    it is what the granted consumers take.  The caller makes that room from
    ranges ranked after the head, never from a range a consumer is reading.

    Two consumers can need one range (#1026): a claim may name the range it
    needs as ``need_mover``, and consumers of one shared range name the same
    mover.  Its GiB is spent once.  A consumer whose range an earlier
    consumer was granted is granted too, with nothing left to spend
    (``shared_with`` names the earlier one); otherwise it ranks as any other
    consumer does.
    """

    ranked = sorted(claims, key=lambda claim: (
        not bool(claim.get("blocked")), _waited_from(claim),
        float(claim["claimed_unix"]), str(claim["consumer"])))
    left = int(free_gib)
    target = 0
    head: str | None = None
    entries: list[dict[str, object]] = []
    ahead: str | None = None
    granted_mover: dict[str, str] = {}
    for rank, claim in enumerate(ranked):
        key = str(claim["consumer"])
        need = max(0, int(claim.get("need_gib") or 0))
        mover = claim.get("need_mover")
        mover = str(mover) if mover else None
        entry: dict[str, object] = {
            "consumer": key, "rank": rank,
            "claimed_unix": float(claim["claimed_unix"]),
            "blocked": bool(claim.get("blocked")), "need_gib": need,
            "ahead": ahead}
        if claim.get("blocked"):
            entry["blocked_since_unix"] = _waited_from(claim)
        if need <= 0:
            entry["standing"] = CLAIM_SATISFIED
        elif mover is not None and mover in granted_mover:
            entry["standing"] = CLAIM_GRANTED
            entry["shared_with"] = granted_mover[mover]
        elif head is not None:
            entry["standing"] = CLAIM_HELD_BACK
            entry["waiting_on"] = head
        elif need <= left:
            entry["standing"] = CLAIM_GRANTED
            left -= need
            target += need
            if mover is not None:
                granted_mover[mover] = key
        else:
            entry["standing"] = CLAIM_HEAD
            entry["shortfall_gib"] = need - left
            head = key
            target += need
        entries.append(entry)
        ahead = key
    return {"entries": entries, "head": head, "target_free_gib": target}


def _waited_from(claim) -> float:
    """When a ranked claim started waiting: blocked since, else claimed."""

    since = claim.get("blocked_since_unix") if claim.get("blocked") else None
    if (isinstance(since, (int, float)) and not isinstance(since, bool)
            and math.isfinite(float(since))):
        return float(since)
    return float(claim["claimed_unix"])


def relief_stalled_s(order, *, now: float) -> float | None:
    """How long the order's relief has made no room by declines alone (#1037).

    ``short`` with nothing evicted (``relief_evicted_gib`` 0): every
    candidate the pass tried declined -- a pinned copy, the head's own copy,
    a copy still being copied -- so the pass made no room and freed none.
    The age is ``now`` less the ``relief_since_unix`` the tier loop carries
    from record to record while that state lasts.  ``None`` for any other
    relief, or a record from a loop that did not stamp both fields.
    """

    if not isinstance(order, Mapping) or order.get("relief") != "short":
        return None
    evicted = order.get("relief_evicted_gib")
    since = order.get("relief_since_unix")
    if (isinstance(evicted, bool) or not isinstance(evicted, int) or evicted != 0
            or isinstance(since, bool) or not isinstance(since, (int, float))
            or not math.isfinite(float(since))):
        return None
    return max(0.0, float(now) - float(since))


def stuck_victim(order, *, now: float | None = None,
                 stall_bound_s: float | None = None) -> str | None:
    """The one consumer a stuck claim order ends this cycle, or ``None`` (#1011).

    Stuck: the order's last relief pass was ``futile`` -- every candidate
    together, read-ahead and preemptable reading-phase chunks alike, could
    not make the head's room -- no ranked consumer is granted, and every
    ranked consumer is blocked.  Nobody is reading, so no egress will make
    the room either, and without an ending the wait has no end.

    A relief that is ``short`` with nothing evicted is futile for this rule
    once it has lasted ``stall_bound_s`` (:func:`relief_stalled_s`, #1037):
    every candidate declined, record after record, for as long as the wait
    being judged is allowed.  A decline that clears (a pin its reader
    drops, a copy that lands) lets the next pass evict and restarts the
    age.  Without ``now`` and ``stall_bound_s`` only ``futile`` is stuck.

    A granted consumer means the order is moving: its range lands, it reads
    it, and its egress returns room.  A consumer that is not blocked is
    reading.  Either way the order is not stuck, and nobody is ended.

    Every consumer's ``no_progress`` rung reads the same record, so the rule
    names one victim rather than ending each blocked consumer whose grace
    lapses: the lowest-ranked blocked consumer other than the head, whose
    held ranges are the ones ranked farthest from being read.  Only when
    the head is the one ranked consumer is it the victim, which is the
    rule before #1011.  The next cycle ranks again, so a stuck order ends
    at most one consumer a cycle.
    """

    if not isinstance(order, Mapping):
        return None
    if order.get("relief") != "futile":
        stalled = (relief_stalled_s(order, now=now)
                   if now is not None and stall_bound_s is not None else None)
        if stalled is None or stalled < float(stall_bound_s):  # type: ignore[arg-type]
            return None
    entries = [entry for entry in order.get("entries") or ()
               if isinstance(entry, Mapping)]
    if not entries:
        return None
    if any(not entry.get("blocked") or entry.get("standing") in (
            CLAIM_GRANTED, CLAIM_SATISFIED) for entry in entries):
        return None
    head = order.get("head")
    others = [entry for entry in entries if entry.get("consumer") != head]
    victim = max(others or entries, key=lambda entry: int(entry.get("rank") or 0))
    return str(victim.get("consumer"))


def fence_fits(*, held_gib: int, ready_gib: int, output_gib: int,
               capacity_gib: int | None) -> bool:
    """Whether one more fence keeps every future take fundable.

    New-money peak accounting: everything held plus everything queued that
    will commit new capacity plus owed output must leave the tier
    within capacity.  ``ready_gib`` carries new money only (funded rows ride
    at zero); the fence's own take from free is enforced atomically by the
    reserve itself.  ``output_gib`` is the produced-output window nobody
    holds (zero unless the tier loop counts it).  Every claim, copy, pin,
    and temporary overlap is counted exactly once, never twice.
    """

    if capacity_gib is None:
        return False
    return held_gib + ready_gib + output_gib <= capacity_gib


def replenish_ok(*, grant_outstanding: bool, need_gib: int | None,
                 prior_retired: bool) -> bool:
    """Whether a fresh fence may be reserved for the following next step.

    One outstanding RESERVED grant per consumer/tier/leg; a new one needs a
    real need, safe-retire evidence for every earlier leg (staged-held or
    egress-done -- never the progress counter alone), and no live fence.
    Handed-off (fused) grants do not count: they already moved.
    """

    if grant_outstanding:
        return False
    if need_gib is None or need_gib <= 0:
        return False
    return bool(prior_retired)


def cancel_due(*, consumer_live: bool, superseded: bool,
               need_gib: int | None, mover_holds_need: bool) -> str | None:
    """Why a held fence must be released, or ``None`` to keep holding it."""

    if not consumer_live:
        return "consumer-terminal"
    if superseded:
        return "plan-superseded"
    if need_gib is None:
        return "need-gone-final"
    if mover_holds_need:
        return "need-landed"
    return None
