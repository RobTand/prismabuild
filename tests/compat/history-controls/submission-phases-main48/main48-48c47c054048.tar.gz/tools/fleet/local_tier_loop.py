#!/usr/bin/env python3
"""One supervised local-tier capacity/lifecycle pass per owning host."""
import argparse
import json
from pathlib import Path
import signal
import socket
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
_PB_ENTRYPOINT = Path(__file__).resolve(strict=True)
sys.path.insert(0, str(_PB_ENTRYPOINT.parents[
    2 if _PB_ENTRYPOINT.parent.name == "fleet" else 1] / "src"))
from prismabuild.runtime_paths import generation_root
sys.path.insert(0, str(generation_root(__file__) / "src"))
from prismabuild import role_session as runtime_gate  # noqa: E402
from prismabuild import generation_receipt, local_tier, pool, resident_sets


def local_tier_cycle(queue, host, policy):
    spec = policy["hosts"].get(host)
    if spec is None:
        return queue.tier(local_tier.local_resident_tier_id(host)).mint({local_tier.KIND: 0})
    from prismabuild import local_resident
    lease_results = local_resident.lease_pass(resident_sets.ResidentSets(queue.root), host, spec)
    # Remaining trees and retained holders are still counted by the minter.
    result = local_tier.mint_local_tier_capacity(queue, host, spec)
    result["lease_pass"] = lease_results
    queue.announce_tier({"tier_id": local_tier.local_resident_tier_id(host), "tier": "local",
        "host": host, "mountpoint": spec["root"], "capacity_bytes": result["wanted_gib"] * local_tier.GIB,
        "mover_python": sys.executable, "mover_tools_root": str(Path(__file__).resolve().parent)})
    return result


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pool-root", required=True, help="PrismaBuild queue root (the pool directory) that holds the resident set records.")
    parser.add_argument("--policy", default=str(Path(__file__).with_name("local_tier_policy.json")),
                        help="local_tier_policy.json; a host missing from its host map mints nothing and runs no lease pass (the shipped map is empty).")
    parser.add_argument("--interval-s", type=float, default=5, help="Seconds between passes of lease expiry, eviction and capacity minting.")
    parser.add_argument("--once", action="store_true", help="Run one pass for this host and exit instead of looping.")
    args = parser.parse_args(argv)
    if args.interval_s <= 0:
        parser.error("interval must be positive")
    try:
        with runtime_gate.stop_requests(signal.SIGTERM, signal.SIGINT) as stop:
            loaded = runtime_gate.loaded_runtime()
            with runtime_gate.role_singleton(Path(__file__)):
                while not stop.is_set():
                    if isinstance(loaded, generation_receipt.ReceiptUnavailable):
                        loaded = runtime_gate.loaded_runtime()
                    decision = generation_receipt.compare(loaded, runtime_gate.published_runtime())
                    if isinstance(decision, generation_receipt.Drift):
                        return runtime_gate.ROLE_DEFERRED_EXIT if args.once else 0
                    gate = runtime_gate.read_maintenance_gate()
                    if gate is not None:
                        runtime_gate.post_park_marker(gate)
                    if isinstance(decision, generation_receipt.Unknown):
                        reasons = {
                            name: value.reason if isinstance(value, generation_receipt.ReceiptUnavailable) else "known"
                            for name, value in (("loaded", decision.loaded), ("published", decision.published))
                        }
                        print(json.dumps({"event": "localtier-runtime-unknown", **reasons}), flush=True)
                        if args.once:
                            return runtime_gate.ROLE_DEFERRED_EXIT
                    elif gate is None:
                        try:
                            queue = pool.PoolQueue(args.pool_root)
                            queue.records.ensure_layout()
                            result = local_tier_cycle(queue, socket.gethostname(), resident_sets.read_policy(args.policy))
                        except Exception as error:
                            print(json.dumps({"event": "localtier-cycle-error",
                                "host": socket.gethostname(), "error": f"{type(error).__name__}: {error}"}), flush=True)
                            if args.once:
                                return 1
                        else:
                            print(json.dumps(result), flush=True)
                            if args.once:
                                return 1 if any(row.get("error") for row in result.get("lease_pass", [])) else 0
                    elif args.once:
                        return runtime_gate.ROLE_DEFERRED_EXIT
                    stop.wait(args.interval_s)
    except (runtime_gate.RoleLockHeld, runtime_gate.RoleLockUnavailable) as exc:
        print(f"localtier: {exc}", file=sys.stderr)
        return runtime_gate.ROLE_SINGLETON_HELD_EXIT
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
