#!/usr/bin/env python3
"""Publish this checkout as the bytes the fleet executes, and say which commit.

Workers do not run this repository.  They run ``/mnt/shared/prismabuild-fleet/
repo`` -- a copy on the one filesystem every box mounts -- and until now that
copy was maintained by hand.  The failure that follows from a hand-copied
runtime is not subtle: a fix lands in the checkout, the fleet keeps executing
the old bytes, and the two disagree silently because nothing anywhere records
which commit the mirror is.  Thirty-two resubmissions died instantly on
``AttributeError: 'PoolQueue' object has no attribute 'placeable'`` -- a
method committed twenty minutes earlier, in a file the mirror did not have.

So publication becomes a complete immutable generation with a receipt.
``RUNTIME_VERSION.json`` records the commit, whether the tree was dirty, and
a sha256 per published file next to the bytes themselves; the generation is
copied, revalidated and import-probed off-line, then ``repo`` moves to it in
one namespace operation.  A caller therefore sees one complete generation,
never the member-by-member interval a receipt could not attest.  Worker
attestation already records the sha256 of what it loaded, so the two can be
compared after the fact and a mismatch is a fact rather than a suspicion.

The mirror keeps its scripts at the top of ``tools/`` while the checkout has
them under ``tools/fleet/``, because the hook and older command lines address
the flat path.  Both are written, from the same source, rather than left to
drift into two versions of one file -- which is exactly what happened to
``worker_loop.py``, where the flat copy was current and the nested one was
three days stale.

After activation, ``--canary`` submits the fleet canary (issue #688) resolving
against the new generation and records ``verified`` or ``failed`` in the
rollout record ``runtime-generations/<generation>.canary.json``; ``--no-canary``
records ``not_run``. The gate is default-ON (phase 2, flipped 2026-09-19 after
the first verified live 4-leg run); ``--no-canary`` remains the escape hatch.
A failed canary marks and exits nonzero; it never rolls back and never touches
admission. See the canary runbook.
"""

from __future__ import annotations

import argparse
import ast
from contextlib import contextmanager
import fcntl
import hashlib
import importlib.util
import json
import inspect
import math
import os
from pathlib import Path
import re
import shutil
import socket
import stat
import subprocess
import sys
import threading
import time
import uuid

sys.path.insert(0, str(Path(__file__).resolve(strict=True).parent))

_SCRIPT = Path(__file__).resolve()
CHECKOUT = _SCRIPT.parents[1] if _SCRIPT.parent.name == "tools" else _SCRIPT.parents[2]
sys.path.insert(0, str(CHECKOUT / "src"))
from prismabuild import fleet_roster  # noqa: E402
from prismabuild.compatibility_window import (  # noqa: E402
    RECEIPT_MEMBERS, WindowError, client_protocol, require_client_transition,
    require_receipt_participants,
)
from prismabuild.digest_primitives import raw_sha256  # noqa: E402
from prismabuild.generation_receipt import GenerationReceipt  # noqa: E402
import updater_proof  # noqa: E402
MIRROR = Path("/mnt/shared/prismabuild-fleet/repo")
_PUBLISH_MUTEX = threading.RLock()
_PUBLISH_LOCK_DEPTH = 0
_PUBLISH_LOCK_PID: int | None = None
#: Published as ``tools/<name>`` *and* ``tools/fleet/<name>``.
FLEET_SCRIPTS = (
    "docker", "pbrun.py", "pbtest.py", "pbtest_outcomes.py", "pbtest_pins.py", "require_pool.py", "worker_loop.py", "worker.py",
    "seal_and_publish.py",
    "publish_runtime.py", "pool_reset.py", "supervise.py",
    "migrate_role_logs.py",
    # The supervisor spawns prewarm_loop.py on a box declaring the storage
    # role, by published path like every other child. A generation without it
    # makes that role a log line saying the script is not there (#487).
    "prewarm_loop.py",
    # ...and tier_loop.py on a box declaring the tiers role (#583): it
    # mints and announces the box's discovered storage tiers, and a role
    # script that does not travel cannot be spawned.
    "tier_loop.py", "pbresident.py", "local_tier_loop.py", "local_resident.py",
    # ...and stage_move.py, which is not a role script at all: it is the
    # movement node itself, exec'd by an admitted action on the storage box
    # (#583).  A generation without it publishes movers nothing can run.
    "stage_move.py",
    # Source-host PRECOMMIT local-spool exports are ordinary admitted actions.
    # Their payload must travel with the package that seals their command.
    "produced_export.py",
    # ...and stage_release.py beside it, the egress node that deletes a staged
    # range and returns its tier tokens.  The tier loop also imports it for the
    # orphan sweep, so a generation without it leaves a withdrawn consumer's
    # movers holding the stage with nothing able to take it back.
    "stage_release.py",
    # ...and stage_reclaim.py, the operator command that moves digest-proven
    # source-mark-only stage copies into quarantine and restores them (#1636).
    # The stage lives on dl380g10, which has no checkout, so a generation
    # without it leaves that command with no place to run.
    "stage_reclaim.py",
    # ...and ram_promote.py, the ram tier's movement node (#640): it copies a
    # landed stage range into the tmpfs and files the fragment that carries
    # the epoch.  A generation without it leaves the ram window publishing
    # promotions nothing can run.
    "ram_promote.py",
    # Root operator provisioning is separate from publication and discovery.
    "install_ram_mount_unit.py",
    # Qualified scratch profiles bind this producer's bytes in the generation.
    "local_scratch_profile.py",
    # The retained SLURM lane job entry. Submission is a package owner.
    "slurm_job.py",
    # The commands an operator runs on a box that has no checkout.  The
    # published pool_reset.py:582 tells them to run ``pbwait.py <key>``, and
    # neither dl380g10 nor sparklina has a checkout to run it from.
    # runtime_process_census.py is here for the same reason and is only
    # useful there: it reads /proc on the box it runs on.
    "pbstatus.py", "pbmetrics.py", "pbwait.py", "pbcampaign.py", "runtime_process_census.py",
    # pbsnapshot.py runs inside an action: a client that hashes its own
    # source asks it which files in the pbrun checkout PrismaBuild generated.
    # It has to be the executing generation's copy, found by published path.
    "pbsnapshot.py",
    # pbmergeq.py is a client a repository's merge flow runs from a box with
    # no PB checkout; it imports pbtest.py and pbtest_outcomes.py from its own
    # directory, so it must be the same generation's copy (#1417).
    "pbmergeq.py",
    # pbmcp.py is the same case as pbstatus.py and then some: an agent
    # registers it by absolute published path so that every session starts on
    # the current generation, and the boxes it is registered from are exactly
    # the ones with no checkout.
    "pbmcp.py",
    # retire_worker.py belongs to the same set for a sharper reason: the name
    # it retires is a name whose box stopped answering, and the operator who
    # notices is on whichever box is holding the mount.
    "retire_worker.py",
    # The residency-plan backfill (#1041, published by #1381) is the same
    # operator's second cleanup: it reaps plans whose consumer concluded
    # before PoolQueue.finish started retiring them at the terminal write,
    # and the queue it names lives on the shared mount rather than in any
    # checkout.  It lists without --apply and archives only when no child of
    # the plan is still ready, claimed or live.
    "retire_residency_plans.py",
    # The exporter's installer travels with it for the same reason: the box
    # best placed to run it is a box with no checkout.
    "install_pbmetrics.sh",
    # mount_latency.py measures the medium from the box it runs on, so it has
    # to be present on a box with no checkout -- and most of all on the box
    # whose mount is the one in question, which is the box least able to fetch
    # it at the time somebody wants it.
    "mount_latency.py",
    # pb_gc.py is the same case: it sweeps a store from whichever box is
    # holding the mount, and it reads /proc on the box it runs on to find out
    # what is still live there.
    "pb_gc.py",
    # pbgang.py submits a gang (#1517) from a box that has no checkout; a tool
    # missing from this list is a tool no box can run, so the gang canary could
    # not start from a published generation.
    "pbgang.py",
    # pbrun imports pbevidence unconditionally (#1598).  A published script that
    # imports a tools module the publication lacks makes the publisher refuse
    # every generation, so the tool ships even for commands that never use
    # --target-evidence.  It also runs as a normal action on a worker of the
    # class, where it prints the evidence packet.
    "pbevidence.py",
    # Explicit plan-first banked-checkout recovery runs on the owning host.
    "pbrecover_checkout.py",
    # The reconcile, for the same reason: the endings it files are the ones
    # no waiter asked for, and the operator who notices they are missing is
    # on whichever box has the shared mount rather than the checkout.
    "pbsweep.py",
    # Local JOIN/RESIGN and the worker-loop reconciliation hook must work
    # on registered hosts with only the published generation available.
    "fleet_membership.py",
    # Per-job containment clients and root-installed authority sources travel
    # with the generation; installation copies privileged code to root-owned
    # storage rather than executing it from this shared runtime.
    "resource_exec.py", "resource_broker.py", "resource_payload.py",
    "qualify_resource_scope.py", "install_resource_broker.sh",
    # The host-local check an operator runs after provisioning the broker: it
    # reads the installed needrestart main configuration alone to prove the
    # exact-service deferral survived installation (#1378), and the box that
    # needs that proof is the box whose running broker cannot be disturbed by
    # materializing a checkout.
    "qualify_needrestart_broker_deferral.py",
    "upgrade_client.py", "bootstrap_client.py", "install_client_upgrader.sh", "install_supervisor_unit.sh",
    # The one-time root enrollment of a host in automatic movement publication
    # (#1659).  An administrator copies it out of the live generation, as the
    # client upgrader's installer; a generation without it leaves no host able
    # to enroll.  ``runtime_publication.py`` it installs is a package module.
    "install_movement_publisher.sh",
    # A rolling receipt activation reads each enrolled host's installed
    # updater proof (#1850) through this module, and the proof itself is this
    # tool run as an ordinary action on that host.
    "updater_proof.py",
)
# The retained proxy verifies the same stdlib layout helper beside itself.
STANDALONE_PACKAGE_SOURCES = {
    "runtime_paths.py": "src/prismabuild/runtime_paths.py",
}

#: Fleet tools deliberately left out of the generation, each with the reason.
#: Runtime tools travel; qualification harnesses use submitted checkouts.
#: The tuple exists so that leaving one out is a decision
#: somebody wrote down rather than an omission nobody noticed.
EXCLUDED: tuple[tuple[str, str], ...] = (
    ("gate_1730_probe.py",
     "the #1730 fixed-arm storage probe runs from a submitted checkout through "
     "pbrun; it records one measurement and is not an operator command"),
    ("filesystem_floor_proof.py",
     "the #1483 two-host floor proof, run from a checkout through pbrun "
     "against a private registry; a record of one qualification, not an "
     "operator command (the operator CLI is python -m "
     "prismabuild.filesystem_floor)"),
    ("profile_finish_census.py",
     "a read-only profile of the census a finish pays, run from a checkout "
     "through pbrun against a view of a queue's funding directory; it is a "
     "record of one measurement rather than an operator command"),
    ("qualify_docker_stop.py",
     "the #1599 real-container stop proof, run from a checkout inside an "
     "admitted action on a box with Docker; it starts the checkout's own shim "
     "beside it, so it is a qualification of one source tree and not an "
     "operator command for a box without a checkout"),
    ("qualify_rollout.py",
     "paired rollout qualification actors use submitted checkouts and a fresh "
     "private shared root; their simulated host services are not an operator "
     "command or permission to activate the production barrier"),
    ("qualify_claim_recovery.py",
     "paired queue-recovery qualification actors run from an isolated "
     "checkout through pbcampaign against a fresh private queue root; "
     "not an operator command for a box without a checkout"),
    ("qualify_scratch_lifetime.py",
     "scratch-lifetime deployment qualification actors (#1360) run from "
     "a submitted checkout through pbrun on a disk-offering worker; "
     "not an operator command for a box without a checkout"),
    ("admission_shared_io.py",
     "a measurement harness for the admission critical section, run from a "
     "checkout through pbrun against a private queue root; a box with no "
     "checkout has no reason to run it and it must never be pointed at the "
     "live queue"),
    ("bench_stage_adopt.py",
     "a standalone profile of the stage mover's adopt and copy paths "
     "(#981), run from a checkout through pbrun over a synthetic residency "
     "forest and a scratch queue root; it is a record of one measurement "
     "rather than an operator command, and it must never be pointed at the "
     "live stage or the live queue"),
    ("bench_stage_egress.py",
     "a standalone profile of a whole-range egress and the publishers "
     "beside it (#988), run from a checkout through pbrun over a synthetic "
     "residency forest and a scratch queue root; it is a record of one "
     "measurement rather than an operator command, and it must never be "
     "pointed at the live stage or the live queue"),
    ("bench_claim_pass.py",
     "a standalone count of the listings and per-key lookups of one worker "
     "poll (#993), run from a checkout through pbrun under strace over a "
     "synthetic queue root; it is a record of one measurement rather than "
     "an operator command, and it must never be pointed at the live queue"),
    ("bench_tier_cycle.py",
     "a standalone profile of one tier-loop cycle on a campaign-sized "
     "queue (#992), run from a checkout through pbrun over a synthetic "
     "queue and stage root; it is a record of one measurement rather than "
     "an operator command, and it must never be pointed at the live stage "
     "or the live queue"),
    ("bench_tier_cycle_r13.py",
     "the same tier-cycle profile with R13's dead Stage A instance replayed "
     "onto the synthetic queue (#1053), run from a checkout through pbrun; "
     "it is a record of one measurement rather than an operator command, "
     "and it must never be pointed at the live stage or the live queue"),
    ("bench_stage_reconcile.py",
     "a standalone profile of the stage reconcile's census at the live "
     "stage shape (#1073), run from a checkout through pbrun over a "
     "synthetic stage and a scratch queue root; it is a record of one "
     "measurement rather than an operator command, and it must never be "
     "pointed at the live stage or the live queue"),
    ("bench_ram_promote_restart.py",
     "a standalone profile of a restarted RAM promotion taking back the "
     "copies its last attempt left (#1081), run from a checkout through "
     "pbrun over a scratch stage, RAM root and queue root; it is a record "
     "of one measurement rather than an operator command, and it must never "
     "be pointed at the live stage, the live RAM tier or the live queue"),
    ("bench_failed_mover_reclaim.py",
     "a standalone count of what a failed mover's reclaim under a reader "
     "and two phase movers of one staged name cost (#1151), run from a "
     "checkout through pbrun over a scratch stage, origin and queue root; it "
     "is a record of one measurement rather than an operator command, and "
     "it must never be pointed at the live stage or the live queue"),
    ("bench_tier_cold_start.py",
     "a standalone timing of a fresh tier loop's first cycles over a "
     "synthetic receipt backlog (#1153), run from a checkout through pbrun "
     "over a scratch queue root; it is a record of one measurement rather "
     "than an operator command, and it must never be pointed at the live "
     "stage or the live queue"),
    ("qualify_record_visibility.py",
     "a standalone timing of how late an NFS client of the queue sees a "
     "record another box files, run from a checkout through pbrun against "
     "a scratch queue root; it carries the pre-#808 by-name read as its "
     "before arm, so it is a record of one measurement rather than an "
     "operator command, and it must never be pointed at the live queue"),
    ("pbcanary.py",
     "the fleet canary driver (#688) runs from a checkout that has one: "
     "the GitHub runner on dl380 and the rollout gate both invoke the "
     "checkout's copy and submit through the published pbrun client, while "
     "worker boxes execute the driver's legs from the submission snapshot, "
     "never from the generation; a box with no checkout has no reason to "
     "run it"),
    ("pbcanary_watch.py",
     "the canary watcher (#978) runs from a checkout as a systemd oneshot: "
     "it reads the active generation, runs the checkout's pbcanary driver "
     "when the generation has no verdict, and writes the verdict sidecar; "
     "workers never execute it"),
    ("pbcanary_submission.py",
     "the checkout canary's private bounded sealed-action handoff to the "
     "lock-owning publisher; it loads the published pbrun client but never "
     "runs on workers or grants authority to a standalone caller (#1213)"),
    ("pbcanary_verdict.py",
     "the canary's verdict module (#688) is imported by the checkout's "
     "driver at verdict time, never executed standalone; it travels with "
     "the driver above, not with the generation"),
    ("shape_gate.py",
     "the pre-publish shape gate (#987) judges a candidate commit before it "
     "becomes a generation: its reference run is a pbtest of the checkout's "
     "tests/gate_campaign_shape.py, and this publisher imports the "
     "checkout's copy to verify that run's receipt.  A generation never "
     "runs it, so it does not travel with one"),
)


#: Rollout canary gate (issue #688, crew D). The default is ON: publication
#: verifies the generation it just activated unless ``--no-canary`` is
#: passed. Phase 1 landed default-OFF with ``--canary`` as the opt-in; the
#: constant was flipped 2026-09-19 (phase 2) after the first verified live
#: 4-leg run: namespace pb-canary/20260919T173543Z, exit 0, leg-4 envelopes
#: bitwise-equal across sparky+sparklina. The flag spellings and the rollout
#: record are unchanged by the flip. The constant (not an environment
#: variable) is the switch so the default is versioned, reviewable, and
#: published with the generation that implements it.
CANARY_DEFAULT_ENABLED = True
#: Rollout-record statuses. ``pending`` is written before the driver is
#: invoked and rewritten on its verdict. ``not_run`` with exit 2 means
#: incomplete verification (including observation/staging waits), not a pass;
#: with no exit it records an explicit skip. Driver crashes remain failed.
CANARY_STATUSES = ("pending", "verified", "failed", "not_run")
CANARY_RECORD_SCHEMA = "prismaquant.prismabuild.canary_status.v1"

#: Not code, but read by published code.  The supervisor on each box reads
#: the fleet's declared shape from ``fleet_boxes.json``, so a runtime
#: published without it starts no workers at all.  The tier loop reads the
#: ram tier's declared sizing from ``ram_tier_policy.json`` every cycle
#: (#640), so a change to it is a publish rather than an ssh -- and a
#: generation published without it discovers no ram tier, which is the
#: honest answer for a runtime that predates the tier.  The broker installer
#: reads ``50-prismabuild-resource-broker.conf`` beside itself and provisions
#: it as needrestart's exact-service restart exclusion (#1378), so a
#: generation published without it would install an unprotected broker.
FLEET_DATA = ("fleet_boxes.json", "ram_tier_policy.json", "local_tier_policy.json",
              "50-prismabuild-resource-broker.conf")

# These originate at tools/, without a second tools/fleet/ spelling. The
# torch helper is copied by consumers following the published profile guide.
TOP_LEVEL_SCRIPTS = ("prismabuild_worker.py", "profile_torch.py")

# The dashboard deploy tests travel with the runtime, so their implementation
# and maintained dashboard must travel too. This does not start monitoring or
# modify an existing Grafana deployment during worker publication.
OBSERVABILITY_FILES = (
    "README.md", "build_dashboard.py", "deploy_dashboard.py", "prismabuild.json",
    "prismabuild-metrics.service", "prometheus.scrape.yml", "qualify_dashboard.py",
)

# ``pbstatus`` reads the /mnt/shared NFS readahead window through this helper
# and reports it; without the helper in the generation the reading is
# unavailable on every box that has no checkout, which is every worker. The
# helper is stdlib-only and read-only unless given ``--apply``, and publishing
# it installs nothing: the host unit beside it is still installed by an
# operator, as docs/fleet_storage.md says.
STORAGE_FILES = ("nfs_readahead.py",)

#: The modes a published generation's members carry, chosen rather than
#: inherited.  Until #316 the mode came from ``shutil.copy2`` preserving
#: whatever the *publishing checkout* happened to have, which is a box-local
#: umask artifact: a worktree created under umask 077 published every file
#: ``0500``/``0400``, and the same commit published from a umask-002 worktree
#: would have published ``0555``/``0444``.  A generation's permissions must be
#: a property of the generation, not of the shell that made it.
#:
#: World-readable, because a published generation has a reader that is not
#: ``rob``.  ``docs/mount_measurement.md`` installs Netdata's mount collector
#: as a symlink *into the live generation* on purpose, so that a later
#: publication re-points it and no re-link is ever owed -- which makes a
#: non-owner UID a first-class reader of published bytes.  The group bit alone
#: would not do it: Netdata is uid 983 in group ``rob`` on sparky only because
#: a ``usermod`` was run there, while on dl380g10 it is uid 984 with
#: ``groups=984(netdata),110(docker)`` and in no group of Rob's at all.  A
#: group-bit fix would make plugin adoption depend on a per-box ``usermod`` on
#: every current and future box; the ``other`` bits need no provisioning.
#: Nothing in a generation is secret -- it is PrismaBuild's own source, and
#: credentials and queue state live elsewhere -- and the directories on the
#: way already permit traversal by anyone.
#:
#: Write stays denied to everyone including the owner, so the property that
#: makes a generation quotable -- it is immutable and append-only history --
#: is exactly preserved.
PUBLISHED_EXECUTABLE_MODE = 0o555
PUBLISHED_FILE_MODE = 0o444

# Source and private qualification may exercise the epoch state machine, but a
# live publication stays disabled until the coordinator has reviewed the
# cross-host qualification evidence.  This guard is intentionally adjacent to
# the publication entrypoint rather than an operator flag: no command spelling
# can accidentally turn a source-only protocol into a fleet transition.
FINAL_BARRIER_QUALIFICATION_GUARD = True
PUBLISHED_DIRECTORY_MODE = 0o555

# Retain the loaded code without reading source at import. At first use, bind
# source bytes only if they compile to this code; a mutable checkout must not
# let a later pathname revision impersonate the coordinator already loaded.
COORDINATOR_SOURCE = Path(__file__).resolve()
COORDINATOR_CODE = sys._getframe().f_code
COORDINATOR_SHA256 = None


def _coordinator_sha256() -> str:
    global COORDINATOR_SHA256
    try:
        raw = COORDINATOR_SOURCE.read_bytes()
        digest = hashlib.sha256(raw).hexdigest()
        if COORDINATOR_SHA256 is None:
            code = compile(raw, COORDINATOR_CODE.co_filename, "exec", dont_inherit=True)
            if code != COORDINATOR_CODE:
                raise SystemExit("rollout coordinator source changed after it was loaded")
            COORDINATOR_SHA256 = digest
        elif digest != COORDINATOR_SHA256:
            raise SystemExit("rollout coordinator source changed after it was loaded")
    except (OSError, SyntaxError, ValueError) as exc:
        raise SystemExit(f"rollout coordinator identity cannot be read: {exc}") from exc
    return COORDINATOR_SHA256


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1 << 20), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _git_result(*argv: str):
    from prismabuild import core as pb
    return pb._git_run(CHECKOUT, *argv, timeout=None)


def _commit_identity() -> str:
    """The exact Git commit the published bytes claim, or refuse.

    A linked worktree under the shared mount can still point its ``.git`` file
    at a box-local control directory.  On another box ``git rev-parse`` then
    exits 128; treating its empty stdout as a commit published real bytes under
    ``commit: ""``.  A receipt with no identity is not an approximate receipt.
    """

    result = _git_result("rev-parse", "--verify", "HEAD")
    commit = result.stdout.strip()
    if result.returncode != 0 or re.fullmatch(r"[0-9a-f]{40}", commit) is None:
        detail = (result.stderr or result.stdout or "no output").strip()
        raise SystemExit(
            "cannot prove a 40-hex Git commit for runtime publication: "
            f"git rev-parse --verify HEAD exited {result.returncode}: {detail}"
        )
    return commit


def _working_tree_dirty() -> bool:
    # Every file under the published source/script/test roots is eligible for
    # the generation below, including a newly-created one Git does not yet
    # track.  Excluding untracked paths here could therefore put bytes absent
    # from ``commit`` into a receipt that claimed ``dirty: false``.
    result = _git_result("status", "--porcelain")
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "no output").strip()
        raise SystemExit(
            "cannot prove whether the runtime checkout is clean: "
            f"git status exited {result.returncode}: {detail}"
        )
    return bool(result.stdout.strip())


def _git_index_modes() -> dict[str, int]:
    """The mode Git records for every tracked file, keyed by checkout path.

    The executable bit a published file carries is a fact the repository
    already states -- ``100755`` or ``100644`` in the index -- so publication
    reads it there rather than guessing from a filename, an extension, or a
    hardcoded list of "the plugin files".  The alternative that was in place
    read it from the publishing worktree's filesystem, which is why the same
    commit published different modes from different worktrees.

    A failure here is a refusal, in the shape ``_commit_identity`` uses: a
    publisher that cannot read the index cannot say which of its members are
    programs, and guessing would put an unexecutable collector on the fleet
    exactly as before.
    """

    result = _git_result("ls-files", "--stage", "-z")
    if result.returncode != 0:
        detail = (result.stderr or result.stdout or "no output").strip()
        raise SystemExit(
            "cannot read the Git index modes the published files derive from: "
            f"git ls-files --stage exited {result.returncode}: {detail}"
        )
    modes: dict[str, int] = {}
    for entry in result.stdout.split("\0"):
        if not entry:
            continue
        head, separator, path = entry.partition("\t")
        fields = head.split()
        if not separator or len(fields) != 3 or not re.fullmatch(r"[0-7]{6}", fields[0]):
            raise SystemExit(
                f"cannot parse a Git index entry for runtime publication: {entry!r}"
            )
        modes[path] = int(fields[0], 8)
    return modes


def _published_mode(source: Path, index_modes: dict[str, int]) -> int:
    """The mode ``source`` gets in the generation: 0555 if it is a program.

    Tracked files take the answer from the index.  An untracked one -- which
    only a ``--allow-dirty`` publication has -- has no index entry to read, so
    its own owner-execute bit is the only statement available and is used.
    Either way the group and other read bits are set, which is the whole point.
    """

    try:
        relative = source.resolve().relative_to(CHECKOUT.resolve()).as_posix()
    except ValueError:
        relative = None
    recorded = index_modes.get(relative) if relative is not None else None
    if recorded is not None:
        executable = bool(recorded & 0o111)
    else:
        executable = bool(source.stat().st_mode & stat.S_IXUSR)
    return PUBLISHED_EXECUTABLE_MODE if executable else PUBLISHED_FILE_MODE


def _source_for(name: str) -> Path:
    parts = name.split("/")
    if (parts[:-1] in (["tools"], ["tools", "fleet"])
            and parts[-1] in STANDALONE_PACKAGE_SOURCES):
        return CHECKOUT / STANDALONE_PACKAGE_SOURCES[parts[-1]]
    if name.startswith("tools/fleet/"):
        base = name.rsplit("/", 1)[1]
        source = CHECKOUT / "tools" / "fleet" / base
        return source if source.is_file() else CHECKOUT / "tools" / base
    if name in {f"tools/{script}" for script in TOP_LEVEL_SCRIPTS}:
        return CHECKOUT / name
    if name in ("tools/generation_receipt.py", "tools/digest_primitives.py"):
        return CHECKOUT / "src/prismabuild" / name.rsplit("/", 1)[1]
    if name.startswith("tools/"):
        base = name.rsplit("/", 1)[1]
        source = CHECKOUT / "tools" / "fleet" / base
        return source if source.is_file() else CHECKOUT / "tools" / base
    return CHECKOUT / name


def _imported_modules(source: Path) -> set[str]:
    """Top-level names ``source`` imports absolutely, at any depth."""
    tree = ast.parse(source.read_text(encoding="utf-8"), filename=str(source))
    names: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            names.update(alias.name.split(".")[0] for alias in node.names)
            names.update(alias.name for alias in node.names
                         if alias.name.startswith("prismabuild."))
        elif isinstance(node, ast.ImportFrom) and node.level == 0 and node.module:
            names.add(node.module.split(".")[0])
            if node.module == "prismabuild":
                names.update("prismabuild." + alias.name for alias in node.names)
            elif node.module.startswith("prismabuild."):
                names.add(node.module)
    return names


def _unshipped_imports(published: dict[str, str]) -> list[str]:
    """Published scripts that import a tools module this publication lacks (#1284).

    Neither dl380g10 nor sparklina has a checkout: the generation is the only
    place their commands exist, so a published script that imports a module
    of this checkout's ``tools/`` the publication does not carry dies at
    import on those boxes.  Generation 9098f84c872b did exactly that, and its
    tier role crash-looped on every respawn.
    """
    problems: list[str] = []
    for member in sorted(published):
        parts = member.split("/")
        if len(parts) != 2 or parts[0] != "tools" or not member.endswith(".py"):
            continue
        source = _source_for(member)
        if not source.is_file():
            continue
        for name in sorted(_imported_modules(source)):
            if name.startswith("prismabuild."):
                package_member = "src/" + name.replace(".", "/") + ".py"
                if (CHECKOUT / package_member).is_file() and package_member not in published:
                    problems.append(f"{member} imports {name}, which this "
                                    "publication does not carry")
            local = any((CHECKOUT / base / f"{name}.py").is_file()
                        for base in ("tools/fleet", "tools"))
            if local and f"tools/{name}.py" not in published:
                problems.append(f"{member} imports {name}, which this "
                                "publication does not carry")
    return problems


def _publication_manifest() -> dict[str, str]:
    published: dict[str, str] = {}
    for source in sorted((CHECKOUT / "src" / "prismabuild").glob("*.py")):
        published[f"src/prismabuild/{source.name}"] = _sha256(source)
    for name in ("generation_receipt.py", "digest_primitives.py"):
        published[f"tools/{name}"] = published[f"src/prismabuild/{name}"]
    for name, owner in STANDALONE_PACKAGE_SOURCES.items():
        if owner not in published:
            continue
        published[f"tools/{name}"] = published[owner]
        published[f"tools/fleet/{name}"] = published[owner]
    for name in FLEET_SCRIPTS:
        source = CHECKOUT / "tools" / "fleet" / name
        if not source.is_file():
            source = CHECKOUT / "tools" / name
        if not source.is_file():
            continue
        published[f"tools/{name}"] = _sha256(source)
        published[f"tools/fleet/{name}"] = published[f"tools/{name}"]
    for name in FLEET_DATA:
        source = CHECKOUT / "tools" / "fleet" / name
        if source.is_file():
            published[f"tools/{name}"] = _sha256(source)
            published[f"tools/fleet/{name}"] = published[f"tools/{name}"]
    skill = CHECKOUT / "skills" / "prismabuild" / "SKILL.md"
    if skill.is_file():
        published["skills/prismabuild/SKILL.md"] = _sha256(skill)
    # The installed skill requires the policy and operating guide. Keep the
    # small documentation tree and root guides together so their relative
    # references resolve within this same sealed generation, without a checkout.
    guides = [CHECKOUT / "README.md", CHECKOUT / "AGENTS.md",
              CHECKOUT / "worker-expansion-design.md",
              *sorted((CHECKOUT / "docs").rglob("*.md")),
              *sorted((CHECKOUT / "docs").rglob("*.json"))]
    for source in guides:
        if source.is_file():
            published[source.relative_to(CHECKOUT).as_posix()] = _sha256(source)
    # The published push-guard test depends on its repository-owned hook.
    hook = CHECKOUT / ".githooks" / "pre-push"
    if hook.is_file():
        published[".githooks/pre-push"] = _sha256(hook)
    for name in TOP_LEVEL_SCRIPTS:
        source = CHECKOUT / "tools" / name
        if source.is_file():
            published[f"tools/{name}"] = _sha256(source)
    for source in sorted((CHECKOUT / "tests").glob("*.py")):
        published[f"tests/{source.name}"] = _sha256(source)
    for name in OBSERVABILITY_FILES:
        source = CHECKOUT / "fleet" / "observability" / name
        if source.is_file():
            published[f"fleet/observability/{name}"] = _sha256(source)
    for name in STORAGE_FILES:
        source = CHECKOUT / "fleet" / "storage" / name
        if source.is_file():
            published[f"fleet/storage/{name}"] = _sha256(source)
    return published


def _fsync_file(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _fsync_directory(path: Path) -> None:
    descriptor = os.open(path, os.O_RDONLY)
    try:
        try:
            os.fsync(descriptor)
        except OSError:
            # Some NFS servers decline directory fsync.  Every regular member
            # is still flushed before the namespace operation below.
            pass
    finally:
        os.close(descriptor)


def _write_receipt(path: Path, receipt: dict[str, object]) -> str:
    from prismabuild.digest_primitives import raw_sha256
    raw = (json.dumps(receipt, indent=1) + "\n").encode("utf-8")
    with path.open("wb") as handle:
        handle.write(raw)
        handle.flush()
        os.fsync(handle.fileno())
    return raw_sha256(raw)


def _probe(root: Path) -> None:
    probe = subprocess.run(
        [sys.executable, "-B", "-c",
         "import sys; sys.path.insert(0, r'%s'); "
         "from prismabuild import pool, core; "
         "assert hasattr(pool.PoolQueue, 'claim'); print('import ok')"
         % (root / "src")],
        capture_output=True, text=True, check=False,
    )
    print((probe.stdout or probe.stderr).strip())
    if probe.returncode != 0:
        raise SystemExit(
            f"refusing to activate a runtime that failed its import probe "
            f"with status {probe.returncode}"
        )


def _seal_generation(root: Path) -> None:
    """Deny write to everyone, and settle the read and execute bits.

    Generations are append-only history, so write is denied to the owner too.
    The rest of the mode is set here rather than inherited: a directory came
    from ``mkdir`` under the publisher's umask and the receipt came from
    ``open("w")`` under the same umask, so a umask-077 publisher would close
    the generation to its non-owner readers by accident -- which is the defect
    in #316, one level up from the files.  Every member therefore lands on
    ``PUBLISHED_*_MODE``; the copy loop has already set each file's execute
    bit from the Git index, and this preserves that distinction rather than
    re-deciding it.
    """

    for path in sorted(root.rglob("*"), reverse=True):
        if path.is_symlink():
            continue
        if path.is_dir():
            path.chmod(PUBLISHED_DIRECTORY_MODE)
        elif path.stat().st_mode & stat.S_IXUSR:
            path.chmod(PUBLISHED_EXECUTABLE_MODE)
        else:
            path.chmod(PUBLISHED_FILE_MODE)
    root.chmod(PUBLISHED_DIRECTORY_MODE)

def _sign_movement_approval(generation: Path, *, receipt_sha256: str) -> None:
    """Write the movement-role publisher approval sibling (#1659).

    Best effort: without the dedicated publisher principal's signing secret
    there is no approval, enrolled hosts publish no protected copy, and the
    fleet keeps the behaviour it had before roles existed. The secret must be
    0600, owned by the publisher account, and under an account that does not
    own the runtime store: a same-account key is refused, so a store writer
    cannot approve its own bytes. A person approves that principal once.
    The digest comes from the receipt bytes constructed by this publisher.
    Never read approval input from the exposed generation store.
    """
    try:
        import hashlib as _hashlib
        import hmac as _hmac
        import os as _os
        key_path = Path.home() / ".config" / "prismabuild" / "movement-approval.key"
        info = key_path.stat()
        if info.st_mode & 0o077 or info.st_uid != _os.geteuid():
            return
        try:
            if info.st_uid == generation.parent.stat().st_uid:
                return
        except OSError:
            return
        secret = key_path.read_text(encoding="utf-8").strip()
        if not __import__("re").fullmatch(r"[0-9a-f]{64}", secret):
            return
        if not re.fullmatch(r"[0-9a-f]{64}", receipt_sha256):
            return
        tag = _hmac.new(bytes.fromhex(secret), receipt_sha256.encode("utf-8"), _hashlib.sha256).hexdigest()
        sibling = generation.parent / f"{generation.name}.approval"
        sibling.write_text(tag + "\n", encoding="utf-8")
    except (OSError, ValueError):
        return


def _unseal_tree(root: Path) -> None:
    """Undo ``_seal_generation`` on a tree that is still private to us."""

    for path in [root, *root.rglob("*")]:
        if path.is_symlink():
            continue
        path.chmod(path.stat().st_mode | 0o200)


def _remove_staging_tree(stage: Path) -> None:
    """Remove a private ``.staging`` tree even after it was sealed.

    ``_seal_generation`` runs before the rename, so a failure between the two
    leaves a read-only tree that plain ``rmtree`` cannot delete, and the leak
    sits under ``runtime-generations`` forever (issue #34).  Only the private
    staging target is ever unsealed here; a published generation is never
    touched.  This runs from a ``finally``: a cleanup failure is reported and
    swallowed so the publication error that caused it stays the exception the
    caller sees.
    """

    if stage.suffix != ".staging":
        raise ValueError(f"refusing to remove a non-staging tree: {stage}")
    try:
        _unseal_tree(stage)
        shutil.rmtree(stage)
    except OSError as exc:
        print(
            f"warning: staging tree survived failed publication: {stage}: {exc}",
            file=sys.stderr,
        )


def _activate(generation: Path, *, migrate_directory: bool) -> Path | None:
    """Expose ``generation`` at MIRROR in one namespace operation.

    Once MIRROR is a symlink, replacing a prepared sibling symlink is one
    atomic operation.  Linux ``RENAME_EXCHANGE`` would make the one-time move
    from the historical non-empty directory atomic too, but the fleet's NFS
    mount rejects that operation with ``EINVAL``.  That migration therefore
    requires an explicit maintenance flag: first retain the old directory,
    then install the complete symlink, rolling the old name back if install
    fails.  A caller can be refused in that narrow interval; it can never read
    a mixed generation.  Publication never deletes a prior generation.
    """

    MIRROR.parent.mkdir(parents=True, exist_ok=True)
    candidate = MIRROR.parent / f".{MIRROR.name}.activate-{uuid.uuid4().hex}"
    target = os.path.relpath(generation, MIRROR.parent)
    os.symlink(target, candidate)
    _fsync_directory(MIRROR.parent)
    legacy: Path | None = None
    try:
        if MIRROR.is_symlink() or not MIRROR.exists():
            os.replace(candidate, MIRROR)
        elif MIRROR.is_dir():
            if not migrate_directory:
                raise SystemExit(
                    f"{MIRROR} is the legacy directory runtime; refusing its "
                    "one-time maintenance handoff without --migrate-directory"
                )
            legacy = generation.parent / (
                f"legacy-{int(time.time())}-{uuid.uuid4().hex[:8]}"
            )
            os.replace(MIRROR, legacy)
            try:
                os.replace(candidate, MIRROR)
            except BaseException:
                if not MIRROR.exists() and not MIRROR.is_symlink():
                    os.replace(legacy, MIRROR)
                raise
        else:
            raise SystemExit(
                f"refusing to replace live runtime {MIRROR}: expected a "
                "directory or symlink"
            )
        _fsync_directory(MIRROR.parent)
    finally:
        if candidate.is_symlink():
            candidate.unlink()
    return legacy


class _CanaryPrecondition(Exception):
    """The canary produced no verdict on the generation.

    Missing driver, unimportable driver, a driver that raises, or a driver
    whose return shape drifted from the assumed contract below: in every case
    there is nothing to verify against, and "did not test" is never "passed",
    so the rollout record is marked ``failed`` with the reason in ``detail``.
    """


def _shape_gate_path() -> Path:
    """The pre-publish shape gate (#987), read from the publishing checkout."""

    return CHECKOUT / "tools" / "fleet" / "shape_gate.py"


def _load_shape_gate():
    """Import the checkout's shape gate, the module that judges its receipt."""

    path = _shape_gate_path()
    if not path.is_file():
        raise SystemExit(
            f"no shape gate at {path}: this checkout cannot verify a gate "
            "receipt.  Nothing was published."
        )
    spec = importlib.util.spec_from_file_location("shape_gate", path)
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot load the shape gate at {path}: no import spec")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def _shape_gate_record(args, *, commit: str, dirty: bool) -> dict[str, object]:
    """The gate's verdict on ``commit``, or refuse to publish.

    A fresh publication, ``--stage-only`` and ``--dry-run`` included, names
    either a passing gate run of this commit (``--shape-gate-action``) or a
    reason to publish without one (``--shape-gate-waiver``).  There is no
    third way and no default: a generation's receipt says which it was, and
    the rollout canary prints it.
    """

    waiver = args.shape_gate_waiver
    if waiver is not None:
        return {"verdict": "waived", "reason": waiver.strip()}
    if args.shape_gate_action is None:
        raise SystemExit(
            "refusing to publish without the pre-publish shape gate (#987).  "
            "Run it against this commit as one PB shard:\n"
            "  pbtest.py --checkout <this tree> --python <venv>/bin/python "
            "--tag gb10 --priority 0 --timeout-s 3600 --shards 1 "
            "--json <receipt>.json tests/gate_campaign_shape.py\n"
            "then pass its action key as --shape-gate-action KEY, or pass "
            "--shape-gate-waiver REASON to publish without it.  Nothing was "
            "published."
        )
    if dirty:
        raise SystemExit(
            "a dirty tree is not the commit the shape gate ran: the gate "
            "receipt covers committed bytes only.  Commit and rerun the gate, "
            "or pass --shape-gate-waiver REASON.  Nothing was published."
        )
    gate = _load_shape_gate()
    try:
        return gate.verify_gate_receipt(
            action_key=args.shape_gate_action, commit=commit, checkout=CHECKOUT,
            queue_root=MIRROR.parent / "pb-queue", cas_root=MIRROR.parent / "cas")
    except gate.ShapeGateFailure as exc:
        raise SystemExit(
            f"the shape gate receipt does not cover {commit[:12]}: "
            f"{exc.detail}.  Nothing was published."
        ) from exc


def _shape_gate_line(record: dict[str, object]) -> str:
    """One line naming how a generation passed the shape gate."""

    if record.get("verdict") == "waived":
        return f"shape gate: WAIVED: {record.get('reason')}"
    return (f"shape gate: passed by {str(record.get('action_key'))[:12]} "
            f"on {record.get('finished_host')} "
            f"(tables {', '.join(map(str, record.get('tables') or ()))})")


def _roster_option_names(args: object, *, where: str) -> set[str]:
    """The ``--`` option names ``args`` declares, without values.

    Only the names matter: a value that moves (``--mem-gb 96`` to
    ``--mem-gb 104``) keeps the capability, while a name that vanishes
    (``--gang-admission``) removes it.  Both spellings of a valued
    option count as the same name (``--python X`` and ``--python=X``).
    A bare ``--`` token ends the options, as it does on a command
    line; anything after it is a positional, not an option.

    A box that declares no list of args is malformed, not empty: the
    gate refuses it rather than reading silence as "no options to
    keep" (#1664).  ``where`` names the roster side in that refusal.
    """

    if not isinstance(args, list) or not all(isinstance(arg, str)
                                             for arg in args):
        raise SystemExit(f"refusing to publish: {where} declares no usable "
                         f"loop args (#1664). Nothing was published and the "
                         f"live runtime still points where it did.")
    names: set[str] = set()
    for arg in args:
        if arg == "--":
            break
        if not arg.startswith("--") or len(arg) == 2:
            continue
        names.add(arg.split("=", 1)[0])
    return names


def _dropped_roster_options(live: object, candidate: object) -> dict[str, list[str]]:
    """Option names ``candidate`` drops per box, keyed by roster key (#1664).

    Every box the live roster declares is compared under its own key;
    an alias answers for the box's placement tags, never for its
    options, so the same key must carry the same names in both
    rosters.  A box the candidate adds starts fresh.  A box the
    candidate removes or reshapes without a usable ``args`` list drops
    every live name the box declared: the seal and the mirror carry the
    candidate's bytes, so a missing entry cannot keep a live flag.
    """

    dropped: dict[str, list[str]] = {}
    live_boxes = live.get("boxes") if isinstance(live, dict) else None
    candidate_boxes = (candidate.get("boxes") if isinstance(candidate, dict)
                       else None)
    if not isinstance(live_boxes, dict):
        return dropped
    if not isinstance(candidate_boxes, dict):
        raise SystemExit("refusing to publish: the candidate roster has no "
                         "boxes mapping (#1664). Nothing was published and "
                         "the live runtime still points where it did.")
    for key in sorted(live_boxes):
        live_entry = live_boxes[key]
        if not isinstance(live_entry, dict):
            continue
        live_names = _roster_option_names(
            live_entry.get("args"), where=f"live box {key!r}")
        candidate_entry = candidate_boxes.get(key)
        if not isinstance(candidate_entry, dict):
            missing = sorted(live_names)
        else:
            try:
                candidate_names = _roster_option_names(
                    candidate_entry.get("args"),
                    where=f"candidate box {key!r}")
            except SystemExit:
                missing = sorted(live_names)
            else:
                missing = sorted(live_names - candidate_names)
        if missing:
            dropped[key] = missing
    return dropped


def _live_roster() -> dict | None:
    """The live generation's roster, or ``None`` when there is none to keep.

    The comparison reads the sealed generation the live pointer names,
    not a mirror copy beside it: a stale ``fleet_boxes.json`` next to
    ``repo`` caused the 2026-10-09 gang outage by answering for a
    generation that still carried the flag.  A bootstrap with no live
    pointer, a legacy directory runtime, or a generation that predates
    the roster has no live names to preserve, so it passes.
    """

    try:
        if not MIRROR.is_symlink():
            return None
        live = MIRROR.resolve(strict=True)
    except OSError:
        return None
    if not live.is_dir() or live.name.startswith("."):
        return None
    try:
        return fleet_roster.Roster.at(live).document
    except (OSError, ValueError):
        return None


def _candidate_roster(expected_sha256: str) -> fleet_roster.Roster:
    """The roster this publication would publish, or refuse."""

    try:
        roster = fleet_roster.Roster.at(CHECKOUT, expected_sha256=expected_sha256)
        roster.validate_publication()
    except (OSError, ValueError) as exc:
        raise SystemExit(f"cannot publish the candidate roster: {exc}") from exc
    return roster


def _roster_option_record(args, candidate: fleet_roster.Roster | None) -> dict[str, object] | None:
    """Refuse a candidate that drops a live ``--`` option name (#1664).

    The check runs inside the publication lock, before anything is
    staged, and reads the sealed live generation the pointer names. The
    candidate is the already captured, manifest-verified publication roster.
    An explicit override names who removes the option and why; both
    are recorded in the receipt with the dropped names.  A bootstrap
    with no live generation, or a live generation without a roster,
    has nothing to preserve and passes with no record.
    """

    live = _live_roster()
    if live is None:
        return None
    if candidate is None:
        raise SystemExit("candidate roster is absent from publication manifest")
    dropped = _dropped_roster_options(live, candidate.document)
    if not dropped:
        return None
    by = args.drop_roster_option_by
    reason = args.drop_roster_option_reason
    if by is None or reason is None:
        lines = [f"{key}: {', '.join(names)}" for key, names in dropped.items()]
        raise SystemExit(
            "refusing to publish: the candidate roster drops a -- option "
            "the live generation declares (#1664): "
            + "; ".join(lines) + ". Nothing was published and the live "
            "runtime still points where it did. Pass "
            "--drop-roster-option-by WHO --drop-roster-option-reason WHY "
            "to remove the option on purpose; both are recorded in the "
            "generation's receipt.")
    return {"by": by.strip(), "reason": reason.strip(), "dropped": dropped}


def _canary_driver_path() -> Path:
    """Where crew A's driver (issue #688 deliverable 1) is expected."""

    return CHECKOUT / "tools" / "fleet" / "pbcanary.py"


def _load_canary_driver():
    """Import the driver; never duplicate its submit-and-verify logic.

    CONFIRMED crew-A entry shape (verified at #688 integration against
    ``tools/fleet/pbcanary.py``): ``run_canary(generation=<name>) -> int``,
    where the int is the issue's verdict exit code (0 every leg verified,
    1 a leg failed its contract, 2 precondition refused). The driver's
    other settings take their CLI defaults; the generation is recorded in
    its run record and sealed into each action's environment. Anything
    else -- no ``run_canary`` attribute, a non-int return, an exception --
    is a ``_CanaryPrecondition``: the generation is marked ``failed`` and
    publication exits nonzero, rather than inventing a verdict.
    ``SystemExit`` raised by the driver is honored as its verdict code
    (``None`` counts as 0, a string message as 1).
    """

    driver = _canary_driver_path()
    if not driver.is_file():
        raise _CanaryPrecondition(
            f"no canary driver at {driver}: crew A has not landed "
            "tools/fleet/pbcanary.py in this checkout"
        )
    spec = importlib.util.spec_from_file_location("pbcanary", driver)
    if spec is None or spec.loader is None:
        raise _CanaryPrecondition(
            f"cannot load canary driver at {driver}: no import spec"
        )
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except SystemExit:
        raise
    except Exception as exc:
        raise _CanaryPrecondition(
            f"canary driver at {driver} failed to import: {exc!r}"
        ) from exc
    entry = getattr(module, "run_canary", None)
    if entry is None:
        raise _CanaryPrecondition(
            f"canary driver at {driver} has no run_canary(generation=...) "
            "entry: assumed crew-A shape drifted; refusing to invent a verdict"
        )
    return entry


def _invoke_canary_driver(generation_name: str, *, publication_slot: bool = True) -> tuple[int, str]:
    """Run the driver against the just-activated generation; return (code, detail)."""

    # Resolve the shared helper before the driver starts its submission budget.
    import pbstatus

    entry = _load_canary_driver()
    report: dict = {}

    def authorize(action, *, run_id, deadline):
        # POSIX publication ownership belongs to this process, not a fork
        # inheriting a positive nesting depth or a readable random token.
        if _PUBLISH_LOCK_DEPTH < 1 or _PUBLISH_LOCK_PID != os.getpid():
            raise ValueError("publication canary mint requires the owned publication lock")
        remaining = float(deadline) - time.monotonic()
        if not math.isfinite(remaining) or remaining <= 0:
            raise TimeoutError("publication canary authorization deadline expired")
        budget = pbstatus.Deadline(remaining)
        sys.path.insert(0, str(CHECKOUT / "src"))
        from prismabuild import core, publication_canary
        checked = core.validate_action(action)
        value = publication_canary.intent(checked)
        environment = checked.get("environment")
        variables = environment.get("variables") if isinstance(environment, dict) else None
        if not isinstance(variables, dict):
            raise ValueError("publication canary environment is not a mapping")
        if (value is None or value["generation"] != generation_name
                or value["host"] != socket.gethostname()
                or variables.get("PBCANARY_LEG") != "leg-2"
                or variables.get("PBCANARY_RUN_ID") != run_id
                or variables.get("PBCANARY_GENERATION") != generation_name):
            raise ValueError("publication canary action does not bind this publisher run")
        # Only this parent authorizes. The exact, exclusive-create mutation
        # runs in the existing bounded helper: a hard-mounted store cannot
        # trap the publisher while it holds the publication lock. A timed-out
        # helper can leave a late grant, but receives no READY authorization;
        # never retry an uncertain mint or reclaim its one-generation budget.
        abandoned = []
        minted = pbstatus.bounded(
            "publication canary mint",
            lambda: str(publication_canary.mint(
                MIRROR.parent / "pb-queue", checked, run_id=run_id)),
            deadline=budget, abandoned=abandoned, announce_retained=False)
        if minted.get("status") == "timed_out":
            raise TimeoutError(
                "publication canary mint deadline expired; "
                f"retained helper={json.dumps(abandoned, sort_keys=True)}")
        if minted.get("status") != "ok":
            raise ValueError(f"publication canary mint refused: {minted.get('error')}")

    try:
        # Older retained drivers implement the original generation-only API.
        # New drivers return their durable per-leg identities through report.
        parameters = inspect.signature(entry).parameters
        options: dict[str, object] = {"report": report} if "report" in parameters else {}
        if publication_slot and "publication_canary_authorizer" in parameters:
            options["publication_canary_authorizer"] = authorize
        result = entry(generation=generation_name, **options)
    except SystemExit as exc:
        code = exc.code
        if code is None:
            return 0, "driver exited without a code; counted as verified"
        if isinstance(code, int):
            return code, f"driver raised SystemExit({code})"
        return 1, f"driver refused: {code}"
    except _CanaryPrecondition:
        raise
    except Exception as exc:
        raise _CanaryPrecondition(
            f"canary driver raised instead of returning a verdict: {exc!r}"
        ) from exc
    if isinstance(result, bool) or not isinstance(result, int):
        raise _CanaryPrecondition(
            f"canary driver returned {result!r}: assumed contract is "
            "run_canary(generation=...) -> int exit code (0/1/2 per #688)"
        )
    detail = {
        0: "every leg executed and every receipt verified",
        1: "a leg failed its contract; the driver names the leg and the refusing check",
        2: "canary not verified: precondition refused or observation/staging budget exhausted",
    }.get(result, f"unrecognized driver exit code: {result}")
    if report:
        detail += "; " + json.dumps(report, sort_keys=True)
    return result, detail


def _canary_record_path(store: Path, generation_name: str) -> Path:
    """The rollout record: a sidecar beside the sealed generation.

    The generation directory itself is sealed read-only at publication, so
    the post-activation verdict cannot live inside it without breaking the
    append-only history. This sibling file is the only mutable rollout
    state, and ``supervise`` ignores store children that carry no
    ``RUNTIME_VERSION.json``, so it is never mistaken for a generation.
    """

    return store / f"{generation_name}.canary.json"


def _write_canary_record(
    path: Path, *, generation: str, commit: str, status: str,
    exit_code: int | None, detail: str, shape_gate: dict[str, object],
) -> None:
    assert status in CANARY_STATUSES, status
    _write_receipt(path, {
        "schema": CANARY_RECORD_SCHEMA,
        "generation": generation,
        "commit": commit,
        "canary_status": status,
        "canary_exit": exit_code,
        "detail": detail,
        "shape_gate": shape_gate,
        "recorded_unix": time.time(),
        "recorded_by": socket.gethostname(),
    })


def _run_rollout_canary(
    *, store: Path, generation_name: str, commit: str, enabled: bool,
    shape_gate: dict[str, object], publication_slot: bool = True,
    record_path: Path | None = None,
) -> int:
    """Record the canary outcome for an activated generation; return the process exit.

    Exit 0 means the rollout record says ``verified`` (canary ran green) or
    ``not_run`` (explicit skip). Exit 2 means ``not_run`` with incomplete
    verification (including starvation); it is not a pass. Exit 1 means ``failed``. A
    failure marks the record and exits nonzero; it never rolls anything back
    and never touches admission -- campaign-primacy (issue #688 non-goals).
    """

    record = record_path if record_path is not None else _canary_record_path(store, generation_name)
    # A waived gate is said on every rollout, whatever the canary does.
    print(f"{generation_name} {_shape_gate_line(shape_gate)}",
          file=sys.stderr if shape_gate.get("verdict") == "waived" else sys.stdout)
    if not enabled:
        reason = ("--no-canary" if CANARY_DEFAULT_ENABLED
                  else "gate default-OFF (phase 1); pass --canary to verify")
        _write_canary_record(record, generation=generation_name, commit=commit,
                             shape_gate=shape_gate, status="not_run", exit_code=None,
                             detail=f"canary skipped: {reason}")
        print(f"canary not_run for {generation_name}: {reason}")
        return 0
    _write_canary_record(record, generation=generation_name, commit=commit,
                         shape_gate=shape_gate, status="pending", exit_code=None,
                         detail="canary submitted against the activated generation")
    print(f"canary pending for {generation_name}; invoking the driver", flush=True)
    try:
        code, detail = (_invoke_canary_driver(generation_name) if publication_slot else
                        _invoke_canary_driver(generation_name, publication_slot=False))
    except _CanaryPrecondition as exc:
        _write_canary_record(record, generation=generation_name, commit=commit,
                             shape_gate=shape_gate, status="failed", exit_code=None, detail=str(exc))
        print(f"canary failed for {generation_name}: {exc}", file=sys.stderr)
        return 1
    if code == 0:
        _write_canary_record(record, generation=generation_name, commit=commit,
                             shape_gate=shape_gate, status="verified", exit_code=code, detail=detail)
        print(f"canary verified for {generation_name}: {detail}")
        return 0
    status = "not_run" if code == 2 else "failed"
    _write_canary_record(record, generation=generation_name, commit=commit,
                         shape_gate=shape_gate, status=status, exit_code=code, detail=detail)
    print(f"canary {status} for {generation_name} (exit {code}): {detail}; "
          "activation stands, nothing was rolled back", file=sys.stderr)
    return 2 if code == 2 else 1


def _rollout_reason(rollout: str, reason: str | None) -> str | None:
    """Validate the declaration that decides whether generations may mix."""

    if rollout not in {"barrier", "rolling"}:
        raise SystemExit(f"unknown rollout mode: {rollout!r}")
    if rollout == "rolling":
        if not isinstance(reason, str) or not reason.strip():
            raise SystemExit(
                "--rollout rolling requires a nonblank --rollout-reason stating "
                "why this generation is safe to run beside the previous one"
            )
        return reason.strip()
    if reason is not None:
        raise SystemExit("--rollout-reason is only valid with --rollout rolling")
    return None


@contextmanager
def _publication_lock():
    """One publisher or recovery coordinator, across NFS clients and threads.

    This permanent POSIX lock is never removed or broken on elapsed time.
    Closing another descriptor for this inode would release a process's lock,
    so nested entry reuses the outer descriptor instead of opening it again.
    """
    global _PUBLISH_LOCK_DEPTH, _PUBLISH_LOCK_PID
    with _PUBLISH_MUTEX:
        if _PUBLISH_LOCK_DEPTH:
            if _PUBLISH_LOCK_PID != os.getpid():
                raise SystemExit("a fork cannot inherit publication lock ownership")
            _PUBLISH_LOCK_DEPTH += 1
            try:
                yield
            finally:
                _PUBLISH_LOCK_DEPTH -= 1
            return
        path = MIRROR.parent / ".publication.lock"
        try:
            MIRROR.parent.mkdir(parents=True, exist_ok=True)
            fd = os.open(path, os.O_RDWR | os.O_CREAT | os.O_NOFOLLOW, 0o644)
        except OSError as exc:
            raise SystemExit(f"cannot open publication lock {path}: {exc}; nothing activated") from exc
        try:
            if not stat.S_ISREG(os.fstat(fd).st_mode):
                raise SystemExit(f"publication lock is not a regular file: {path}")
            try:
                fcntl.lockf(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)
            except BlockingIOError as exc:
                raise SystemExit("another publication or barrier coordinator holds the publication lock") from exc
            _PUBLISH_LOCK_DEPTH = 1
            _PUBLISH_LOCK_PID = os.getpid()
            try:
                yield
            finally:
                _PUBLISH_LOCK_DEPTH = 0
                _PUBLISH_LOCK_PID = None
        finally:
            os.close(fd)


def _rollout_config():
    return {"runtime": str(MIRROR),
            "generation_store": str(MIRROR.parent / "runtime-generations"),
            "rollout_root": str(MIRROR.parent / "rollout")}


def _require_external_coordinator():
    # A production barrier waits for every admitted scope, including its own
    # caller. Stage/probe through PB, then drive only the control-plane
    # transition externally. Private qualification fleets remain admitted.
    if (MIRROR.parent.resolve() == Path("/mnt/shared/prismabuild-fleet").resolve()
            and re.search(r"prismabuild-job[0-9a-f]{32}\.slice",
                          Path("/proc/self/cgroup").read_text())):
        raise SystemExit("a live barrier cannot coordinate from its own admitted scope; "
                         "use --stage-only through PB, then activate or resume externally")


def _require_barrier_qualification() -> None:
    """Keep every public barrier mutation disabled until qualification is reviewed.

    Private source fixtures deliberately set the module constant false around
    their state-machine exercise.  No pathname is an authority boundary here:
    public publication, resume, and rollback all refuse by default everywhere.
    """
    if FINAL_BARRIER_QUALIFICATION_GUARD:
        raise SystemExit(
            "barrier activation remains qualification-guarded: source protocol "
            "is present, but no runtime generation was staged or activated"
        )


def _rollout_view(epoch=None):
    _coordinator_sha256()
    try:
        agent = _agent_definitions()
        view = agent.read_rollout(_rollout_config(), epoch)
        if view is not None:
            _assert_coordinator_identity(view, agent=agent)
        return view
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"rollout epoch evidence unavailable: {exc}; admission must remain held") from exc


def _assert_coordinator_identity(view, *, agent=None):
    """Bind retained decisions to the exact coordinator and marker semantics."""
    expected = view["intent"].get("coordinator_sha256")
    if expected != _coordinator_sha256():
        raise SystemExit("rollout coordinator identity differs from the armed epoch")
    try:
        expected_agent = view["intent"]["agent_sha256"]
        if agent is None:
            agent = _agent_definitions(expected_sha=expected_agent)
        if agent._pb_source_sha256 != expected_agent:
            raise SystemExit("rollout marker semantics identity differs from the armed updater hash")
        source = CHECKOUT / "tools" / "fleet" / "upgrade_client.py"
        if _sha256(source) != expected_agent:
            raise SystemExit("rollout marker semantics differ from the armed updater hash")
        if not hasattr(agent, "validate_marker"):
            raise SystemExit("rollout marker helper lacks validation semantics")
    except OSError as exc:
        raise SystemExit(f"rollout coordinator identity cannot be read: {exc}") from exc
    return agent


def _bootstrap_pending_path():
    return MIRROR.parent / "rollout" / "pending-bootstrap.json"


def _require_no_pending_bootstrap():
    path = _bootstrap_pending_path()
    try:
        path.lstat()
    except FileNotFoundError:
        return
    raise SystemExit("pending installed bootstrap excludes ordinary publication; resume its exact assessment")


def _bootstrap_roster(source, target):
    groups = []
    for root in (source, target):
        captured = GenerationReceipt.capture((root / "RUNTIME_VERSION.json").read_bytes())
        roster = fleet_roster.Roster.qualified(root, captured.files)
        active, _ = _active_roster_boxes(roster)
        groups.append({host: sorted(names) for host, names in active})
    if groups[0] != groups[1]:
        raise WindowError("bootstrap source/target enrolled rosters differ")
    return groups[0]


def _bootstrap_fsync_directory(path):
    descriptor = os.open(path, os.O_RDONLY | os.O_DIRECTORY | os.O_NOFOLLOW)
    try:
        os.fsync(descriptor)
    finally:
        os.close(descriptor)


def _durable_bootstrap_directory(path):
    missing = []
    cursor = path
    while not cursor.exists():
        missing.append(cursor)
        cursor = cursor.parent
    for directory in reversed(missing):
        directory.mkdir()
        _bootstrap_fsync_directory(directory)
        _bootstrap_fsync_directory(directory.parent)
        if not directory.is_dir() or directory.is_symlink():
            raise WindowError("bootstrap directory readback differs")
    for directory in (path, *path.parents):
        _bootstrap_fsync_directory(directory)


def _write_bootstrap_pending(path, value):
    _durable_bootstrap_directory(path.parent)
    temporary = path.parent / (".bootstrap-" + uuid.uuid4().hex)
    try:
        _write_receipt(temporary, value)
        os.replace(temporary, path)
        _bootstrap_fsync_directory(path.parent)
        if json.loads(path.read_bytes()) != value:
            raise WindowError("bootstrap intent readback differs")
    finally:
        temporary.unlink(missing_ok=True)


def _record_bootstrap_root_responses(plan, observations, phase):
    from prismabuild.digest_primitives import canonical_sha256
    directory = MIRROR.parent / "rollout/bootstrap" / plan["id"]
    _durable_bootstrap_directory(directory)
    path = directory / (phase + "-" + observations.nonce + ".json")
    digest = _write_receipt(path, {"schema": "prismabuild.bootstrap_root_transcript.v1",
        "plan_sha256": canonical_sha256(plan), "nonce": observations.nonce,
        "started_unix": observations.started_unix, "responses": observations.rows})
    _bootstrap_fsync_directory(directory)
    if raw_sha256(path.read_bytes()) != digest:
        raise WindowError("bootstrap transcript readback differs")
    return {"path": str(path), "sha256": digest}


def _reserve_installed_bootstrap(assessment_path):
    from prismabuild import installed_bootstrap
    from prismabuild.digest_primitives import canonical_sha256
    assessment = installed_bootstrap.read_assessment(assessment_path)
    plan = assessment["plan"]
    with _publication_lock():
        _require_no_epoch()
        source, _ = _sealed_generation(plan["source"]["generation"])
        target, _ = _sealed_generation(plan["target"]["generation"])
        expected_pointer = target if plan.get("direction") == "restore" else source
        if MIRROR.resolve(strict=True) != expected_pointer or _bootstrap_roster(source, target) != plan["roster"]:
            raise SystemExit("bootstrap reservation source or roster changed")
        qualification = installed_bootstrap.verify_qualification(assessment, checkout=CHECKOUT, fleet_root=MIRROR.parent)
        if plan.get("qualified_runtimes") != list(qualification.runtimes):
            raise WindowError("bootstrap reservation native runtime bindings differ from verified receipts")
        installed_bootstrap.require_live_window(plan, target=target)
        if plan.get("direction") == "restore":
            accepted = _bootstrap_pending_path().parent / ("bootstrap-" + plan["id"] + "-forward.accepted.json")
            prior = json.loads(accepted.read_bytes())
            if prior.get("forward_plan_sha256") != canonical_sha256({**plan, "direction": "forward"}):
                raise SystemExit("rollback differs from the accepted original bootstrap intent")
        _write_bootstrap_pending(_bootstrap_pending_path(), {
            "schema": "prismabuild.pending_bootstrap.v1", "id": plan["id"],
            "direction": plan.get("direction", "forward"),
            "source": plan["source"], "target": plan["target"],
            "forward_plan_sha256": canonical_sha256({**plan, "direction": "forward"}), "state": "reserved"})
        return 0


def _activate_installed_bootstrap(name, assessment_path, *, dry_run=False, rollout="rolling"):
    from prismabuild import installed_bootstrap
    from prismabuild.digest_primitives import canonical_sha256
    if rollout != "rolling":
        raise SystemExit("installed bootstrap requires explicit rolling activation")
    _require_external_coordinator()
    assessment = installed_bootstrap.read_assessment(assessment_path)
    plan = assessment["plan"]
    direction = plan.get("direction", "forward")
    selected = plan["target" if direction == "forward" else "source"]["generation"]
    if name != selected:
        raise SystemExit("installed bootstrap activation target differs from its original intent")
    with _publication_lock():
        # Check epochs without mistaking our own pending bootstrap for one.
        directory = MIRROR.parent / "rollout/epochs"
        if directory.exists() and _rollout_view() is not None:
            raise SystemExit("active rollout epoch excludes installed bootstrap")
        source, _ = _sealed_generation(plan["source"]["generation"])
        target, receipt = _sealed_generation(plan["target"]["generation"])
        if receipt["files"].get("tools/publish_runtime.py") != _coordinator_sha256():
            raise WindowError("bootstrap coordinator differs from the sealed target")
        roster = _bootstrap_roster(source, target)
        pending = _bootstrap_pending_path()
        intent = {"schema": "prismabuild.pending_bootstrap.v1", "id": plan["id"],
            "direction": plan.get("direction", "forward"),
                  "source": plan["source"], "target": plan["target"],
                  "forward_plan_sha256": canonical_sha256({**plan, "direction": "forward"})}
        if pending.is_symlink():
            raise SystemExit("unsafe pending bootstrap marker")
        prior = json.loads(pending.read_bytes()) if pending.exists() else None
        ownership = {key: value for key, value in intent.items() if key != "direction"}
        if prior is not None and any(prior.get(key) != value for key, value in ownership.items()):
            raise SystemExit("another pending bootstrap owns publication")
        select_restore = prior is not None and prior.get("direction") != direction
        if select_restore:
            if (prior.get("direction") != "forward" or direction != "restore"
                    or prior.get("state") not in ("reserved", "activation-intent", "awaiting-convergence", "ordinary-canary")):
                raise SystemExit("pending bootstrap direction cannot change through this activation")
            intent["direction_decision"] = {
                "from": "forward", "to": "restore", "selected_unix": time.time(),
                "plan_sha256": canonical_sha256(plan), "previous_intent": prior}
        elif prior is not None and "direction_decision" in prior:
            decision = prior["direction_decision"]
            if (direction != "restore" or decision.get("from") != "forward"
                    or decision.get("to") != "restore" or decision.get("plan_sha256") != canonical_sha256(plan)
                    or any(decision.get("previous_intent", {}).get(key) != value for key, value in ownership.items())
                    or decision.get("previous_intent", {}).get("direction") != "forward"):
                raise SystemExit("pending bootstrap reverse decision differs from original intent")
            intent["direction_decision"] = decision
        live = MIRROR.resolve(strict=True)
        if live not in (source, target) or (prior is None and live != source):
            raise SystemExit("bootstrap source pointer differs from original a174 intent")
        if not dry_run and socket.gethostname().split('.')[0] not in ("sparky", "sparklina", "gx10-6b77"):
            raise SystemExit("bootstrap coordinator must run on sparky or sparklina for the GPU canary")
        if select_restore and not dry_run:
            # Select recovery before external reads. Every subsequent progress
            # record retains the previous intent and the irreversible direction.
            _write_bootstrap_pending(pending, {**intent, "state": "restore-selected"})
        # Receipt verification may read substantial evidence. Fresh challenges
        # follow it, while the same publication lock still excludes mutation.
        result, observations = installed_bootstrap.assess(
            assessment, checkout=CHECKOUT, fleet_root=MIRROR.parent,
            source=source, target=target, roster=roster, verify_live=True)
        if dry_run:
            return 0
        transcript = _record_bootstrap_root_responses(plan, observations, "before-activation")
        _write_bootstrap_pending(pending, {**intent, "state": "activation-intent",
            "direction": direction, "assessment": result, "root_transcript": transcript})
        # Recheck both sealed identities after all external reads. Responses
        # carry their own maximum age and exact captured/compiled identities.
        _sealed_generation(source.name)
        _sealed_generation(target.name)
        from prismabuild.compatibility_window import require_installed_bootstrap
        from prismabuild.compatibility_window import BootstrapQualification
        require_installed_bootstrap(source, target, observations, roster=roster,
            qualification=BootstrapQualification(plan, action_keys=result["actions"], runtimes=result["qualified_runtimes"]),
            rollback_designation=assessment["rollback_designation"])
        for row in observations.rows.values():
            scopes = row.get("broker", {}).get("active_scopes")
            if type(scopes) is not int or scopes != 0:
                raise WindowError("bootstrap activation waits for the ordinary idle-queue boundary")
        for state in ("ready", "claimed"):
            directory = MIRROR.parent / "pb-queue" / state
            if not directory.is_dir():
                raise WindowError("bootstrap queue directory is unavailable")
            with os.scandir(directory) as entries:
                if any(entry.name.endswith('.json') for entry in entries):
                    raise WindowError("bootstrap activation requires an observed empty ready and claimed queue")
        if not 0 <= time.time() - observations.started_unix <= 60:
            raise WindowError("bootstrap root responses expired while checking the queue")
        _activate(target if direction == "forward" else source, migrate_directory=False)
        _bootstrap_fsync_directory(MIRROR.parent)
        _write_bootstrap_pending(pending, {**intent, "state": "awaiting-convergence",
            "direction": direction, "assessment": result, "root_transcript": transcript})
        # Root observes real generation-pinned serving processes and fresh
        # worker offers after the pointer move. No process is stopped here.
        installed_bootstrap.require_convergence(plan, fleet_root=MIRROR.parent)
        selected_root = target if direction == "forward" else source
        selected_receipt = receipt if direction == "forward" else json.loads((source / "RUNTIME_VERSION.json").read_bytes())
        admission = assessment.get("canary_admission", "publication-slot")
        if admission not in ("ordinary", "publication-slot"):
            raise WindowError("unknown bootstrap canary admission mode")
        options = {}
        if admission == "ordinary":
            reason = assessment.get("ordinary_canary_reason")
            if not isinstance(reason, str) or not reason.strip():
                raise WindowError("ordinary bootstrap canary requires an explicit operator reason")
            record_path = target.parent / (selected_root.name + ".bootstrap-" + plan["id"] + "-" + observations.nonce + ".canary.json")
            options = {"publication_slot": False, "record_path": record_path}
            _write_bootstrap_pending(pending, {**intent, "state": "ordinary-canary", "direction": direction,
                "canary_record": str(record_path), "canary_admission": admission, "reason": reason,
                "assessment": result, "root_transcript": transcript})
        code = _run_rollout_canary(store=target.parent, generation_name=selected_root.name,
                    commit=selected_receipt["commit"], enabled=True,
                    shape_gate=selected_receipt.get("shape_gate", {}), **options)
        if code:
            return code
        final_observations = installed_bootstrap.require_convergence(plan, fleet_root=MIRROR.parent)
        final_transcript = _record_bootstrap_root_responses(plan, final_observations, "after-canary")
        canary_record = options.get("record_path", _canary_record_path(target.parent, selected_root.name))
        canary = json.loads(canary_record.read_bytes())
        if (canary.get("canary_status") != "verified" or canary.get("generation") != selected_root.name
                or canary.get("commit") != selected_receipt["commit"]):
            raise WindowError("bootstrap canary lacks a verified bound record")
        _write_bootstrap_pending(pending, {**intent, "state": "accepted", "direction": direction,
            "assessment": result, "root_transcript": transcript, "final_root_transcript": final_transcript,
            "canary_admission": admission, "canary_record": str(canary_record),
            "canary_sha256": raw_sha256(canary_record.read_bytes())})
        archive = pending.parent / ("bootstrap-" + plan["id"] + "-" + direction + ".accepted.json")
        os.replace(pending, archive)
        _bootstrap_fsync_directory(archive.parent)
        return 0


def _require_no_epoch():
    _require_no_pending_bootstrap()
    # Retain rolling/bootstrap use from minimal source trees before epochs
    # existed. An unavailable directory is never the same as an absent one.
    directory = MIRROR.parent / "rollout" / "epochs"
    try:
        directory.stat()
    except FileNotFoundError:
        return
    view = _rollout_view()
    if view is not None:
        raise SystemExit(f"rollout epoch {view['intent']['epoch']} remains active; "
                         "use --resume-barrier, not another publication")


def _sealed_generation(name):
    """Read-only receipt/member integrity shared by rollout and metadata inspection.

    This proves sealed filesystem bytes, not a process's loaded Python memory.
    Rollout-specific updater authority remains in ``_barrier_generation``.
    """
    if not isinstance(name, str) or re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._-]{0,127}", name) is None:
        raise SystemExit(f"invalid barrier generation: {name!r}")
    store = (MIRROR.parent / "runtime-generations").resolve(strict=True)
    root = store / name
    if root.resolve(strict=True) != root or root.stat().st_mode & 0o222:
        raise SystemExit(f"barrier generation is not sealed: {name}")
    try:
        captured = GenerationReceipt.capture((root / "RUNTIME_VERSION.json").read_text())
        receipt = captured.require_generation(name)
        captured.require_commit()
        for member in captured.files:
            path = captured.member_path(root, member)
            if (path.resolve(strict=True) != path or not path.is_file()
                    or path.stat().st_mode & 0o222 or not captured.matches_file(member, path)):
                raise ValueError(f"unsealed or changed generation member: {member}")
        return root, receipt
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"cannot qualify barrier generation {name}: {exc}") from exc


def _barrier_generation(name):
    """Revalidate integrity AND the existing rollout updater prerequisite."""
    root, receipt = _sealed_generation(name)
    try:
        agent_path = "tools/upgrade_client.py"
        if agent_path not in receipt["files"]:
            raise ValueError("no updater in generation")
        source = GenerationReceipt(receipt).source_declarations(
            agent_path, (root / agent_path).read_bytes())
        try:
            rollout_protocol = source.protocol("CLIENT_UPGRADE_ROLLOUT_PROTOCOL")
        except ValueError as exc:
            raise ValueError("generation has no rollout-aware updater; a rolling bridge is required") from exc
        if rollout_protocol != 1:
            raise ValueError("generation has no rollout-aware updater; a rolling bridge is required")
        return root, receipt
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"cannot qualify barrier generation {name}: {exc}") from exc


def _installed_updater_proofs(keys):
    """Each proving host's installed updater digest, read from its proof action (#1850).

    A proof is ``tools/fleet/updater_proof.py`` run as an ordinary PB action on
    the host.  The host is the one the queue records as claiming the attempt
    whose verified CAS result carries the proof, never the proof's own word;
    :func:`updater_proof.judge` requires the two to agree and the proof to be
    current.  One proof per host.
    """
    from prismabuild import client, record_store

    queue = client.PoolQueue(MIRROR.parent / "pb-queue")
    tool = updater_proof.tool_sha256()
    now = time.time()
    installed = {}
    for key in keys:
        if not isinstance(key, str) or re.fullmatch(r"[0-9a-f]{64}", key) is None:
            raise WindowError(f"installed updater proof {key!r} is not a full action key")
        try:
            record = record_store.read_bounded_document(
                queue.records.item_path(record_store.DONE, key), max_bytes=1 << 20)
            if not isinstance(record, dict):
                raise ValueError("no done ending")
            result = client.read_verified_action_result(
                queue, key, published_unix=record.get("published_unix"),
                attempt=record.get("attempts"), max_result_bytes=1 << 20)
        except (client.ActionResultError, OSError, ValueError, TypeError) as exc:
            raise WindowError(f"installed updater proof {key[:12]} has no verified result: {exc}") from exc
        host = result["host"]
        if not isinstance(host, str) or not host:
            raise WindowError(f"installed updater proof {key[:12]} names no claiming host")
        digest = updater_proof.judge(updater_proof.last_proof(result["payload"]),
                                     host=host, now=now, tool=tool)
        if host in installed:
            raise WindowError(f"more than one installed updater proof for {host}")
        installed[host] = digest
    return installed


def _require_reader_direction(target, *, rollout, receipt=None, files=None, proofs=()):
    """Source transport is necessary; rolling needs every participant's current installed proof."""
    try:
        roots = (target, MIRROR.resolve(strict=True) if MIRROR.exists() else None)
        observations = []
        for index, (root, captured) in enumerate(zip(roots, (receipt, None))):
            has_updater = root is not None and any((root / member).is_file() for member in
                ("tools/fleet/upgrade_client.py", "tools/upgrade_client.py"))
            if index == 0 and files is not None and "tools/upgrade_client.py" not in files:
                has_updater = False
            observations.append(client_protocol(root, receipt=captured) if has_updater else None)
        if files is not None and observations[0] is not None:
            captured = observations[0]
            if files["tools/upgrade_client.py"] != captured["updater_sha256"]:
                raise WindowError("candidate updater differs from the captured publication manifest")
        for row in observations:
            if row is not None:
                require_client_transition(row, row)
        if any(row is None for row in observations):
            if any(row and set(row["present"]) & RECEIPT_MEMBERS for row in observations):
                raise WindowError("receipt activation requires current installed updater proof; "
                                  "a separately authorized installed-reader bootstrap is required")
            return
        direction = require_client_transition(*observations)
        if rollout == "rolling" and any(set(row["present"]) & RECEIPT_MEMBERS for row in observations):
            if files is None:
                files = (receipt if receipt is not None else GenerationReceipt.capture(
                    (target / "RUNTIME_VERSION.json").read_bytes())).files
            live = GenerationReceipt.capture((roots[1] / "RUNTIME_VERSION.json").read_bytes())
            roster = _barrier_roster(((roots[1], {"files": live.files}), (target, {"files": files})))
            require_receipt_participants(direction, _installed_updater_proofs(proofs), roster)
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"refusing reader-first activation: {exc}") from exc


def _require_epoch_receipt_participants(view):
    """Drained participants proved installed AND executing intent agent bytes."""
    try:
        generations = tuple(_barrier_generation(view["intent"][key])
                            for key in ("to_generation", "from_generation"))
        sources = tuple(client_protocol(root, receipt=GenerationReceipt(receipt))
                        for root, receipt in generations)
        direction = require_client_transition(*sources)
        if not any(set(row["present"]) & RECEIPT_MEMBERS for row in sources):
            return
        intent = view["intent"]
        if any(row["updater_sha256"] != intent["agent_sha256"] for row in sources):
            raise WindowError("receipt epoch requires the same installed updater in both generations")
        if _barrier_roster(tuple(reversed(generations))) != intent["roster"]:
            raise WindowError("receipt epoch enrolled participant identities changed")
        _, missing = _quorum(view, "drained")
        if missing:
            raise WindowError(f"current installed updater quorum is missing: {missing}")
        agent = _assert_coordinator_identity(view)
        for host in intent["roster"]:
            marker = view["markers"][agent.marker_name(host, "drained")]
            if (marker["posted_unix"] < intent["armed_unix"]
                    or ("installed_agent_sha256" in marker
                        and marker["installed_agent_sha256"] != intent["agent_sha256"])):
                raise WindowError(f"current installed updater proof differs for {host}")
        # _rollout_status checks installed and executing hashes against this
        # intent before posting its epoch-bound drained marker. History is
        # never consulted for this current participant proof.
        installed = {host: intent["agent_sha256"] for host in intent["roster"]}
        require_receipt_participants(direction, installed, intent["roster"])
    except (OSError, ValueError, KeyError, TypeError) as exc:
        raise SystemExit(f"refusing reader-first epoch activation: {exc}") from exc


def _barrier_roster(generations):
    """Freeze the union of old/new boxes; a roster edit cannot drop a member.

    A box the *target* generation declares absent (``retired``/``offline``,
    #606) is excluded from the quorum instead: the union still freezes it, so
    a silent file edit cannot drop a member, but an explicit declared absence
    with its provenance is exactly how a member leaves.  An absent box that
    is still announcing is refused rather than skipped -- a live participant
    the quorum ignores is a split fleet, and the operator either stops it or
    un-declares the absence.  A group mixing absent and active names is the
    same ambiguity and refuses too.
    """
    groups = []
    boxes_by_generation = []
    for root, receipt in generations:
        try:
            roster = fleet_roster.Roster.qualified(root, receipt["files"])
            boxes = roster.boxes
            for key, declared_names, value in roster.barrier_declarations():
                names = set(declared_names)
                overlap = [group for group in groups if group & names]
                for group in overlap:
                    names |= group
                    groups.remove(group)
                groups.append(names)
            boxes_by_generation.append(boxes)
        except (OSError, ValueError, KeyError, TypeError) as exc:
            raise SystemExit(f"invalid barrier roster in {root.name}: {exc}") from exc
    # Offers only resolve spelling and reject undeclared live participants.
    # Their age is evaluated after the complete read, never used as quorum.
    offers = []
    directory = MIRROR.parent / "pb-queue/workers"
    try:
        for path in directory.iterdir():
            if path.name.startswith(".") or path.suffix != ".json":
                continue
            value = json.loads(path.read_text())
            if (not isinstance(value, dict) or value.get("schema") != "prismaquant.prismabuild.pool_offer.v1"
                    or path.name != str(value.get("host")) + ".json"):
                raise ValueError(f"invalid worker offer {path.name}")
            stamp = value.get("announced_unix")
            if type(stamp) not in (int, float) or not math.isfinite(stamp):
                raise ValueError(f"invalid worker offer time {path.name}")
            offers.append(value)
    except (OSError, ValueError, TypeError) as exc:
        raise SystemExit(f"cannot establish live barrier roster: {exc}") from exc
    now = time.time()
    live = {o["host"] for o in offers if -60 <= now - o["announced_unix"] <= 120}
    target_boxes = boxes_by_generation[-1]
    absent_names: set[str] = set()
    absent_detail: dict[str, str] = {}
    for key, value in target_boxes.items():
        status, detail = fleet_roster.box_status(key, value)
        if status in fleet_roster.ABSENT:
            names = {key}
            if isinstance(value, dict) and value.get("_alias"):
                names.add(value["_alias"])
            absent_names |= names
            absent_detail[key] = fleet_roster.describe_absent(key, detail)
    announced_absent = sorted(absent_names & live)
    if announced_absent:
        raise SystemExit(
            "barrier roster refuses: boxes declared absent are announcing: "
            f"{announced_absent}. Stop their loops or un-declare the absence: "
            + "; ".join(sorted(absent_detail.values()))
        )
    kept = []
    for group in groups:
        if group <= absent_names:
            continue
        if group & absent_names:
            raise SystemExit(
                f"barrier roster mixes absent and active names in one box: "
                f"{sorted(group)}; fix the roster's aliases and statuses")
        kept.append(group)
    groups = kept
    if not groups:
        raise SystemExit(
            "barrier roster is empty: every declared box is absent: "
            + "; ".join(sorted(absent_detail.values())))
    declared = set().union(*groups)
    if live - declared - absent_names:
        raise SystemExit(f"undeclared live barrier hosts: {sorted(live - declared - absent_names)}")
    canonical = []
    for group in groups:
        matches = live & group
        if len(matches) != 1:
            raise SystemExit(f"barrier roster requires exactly one live identity for {sorted(group)}; found {sorted(matches)}")
        canonical.append(matches.pop())
    return sorted(canonical)


def _quorum(view, phase):
    agent = _assert_coordinator_identity(view)
    observed, missing = {}, []
    for host in view["intent"]["roster"]:
        name = agent.marker_name(host, phase)
        value = view["markers"].get(name)
        if value is None:
            missing.append(host)
        else:
            agent.validate_marker(name, value, view["intent"], view["intent_sha256"])
            observed[host] = agent.digest(agent.canonical_json(value))
    return observed, missing


def _decision(view, phase, *, direction, observed, **extra):
    agent = _assert_coordinator_identity(view)
    generation = view["intent"]["to_generation" if direction == "forward" else "from_generation"]
    value = agent.make_marker(view["intent"], phase, generation=generation,
                              direction=direction, observed=observed,
                              decided_unix=time.time(),
                              decided_by=f"{socket.gethostname()}:{os.getuid()}", **extra)
    name = phase + ".json"
    agent.validate_marker(name, value, view["intent"], view["intent_sha256"])
    existing = view["markers"].get(name)
    if existing is not None:
        if any(existing.get(k) != v for k, v in value.items() if k not in ("decided_unix", "decided_by")):
            raise SystemExit(f"conflicting rollout decision: {name}")
        return
    _assert_coordinator_identity(view, agent=agent)
    if not agent.post_marker(MIRROR.parent / "rollout", f"epochs/{view['intent']['epoch']}/{name}",
                             agent.canonical_json(value)):
        raise SystemExit(f"rollout decision raced: {name}; re-read with --resume-barrier")


def _barrier_step(epoch, *, rollback_reason=None):
    """One recoverable step. No observation of elapsed time grants a swap."""
    view = _rollout_view(epoch)
    if view is None:
        raise SystemExit(f"rollout epoch disappeared: {epoch}")
    agent = _assert_coordinator_identity(view)
    intent, markers = view["intent"], view["markers"]
    source, target = intent["from_generation"], intent["to_generation"]
    live = view["live_generation"]
    if "terminal.json" in markers:
        return {"epoch": epoch, "state": markers["terminal.json"]["outcome"], "complete": True}
    drained, missing = _quorum(view, "drained")
    if rollback_reason is not None and "resume.json" in markers:
        raise SystemExit("rollback is refused after the fleet resume decision; use a new barrier")
    failures = [h for h in intent["roster"] if agent.marker_name(h, "failed") in markers]
    if rollback_reason is not None or (failures and "resume.json" not in markers):
        if missing:
            return {"epoch": epoch, "state": "draining", "missing": missing, "failed": failures, "complete": False}
        if "rollback.json" not in markers:
            _require_epoch_receipt_participants(view)
            _decision(view, "rollback", direction="rollback", observed=drained,
                      reason=rollback_reason or f"member rotation failed on {', '.join(failures)}")
            return {"epoch": epoch, "state": "rollback_declared", "complete": False}
    rollback = "rollback.json" in markers
    direction = "rollback" if rollback else "forward"
    expected = source if rollback else target
    if missing:
        if live != source:
            raise SystemExit("rollout symlink moved before the fleet drain quorum")
        return {"epoch": epoch, "state": "draining", "missing": missing, "complete": False}
    _require_epoch_receipt_participants(view)
    activation = "reverted" if rollback else "activated"
    if activation + ".json" not in markers:
        if live not in (source, target):
            raise SystemExit("unexpected third generation during rollout; all hosts remain held")
        root, _ = _barrier_generation(expected)
        _assert_coordinator_identity(_rollout_view(epoch))
        # The caller owns the publication lock. Re-read after potentially slow
        # member hashing so an external symlink change cannot become our swap.
        actual = MIRROR.resolve(strict=True).name
        if actual != live:
            raise SystemExit("runtime moved during rollout verification; admission remains held")
        if actual != expected:
            _activate(root, migrate_directory=False)
        if MIRROR.resolve(strict=True) != root:
            raise SystemExit("rollout activation readback mismatch; admission remains held")
        _decision(view, activation, direction=direction, observed=drained)
        return {"epoch": epoch, "state": activation, "complete": False}
    if live != expected:
        raise SystemExit("runtime differs from recorded rollout activation; admission remains held")
    rotated, missing = _quorum(view, "rolled-back" if rollback else "rotated")
    if "resume.json" not in markers:
        if missing:
            return {"epoch": epoch, "state": "rollback_rotating" if rollback else "rotating",
                    "missing": missing, "complete": False}
        _decision(view, "resume", direction=direction, observed=rotated)
        return {"epoch": epoch, "state": "resume_authorized", "complete": False}
    resumed, missing = _quorum(view, "resumed")
    if missing:
        return {"epoch": epoch, "state": "resuming", "missing": missing, "complete": False}
    outcome = "rolled_back" if rollback else "completed"
    _decision(view, "terminal", direction=direction, observed=resumed, outcome=outcome)
    return {"epoch": epoch, "state": outcome, "complete": True}


def _wait_barrier(epoch, *, wait_s=300, rollback_reason=None):
    _require_barrier_qualification()
    _require_external_coordinator()
    if not math.isfinite(wait_s) or wait_s < 0:
        raise SystemExit("--barrier-wait-s must be finite and nonnegative")
    deadline, previous = time.monotonic() + wait_s, None
    while True:
        result = _barrier_step(epoch, rollback_reason=rollback_reason)
        rendered = json.dumps(result, sort_keys=True)
        if rendered != previous:
            print(rendered, flush=True)
            previous = rendered
        if result["complete"]:
            return 0 if result["state"] == "completed" else 1
        if time.monotonic() >= deadline:
            print(f"barrier {epoch} remains pending; --resume-barrier {epoch} continues it. "
                  "No timeout releases admission.", flush=True)
            return 75
        time.sleep(min(2, max(0, deadline - time.monotonic())))


def _arm_barrier(name, *, wait_s=300):
    _require_barrier_qualification()
    _require_external_coordinator()
    _require_no_epoch()
    if not MIRROR.is_symlink():
        raise SystemExit("barrier requires an existing sealed runtime symlink")
    source = _barrier_generation(MIRROR.resolve(strict=True).name)
    target = _barrier_generation(name)
    if source[0] == target[0]:
        print(f"runtime already activates {name}; no rollout required")
        return 0
    member = "tools/upgrade_client.py"
    sha = target[1]["files"][member]
    coordinator_member = "tools/fleet/publish_runtime.py"
    coordinator_sha = target[1]["files"].get(coordinator_member)
    if (not isinstance(coordinator_sha, str)
            or source[1]["files"].get(coordinator_member) != coordinator_sha
            or coordinator_sha != _coordinator_sha256()):
        raise SystemExit("barrier requires the same executing coordinator in source and target; "
                         "converge a reviewed rolling bridge first")
    if source[1]["files"][member] != sha:
        raise SystemExit("barrier requires the same rollout-aware updater in both generations; "
                         "converge a reviewed rolling bridge first")
    _require_reader_direction(target[0], receipt=GenerationReceipt(target[1]), rollout="barrier")
    roster = _barrier_roster((source, target))
    # Historical presence is only the inexpensive bootstrap check. Fresh
    # participant markers, durable holds and quorums grant actual movement.
    agent = _agent_definitions(expected_sha=sha)
    attested = _attested_agents(agent)
    missing = [host for host in roster if sha not in attested.get(host, set())]
    if missing:
        raise SystemExit(f"barrier updater bootstrap attestations missing on {missing}")
    epoch = uuid.uuid4().hex
    intent = {"schema": "prismabuild.rollout_barrier.intent.v1", "epoch": epoch,
              "from_generation": source[0].name, "to_generation": name,
              "roster": roster, "agent_sha256": sha,
              "coordinator_sha256": coordinator_sha, "drain_policy": "wait",
              "armed_unix": time.time(), "armed_by": f"{socket.gethostname()}:{os.getuid()}"}
    agent.validate_intent(intent, epoch=epoch)
    if MIRROR.resolve(strict=True) != source[0]:
        raise SystemExit("runtime moved while arming the barrier")
    _assert_coordinator_identity({"intent": intent}, agent=agent)
    if not agent.post_marker(MIRROR.parent / "rollout", f"epochs/{epoch}/intent.json",
                             agent.canonical_json(intent)):
        raise SystemExit("rollout epoch identity collided; nothing activated")
    print(f"armed barrier {epoch}: {source[0].name} -> {name}; hosts={roster}", flush=True)
    return _wait_barrier(epoch, wait_s=wait_s)


def _activate_existing(
    name: str, *, dry_run: bool, rollout: str = "barrier",
    rollout_reason: str | None = None, wait_s: float = 300, proofs=(),
) -> int:
    if dry_run:
        return _activate_existing_locked(name, dry_run=True, rollout=rollout,
                                         rollout_reason=rollout_reason, wait_s=wait_s,
                                         proofs=proofs)
    with _publication_lock():
        return _activate_existing_locked(name, dry_run=False, rollout=rollout,
                                         rollout_reason=rollout_reason, wait_s=wait_s,
                                         proofs=proofs)


def _activate_existing_locked(
    name: str, *, dry_run: bool, rollout: str = "barrier",
    rollout_reason: str | None = None, wait_s: float = 300, proofs=(),
) -> int:
    """Point the live runtime at a generation that already exists.

    Rollback's whole job.  A generation is immutable and already carries a
    receipt proving its bytes, so restoring one is a namespace operation and
    nothing else -- no copy, no re-hash, no dependence on what the checkout
    happens to contain now.  Publication never deletes a generation, which is
    what makes this possible at all.

    The name is validated rather than trusted: it must be a direct child of the
    generation store, it must not be a dot-name, and it must carry a receipt
    that reads.  A path that escapes the store, a staging tree, or a directory
    that is not a published generation is refused before ``repo`` is touched.
    """

    rollout_reason = _rollout_reason(rollout, rollout_reason)
    _require_no_epoch()
    if rollout == "barrier" and not dry_run:
        return _arm_barrier(name, wait_s=wait_s)
    store = MIRROR.parent / "runtime-generations"
    # A dot-name is never a generation, and one shape of it is dangerous.  A
    # publish stages at ``.<generation>.staging`` in this same store, writes
    # the receipt into it, and removes it on failure -- but that removal
    # reports an OSError and continues, so an interrupted publish can leave a
    # survivor that carries a receipt and passes every other check here.  Its
    # bytes were never sealed or probed.
    if "/" in name or name in ("", ".", "..") or name.startswith("."):
        raise SystemExit(
            f"not a generation name: {name!r}. A staging tree left behind by "
            "an interrupted publish is a dot-name and carries a receipt; it "
            "is not a generation."
        )
    generation = store / name
    if not (generation / "RUNTIME_VERSION.json").is_file():
        raise SystemExit(
            f"{generation} is not a published generation: no RUNTIME_VERSION.json"
        )
    # Rollback is the command that runs when everything else has failed, so a
    # short or damaged receipt has to be a sentence rather than a traceback.
    try:
        receipt = GenerationReceipt.capture((generation / "RUNTIME_VERSION.json").read_text()).document
    except (OSError, ValueError) as exc:
        raise SystemExit(
            f"{generation}: receipt is not readable ({exc}); this is not a "
            "generation to point the live runtime at."
        ) from exc
    if not isinstance(receipt, dict):
        raise SystemExit(
            f"{generation}: receipt is not readable (not a JSON object); this "
            "is not a generation to point the live runtime at."
        )
    if rollout == "rolling" or not dry_run:
        _require_reader_direction(generation, receipt=GenerationReceipt(receipt), rollout=rollout,
                                  proofs=proofs)
    if rollout == "barrier":
        # A rollback publishes no manifest, so the value to prove the fleet
        # against is the one already recorded in the generation being restored.
        files = receipt.get("files")
        member = _agent_definitions().MEMBERS["upgrade_client.py"]
        agent_sha = files.get(member) if isinstance(files, dict) else None
        if not isinstance(agent_sha, str) or not agent_sha:
            raise SystemExit(
                f"{generation}: receipt records no sha256 for {member}, so a "
                "barrier activation cannot be proved against it."
            )
        try:
            roster = fleet_roster.Roster.qualified(generation, files)
        except (OSError, ValueError) as exc:
            raise SystemExit(f"invalid generation roster: {exc}") from exc
        _barrier_preflight(agent_sha, dry_run=dry_run, roster=roster)
    print(
        f"activating {name}: commit {str(receipt.get('commit', ''))[:12]}, "
        f"default transport {receipt.get('default_transport') or 'pool'}"
    )
    if rollout == "rolling":
        print(f"rollout rolling: {rollout_reason}")
    if dry_run:
        return 0
    _activate(generation, migrate_directory=False)
    print(f"activated {MIRROR} -> {generation}")
    return 0


def _agent_definitions(*, expected_sha=None):
    """The agent's own module, loaded from the checkout being published.

    The coordinator has to spell a marker name exactly the way the agent
    spelled it, and read the member key exactly as the agent reads it.  Two
    copies of either spelling agree right up until somebody edits one, so
    there is one copy and this reads it.  Loading under a private name keeps
    the checkout's module out of anybody else's import table.
    """

    source = CHECKOUT / "tools" / "fleet" / "upgrade_client.py"
    spec = importlib.util.spec_from_file_location(
        "_publish_runtime_upgrade_client", source
    )
    if spec is None or spec.loader is None:
        raise SystemExit(f"cannot read the client agent at {source}")
    module = importlib.util.module_from_spec(spec)
    # A preflight must not create __pycache__ in the checkout. Compile the
    # source bytes directly so the check neither writes nor trusts a cached
    # version of the definitions it is supposed to read from this source.
    try:
        raw = source.read_bytes()
        actual_sha = hashlib.sha256(raw).hexdigest()
        if expected_sha is not None and actual_sha != expected_sha:
            raise SystemExit("rollout marker semantics identity differs from the armed updater hash")
        code = compile(raw, str(source), "exec")
    except (OSError, SyntaxError) as exc:
        raise SystemExit(f"cannot read the client agent at {source}: {exc}") from exc
    exec(code, module.__dict__)
    # Bind the bytes actually executed, independently of later pathname reads.
    module._pb_source_sha256 = actual_sha
    return module


def _active_roster_boxes(roster: fleet_roster.Roster) -> tuple[list[tuple[str, frozenset[str]]], list[str]]:
    """The roster boxes a barrier must hear from, and the absent ones it skips.

    A box declared ``retired`` or ``offline`` in ``fleet_boxes.json`` (#606)
    is excluded from the attestation preflight and the barrier quorum: an
    absent box must not veto a publish for the boxes that are live.  The
    declaration needs its provenance (``status_reason``/``status_by``/
    ``status_unix``); an unknown status or a missing provenance refuses here,
    because an ambiguous presence is not an active box.
    """

    active = []
    absent = []
    for key, names, entry in roster.declarations():
        try:
            status, detail = fleet_roster.box_status(key, entry)
        except fleet_roster.RosterPresenceError as exc:
            raise SystemExit(f"cannot establish the fleet roster: {exc}") from exc
        if status in fleet_roster.ABSENT:
            absent.append(fleet_roster.describe_absent(key, detail))
        else:
            active.append((key, names))
    return active, absent


def _attested_agents(agent) -> dict[str, set[str]]:
    """Which agent versions each host has recorded in the rollout tree.

    A marker is counted only when it proves itself: its body has to parse,
    carry the agent's schema, and reproduce its own file name through the
    agent's own name function.  A name alone is a claim about a file; a name
    that matches the body it sits on is a claim the writer had to mean.
    Write-once records survive upgrades and downgrades; they do not establish
    the currently installed version or participation in a particular rollout.
    """

    directory = MIRROR.parent / agent.ROLLOUT_DIRNAME / agent.AGENTS_DIRNAME
    try:
        entries = sorted(entry.name for entry in directory.iterdir())
    except FileNotFoundError:
        return {}
    except OSError as exc:
        raise SystemExit(f"cannot read {directory}: {exc}") from exc
    attested: dict[str, set[str]] = {}
    for name in entries:
        parts = name.rsplit(".", 2)
        if len(parts) != 3 or parts[2] != "json":
            continue
        try:
            with (directory / name).open("rb") as stream:
                raw = stream.read(agent.MAX_MARKER + 1)
        except OSError:
            continue
        if len(raw) > agent.MAX_MARKER:
            continue
        try:
            body = json.loads(raw)
        except ValueError:
            continue
        if not isinstance(body, dict) or body.get("schema") != agent.ATTESTATION_SCHEMA:
            continue
        host = body.get("host")
        client = body.get("client_sha256")
        if not isinstance(host, str) or not isinstance(client, str):
            continue
        if agent.attestation_name(host, client) != name:
            continue
        attested.setdefault(host, set()).add(client)
    return attested


def _require_attested_fleet(agent_sha: str, roster: fleet_roster.Roster) -> None:
    """Require historical attestations for the target agent on every live box.

    This is only a bootstrap prerequisite. Matching records can remain after
    every host has moved to another version. A barrier must additionally prove
    current participation in its own epoch, then its drain and rotation quorums.

    Boxes declared absent (``retired``/``offline``) in the roster are not
    required to have posted: an offline box must not veto a publish for the
    boxes that are live (#606).  Their exclusion is said out loud on success
    so a stale retirement cannot pass silently.
    """

    agent = _agent_definitions()
    attested = _attested_agents(agent)
    try:
        active, absent = _active_roster_boxes(roster)
    except ValueError as exc:
        raise SystemExit(f"cannot establish historical attestation roster: {exc}") from exc
    missing = []
    for key, names in active:
        held = set().union(*(attested.get(name, set()) for name in names))
        if agent_sha in held:
            continue
        spelling = key if len(names) == 1 else f"{key} ({'/'.join(sorted(names))})"
        if not held:
            # A box that has posted nothing at all is more often a box with no
            # agent installed than a box one tick behind, and rolling does not
            # install one.  Say so here rather than let the advice below be
            # read as covering a case it does not.
            missing.append(
                f"  {spelling}: has posted no attestation. A box with no "
                "client upgrade agent installed cannot hold a barrier at all; "
                "see docs/client_upgrade.md."
            )
        else:
            posted = ", ".join(sorted(short[:12] for short in held))
            missing.append(f"  {spelling}: posted versions {posted}")
    if missing:
        raise SystemExit(
            "refusing barrier attestation preflight: not every box has posted "
            f"the agent version this generation requires ({agent_sha[:12]}).\n"
            + "\n".join(missing)
            + "\nIf a reviewed compatibility assessment permits a normal rolling "
            "publication, pass --rollout rolling with its nonblank "
            "--rollout-reason, let each box converge and post its attestation, then "
            "repeat --rollout barrier --dry-run. Historical attestations do not prove "
            "current participation."
        )
    for line in absent:
        print(f"barrier preflight: skipping absent box: {line}", flush=True)


def _barrier_preflight(agent_sha: str, *, dry_run: bool,
                       roster: fleet_roster.Roster | None) -> None:
    """Check bootstrap compatibility; epoch quorums grant activation later."""

    if not dry_run:
        if not MIRROR.is_symlink():
            raise SystemExit("barrier requires an existing sealed runtime symlink")
        _, receipt = _barrier_generation(MIRROR.resolve(strict=True).name)
        if receipt["files"]["tools/upgrade_client.py"] != agent_sha:
            raise SystemExit("barrier updater differs from the live generation; "
                             "converge a reviewed rolling bridge first")
    if roster is None:
        raise SystemExit("barrier roster is absent from publication manifest")
    _require_attested_fleet(agent_sha, roster)
    print(
        "barrier preflight: historical attestations match; current participation, "
        "drain and rotation have not been proved. Only epoch quorums authorize activation."
    )


def main() -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--allow-dirty", action="store_true",
                    help="publish a tree with uncommitted changes")
    ap.add_argument(
        "--migrate-directory", action="store_true",
        help="perform the one-time fail-closed handoff from the legacy live directory",
    )
    ap.add_argument(
        "--default-transport", choices=("pool", "slurm"), default=None,
        help="the transport every pbrun and producer running THIS generation "
             "uses when nothing says otherwise; recorded in the receipt and "
             "read by fleet_submit.default_transport.  Omitted means the pull "
             "queue, which is what every generation published before the "
             "SLURM cutover means too.",
    )
    ap.add_argument(
        "--activate-generation", metavar="NAME", default=None,
        help="point the live runtime at an existing generation instead of "
             "publishing a new one; this is what rollback does, and it is "
             "deliberately not a re-publish -- the previous generation's bytes "
             "and receipt are already proved and a rebuild from a moved "
             "checkout would not be the same thing.",
    )
    ap.add_argument(
        "--rollout", choices=("rolling", "barrier"), default="barrier",
        help="barrier drains and rotates the fleet before admission resumes; "
             "rolling requires a stated mixed-generation-safety reason. "
             "Barrier --dry-run checks bootstrap history only.",
    )
    ap.add_argument("--reserve-installed-bootstrap", type=Path, metavar="ASSESSMENT",
                    help="reserve publication before the first root bootstrap preparation")
    ap.add_argument("--installed-bootstrap", type=Path, metavar="ASSESSMENT",
                    help="activate an already sealed generation after authenticated installed bootstrap assessment")
    ap.add_argument(
        "--installed-updater-proof", action="append", metavar="KEY", default=None,
        help="the full action key of tools/fleet/updater_proof.py run on one enrolled host; "
             "repeat once per host. A rolling activation between receipt-carrying generations "
             "needs current proof from every enrolled participant (#1850)",
    )
    ap.add_argument("--stage-only", action="store_true",
                    help="seal and import-probe a generation without arming or activating it; "
                         "use inside PB, then activate with the external control-plane coordinator")
    ap.add_argument("--resume-barrier", metavar="EPOCH",
                    help="continue a retained epoch without creating a new publication")
    ap.add_argument("--rollback-barrier", metavar="EPOCH",
                    help="declare rollback to this epoch's source before its resume decision")
    ap.add_argument("--rollback-reason", metavar="TEXT",
                    help="required reason for --rollback-barrier")
    ap.add_argument("--barrier-wait-s", type=float, default=300,
                    help="how long the coordinator waits; expiry returns 75 and never releases admission")
    ap.add_argument(
        "--rollout-reason", default=None,
        help="required nonblank mixed-generation-safety reason for --rollout rolling; "
             "recorded in a newly published generation receipt",
    )
    ap.add_argument(
        "--dry-run", action="store_true",
        help="report what would happen and write nothing.  A publish still "
             "resolves the commit and still refuses a dirty tree, then lists "
             "the files it would publish and stops before the generation "
             "store is created.  With --activate-generation the name and its "
             "receipt are validated and the target is printed, but the live "
             "runtime is not repointed.",
    )
    ap.add_argument(
        "--canary", action="store_true",
        help="after activation, submit the fleet canary (issue #688) resolving "
             "against the new generation and record verified|failed in its "
             "rollout record; a failed canary marks and exits nonzero without "
             "rolling back. The gate is default-ON, so the flag only forces a "
             "default already in effect.",
    )
    ap.add_argument(
        "--no-canary", action="store_true",
        help="skip the fleet canary and record not_run in the rollout record; "
             "the escape hatch now that the gate is default-ON (phase 2).",
    )
    gate = ap.add_mutually_exclusive_group()
    gate.add_argument(
        "--shape-gate-action", metavar="KEY", default=None,
        help="the PB action key (or a unique 12-digit prefix) of a passing "
             "pre-publish shape gate run of this commit: one pbtest shard of "
             "tests/gate_campaign_shape.py (#987).  A fresh publication needs "
             "this or --shape-gate-waiver.",
    )
    gate.add_argument(
        "--shape-gate-waiver", metavar="REASON", default=None,
        help="publish without a shape gate receipt; the nonblank reason is "
             "recorded in the generation's receipt and printed by the rollout "
             "canary.",
    )
    ap.add_argument(
        "--drop-roster-option-by", metavar="WHO", default=None,
        help="who removes a live roster -- option on purpose; required "
             "together with --drop-roster-option-reason, and both are "
             "recorded in the generation's receipt (#1664).",
    )
    ap.add_argument(
        "--drop-roster-option-reason", metavar="REASON", default=None,
        help="why the candidate roster drops a live -- option; required "
             "together with --drop-roster-option-by, and both are recorded "
             "in the generation's receipt (#1664).",
    )
    args = ap.parse_args()
    if not math.isfinite(args.barrier_wait_s) or args.barrier_wait_s < 0:
        ap.error("--barrier-wait-s must be finite and nonnegative")
    recovery = args.resume_barrier or args.rollback_barrier
    if args.reserve_installed_bootstrap and (args.installed_bootstrap or args.activate_generation
            or recovery or args.stage_only or args.dry_run or args.rollout != "rolling"):
        ap.error("bootstrap reservation requires rolling and excludes activation/publication")
    if args.installed_bootstrap and (not args.activate_generation or args.rollout != "rolling"
                                    or recovery or args.stage_only or args.no_canary or args.canary):
        ap.error("--installed-bootstrap requires rolling --activate-generation and its mandatory canary")
    if args.installed_updater_proof and (args.rollout != "rolling" or args.stage_only or recovery
                                         or args.installed_bootstrap or args.reserve_installed_bootstrap):
        ap.error("--installed-updater-proof judges a rolling activation; it excludes barrier, "
                 "--stage-only, recovery and the installed bootstrap")
    if args.resume_barrier and args.rollback_barrier:
        ap.error("choose one of --resume-barrier and --rollback-barrier")
    if recovery and (args.activate_generation or args.stage_only or args.allow_dirty
                     or args.migrate_directory or args.default_transport
                     or args.rollout != "barrier" or args.rollout_reason
                     or args.canary or args.no_canary
                     or args.shape_gate_action or args.shape_gate_waiver is not None):
        ap.error("barrier recovery cannot be combined with publication options")
    if args.rollback_barrier and not (args.rollback_reason and args.rollback_reason.strip()):
        ap.error("--rollback-barrier requires a nonblank --rollback-reason")
    if args.rollback_reason is not None and not args.rollback_barrier:
        ap.error("--rollback-reason requires --rollback-barrier")
    if args.canary and args.no_canary:
        ap.error("--canary and --no-canary conflict")
    if args.stage_only and (args.canary or args.no_canary):
        ap.error("the canary verifies a live generation; --stage-only activates nothing")
    if args.stage_only and args.activate_generation:
        ap.error("--stage-only cannot activate an existing generation")
    if args.activate_generation and (args.shape_gate_action
                                     or args.shape_gate_waiver is not None):
        ap.error("the shape gate judges a fresh publication; an existing "
                 "generation keeps the gate record it was published with")
    if args.shape_gate_waiver is not None and not args.shape_gate_waiver.strip():
        ap.error("--shape-gate-waiver requires a nonblank reason")
    override = (args.drop_roster_option_by, args.drop_roster_option_reason)
    if (override[0] is None) != (override[1] is None):
        ap.error("--drop-roster-option-by and --drop-roster-option-reason "
                 "are required together")
    if override[0] is not None and not override[0].strip():
        ap.error("--drop-roster-option-by requires a nonblank name")
    if override[1] is not None and not override[1].strip():
        ap.error("--drop-roster-option-reason requires a nonblank reason")
    if args.activate_generation and override[0] is not None:
        ap.error("an existing generation keeps the roster record it was "
                 "published with; the roster override judges a fresh "
                 "publication only")
    if args.dry_run:
        return _run_publication(args)
    with _publication_lock():
        return _run_publication(args)


def _run_publication(args) -> int:
    rollout_reason = _rollout_reason(args.rollout, args.rollout_reason)
    recovery = args.resume_barrier or args.rollback_barrier
    if getattr(args, "reserve_installed_bootstrap", None) is not None:
        return _reserve_installed_bootstrap(args.reserve_installed_bootstrap)
    # Refuse before reading/staging a candidate generation.  The recovery
    # branch would otherwise reach `_wait_barrier`, which can call the pointer
    # mutation through `_barrier_step`.
    if args.rollout == "barrier" and not args.dry_run and not args.stage_only:
        _require_barrier_qualification()
    if recovery:
        if args.dry_run:
            view = _rollout_view(recovery)
            print(json.dumps(view, sort_keys=True))
            return 0
        return _wait_barrier(recovery, wait_s=args.barrier_wait_s,
                             rollback_reason=args.rollback_reason)

    if getattr(args, "installed_bootstrap", None) is not None:
        return _activate_installed_bootstrap(args.activate_generation, args.installed_bootstrap,
                                            dry_run=args.dry_run, rollout=args.rollout)
    _require_no_epoch()

    if args.activate_generation is not None:
        if args.canary or args.no_canary:
            raise SystemExit(
                "the rollout canary runs only on fresh publication; rollback "
                "(--activate-generation) leaves existing rollout records untouched"
            )
        return _activate_existing(
            args.activate_generation, dry_run=args.dry_run, rollout=args.rollout,
            rollout_reason=rollout_reason, wait_s=args.barrier_wait_s,
            proofs=getattr(args, "installed_updater_proof", None) or (),
        )

    # Identity is established before MIRROR is even enumerated, much less
    # touched.  Failure here is a refusal, never an empty field in a receipt.
    commit = _commit_identity()
    dirty = _working_tree_dirty()
    if dirty and not args.allow_dirty:
        raise SystemExit(
            "refusing to publish a dirty tree: the receipt would name a commit "
            "whose bytes are not the bytes published.  Commit, or pass "
            "--allow-dirty and accept that the version is only approximate."
        )

    published = _publication_manifest()
    roster_sha256 = published.get("tools/fleet/fleet_boxes.json")
    candidate = (_candidate_roster(roster_sha256)
                 if roster_sha256 is not None else None)
    problems = _unshipped_imports(published)
    if problems:
        raise SystemExit(
            "refusing to publish: a published script imports a module this "
            "publication does not carry (#1284):\n  " + "\n  ".join(problems)
            + "\nNothing was published.")
    # --canary forces the gate on, --no-canary forces it off (the two together
    # are refused in main()); otherwise the versioned default decides.
    canary_enabled = bool(args.canary or (CANARY_DEFAULT_ENABLED and not args.no_canary))
    # Read before a single byte is staged: a publisher that cannot say
    # which of its members are programs refuses here, not halfway
    # through a tree it then has to clean up.
    index_modes = _git_index_modes()
    if not args.stage_only and (args.rollout == "rolling" or not args.dry_run):
        _require_reader_direction(CHECKOUT, rollout=args.rollout, files=published,
                                  proofs=getattr(args, "installed_updater_proof", None) or ())
    if args.rollout == "barrier" and not args.stage_only:
        member = _agent_definitions().MEMBERS["upgrade_client.py"]
        agent_sha = published.get(member)
        if not isinstance(agent_sha, str) or not agent_sha:
            raise SystemExit(
                f"this publication carries no {member}, so a barrier rollout "
                "has nothing to prove the fleet against."
            )
        _barrier_preflight(agent_sha, dry_run=args.dry_run, roster=candidate)

    if canary_enabled and not _canary_driver_path().is_file():
        raise SystemExit(
            f"canary requested but no driver at {_canary_driver_path()}: "
            "nothing was published and the live runtime still points where it did."
        )
    # The last refusals before anything is written: the gates read the
    # fleet's records, and an earlier refusal is cheaper to hear first.
    shape_gate = _shape_gate_record(args, commit=commit, dirty=dirty)
    roster_override = _roster_option_record(args, candidate)
    if args.rollout == "rolling":
        print(f"rollout rolling: {rollout_reason}")
    print(_shape_gate_line(shape_gate),
          file=sys.stderr if shape_gate.get("verdict") == "waived" else sys.stdout)
    print(f"publishing {len(published)} files from {commit[:12]}"
          f"{' (dirty)' if dirty else ''} to {MIRROR}")
    if args.dry_run:
        print(f"canary: {'enabled' if canary_enabled else 'disabled'} "
              f"(gate default-{'ON' if CANARY_DEFAULT_ENABLED else 'OFF'})")
        for name in sorted(published):
            print(f"  {name}")
        return 0

    store = MIRROR.parent / "runtime-generations"
    nonce = uuid.uuid4().hex[:12]
    generation_name = f"{commit[:12]}-{int(time.time())}-{nonce}"
    stage = store / f".{generation_name}.staging"
    generation = store / generation_name
    # The same refusal shape as the dirty-tree refusal above, and for the same
    # reason: these two directories are the first bytes written, so a store
    # this user cannot write is a fact to state before "publishing N files"
    # rather than a PermissionError traceback after it.  The live runtime is
    # untouched either way.
    try:
        store.mkdir(parents=True, exist_ok=True)
        stage.mkdir()
    except OSError as exc:
        raise SystemExit(
            f"cannot write the generation store {store}: {exc}.  Nothing was "
            "published and the live runtime still points where it did."
        ) from exc
    activated = False
    try:
        for name, expected in sorted(published.items()):
            source = _source_for(name)
            target = stage / name
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(source, target)
            # copy2 preserves the source's mode, which is the publishing
            # worktree's umask rather than anything about the file.  Say what
            # the generation carries instead of inheriting an accident.
            os.chmod(target, _published_mode(source, index_modes))
            _fsync_file(target)
            actual = _sha256(target)
            if actual != expected:
                raise SystemExit(
                    f"copied runtime member changed at {name}: expected "
                    f"{expected}, staged {actual}"
                )

        # A checkout can advance while a slow NFS copy is in progress.  Hash
        # the complete source set again and re-prove both Git facts before a
        # receipt names the staged bytes.
        if _commit_identity() != commit or _working_tree_dirty() != dirty:
            raise SystemExit(
                "runtime checkout identity moved while publication was staged"
            )
        if _publication_manifest() != published:
            raise SystemExit(
                "runtime source bytes moved while publication was staged"
            )

        receipt: dict[str, object] = {
            "schema": "prismaquant.prismabuild.runtime_version.v1",
            "commit": commit,
            "rollout": args.rollout,
            **({"rollout_reason": rollout_reason}
               if args.rollout == "rolling" else {}),
            # Optional, and absent means the pull queue: every generation
            # published before the SLURM cutover has no such field and must
            # keep behaving as it did.
            **({"default_transport": args.default_transport}
               if args.default_transport else {}),
            "dirty": dirty,
            # How this commit passed the pre-publish shape gate (#987): the
            # verified gate run, or the waiver and its reason.
            "shape_gate": shape_gate,
            # Present only when the roster drops a live -- option name on
            # purpose (#1664): who removed it, why, and which names per box.
            **({"roster_option_override": roster_override}
               if roster_override is not None else {}),
            "generation": generation_name,
            "published_unix": time.time(),
            "published_by": socket.gethostname(),
            "files": published,
        }
        receipt_sha256 = _write_receipt(stage / "RUNTIME_VERSION.json", receipt)
        _probe(stage)
        _seal_generation(stage)
        _fsync_directory(stage)
        os.replace(stage, generation)
        _fsync_directory(store)
        _sign_movement_approval(generation, receipt_sha256=receipt_sha256)
        if args.stage_only:
            print(json.dumps({"state": "staged", "generation": generation_name,
                              "path": str(generation), "activated": False,
                              "shape_gate": shape_gate}, sort_keys=True))
            return 0
        if args.rollout == "barrier":
            barrier_exit = _arm_barrier(generation_name, wait_s=args.barrier_wait_s)
            if barrier_exit != 0:
                # Rolled back or still pending: the rollout has no ending yet,
                # so there is no rollout record to write. The resume path owns it.
                return barrier_exit
            return _run_rollout_canary(store=store, generation_name=generation_name,
                                       commit=commit, enabled=canary_enabled,
                                       shape_gate=shape_gate)
        legacy = _activate(
            generation, migrate_directory=args.migrate_directory
        )
        activated = True
        print(f"activated {MIRROR} -> {generation}")
        if legacy is not None:
            print(f"retained previous directory runtime at {legacy}")
        return _run_rollout_canary(store=store, generation_name=generation_name,
                                   commit=commit, enabled=canary_enabled,
                                   shape_gate=shape_gate)
    finally:
        if not activated and stage.exists():
            _remove_staging_tree(stage)


if __name__ == "__main__":
    raise SystemExit(main())
