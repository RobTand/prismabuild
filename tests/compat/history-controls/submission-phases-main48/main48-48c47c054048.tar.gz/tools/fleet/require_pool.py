#!/usr/bin/env python3
"""Refuse test and GPU work that does not go through PrismaBuild.

Briefs are discipline, not enforcement, and discipline is what failed: the
same briefs that said "use the pool" produced fifteen agents recomputing one
baseline and a flock jam seven deep.  This hook moves the rule from prose an
agent may skim to a refusal it cannot.

Recognized test runners and GPU containers are also refused. The global agent
policy covers indirect execution this lexical guard cannot prove. Read-only inspection (``nvidia-smi``, ``squeue``,
``sinfo``) is allowed, because refusing it would only teach agents to route
around the hook.  What is refused is the things that actually contend for the
GPU: the CUDA venv interpreter, the box-local flock wrappers the pool replaces,
and -- since the fleet has a scheduler -- a bare ``sbatch``, ``srun`` or
``salloc``.

That last one is not a fourth rule, it is the same rule reaching the shape that
defeats its proxy.  The proxy for GPU work is the CUDA interpreter on the
command line, and a submission names no interpreter at all: the venv is inside
the job script, on a node this box never sees.  So the one shape that most
needs to go through the lane was the one shape the hook let through.
``scancel`` is deliberately left alone: cancelling a job is not starting work,
and a guard that refuses the cleanup strands the person complying with it.

A here-document body is read as shell in two circumstances, and they are two
rules rather than one.  A shell reading its standard input makes the body a
script (``_feeds_a_shell``).  So does a shell being handed the substitution
the body printed: ``bash -c "$(cat <<'X'`` ... ``X)"`` executes that text, and
``_runs_substitution_output`` is the rule that says so.

Two carve-outs, and both are the same lesson.  A guard that can refuse its own
repair, or refuse the alternative it names, is worse than no guard: it strands
the person trying to comply.  So commands that never start GPU work are let
through by name, and so is the pool's own machinery -- including starting a
worker, whose ``--python`` argument is the CUDA venv path by design.

The same lesson reaches one shape further in.  A command that hands prose to a
program -- an agent posting "shard 3 died under the runner" to the mailbox --
is a mention of fleet work, not an instance of it, and refusing it makes the
mailbox lossy in the case it is most needed: nobody can warn about a runner
failure without the warning being mistaken for the failure.  So in a segment
that is an interpreter running a SCRIPT FILE, quoted arguments are read as
prose (see ``_prose_start``).  Nothing that executes an argument qualifies --
``python -c``, ``python -m``, a shell, a wrapper, or a launcher forwarding its
trailing argv -- because those are lexically identical to the mailbox and the
difference is what runs the words.

Staged rather than flipped: enforcement requires the flag file to exist, so
turning it on is one ``touch`` and does not edit config under running agents.
"""
from __future__ import annotations

import json
from functools import lru_cache
import os
import re
import sys
import time
from pathlib import Path

FLAG = Path(os.environ.get("REQUIRE_POOL_FLAG", "/home/rob/tmp/arb/require_pool.on"))
sys.path.insert(0, str(Path(__file__).resolve(strict=True).parent))
_PB_ENTRYPOINT = Path(__file__).resolve(strict=True)
sys.path.insert(0, str(_PB_ENTRYPOINT.parents[
    2 if _PB_ENTRYPOINT.parent.name == "fleet" else 1] / "src"))
from prismabuild.runtime_paths import fleet_tool, generation_root  # noqa: E402

_RUNTIME_ROOT = generation_root(__file__)
sys.path.insert(0, str(_RUNTIME_ROOT / "src"))
from prismabuild.fleet_roster import Roster  # noqa: E402
#: The submitter the refusals below tell an operator to run.  Resolved under
#: both layouts, because a hook running from a checkout would otherwise print
#: the published runtime's flat path, which a checkout does not have.
PBRUN = str(
    fleet_tool("pbrun.py", root=_RUNTIME_ROOT)
    or _RUNTIME_ROOT / "tools" / "pbrun.py"
)

# The CUDA interpreter, the flock wrappers, and a bare flock on the GPU lock.
# That last one is not hypothetical: the wrappers were only ever a convenience,
# and the jam this hook exists to prevent re-formed from direct `flock
# .../.gpu.lock ...` invocations that named no wrapper at all -- one pytest
# holding an exclusive GPU lock for 73 minutes with a `docker run --gpus all`
# waiting 53 minutes behind it.  Matching the wrappers alone would have left
# the observed path open.
#
# Anything else -- nvidia-smi, a CPU python, a git command -- is none of this
# hook's business.
#
# Which interpreter is "the CUDA interpreter" is configuration, not a name this
# hook knows (#1076).  ``fleet_boxes.json`` lists it under ``gpu_interpreters``:
# the file the supervisor starts the loops from, published beside this hook.
# A loop's own ``--python`` is not that list -- sparky's loops name none, and
# a box's worker launcher may be the system interpreter -- so the list is
# declared rather than inferred.
LOCK_WRAPPERS = (
    r"/gpuslot\.sh"
    r"|/gpulock\.sh"
    r"|flock\s[^|;]*\.gpu\.lock"
)


def interpreter_signature(path: str) -> str:
    """The part of ``path`` a command spells whatever its home directory.

    From the venv's parent directory on -- ``venvs/<name>/bin/python`` for
    ``/home/<user>/<dir>/venvs/<name>/bin/python`` -- so an absolute, a
    ``~``-relative and a ``$HOME``-relative spelling all match, as the single
    literal this replaced did.
    """

    parts = Path(path).parts
    return "/".join(parts[-4:]) if len(parts) > 4 else path


def contends_pattern(declared: tuple[str, ...]) -> re.Pattern[str]:
    """The refusal pattern: the configured GPU interpreters and the wrappers.

    With no interpreter configured, only the wrappers are refused: this hook
    runs before every command, and refusing everything because a data file is
    absent would lock out the edit that restores it.
    """

    interpreters = "|".join(sorted(
        re.escape(interpreter_signature(path))
        for path in declared if isinstance(path, str) and path
    ))
    return re.compile(f"{interpreters}|{LOCK_WRAPPERS}" if interpreters else LOCK_WRAPPERS)


@lru_cache(maxsize=1)
def configured_contends_pattern() -> re.Pattern[str]:
    try:
        interpreters = Roster.at(_RUNTIME_ROOT).gpu_interpreters
    except (OSError, ValueError):
        interpreters = ()
    return contends_pattern(interpreters)


#: Commands that never start GPU work, whatever their text contains.  A commit
#: message quoting the refused pattern is prose ABOUT the rule, not an instance
#: of it -- and this hook refused its own commit, then refused the edit that
#: would have fixed that, before this existed.  A guard that can lock out its
#: own repair is a worse failure than the one it guards against.
NEVER_GPU = (
    "git", "gh", "echo", "cat", "rg", "grep", "sed", "awk", "less", "diff",
    # Asking where a program is, what it is, or what it says about itself.
    # ``which sbatch`` and ``man sbatch`` are the first two commands anyone
    # runs at a scheduler they have never used, and refusing them teaches the
    # reader to route around the hook before they have read the rule.
    "which", "whereis", "type", "man", "ls", "stat", "file",
    "head", "tail", "wc", "dpkg", "apt", "apt-get", "apt-cache",
    # Reading the process table.  These search for a name; they never run it,
    # so an argument naming a runner is what is being LOOKED FOR rather than
    # what is being started -- ``pgrep -f <runner>`` was refused as if it were
    # the runner.  That refusal fell on an agent asking whether the run it had
    # already submitted through the pool was still alive, which is the one
    # question a submitter most needs to answer and the one this hook has no
    # reason to block.  Read-only spellings only: ``pkill`` and ``kill`` act on
    # what they find and are deliberately absent.
    "ps", "pgrep", "pidof", "pstree",
)


#: ``command`` is NOT in the list above, because it is not a command that
#: never starts work: ``command sbatch job.sh`` submits the job, and the whole
#: segment was exempt for as long as the builtin's name led it.  Its two
#: inspection switches are the part that must stay allowed -- ``command -v
#: sbatch`` prints a path and runs nothing, and it is in the runbook -- so
#: those are exempted by shape rather than by the builtin's name.  ``-p`` is
#: accepted between the two because it only chooses the default PATH.
INSPECTION_SWITCHES = frozenset({"-v", "-V"})


#: A segment that switches the GPU off for its own child cannot be GPU work,
#: whatever interpreter it names.  Two agents in one day were refused for
#: ``kl_tool.py --help`` and ``kl_tool.py compare --help`` -- argparse text
#: that starts nothing -- because the rule's proxy is the interpreter path and
#: nothing asked what the command does.  The interpreter stays the proxy: it
#: is the deliberate one, and asking "does this touch CUDA" of an arbitrary
#: command line is exactly the guess this hook refuses to make.  What this
#: adds is a way to *say so*, and the saying is enforced by the kernel rather
#: than believed: with ``CUDA_VISIBLE_DEVICES`` empty the child sees no
#: device, so this cannot become a way around the pool -- work smuggled
#: through it would simply fail.  ``--help`` under that prefix is the use.
NO_DEVICE = re.compile(r"""(?:^|\s)CUDA_VISIBLE_DEVICES=(?:''|""|)(?=\s)""")


#: The pool's own machinery, which must never be refused by the hook that
#: exists to route work *into* it.  ``pbrun`` submits; ``worker_loop`` and
#: ``worker`` are the things that consume the queue -- and a worker is
#: configured with ``--python <the CUDA venv>``, so it names the refused
#: pattern by construction.  Refusing that means the hook blocks the pool from
#: being started at all, which is the same class of failure as refusing its own
#: repair: the guard removing the alternative it is pointing at.
#:
#: ``slurm_job.py`` joins them for both reasons at once: it is what a SLURM job
#: execs on the node, so it *is* the sanctioned path, and it carries the
#: action's own sealed interpreter -- the CUDA venv -- on its command line.
POOL_ENTRYPOINTS = ("pbrun.py", "pbtest.py", "pbcampaign.py",
                    "worker_loop.py", "worker.py", "slurm_job.py")


#: A submission to the scheduler, by any of its three verbs.  Bounded by
#: non-word characters on both sides so that ``/usr/bin/sbatch`` is one and
#: ``my-sbatch-wrapper`` and ``sbatch.sh`` are not -- and so that ``scancel``,
#: ``squeue`` and ``sinfo`` never match: reading the queue and cancelling a job
#: start no work.
SCHEDULER = re.compile(r"(?<![\w.-])(?:sbatch|srun|salloc)(?![\w.-])")


#: The verbs' own help and version switches.  ``sbatch --help`` submits
#: nothing, and it is how a reader of the runbook finds out whether the
#: scheduler is installed at all.  Only a segment that is the verb and these
#: switches and nothing else is let through: ``sbatch --help job.sh`` also
#: submits nothing in practice, but the hook does not parse the verbs' grammar
#: and does not guess.  A bare ``sbatch`` with no switch reads a script from
#: standard input, which is a submission.
DESCRIBES_ITSELF = frozenset({"-h", "--help", "--usage", "-V", "--version"})


def _describes_itself(segment: str) -> bool:
    """True when this segment only asks a scheduler verb about itself."""

    tokens = _command_tokens(segment)
    if len(tokens) < 2:
        return False
    if tokens[0].rsplit("/", 1)[-1] not in ("sbatch", "srun", "salloc"):
        return False
    return set(tokens[1:]) <= DESCRIBES_ITSELF


#: Shell words that stand in front of a command without being one.  A
#: compound command's boundaries put these at the head of a segment -- ``for f
#: in *.py; do grep sbatch $f; done`` runs ``grep``, and the segment the
#: boundaries hand over begins ``do`` -- so a segment led by one of these was
#: judged as an unknown command and refused.  That is the same failure as
#: judging a compound command by its first token, one level in: the word the
#: exemption has to look at is the command word, not whatever is leftmost.
#: ``for``, ``case`` and ``select`` are deliberately absent: the word after
#: those is a variable name, not a command, so stripping them would judge a
#: loop by its loop variable.
RESERVED_WORDS = frozenset({
    "!", "{", "if", "elif", "then", "else", "while", "until", "do", "time",
})


def _past_prefixes(words: list[str]) -> list[str]:
    """The words past the prefixes that are not the command."""

    tokens = list(words)
    while tokens:
        head = tokens[0]
        if head in RESERVED_WORDS:
            tokens.pop(0)
            continue
        if "=" in head and not head.startswith("/"):
            tokens.pop(0)          # a variable assignment prefixing a command
            continue
        break
    return tokens


def _command_tokens(segment: str) -> list[str]:
    """The segment's words, past the prefixes that are not the command."""

    return _past_prefixes(segment.split())


def _first_token(command: str) -> str:
    """The command actually being run, past the words that are not it."""

    tokens = _command_tokens(command)
    # ``command X ...`` runs X, so X is the command being judged.  ``-p`` is
    # accepted between them because it only chooses the default PATH.
    while tokens and (tokens[0].rsplit("/", 1)[-1] == "command"
                      or tokens[0] == "-p"):
        tokens.pop(0)
    return tokens[0].rsplit("/", 1)[-1] if tokens else ""


def _inspects_only(segment: str) -> bool:
    """True when this segment only asks ``command`` where a program is."""

    tokens = _command_tokens(segment)
    if not tokens or tokens[0].rsplit("/", 1)[-1] != "command":
        return False
    rest = [token for token in tokens[1:] if token != "-p"]
    return bool(rest) and rest[0] in INSPECTION_SWITCHES


def _drop_pool_payload(command: str) -> str:
    """Cut a pool submission's payload off before the command is segmented.

    ``pbrun.py --gpu -- <cmd>`` hands everything past ``--`` to the pool, which
    execs it on a worker that already holds the reservation.  Segmenting that
    payload tears the interpreter away from the entrypoint that vouches for it,
    so a submission whose payload was ``bash -lc 'cd x && <cuda venv> -m
    pytest'`` was refused *as off-pool GPU work* -- the hook locking out the
    very submission it exists to require.

    The cut is deliberately narrow: it needs a pool entrypoint AND a ``--``
    after it, because that pair is what makes the rest argv for another
    process.  A chain like ``pbrun.py --help && <cuda venv> train.py`` has no
    ``--``, so its second segment is still scanned and still refused.

    It is applied to ONE segment, after the boundaries are known, and that is
    the correction issue #89 names.  Cutting the raw command line at the first
    entrypoint's ``--`` threw away everything after it, including commands
    that belong to the outer shell and never reach pbrun: ``pbrun.py --gpu --
    true && <cuda python> train.py`` runs the second command locally, and
    ``pbrun.py -- true && sbatch job.sh`` submits locally, and neither was
    scanned.  A payload that really is argv keeps its ``&&`` inside quotes,
    which the segmenter does not split on, so the payload the cut exists for
    is still one segment.
    """

    best = None
    for entry in POOL_ENTRYPOINTS:
        at = command.find(entry)
        if at < 0:
            continue
        sep = re.search(r"\s--\s", command[at:])
        if sep is None:
            continue
        cut = at + sep.start()
        if best is None or cut < best:
            best = cut
    return command if best is None else command[:best]


#: A here-document opener, as the shell would read one.  The delimiter may be
#: quoted, which is what decides whether the body is expanded -- and POSIX
#: gives three spellings of "quoted", not one: ``<<'EOF'``, ``<<"EOF"`` and
#: ``<<\\EOF`` all stop expansion.  Matching only the first two read a
#: backslash-quoted delimiter as an unquoted one and scanned a body the shell
#: copies verbatim.
HEREDOC = re.compile(
    r"""<<-?\s*(?:"""
    r"""(?P<mark>['"])(?P<quoted>[A-Za-z_][A-Za-z0-9_]*)(?P=mark)"""
    r"""|\\(?P<escaped>[A-Za-z_][A-Za-z0-9_]*)"""
    r"""|(?P<bare>[A-Za-z_][A-Za-z0-9_]*)"""
    r""")"""
)


def _heredoc_tag(match: re.Match[str]) -> tuple[str, bool]:
    """The delimiter this opener names, and whether it stops expansion."""

    for group in ("quoted", "escaped"):
        if match.group(group) is not None:
            return match.group(group), True
    return match.group("bare"), False

#: Programs that read their standard input as SHELL.  A here-document fed to
#: one of these is a script in the language this module parses, so scanning it
#: is the whole point rather than the mistake: ``bash <<'EOF'`` with the CUDA
#: interpreter inside it starts exactly the work this hook refuses.
#:
#: An interpreter of some other language does NOT belong here, and ``python``
#: used to (issue #223).  Its body is not shell, so segmenting it produced
#: Python tokens where commands go -- ``print`` and a variable name read as
#: two commands, a runner's name inside a string literal read as the runner
#: being run -- and the hook refused, in one session, a script that evaluated
#: its own predicates, the test cases for issue #209's fix, and that pull
#: request's body.  Nor did the scan buy enforcement: ``cat > x.py <<'EOF'``
#: writes the same program and ``python3 x.py`` runs it, and both are allowed
#: today.  So a here-document fed to ``python3 -`` is treated as the file it
#: stands in for, which is what this module means when it says of itself that
#: it is a command-line guard and not a proof of arbitrary program behavior.
#:
#: The delimiter still decides the rest: an UNQUOTED body is expanded by the
#: shell before the interpreter ever sees the text, so its ``$( ... )`` and
#: backquotes are shell the shell really runs and are still scanned, whichever
#: program reads the body.  See ``_heredocs``.
#:
#: This list answers "who reads the body".  It does not answer "who runs what
#: the body printed", which is a separate question with a separate rule:
#: ``_runs_substitution_output`` and ``PASS_THROUGH`` below (issue #247).
SHELLS = ("bash", "sh", "dash", "zsh", "ksh")


def _is_shell(name: str) -> bool:
    return name in SHELLS


#: Programs that copy their standard input to their standard output.  The same
#: kind of enumeration as ``SHELLS`` above -- a fact about what a named program
#: does with a body, not a guess about an arbitrary command line -- and it is
#: what makes a here-document body reach the output of the ``$( ... )`` it sits
#: in.  It is only ever consulted for a substitution whose output a shell RUNS
#: (issue #247); everywhere else the body is still data.
#:
#: Narrow on purpose.  ``bash -c "$(sed 's/a/b/' <<'X' ... X)"`` also runs a
#: body, transformed, and is not matched: the module is a command-line guard,
#: not a proof of what ``sed`` emits, and the standing agent policy covers the
#: indirect shapes it cannot read.
PASS_THROUGH = frozenset({"cat", "tee"})


#: An output redirection that takes the body away from the substitution's own
#: standard output.  ``cat > f <<'X'`` and ``cat <<'X' > f`` write a file and
#: emit nothing, so the ``-c`` that runs the substitution runs an empty string
#: -- and the fleet's own worker-start script is written exactly that way.
#: ``2>`` is excluded because it moves the other stream; ``1>``, ``>>`` and
#: ``&>`` are not, because they all move this one.
REDIRECTS_STDOUT = re.compile(r"(?<![2-9<>])>")


#: Commands that run another command given to them as an argument.  The shell
#: reading a here-document is not always the command word of the segment that
#: owns it: ``ssh box bash``, ``sudo bash`` and ``docker exec -i
#: c bash`` all end in a shell that reads the body, and the first of those is
#: how routine work reaches the other boxes here.  Looking past the command
#: word only for these keeps ``grep -c python`` and ``cat bash_notes`` what
#: they are, which reading every word of every segment did not.
WRAPPERS = frozenset({
    "ssh", "sudo", "doas", "env", "nice", "ionice", "timeout", "nohup",
    "setsid", "stdbuf", "xargs", "docker", "podman", "kubectl", "chroot",
    "unshare", "taskset", "flock", "command", "time",
})


def _name_of(token: str) -> str:
    return token.strip("'\"").rsplit("/", 1)[-1]


#: Switches that hand an interpreter something to RUN rather than something to
#: read: python's ``-c`` and ``-m``, a shell's ``-c`` in its clustered
#: spellings, and ``sbatch --wrap``, whose value is a command line.  A segment
#: carrying one of these executes an argument, so none of its arguments can be
#: called prose.
CODE_SWITCHES = frozenset({
    "-c", "-m", "-e", "-lc", "-ic", "-cl", "-mc",
    "--command", "--eval", "--exec", "--wrap",
})


#: One quoted argument, in the two spellings an option's value takes.
QUOTED = re.compile(r"""'[^']*'|"[^"]*\"""")


def _split_words(segment: str) -> tuple[list[str], str]:
    """The segment's finished words, and the unfinished one it ends inside.

    Splitting the two apart is what lets a caller ask where a word BEGINS
    rather than only what the words are.  ``bash -c "`` ends inside a word
    that has nothing in it yet but an opening quote, and ``bash -c echo `` ends
    between words; the word list is the same length either way, so only the
    remainder tells them apart.  See ``_runs_substitution_output``.
    """

    words: list[str] = []
    current: list[str] = []
    quote = ""
    for char in segment:
        if quote:
            current.append(char)
            if char == quote:
                quote = ""
            continue
        if char in "'\"":
            quote = char
            current.append(char)
            continue
        if char.isspace():
            if current:
                words.append("".join(current))
                current = []
            continue
        current.append(char)
    return words, "".join(current)


def _words(segment: str) -> list[str]:
    """The segment's words, with their quotes kept.

    ``shlex`` would strip them, and the quotes are the signal: they are what
    separates a word that carries prose from a word that carries a path.
    """

    words, partial = _split_words(segment)
    return [*words, partial] if partial else words


def _prose_start(segment: str) -> int | None:
    """Where this segment's arguments stop being commands, if they ever do.

    Issue #209: a mailbox send was refused because the message body described
    a shard that had died under a test runner.  Nothing ran and no GPU was
    touched -- the command posts a JSON file to a directory -- but the runner's
    name in the ``--body`` prose matched the scan.  That is the failure this
    module's own docstring already names for a commit message, one caller
    later, and it makes the mailbox lossy in exactly the case it is most
    needed: one agent cannot warn another about a runner failure without the
    warning being mistaken for the failure.

    The exemption is keyed on a shape rather than on that caller's path,
    because the path is a caller outside this repo and the shape is a fact
    about execution: ``python x.py ...`` is the shell exec'ing an interpreter
    and the interpreter exec'ing a FILE.  Neither of them execs an argument,
    so a quoted argument of such a segment is prose ABOUT work, not work.

    Every way of handing an argument to something that runs it fails this
    test, and that is the load-bearing half:

    * ``python -c`` and ``python -m`` run the argument, so they return None.
    * A shell -- ``bash -lc "pytest"`` -- is not a script run at all.
    * A wrapper -- ``ssh box "pytest"``, ``docker run --entrypoint "pytest"``
      -- does not lead with a python interpreter, so it never gets here.
    * Nor does a launcher that forwards its trailing argv: ``uv run "pytest"``,
      ``systemd-run --pty "pytest"``, ``watch "pytest tests"``.  This is why
      the exemption is not "a quoted argument is prose": that reading is
      lexically identical to those, and would have opened a hole wider than
      the bug.

    The index returned is that of the first word past the script path.  The
    interpreter and the script path themselves are never elided, so a quoted
    command word -- ``'/…/venvs/gpu/bin/python' train.py`` -- is still
    read as the command it is.
    """

    words = _words(segment)
    index = 0
    while index < len(words):
        head = words[index]
        if head in RESERVED_WORDS or ("=" in head and not head.startswith("/")):
            index += 1
            continue
        break
    if index >= len(words):
        return None
    if re.fullmatch(r"python[0-9.]*", _name_of(words[index])) is None:
        return None
    index += 1
    while index < len(words):
        word = words[index]
        if word in CODE_SWITCHES:
            return None
        if word.startswith("-"):
            index += 1
            continue
        # The first thing that is not a switch is what python will run.  Only
        # a file makes this a script run; anything else is not read here.
        return index + 1 if _name_of(word).endswith(".py") else None
    return None


def _mentions_elided(segment: str) -> str:
    """The segment as the guard should read it, with its prose blanked out.

    Quotes are read lexically and escapes inside them are not tracked, so a
    body carrying an escaped quote ends its span early and the rest of the
    prose is scanned as command text.  That falls to the refusing side on
    purpose: the way to send prose this guard would misread is to hand it to
    the tool in a file, where it is never on a command line at all.
    """

    start = _prose_start(segment)
    if start is None:
        return segment
    words = _words(segment)
    return " ".join(words[:start]
                    + [QUOTED.sub(" ", word) for word in words[start:]])


def _feeds_a_shell(segment: str) -> bool:
    """True when this segment hands its standard input to a shell.

    A shell, not an interpreter of any language: what makes a body worth
    scanning is that the body is shell, and only a shell makes it so.
    """

    tokens = _command_tokens(segment)
    if not tokens:
        return False
    if _is_shell(_name_of(tokens[0])):
        return True
    if _name_of(tokens[0]) not in WRAPPERS:
        return False
    return any(_is_shell(_name_of(token)) for token in tokens[1:])


#: A SHELL's run switch: the one that makes the shell execute an argument
#: instead of reading a script or its standard input.  ``CODE_SWITCHES`` above
#: is the wider vocabulary -- it carries python's ``-m`` and ``sbatch``'s
#: ``--wrap`` -- and this is deliberately not it.  What makes a body worth
#: reading as commands is that the body is SHELL, which is the same line
#: ``_feeds_a_shell`` draws and the same one issue #223 settled: ``python3 -c
#: "$(cat <<'X' ... X)"`` runs Python, and ``cat > x.py <<'X' ... X; python3
#: x.py`` writes and runs the same program and is allowed today.
#:
#: Matched as a cluster rather than as a literal, because a shell takes its
#: options clustered and the argument still follows: ``bash -lc``, ``bash
#: -xc`` and ``bash -euc`` all run the next word.
def _runs_argument(token: str) -> bool:
    """True when this switch makes a shell run the word that follows it."""

    if token == "--command":
        return True
    return (len(token) > 1 and token.startswith("-")
            and not token.startswith("--") and "c" in token[1:])


#: Where the value of a shell's run switch stops being the substitution and
#: starts being something else.  ``bash -c "$( ... )"`` and ``bash -c "cd x;
#: $( ... )"`` both run the substitution's output as a command; ``bash -c
#: "echo $( ... )"`` prints it, and ``bash -c echo $( ... )`` never gives the
#: switch the substitution at all.  So the test is not "the value contains a
#: substitution" -- it is "the value reaches the substitution at a point where
#: a command may begin".
COMMAND_MAY_BEGIN = re.compile(r"(?:^|[;&|\n])\s*\Z")


def _runs_substitution_output(prefix: str) -> bool:
    """True when a shell will RUN what the ``$( ... )`` after ``prefix`` prints.

    Issue #247.  A ``-c`` switch runs the text a command substitution
    produced, and until this the body that became that text was never scanned:
    ``_heredocs`` asked who owned the opener and got ``cat``, which is a
    writer, so the body was dropped as data.  It is not data.  It is the
    script the shell in front of the substitution is about to execute.

    This is a rule about ``-c``, not about standard input, which is why it is
    separate from ``_feeds_a_shell``: the body is shell because the ENCLOSING
    command hands its argument to an interpreter to run, not because an
    interpreter reads the body itself.

    Three things have to hold, and each is one of the ways the shape can be
    mistaken for a neighbour that runs nothing:

    * The command word is a shell, reached directly or through a wrapper
      (``ssh lina bash -c``, ``sudo bash -c``).  An interpreter of another
      language is not one; see ``_runs_argument``.
    * Its last finished word is a run switch, so the switch's value has not
      been supplied yet.  ``bash -c echo $(...)`` fails this, and it must:
      ``-c`` takes ``echo``, and the substitution is the argument a printed
      script never reads.
    * The value word reaches the substitution where a command may begin.
      ``bash -c "echo $(...)"`` fails this and prints its body.

    The pool's own submissions are excluded by the mechanism that already
    excludes them elsewhere: if ``_drop_pool_payload`` would cut this prefix,
    the substitution is inside a payload another process execs under a
    reservation, and the entrypoint in front of it is what vouches for it.
    """

    if _drop_pool_payload(prefix) != prefix:
        return False
    words, partial = _split_words(prefix)
    if COMMAND_MAY_BEGIN.search(partial.lstrip("'\"")) is None:
        return False
    tokens = _past_prefixes(words)
    if not tokens:
        return False
    if _is_shell(_name_of(tokens[0])):
        rest = tokens[1:]
    elif _name_of(tokens[0]) in WRAPPERS:
        rest = None
        for index, token in enumerate(tokens[1:], 1):
            if _is_shell(_name_of(token)):
                rest = tokens[index + 1:]
                break
        if rest is None:
            return False
    else:
        return False
    if rest and rest[-1] == "--":
        # ``bash -c -- "$(...)"``: the separator ends option parsing, so the
        # next word is still the code the shell runs.  Without this the rule
        # reads ``--`` as the last switch and finds no ``c`` in it.  A bare
        # ``bash -- "$(...)"`` is unaffected: the list empties and the word is
        # a file name, not code.
        rest = rest[:-1]
    return bool(rest) and _runs_argument(rest[-1])


def _copies_body_to_output(owner: str, downstream: str) -> bool:
    """True when this command puts a here-document body on its own output.

    Only asked of a substitution whose output a shell runs.  The redirection
    test is the half that keeps the existing carve-out: ``cat > f <<'X'``
    and ``cat <<'X' > f`` both write a file and print nothing, so what the
    ``-c`` runs is an empty string, and the fleet's own worker-start script is
    written in exactly that shape.  ``downstream`` is the rest of the line
    after the opener tokens, cut at the first pipe, because a pipeline is
    already decided by ``piped_to_shell``.
    """

    tokens = _command_tokens(owner)
    if not tokens:
        return False
    if _name_of(tokens[0]) not in PASS_THROUGH:
        if _name_of(tokens[0]) not in WRAPPERS:
            return False
        if not any(_name_of(token) in PASS_THROUGH for token in tokens[1:]):
            return False
    return not (REDIRECTS_STDOUT.search(owner)
                or REDIRECTS_STDOUT.search(downstream.split("|", 1)[0]))


def _substitution(text: str, start: int) -> tuple[str, int]:
    """The body of the ``$( ... )`` at ``start``, and the index past its ``)``.

    Quotes and nested parentheses are tracked, so ``$(echo "a)b")`` ends at
    the right place.  An unterminated substitution yields the rest of the
    text, which is the conservative reading: what the shell would run if the
    caller finished typing.

    A here-document body inside the substitution is skipped rather than read
    as command text, because the body is prose as often as not and an
    apostrophe in it would otherwise open a quote that swallows the closing
    ``)`` and everything after it.  ``git commit -m "$(cat <<'EOF'`` with a
    body saying "doesn't" is the case that matters, and it is the shape this
    repo writes commit messages with.
    """

    begin = start + 2
    index = begin
    depth = 0
    quote = ""
    pending: list[str] = []
    while index < len(text):
        char = text[index]
        if quote:
            if char == "\\" and quote == '"' and index + 1 < len(text):
                index += 2
                continue
            if char == quote:
                quote = ""
            index += 1
            continue
        if char == "\\" and index + 1 < len(text):
            index += 2
            continue
        if char in "'\"":
            quote = char
            index += 1
            continue
        if text.startswith("<<", index):
            match = HEREDOC.match(text, index)
            if match is None:
                index += 2
                continue
            pending.append(_heredoc_tag(match)[0])
            index = match.end()
            continue
        if char == "\n" and pending:
            index = _past_bodies(text, index, pending)
            pending = []
            continue
        if char == "(":
            depth += 1
        elif char == ")":
            if depth == 0:
                return text[begin:index], index + 1
            depth -= 1
        index += 1
    return text[begin:], len(text)


def _pipeline_after(line: str, at: int) -> str:
    """The rest of the pipeline the command at ``at`` sits in.

    Everything from ``at`` up to the first boundary that ends a pipeline: a
    ``;``, a ``&&``, a ``||``, a ``&`` or a newline.  A ``|`` deliberately
    does not end it, because a pipeline is the one boundary that hands a
    command's output to the next command as input.

    Only a lone ``&`` ends it, on the same reading ``_commands_in`` uses: the
    redirection spellings that merely contain the character belong to the
    command they sit in, and ``cat <<'EOF' 2>&1 | bash`` still pipes its body
    into an interpreter.
    """

    quote = ""
    index = at
    while index < len(line):
        char = line[index]
        if quote:
            if char == quote:
                quote = ""
            index += 1
            continue
        if char == "\\" and index + 1 < len(line):
            index += 2
            continue
        if char in "'\"":
            quote = char
            index += 1
            continue
        if line.startswith("&&", index) or line.startswith("||", index):
            return line[at:index]
        if char == "&" and (line[index + 1:index + 2] == ">"
                            or (index and line[index - 1] in "><&")):
            index += 1
            continue
        if char in ";&\n()":
            return line[at:index]
        index += 1
    return line[at:]


def _past_bodies(text: str, newline: int, tags: list[str]) -> int:
    """Where the here-document bodies opened on one line end.

    ``newline`` indexes the newline that ends the opener's line, so the first
    body starts right after it and each body ends at its own terminator line.
    The index returned is the newline that closes the last of them, which is
    where the shell resumes reading the command line.
    """

    at = newline
    for tag in tags:
        while at < len(text):
            end = text.find("\n", at + 1)
            line = text[at + 1:len(text) if end < 0 else end]
            if line.strip() == tag:
                at = len(text) if end < 0 else end
                break
            if end < 0:
                return len(text)
            at = end
    return at


def _backquoted(text: str, start: int) -> tuple[str, int]:
    """The body of the backquoted command at ``start``, and the index past it."""

    index = start + 1
    while index < len(text):
        if text[index] == "\\" and index + 1 < len(text):
            index += 2
            continue
        if text[index] == "`":
            return text[start + 1:index], index + 1
        index += 1
    return text[start + 1:], len(text)


def _commands_in(text: str) -> list[str]:
    """The commands one piece of shell text runs, each as its own segment.

    This is the correction the whole of issue #89 turns on: the boundaries are
    identified BEFORE any exemption is applied, and they are identified with
    the quoting rules the shell uses rather than by splitting on the operator
    characters wherever they appear.  Splitting raw text got both directions
    wrong at once.  A quoted ``&&`` inside a pbrun payload is not a boundary
    and used to be one, which is why the payload had to be cut off the front
    of the command line; an unquoted ``&&`` after a pbrun payload IS a
    boundary and used to be swallowed by that cut, so the command the outer
    shell ran next was never judged.

    A ``$( ... )`` or backquoted substitution is a command the shell runs, so
    its body becomes its own segment.  The text around it keeps accumulating
    with the substitution elided, so the enclosing command still leads its own
    segment and keeps whatever exemption it had: ``git commit -m "$(cat f)"``
    is a ``git`` segment and a ``cat`` segment, and neither is refused.  The
    body is scanned by ``_scan`` rather than by this function alone, because a
    substitution is a whole shell context and may open a here-document of its
    own -- ``git commit -m "$(cat <<'EOF'`` is how a long message is written
    here, and reading its body as commands refused the commit.

    A ``#`` at the start of a word begins a comment, which runs to the end of
    the line and is not a command.  It has to be recognized for the same
    reason quotes do: an apostrophe in a comment otherwise opens a quote that
    runs on and glues the next line's real command into the comment's segment,
    where it inherits the comment's verdict in whichever direction is wrong.
    """

    segments: list[str] = []
    buffer: list[str] = []
    quote = ""
    index = 0

    def flush() -> None:
        piece = "".join(buffer).strip()
        if piece:
            segments.append(piece)
        buffer.clear()

    while index < len(text):
        char = text[index]
        if quote == "'":
            buffer.append(char)
            if char == "'":
                quote = ""
            index += 1
            continue
        if char == "\\" and index + 1 < len(text):
            # A backslash-newline is a line continuation, not a boundary and
            # not two literal characters.  Handling it here rather than by
            # rewriting the whole command first keeps it out of here-document
            # bodies and quoted strings, where the shell does not apply it.
            buffer.append(" " if text[index + 1] == "\n"
                          else text[index:index + 2])
            index += 2
            continue
        if text.startswith("$(", index):
            runs = _runs_substitution_output("".join(buffer))
            inner, index = _substitution(text, index)
            segments.extend(_scan(inner, output_run=runs))
            buffer.append(" ")
            continue
        if char == "`":
            runs = _runs_substitution_output("".join(buffer))
            inner, index = _backquoted(text, index)
            segments.extend(_scan(inner, output_run=runs))
            buffer.append(" ")
            continue
        if quote == '"':
            buffer.append(char)
            if char == '"':
                quote = ""
            index += 1
            continue
        if char in "'\"":
            quote = char
            buffer.append(char)
            index += 1
            continue
        if char == "#" and (not buffer or buffer[-1][-1:].isspace()):
            flush()
            end = text.find("\n", index)
            index = len(text) if end < 0 else end
            continue
        if text.startswith("&&", index) or text.startswith("||", index):
            flush()
            index += 2
            continue
        if char == "&":
            # A lone ``&`` backgrounds the command before it and starts
            # another, so it is a boundary.  The redirection spellings that
            # merely contain the character are not: ``2>&1``, ``>&2``, ``&>``
            # and ``<&3`` all belong to the command they sit in.
            if text[index + 1:index + 2] == ">" or buffer and \
                    buffer[-1][-1:] in "><&":
                buffer.append(char)
                index += 1
                continue
            flush()
            index += 1
            continue
        if char in ";|\n()":
            flush()
            index += 1
            continue
        buffer.append(char)
        index += 1
    flush()
    return segments


def _expansions_in(text: str) -> list[str]:
    """The commands an UNQUOTED here-document body runs when it is expanded.

    An unquoted delimiter makes the body behave like a double-quoted string:
    quotes inside it are literal, and ``$( )`` and backquotes still run.  So
    ``cat >/dev/null <<EOF`` carrying ``$(<cuda python> train.py)`` starts GPU
    work even though the command writing the file is ``cat``.
    """

    segments: list[str] = []
    index = 0
    while index < len(text):
        if text[index] == "\\" and index + 1 < len(text):
            index += 2
            continue
        if text.startswith("$(", index):
            inner, index = _substitution(text, index)
            segments.extend(_scan(inner))
            continue
        if text[index] == "`":
            inner, index = _backquoted(text, index)
            segments.extend(_scan(inner))
            continue
        index += 1
    return segments


def _find_heredoc(text: str) -> tuple[int, int, str, bool] | None:
    """The first here-document opener the shell would act on AT THIS LEVEL.

    Quote-aware, so a ``<<EOF`` inside a quoted argument is text rather than
    an opener.

    Substitution-aware too, and for the same reason one level down: a ``$( ...
    )`` or backquoted span is a shell context of its own, so an opener inside
    it belongs to a command inside it.  Claiming it from out here got its
    owner wrong every time (issue #239).  ``_heredocs`` asks who owns an
    opener with ``_commands_in(rest[:opens_at])``, and on ``echo $(bash `` that
    prefix ends in the substitution's own segment rather than the enclosing
    command's, so the owner came back ``echo``: a body a shell really runs was
    read as data and never scanned.  Skipping the span here leaves the opener
    to the ``_scan`` pass ``_commands_in`` already makes over the
    substitution's body, where the owner is computed from text that has no
    substitution in front of it, and both halves of that bug are out of reach.

    The ordering matches ``_commands_in``: a substitution is recognized inside
    a double-quoted string, because the shell expands it there, and not inside
    a single-quoted one, because it does not.

    Leaving the span to ``_commands_in`` is also what gives the ``-c`` rule
    somewhere to stand: that is the pass which knows the text in FRONT of the
    substitution, and so the only one that can tell whether a shell is about
    to run what the substitution prints (issue #247).
    """

    quote = ""
    index = 0
    while index < len(text):
        char = text[index]
        if quote == "'":
            if char == "'":
                quote = ""
            index += 1
            continue
        if char == "\\" and index + 1 < len(text):
            index += 2
            continue
        if text.startswith("$(", index):
            _, index = _substitution(text, index)
            continue
        if char == "`":
            _, index = _backquoted(text, index)
            continue
        if quote == '"':
            if char == '"':
                quote = ""
            index += 1
            continue
        if char in "'\"":
            quote = char
            index += 1
            continue
        if text.startswith("<<", index):
            match = HEREDOC.match(text, index)
            if match is not None:
                tag, quoted = _heredoc_tag(match)
                return match.start(), match.end(), tag, quoted
            index += 2
            continue
        index += 1
    return None


def _heredocs(command: str, *, output_run: bool = False) -> tuple[str, list[str]]:
    """Split the here-document bodies out, and say what each one is.

    Returns the command text with every body removed, and the segments those
    bodies contribute.  Three cases, and the difference between them is what
    the shell does with the body, not what the body looks like:

    * Fed to a shell (``bash <<EOF``): the body is a script in the language
      this module parses, so all of it is scanned.
    * An unquoted delimiter (``cat >f <<EOF``, ``python3 - <<EOF``): the body
      is data, but the shell expands it before handing it on, so its
      substitutions are scanned whatever reads the body afterwards.
    * A quoted delimiter to anything else (``cat >f <<'EOF'``, ``python3 -
      <<'EOF'``): the shell copies bytes to a file or to another program's
      standard input and runs nothing in the body itself, so it is dropped.
      This is the case the exemption was written for, and it stays: the file
      that starts the fleet's workers names the CUDA interpreter as a
      ``--python`` argument by construction, and the hook refused that write
      four times.  ``python3 - <<'EOF'`` joined it in issue #223 -- its body
      is Python, and reading Python tokens as commands refused prose about
      the rule rather than the rule being broken.

    The second and third cases are decided by ``_feeds_a_shell``, which asks
    for a shell rather than for an interpreter.  That is the whole of the
    #223 change, and it moves only bodies fed to ``python``: every other
    language's interpreter was already in the third case.

    ``output_run`` adds a reader the third case cannot see.  When a shell is
    about to run what this text PRINTS -- the ``$( ... )`` in the value of a
    ``-c`` switch -- a body that reaches the output is the script that shell
    executes, however quoted its delimiter is.  ``cat`` is a writer in every
    other context and is the program that carries the body there in this one,
    so the third case dropped it: ``bash -c "$(cat <<'X'`` ... ``X)"`` started
    GPU work and nothing scanned it (issue #247).  ``_copies_body_to_output``
    is the half that says the body reaches the output, and it declines a
    redirected write, because ``cat > f <<'X'`` prints nothing and the ``-c``
    then runs an empty string.

    A body fed to a shell is scanned by ``_commands_in``, deliberately, not by
    ``_scan``.  A here-document opened INSIDE an executed body is text the
    outer shell never reads -- the inner program does -- so its own body stays
    in the segments where the enclosing script's commands are judged, and
    ``bash <<'SH'`` wrapping ``python3 - <<'PY'`` cannot hide work in the
    inner body.

    An opener inside a ``$( ... )`` or a backquoted span is not this pass's
    to claim.  That span is a shell context of its own, and the opener belongs
    to a command inside it; ``_find_heredoc`` skips over it, and the ``_scan``
    that ``_commands_in`` already makes over the substitution's body finds it
    there, where the owner is read from text with no substitution in front of
    it.  Claiming it out here asked ``_commands_in(rest[:opens_at])`` a
    question whose answer ended in the substitution's own segment, so ``echo
    $(bash <<'SH'`` came back owned by ``echo`` and a body a shell really runs
    was read as data (issue #239).

    Only the opener TOKENS leave the command line, not the rest of the line
    they sit on.  Dropping everything from the opener to the newline is the
    same "raw text is data" mistake one token over: ``cat > f <<'EOF' &&
    <cuda python> train.py`` runs that second command after the write, and it
    was never judged.  A line may also carry more than one opener, and the
    shell reads their bodies in order, so they are consumed in order rather
    than leaving the second body standing where a command should be.
    """

    kept: list[str] = []
    extra: list[str] = []
    rest = command
    while True:
        opener = _find_heredoc(rest)
        if opener is None:
            kept.append(rest)
            break
        start, end, tag, quoted = opener
        line_end = rest.find("\n", end)
        if line_end < 0:
            # An opener with no body yet: nothing has been fed in, so there is
            # nothing to strip and the text before it still stands as command.
            kept.append(rest)
            break
        # Every opener on this command line, in the order the shell reads
        # their bodies, and the spans to excise from the line itself.
        openers = [(tag, quoted, start)]
        spans = [(start, end)]
        cursor = end
        while cursor < line_end:
            more = _find_heredoc(rest[cursor:line_end])
            if more is None:
                break
            openers.append((more[2], more[3], cursor + more[0]))
            spans.append((cursor + more[0], cursor + more[1]))
            cursor += more[1]
        line = ""
        at = 0
        for span_start, span_end in spans:
            line += rest[at:span_start]
            at = span_end
        after_openers = len(line)
        line += rest[at:line_end]
        kept.append(line)
        # A pipeline hands a command's output to the next one as input, so
        # ``cat <<'EOF' | bash`` executes the body just as ``bash <<'EOF'``
        # does, one command further along.  Only the pipeline counts: after a
        # ``&&`` the next command reads its own standard input, and treating
        # ``cat > f <<'EOF' && bash other.sh`` as executable would refuse the
        # file write this exemption exists for.
        downstream = _pipeline_after(line, after_openers)
        piped_to_shell = "|" in downstream and any(
            _feeds_a_shell(part) for part in _commands_in(downstream))
        body_text = rest[line_end + 1:]
        for tag, quoted, opens_at in openers:
            # The command a here-document is attached to is the last one
            # before ITS OWN opener, not the first one on the line: ``cd x &&
            # bash <<EOF`` feeds bash.  Per opener rather than per line,
            # because one line can open two bodies for two different readers:
            # ``cat > f <<'A' ; bash <<'B'`` writes the first and executes the
            # second, and deciding both from the first owner dropped a shell
            # script as if it were a file write.
            owner_segments = _commands_in(rest[:opens_at])
            owner = owner_segments[-1] if owner_segments else ""
            executed = (_feeds_a_shell(owner) or piped_to_shell
                        or (output_run
                            and _copies_body_to_output(owner, downstream)))
            lines = body_text.split("\n")
            body: list[str] = []
            remainder = ""
            for position, entry in enumerate(lines):
                if entry.strip() == tag:
                    remainder = "\n".join(lines[position + 1:])
                    break
                body.append(entry)
            text = "\n".join(body)
            if executed:
                extra.extend(_commands_in(text))
            elif not quoted:
                extra.extend(_expansions_in(text))
            body_text = remainder
        rest = body_text
    # Rejoin with a boundary, not a space.  Gluing the command before a
    # heredoc to the command after it makes one segment whose first token is
    # the writer -- ``cat``, which is exempt -- and the work behind the
    # heredoc inherits that exemption.  Same hole as judging a compound
    # command by its first token, reached from a different direction.
    return "\n".join(part for part in kept if part), extra


def _scan(text: str, *, output_run: bool = False) -> list[str]:
    """Every command one piece of shell text runs, here-documents included.

    One function rather than two calls at the top level, because a command
    substitution is a shell context in its own right: its body can open a
    here-document, and reading that body without this pass turned a commit
    message into commands.

    ``output_run`` says that a shell will execute what this text PRINTS -- the
    ``$( ... )`` in the value of a ``-c`` switch -- so a here-document body
    that reaches the output is the script, not data.  It is set only by
    ``_commands_in``, from the text in front of the substitution, and never
    inherited: a substitution nested inside this one decides for itself.
    """

    kept, extra = _heredocs(text, output_run=output_run)
    return [*_commands_in(kept), *extra]


def _segments(command: str) -> list[str]:
    """The commands inside one Bash invocation, each judged on its own.

    A leading ``cat`` does not vouch for what follows ``&&``, and a refused
    segment is not excused by a permitted neighbour.
    """

    # The payload cut is per segment, so it can no longer discard the outer
    # shell's own commands.  See ``_drop_pool_payload``.
    return [_drop_pool_payload(segment) for segment in _scan(command)]


def contends(command: str) -> bool:
    """True when any segment of this command starts GPU work off-pool."""

    pattern = configured_contends_pattern()
    for segment in _segments(command):
        if not pattern.search(_mentions_elided(segment)):
            continue
        if _inspects_only(segment):
            continue
        if _first_token(segment) in NEVER_GPU:
            continue
        if NO_DEVICE.search(segment):
            continue
        if any(entry in segment for entry in POOL_ENTRYPOINTS):
            continue
        return True
    return False


def submits(command: str) -> bool:
    """True when any segment submits to SLURM outside the fleet's lane.

    The exemptions are the three that cannot be anything else: a segment led
    by a command that never starts work (a commit message, a grep for the
    word, ``which sbatch``), a verb asked only about itself (``sbatch
    --help``), and a segment naming the lane's own entrypoints, which are
    what run ``sbatch`` on this fleet's behalf.  ``command -v sbatch`` joins
    the first of those by shape rather than by the builtin's name, because
    ``command sbatch job.sh`` submits.

    ``CUDA_VISIBLE_DEVICES=`` is NOT an exemption here, deliberately.  It works
    for a local command because the kernel then denies the child a device; it
    says nothing about a job the scheduler will start on another node with a
    GRES allocation of its own.
    """

    for segment in _segments(command):
        if not SCHEDULER.search(_mentions_elided(segment)):
            continue
        if _inspects_only(segment):
            continue
        if _first_token(segment) in NEVER_GPU:
            continue
        if _describes_itself(segment):
            continue
        if any(entry in segment for entry in POOL_ENTRYPOINTS):
            continue
        return True
    return False


# This is a command-line guard, not a proof of arbitrary program behavior.
# The standing agent policy covers indirect test/GPU execution too.
TEST_WORK = re.compile(
    r"(?<![\w.-])(?:pytest|py.test|ctest|tox|nox)(?![\w.-])"
    # ``-m`` takes its value attached as readily as spaced -- ``python3
    # -mpytest`` is what the interpreter documents -- and the runner names
    # above are matched with a ``(?<![\w.-])`` guard that the ``m`` in front
    # of them defeats.  So the attached spelling ran the whole matrix off-pool
    # while the spaced one was refused (issue #225).  Two clauses rather than
    # one, because ``unittest`` is a module the interpreter runs and never a
    # command by itself, so it is only ever reachable through ``-m``.
    r"|(?:^|\s)-m\s*unittest\b"
    r"|(?:^|\s)-m(?:pytest|py.test|ctest|tox|nox)(?![\w.-])"
    r"|\b(?:cargo|go)\s+test\b"
    r"|\b(?:npm|pnpm|yarn)\s+(?:run\s+)?test(?:[ :\s]|$)"
)
GPU_CONTAINER = re.compile(r"\b(?:docker|podman)\s+[^;]*--gpus(?:[ =]|$)")

#: vLLM work, exempt from admission universally (Rob, 2026-09-07): a serve, a
#: census, a routing run, a benchmark against a live endpoint -- including its
#: GPU containers, which is the shape this carve-out is for.  Lexical: the
#: segment names vLLM as the image or the program it runs
#: (``vllm/vllm-openai``, ``vllm serve``).  Container-only, deliberately: the
#: tessera#550 pytest refusal was correct, and a test file is not a serve
#: because its name says ``vllm``.
VLLM_CONTAINER = re.compile(r"vllm", re.IGNORECASE)

#: Fabric work that happens to borrow the image is not vLLM (#588's scoping
#: note): a bare NCCL collective in a vLLM image is decided case by case by
#: whoever holds the keyboard, and this carve-out must not decide it for
#: them.  Nor is a test runner inside the container a serve.  This pattern is
#: read against the container's PROGRAM and its arguments, never the image
#: reference: ``spark-vllm-nccl230`` is an image whose name records the NCCL
#: 2.30.7 swap it carries, and reading ``nccl`` off that name refused the
#: GLM-5.3 serve the image exists to run (#1183).  See ``_docker_program``.
NOT_VLLM_CONTAINER = re.compile(
    r"nccl|all.?reduce|bandwidthTest|p2pBandwidth", re.IGNORECASE)


#: Docker's option grammar, to the one question the hook asks of it: which
#: options take the following WORD as their value, so that the image is the
#: first word past them.  Only options that REQUIRE a separate value belong
#: here.  A flag listed by mistake would swallow the image and move the
#: program one word to the left, handing a real collective the exemption; an
#: unlisted option that really takes a value only leaves its value standing
#: where the image was, so the program search starts one word early and
#: refuses.  That is the conservative direction, and the behaviour before
#: this existed -- the failure mode to avoid is the other one.
DOCKER_VALUE_OPTIONS = frozenset({
    "add-host", "annotation", "attach", "blkio-weight",
    "blkio-weight-device", "cap-add", "cap-drop", "cgroup-parent",
    "cgroupns", "cidfile", "cpu-count", "cpu-percent", "cpu-period",
    "cpu-quota", "cpu-rt-period", "cpu-rt-runtime", "cpu-shares", "cpus",
    "cpuset-cpus", "cpuset-mems", "detach-keys", "device",
    "device-cgroup-rule", "device-read-bps", "device-read-iops",
    "device-write-bps", "device-write-iops", "dns", "dns-option",
    "dns-search", "domainname", "entrypoint", "env", "env-file", "expose",
    "gpus", "group-add", "health-cmd", "health-interval", "health-retries",
    "health-start-interval", "health-start-period", "health-timeout",
    "hostname", "init-path", "ip", "ip6", "ipc", "isolation",
    "kernel-memory", "label", "label-file", "link", "link-local-ip",
    "log-driver", "log-opt", "mac-address", "memory",
    "memory-reservation", "memory-swap", "memory-swappiness", "mount",
    "name", "net", "network", "network-alias", "oom-score-adj", "pid",
    "pids-limit", "platform", "publish", "pull", "restart", "runtime",
    "security-opt", "shm-size", "stop-signal", "stop-timeout",
    "storage-opt", "sysctl", "tmpfs", "ulimit", "user", "userns", "uts",
    "volume", "volume-driver", "volumes-from", "workdir",
})

#: The short options that take a value, whether it is attached
#: (``-p8000:8000``) or a following word (``-p 8000:8000``).  A cluster ends
#: at the value option: ``-itp 8000`` still consumes the next word.
DOCKER_VALUE_SHORT = frozenset(
    {"a", "c", "e", "h", "l", "m", "p", "u", "v", "w"})

#: The options whose value is a PROGRAM the container runs rather than one of
#: its settings: the entrypoint, the health-check command, and the init
#: binary.  A collective named in any of them is a bare collective like any
#: other, so the value joins the program; the other option values do not.
#: Discarding a program-valued option instead would exempt work the hook
#: refused before this parser existed (#1183 review).
DOCKER_PROGRAM_OPTIONS = frozenset({"entrypoint", "health-cmd", "init-path"})


def _short_option_span(word: str) -> int:
    """Words this short-option word consumes: itself and maybe its value.

    ``-p 8000:8000`` is two words, ``-p8000:8000`` and ``-it`` are one, and a
    cluster is read until the first character that names a value option --
    after which the rest of the word is that option's attached value, or the
    next word is its value.
    """

    cluster = word[1:]
    for position, char in enumerate(cluster):
        if char in DOCKER_VALUE_SHORT:
            return 1 if position + 1 < len(cluster) else 2
    return 1


def _docker_program(segment: str) -> str | None:
    """The program a ``docker run`` segment runs, or ``None`` if unreadable.

    Docker's grammar is ``run [OPTIONS] IMAGE [COMMAND] [ARG...]``, and the
    image is the one word whose text is not the work: it names the image the
    task runs, and the work is the program the image runs plus that program's
    arguments.  Reading the collective pattern off the whole segment refused
    an exempt serve because the image was named for the NCCL it carries
    (``spark-vllm-nccl230``, #1183).  So the option words are walked to find
    the image, and what comes back is the program the container execs: the
    values of the options that name a program (``--entrypoint``,
    ``--health-cmd``, ``--init-path``) when the run carries them, plus the
    words after the image.  Both spellings of those options are read,
    attached (``--entrypoint=x``) and spaced (``--entrypoint x``), and a
    short-option cluster consumes its value where the grammar says it does.

    ``None`` means the segment is not a container run this can read -- the
    caller then judges the segment as it always did, which refuses.  This is
    a lexical reader of one CLI's shape, not a proof of what the container
    runs, and the standing agent policy covers the shapes it cannot read.
    """

    words = _words(segment)
    container = next(
        (index for index, word in enumerate(words)
         if _name_of(word) in ("docker", "podman")),
        None)
    if container is None:
        return None
    run = next(
        (index for index in range(container + 1, len(words))
         if _name_of(words[index]) in ("run", "create")),
        None)
    if run is None:
        return None
    program: list[str] = []
    # Past the end while no image has been named, so the words after it are
    # empty and only an entrypoint can still be the program.
    image = len(words)
    index = run + 1
    while index < len(words):
        word = words[index]
        if word == "--":
            image = index + 1
            break
        if word.startswith("--"):
            name, equals, value = word[2:].partition("=")
            if name in DOCKER_PROGRAM_OPTIONS:
                if equals:
                    program.append(value)
                    index += 1
                else:
                    if index + 1 < len(words):
                        program.append(words[index + 1])
                    index += 2
                continue
            index += 1 if equals or name not in DOCKER_VALUE_OPTIONS else 2
            continue
        if word.startswith("-") and len(word) > 1:
            index += _short_option_span(word)
            continue
        image = index
        break
    return " ".join(program + words[image + 1:])


def _vllm_container(segment: str) -> bool:
    """True when this GPU-container invocation is exempt vLLM work (#588).

    The scan can evaluate it: the segment names vLLM as the image or the
    program, runs no test runner, and is not a bare collective in the
    program.  Anything else with ``--gpus`` is still refused.
    """

    program = _docker_program(segment)
    if NOT_VLLM_CONTAINER.search(segment if program is None else program):
        return False
    if TEST_WORK.search(segment):
        return False
    return VLLM_CONTAINER.search(segment) is not None


def unpooled_work(command: str) -> bool:
    for segment in _segments(command):
        if _inspects_only(segment) or _first_token(segment) in NEVER_GPU:
            continue
        if any(entry in segment for entry in POOL_ENTRYPOINTS):
            continue
        scanned = _mentions_elided(segment)
        if TEST_WORK.search(scanned):
            # Asking the test runner for help/version does not run tests.
            if re.search(r"(?:^|\s)--(?:help|version)(?:\s|$)", segment):
                continue
            return True
        if GPU_CONTAINER.search(scanned):
            if _vllm_container(scanned):
                continue
            return True
    return False


#: The largest script file the hook reads into the scan, and the largest the
#: sightings log grows to.  The hook is a lexical guard, not a build system:
#: an unbounded read parks every ``bash x.sh`` behind disk, and an unbounded
#: log is litter.  Past either bound the execution is allowed and, for the
#: log, the volume itself is the signal.
OPAQUE_SCRIPT_MAX_BYTES = 256 * 1024
SIGHTINGS_MAX_BYTES = 10 * 1024 * 1024


def _opaque_script(segment: str) -> str | None:
    """The script file this segment runs without showing its text, if any.

    Issue #588: ``bash ab.sh`` runs a file the lexical scan cannot see
    inside, which is the shape exempt vLLM work took to route around the
    GPU-container rule -- and the same door is open to work that is not
    exempt.  Three shapes, all of them a shell executing a file rather than
    an argument: a shell invoked with a file operand (``bash ab.sh``,
    ``bash < ab.sh``), a script executed by path (``./ab.sh``), and
    ``source``/``.``.  A shell with a run switch (``bash -c ...``) executes
    its argument, which is already scanned, so it is not opaque; neither is
    ``python x.py``, whose text is not shell and which this module does not
    read as commands (#223).
    """

    tokens = _command_tokens(segment)
    if not tokens:
        return None
    head = _name_of(tokens[0])
    if head in ("source", "."):
        rest = [token for token in tokens[1:] if token not in ("<", ">")]
        if rest and not rest[0].startswith("-"):
            return rest[0]
        return None
    if _is_shell(head):
        if any(_runs_argument(token) for token in tokens[1:]):
            return None
        rest = [token for token in tokens[1:]
                if token not in ("<", ">") and not token.startswith("-")]
        return rest[0] if rest else None
    first = tokens[0]
    if head.endswith(".sh") or first.startswith("./") or first.startswith("../"):
        if re.fullmatch(r"python[0-9.]*", head) is not None:
            # ``./python3 train.py`` is ``python x.py`` by another path, and
            # that text is not shell.
            return None
        return first
    return None


def _read_opaque_script(path: str) -> str | None:
    """The script's text, or ``None`` when it cannot be read as text.

    Relative paths resolve against the hook's working directory, which is
    the session's: a script named the way the command names it is the file
    the command runs.  Anything unreadable, oversized or not UTF-8 text is
    ``None`` -- allowed and recorded, never refused on this basis.
    """

    candidate = Path(path)
    if not candidate.is_absolute():
        candidate = Path(os.getcwd()) / candidate
    try:
        if candidate.stat().st_size > OPAQUE_SCRIPT_MAX_BYTES:
            return None
        return candidate.read_text(encoding="utf-8")
    except (OSError, ValueError):
        return None


def _sightings_path() -> Path:
    override = os.environ.get("REQUIRE_POOL_SIGHTINGS")
    if override:
        return Path(override)
    return FLAG.with_name("require_pool_sightings.log")


def _record_sighting(script: str, command: str, *, reason: str) -> None:
    """Log an opaque script execution the scan allowed, best effort.

    The log is the half of #588 that visibility can do: a route-around the
    hook cannot see inside is recorded where an operator can read it, rather
    than passing silently.  Never raises -- a guard that breaks commands by
    failing to log is worse than no log.
    """

    try:
        path = _sightings_path()
        try:
            if path.stat().st_size >= SIGHTINGS_MAX_BYTES:
                return
        except OSError:
            pass
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps({
                "unix": time.time(), "script": script,
                "command": command[:2000], "reason": reason,
            }, sort_keys=True) + "\n")
    except (OSError, ValueError):
        pass


def _opaque_refusal(script: str, offender: str) -> str:
    return (
        f"Refused: {script} runs work that must go through PrismaBuild "
        f"(the hook reads one level into script files):\n  {offender[:200]}\n"
        f"Run it as:\n  /usr/bin/python3 {PBRUN} --gpu -- <your command>\n\n"
        "Flags: --exclusive for a timing run that needs the whole box; "
        "vLLM work -- a serve, a census, a routing run, a benchmark, its "
        "GPU containers -- is exempt and runs directly, without a wrapper "
        "script.\n"
    )


def opaque_refusal(command: str) -> str | None:
    """The refusal an opaque script earns, or ``None`` when none does.

    Split out so the file read and the sightings log stay beside the verdict
    they inform: a script whose text trips the same three rules the command
    line is judged by refuses naming the file, and a script that is clean or
    unreadable is recorded and allowed.  One level only: a script that merely
    calls another script is allowed and logged, and the log is what makes
    deeper nesting visible instead of silent.
    """

    for segment in _segments(command):
        script = _opaque_script(segment)
        if script is None:
            continue
        text = _read_opaque_script(script)
        if text is None:
            _record_sighting(script, command, reason="unreadable")
            continue
        offender = next(
            (part for part in _scan(text)
             if unpooled_work(part) or contends(part) or submits(part)),
            None)
        if offender is not None:
            return _opaque_refusal(script, offender)
        _record_sighting(script, command, reason="scanned-clean")
    return None


def main() -> int:
    if not FLAG.exists():
        return 0
    try:
        event = json.load(sys.stdin)
    except Exception:                                        # noqa: BLE001
        return 0
    command = str((event.get("tool_input") or {}).get("command") or "")
    if unpooled_work(command):
        sys.stderr.write(
            "Refused: all tests and GPU work must run through PrismaBuild.\n"
            f"Use /usr/bin/python3 {PBRUN} --cpus N --demand mem_gb=M "
            "[--gpu] -- <command>, or pbtest.py for test shards.\n"
            "Reserve combined child-process resources and read the CAS receipt.\n"
        )
        return 2
    if contends(command):
        sys.stderr.write(
            "Refused: GPU work goes through the PrismaBuild pool, not a local "
            "lock.\n\n"
            f"Run it as:\n  /usr/bin/python3 {PBRUN} --gpu -- <your command>\n\n"
            "Flags: --exclusive for a timing run that needs the whole box "
            "(expressed as a demand for its full GPU capacity, which the ledger "
            "turns into exclusion); Git checkouts are sealed through the CAS and "
            "may be materialized on any matching box; --here pins one on purpose.\n\n"
            "Why: a box-local flock cannot balance across sparky and sparklina, "
            "and it reproduced hold-while-gated, starvation and partial-hold "
            "waste that the pool's ledger solves structurally.\n"
        )
        return 2                      # exit 2 blocks and shows this to the agent
    if submits(command):
        # The same shape, because it is the same rule: an agent who has read
        # one refusal should be able to read this one without stopping.
        sys.stderr.write(
            "Refused: SLURM work goes through the PrismaBuild lane, not a bare "
            "submission.\n\n"
            f"Run it as:\n  /usr/bin/python3 {PBRUN} --transport slurm "
            "--gpu -- <your command>\n\n"
            "Flags: the lane turns --demand and --tag into --gres and "
            "--constraint, --timeout-s into --time, and seals the checkout "
            "through the CAS so the job materializes it on whichever node the "
            "scheduler picks; scancel and squeue are not refused.\n\n"
            "Why: a bare sbatch names no interpreter, so nothing about it can "
            "be priced, placed against the fleet's own accounting, or looked "
            "up afterwards -- the job's CAS receipt is what makes an action "
            "mean the same thing under either transport.\n"
        )
        return 2                      # exit 2 blocks and shows this to the agent
    refused = opaque_refusal(command)
    if refused is not None:
        sys.stderr.write(refused)
        return 2                      # a script file is not a way past the hook
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
