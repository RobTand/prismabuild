#!/usr/bin/env python3
"""Publish, inspect and release whole-directory resident sets."""
import argparse
from datetime import datetime, timezone
import getpass
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
_PB_ENTRYPOINT = Path(__file__).resolve(strict=True)
sys.path.insert(0, str(_PB_ENTRYPOINT.parents[
    2 if _PB_ENTRYPOINT.parent.name == "fleet" else 1] / "src"))
from prismabuild.runtime_paths import generation_root
sys.path.insert(0, str(generation_root(__file__) / "src"))
from prismabuild import core, resident_sets, submission
from prismabuild.submission_frontend import store_for
from prismabuild.submission_types import SubmissionRefused


from prismabuild import data_manifest as manifest_codec


def timestamp(value):
    parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    if parsed.tzinfo is None:
        raise argparse.ArgumentTypeError("lease dates must include a timezone")
    return parsed.astimezone(timezone.utc).timestamp()


def submit_copies(store, set_id, *, policy_path, checkout):
    """Freeze through the existing submitter, then use its movement builder."""
    from prismabuild import pool
    queue = pool.PoolQueue(store.queue_root)
    return submission.dispatch_resident(store, set_id, queue.tiers(),
        checkout=checkout, policy_path=policy_path, store=store_for(__file__))


def submit_adoption(store, set_id, *, host, source, policy_path, checkout):
    from prismabuild import pool
    queue = pool.PoolQueue(store.queue_root)
    tiers = {row["host"]: row for row in queue.tiers() if row.get("tier_id", "").startswith("local:")}
    if host not in store.read(set_id)["hosts"] or host not in tiers:
        raise ValueError("adoption host must be declared and announce its local tier")
    return submission.adopt_resident(store, set_id, tiers[host],
        checkout=checkout, policy_path=policy_path, source=source, store=store_for(__file__))




def lease_options(command):
    choice = command.add_mutually_exclusive_group(required=True)
    choice.add_argument("--lease-until", type=timestamp,
                        help="Keep the set until this timezone-qualified ISO 8601 time, no later than its hard maximum.")
    choice.add_argument("--campaign", help="Campaign id; keep the lease until explicit release or its hard maximum.")
    command.add_argument("--hard-max", required=True, type=timestamp,
                         help="Required timezone-qualified latest lease time; live rows cannot extend it automatically.")


def lease_from_args(args):
    lease = {"hard_max": args.hard_max}
    lease.update({"campaign": args.campaign} if args.campaign else {"until": args.lease_until})
    return lease



def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--pool-root", required=True, help="PrismaBuild queue root (the pool directory) that holds the resident set records.")
    commands = parser.add_subparsers(dest="command", required=True)
    publish = commands.add_parser("publish")
    publish.add_argument("--manifest", required=True, help="Content manifest JSON (name, bytes and sha256 per file); it must cover the whole canonical directory.")
    publish.add_argument("--canonical-root", required=True, help="The authoritative directory on shared storage that the set mirrors; it stays the source of truth.")
    publish.add_argument("--hosts", required=True, help="Comma-separated hosts that should hold a local copy.")
    lease_options(publish)
    publish.add_argument("--created-by", default=getpass.getuser(), help="Operator name recorded on the set (default: the current user).")
    publish.add_argument("--checkout", default=str(Path.cwd()), help="Git checkout snapshotted into the copy actions (default: the current directory).")
    publish.add_argument("--policy", default=str(Path(__file__).with_name("local_tier_policy.json")), help="local_tier_policy.json giving each host's local root, maximum GiB, floor fraction and docker allowance.")
    status = commands.add_parser("status")
    status.add_argument("set_id", nargs="?", help="Set id to show; omit to list every set.")
    release = commands.add_parser("release")
    release.add_argument("set_id", help="Set id whose lease to end.")
    release.add_argument("--by", default=getpass.getuser(), help="Operator name recorded on the release (default: the current user).")
    adoption = commands.add_parser("adopt")
    adoption.add_argument("set_id", help="Published set id to adopt a directory into.")
    adoption.add_argument("--host", required=True, help="Host whose local tier takes the directory; it must be declared and announce its local tier.")
    adoption.add_argument("--source", required=True, help="Existing directory to move into the tier; it must match the manifest, share the same filesystem as the tier, be outside the tier root, neither be nor contain the canonical directory, and not be bind-mounted.")
    adoption.add_argument("--checkout", default=str(Path.cwd()), help="Git checkout snapshotted into the adoption action (default: the current directory).")
    adoption.add_argument("--policy", default=str(Path(__file__).with_name("local_tier_policy.json")), help="local_tier_policy.json giving each host's local root, maximum GiB, floor fraction and docker allowance.")
    dispatch = commands.add_parser("dispatch", help="Resume publication of copy actions for an existing immutable set.")
    dispatch.add_argument("set_id", help="Previously published resident set id to dispatch without republishing its body.")
    dispatch.add_argument("--checkout", default=str(Path.cwd()),
                          help="Git checkout snapshotted into copy actions (default: the current directory).")
    dispatch.add_argument("--policy", default=str(Path(__file__).with_name("local_tier_policy.json")),
                          help="Local tier policy path carried to each owning host copy action.")
    renew = commands.add_parser("renew", help="Append an explicit policy-bounded lease renewal without changing the set body.")
    renew.add_argument("set_id", help="Published resident set id whose lease to renew.")
    lease_options(renew)
    renew.add_argument("--by", default=getpass.getuser(), help="Operator recorded on the renewal (default: the current user).")
    renew.add_argument("--policy", default=str(Path(__file__).with_name("local_tier_policy.json")),
                       help="Policy supplying renewal_ceiling_s; its default allows at most 14 days from renewal.")
    args = parser.parse_args(argv)
    store = resident_sets.ResidentSets(args.pool_root)
    try:
        if args.command == "publish":
            manifest, _ = manifest_codec.read_data_manifest(args.manifest)
            result = store.publish(manifest=manifest, canonical_root=args.canonical_root,
                hosts=args.hosts.split(","), lease=lease_from_args(args), created_by=args.created_by)
            result["movements"] = submit_copies(store, result["set_id"], policy_path=args.policy, checkout=args.checkout)
        elif args.command == "status":
            result = store.status(args.set_id)
        elif args.command == "adopt":
            result = submit_adoption(store, args.set_id, host=args.host, source=args.source, policy_path=args.policy, checkout=args.checkout)
        elif args.command == "dispatch":
            store.read(args.set_id)
            result = {"set_id": args.set_id, "movements": submit_copies(store, args.set_id,
                policy_path=args.policy, checkout=args.checkout)}
        elif args.command == "renew":
            policy = resident_sets.read_policy(args.policy)
            result = store.renew(args.set_id, lease_from_args(args), by=args.by,
                renewal_ceiling_s=policy["renewal_ceiling_s"])
        else:
            result = store.release(args.set_id, by=args.by)
    except (ValueError, OSError, core.ActionContractError, SubmissionRefused) as exc:
        print(f"pbresident: {exc}", file=sys.stderr)
        return 2
    print(core.sorted_json(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
