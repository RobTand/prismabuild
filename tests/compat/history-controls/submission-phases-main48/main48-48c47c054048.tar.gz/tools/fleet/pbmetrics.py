#!/usr/bin/env python3
"""Export the pull queue's read-only operational state as Prometheus text."""
from __future__ import annotations

import argparse
from collections import defaultdict
from collections.abc import Iterable, Mapping
from dataclasses import dataclass, field
import errno
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import json
import math
import os
from pathlib import Path
import re
import signal
import socket
import sys
import threading
import time

sys.path.insert(0, str(Path(__file__).resolve(strict=True).parent))
_PB_ENTRYPOINT = Path(__file__).resolve(strict=True)
sys.path.insert(0, str(_PB_ENTRYPOINT.parents[
    2 if _PB_ENTRYPOINT.parent.name == "fleet" else 1] / "src"))
from prismabuild.runtime_paths import generation_root  # noqa: E402

RUNTIME_ROOT = generation_root(__file__)
sys.path.insert(0, str(RUNTIME_ROOT / "src"))
from prismabuild import census as fleet_census, pool  # noqa: E402


DEFAULT_QUEUE_ROOT = fleet_census.DEFAULT_QUEUE_ROOT
DEFAULT_LISTEN = "127.0.0.1"
DEFAULT_PORT = 9469
DEFAULT_CACHE_SECONDS = 10.0
DEFAULT_TERMINAL_WINDOW_SECONDS = 3600.0
DEFAULT_TERMINAL_LIMIT = 500
SHUTDOWN_GRACE_S = 10.0
GIB = 1024 ** 3
#: How far ahead of this reader another box's clock may be before its sample
#: stops being credible. A telemetry record is stamped by the box executing the
#: action and read by whichever box runs the exporter, so their clocks are not
#: the same clock: dl380g10's runs milliseconds ahead of sparky's, and a record
#: written "in the future" was being rejected as unusable. Rejecting the
#: freshest record is the wrong way round -- and it fell hardest on the busiest
#: box, whose records are the ones most likely to be seconds old rather than
#: minutes. The bound is the sampler's own period rather than a new constant:
#: a stamp further ahead than one sampling interval is not skew, it is wrong.
_SKEW_S = pool.cpu_admission.MAX_SAMPLE_AGE_S
HOST = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]*\Z")
OUTCOMES = frozenset({
    "executed", "cache_hit", "failed", "timeout", "withdrawn", "reset",
    "finish_lost_race", "unreadable", "unknown",
})
#: What ``RecordStore.file_superseded`` names an unstarted-claim release: the action key,
#: the epoch second it was filed at, and the kind.  The timestamp is IN the
#: name, so the window can be applied without stat'ing a record the scan is
#: about to discard -- the same reason ``_ending_paths`` stats entries rather
#: than reading them.


RESOURCE_NAMES = {
    "cpu": ("cpu", 1),
    "gpu": ("gpu", 1),
    "mem_gb": ("memory_bytes", GIB),
    "gpu_mem_gb": ("gpu_memory_bytes", GIB),
    "gpu_memory_gb": ("gpu_memory_bytes", GIB),
}


def _host(value: object) -> str | None:
    text = str(value or "")
    return text if HOST.fullmatch(text) else None


def _labels(values: Mapping[str, str]) -> str:
    if not values:
        return ""
    def escape(value: str) -> str:
        return value.replace("\\", "\\\\").replace("\n", "\\n").replace('"', '\\"')
    return "{" + ",".join(
        f'{key}="{escape(str(value))}"' for key, value in sorted(values.items())
    ) + "}"


def _value(value: float) -> str:
    return str(int(value)) if value.is_integer() else format(value, ".15g")


@dataclass
class Family:
    name: str
    help: str
    samples: list[tuple[dict[str, str], float]] = field(default_factory=list)

    def add(self, value: object, **labels: str) -> None:
        number = fleet_census.nonnegative_number(value)
        if number is not None:
            self.samples.append((dict(labels), number))

    def render(self) -> list[str]:
        help_text = self.help.replace("\\", "\\\\").replace("\n", "\\n")
        lines = [f"# HELP {self.name} {help_text}", f"# TYPE {self.name} gauge"]
        lines.extend(
            f"{self.name}{_labels(labels)} {_value(value)}"
            for labels, value in sorted(
                self.samples, key=lambda sample: tuple(sorted(sample[0].items()))
            )
        )
        return lines


class Metrics:
    def __init__(self) -> None:
        self.families: dict[str, Family] = {}

    def family(self, name: str, help_text: str) -> Family:
        family = self.families.get(name)
        if family is None:
            family = self.families[name] = Family(name, help_text)
        return family

    def render(self) -> str:
        lines: list[str] = []
        for name in sorted(self.families):
            lines.extend(self.families[name].render())
        return "\n".join(lines) + "\n"


def _resource_samples(values: object) -> list[tuple[str, float]]:
    if not isinstance(values, Mapping):
        return []
    result: list[tuple[str, float]] = []
    for source, value in values.items():
        mapping = RESOURCE_NAMES.get(str(source))
        number = fleet_census.nonnegative_number(value)
        if mapping is not None and number is not None:
            result.append((mapping[0], number * mapping[1]))
    return result


@dataclass
class _HostAttempts:
    """What one host's live claims reported, including what they did not.

    The aggregate is deliberately all-or-nothing, but the counts beside it are
    not: a host whose aggregate is withheld still says how many live claims it
    has and how stale the oldest of them is, so "nothing running here" and
    "the claim that would have told you is the one that stopped reporting" stop
    rendering identically.
    """

    cpu: float = 0.0
    memory_bytes: float = 0.0
    jobs: int = 0
    unavailable: int = 0
    oldest_age_s: float | None = None
    #: ``(action_key, nonce) -> (cpu_seconds, wall_seconds)`` for the claims
    #: with complete, fresh, exact-scope samples, even if another claim makes
    #: the host aggregate unavailable.
    counters: dict[tuple[str, str], tuple[float, float]] = field(default_factory=dict)
    #: ``resource -> value`` for the host's live claims: the largest peak any
    #: one of them reported, and the bytes they have moved between them.
    #: Absent, not zero, for a resource none of them measured -- a sampler that
    #: could not read ``/proc`` and a claim that did no I/O must not read the
    #: same.
    peaks: dict[str, float] = field(default_factory=dict)

    @property
    def complete(self) -> bool:
        return self.jobs > 0 and self.unavailable == 0


def _attempt_telemetry(
    queue: pool.PoolQueue,
    live_jobs: Mapping[str, list[Mapping[str, object]]],
    now: float,
    reader: fleet_census.KeptReads | None = None,
) -> dict[str, _HostAttempts]:
    """Read each live claim's resource-scope telemetry, by claiming host.

    The aggregate a host publishes stays all-or-nothing: a partial sum reads as
    a low whole-host total, which is worse than no number. What changed is that
    withholding it is no longer silent. Every live claim is examined rather than
    abandoning the host at the first unusable record, and the count that could
    not be used is reported beside the count that could.

    That distinction is the whole point. A claim blocked on the shared mount
    keeps its lease -- the loop is alive and heartbeating -- while the sampler
    that writes its telemetry does not run, so its record goes stale. Under the
    old early exit that claim erased its host from the observation entirely, and
    the box in the most trouble was the box that reported nothing. The signal
    was strongest exactly where it was being deleted.

    Raw counters come back too, per claim, because the ratio the aggregate
    carries is a lifetime average: a job that ran hot for fifty minutes and has
    been blocked for ten still averages high. Differencing consecutive readings
    is what tells those apart, and that is done by the caller, which is the only
    party that has a previous reading.
    """
    reader = fleet_census._fresh(reader)
    answer: dict[str, _HostAttempts] = {}
    for host, jobs in live_jobs.items():
        host_attempts = _HostAttempts(jobs=len(jobs))
        for job in jobs:
            key = str(job.get("action_key") or "")
            claim = fleet_census.claim_observation(queue, key, reader)
            scope = claim.get("resource_scope") if isinstance(claim, dict) else None
            nonce = scope.get("nonce") if isinstance(scope, dict) else None
            record = reader.sidecar(
                queue.root / pool.RESERVATIONS / host / "telemetry" / f"{key}.json")
            record = None if isinstance(record, Exception) else record
            sampled = fleet_census.nonnegative_number(record.get("sampled_unix")) if isinstance(record, dict) else None
            cpu_seconds = fleet_census.nonnegative_number(record.get("cpu_seconds")) if isinstance(record, dict) else None
            wall_seconds = fleet_census.nonnegative_number(record.get("wall_seconds")) if isinstance(record, dict) else None
            current = fleet_census.nonnegative_number(record.get("memory_current_bytes")) if isinstance(record, dict) else None
            # Age is reported for any record whose timestamp is credible, even
            # one too old for the aggregate -- that is precisely the reading a
            # reader wants when the aggregate is missing.
            if sampled is not None and now - sampled >= -_SKEW_S:
                # Floored at zero: a stamp from a clock a few milliseconds ahead
                # is as new as this reader can tell, and a negative age is not a
                # reading anyone can act on. The tolerance above is what decides
                # whether the sample counts; this only decides how it reads.
                age = max(0.0, now - sampled)
                if (host_attempts.oldest_age_s is None
                        or age > host_attempts.oldest_age_s):
                    host_attempts.oldest_age_s = age
            matched = (isinstance(record, dict) and record.get("action_key") == key
                       and bool(nonce) and record.get("nonce") == nonce)
            if (not isinstance(record, dict) or record.get("complete") is not True
                    or not matched or sampled is None
                    or not -_SKEW_S <= now - sampled <= pool.cpu_admission.MAX_SAMPLE_AGE_S
                    or cpu_seconds is None or wall_seconds is None or wall_seconds <= 0
                    or current is None):
                host_attempts.unavailable += 1
                continue
            host_attempts.counters[(key, str(nonce))] = (cpu_seconds, wall_seconds)
            host_attempts.cpu += cpu_seconds / wall_seconds
            host_attempts.memory_bytes += current
            peak = fleet_census.nonnegative_number(record.get("memory_peak_bytes"))
            if peak is not None:
                host_attempts.peaks["memory_peak_bytes"] = max(
                    host_attempts.peaks.get("memory_peak_bytes", peak), peak)
            measured_io = record.get("process_io")
            if isinstance(measured_io, Mapping):
                for source, name in (("read_bytes", "io_read_bytes"),
                                     ("write_bytes", "io_write_bytes")):
                    moved = fleet_census.nonnegative_number(measured_io.get(source))
                    if moved is not None:
                        host_attempts.peaks[name] = (
                            host_attempts.peaks.get(name, 0.0) + moved)
        answer[host] = host_attempts
    return answer


def _recent_cores(
    observations: Mapping[str, _HostAttempts],
    previous: dict[tuple[str, str], tuple[float, float]] | None,
) -> dict[str, tuple[float, int]]:
    """Cores used since the previous reading of the same claim, by host.

    The exporter carries no counter of its own, by design -- one would reset on
    every restart and lie about a rate. This is not that: the counters belong to
    the attempt's cgroup and are differenced only against a previous reading of
    *that same attempt*, identified by action key and scope nonce together, so a
    key reused by a later attempt cannot be differenced against an earlier one.

    The first refresh after a start has nothing to difference and reports
    nothing, which is the honest answer to "what has been happening" when the
    answer is "I have seen one moment". ``previous`` is replaced in place with
    the current reading, and only for claims that are live now, so it cannot
    grow with the queue's history.
    """
    answer: dict[str, tuple[float, int]] = {}
    if previous is None:
        return answer
    current: dict[tuple[str, str], tuple[float, float]] = {}
    for host, host_attempts in observations.items():
        cores = 0.0
        covered = 0
        for identity, (cpu_seconds, wall_seconds) in host_attempts.counters.items():
            current[identity] = (cpu_seconds, wall_seconds)
            before = previous.get(identity)
            if before is None:
                continue
            cpu_delta = cpu_seconds - before[0]
            wall_delta = wall_seconds - before[1]
            # A counter that went backwards is not this attempt's; a wall that
            # did not advance gives no rate. Neither is an error worth a false
            # zero, so the claim simply is not covered this refresh.
            if wall_delta <= 0 or cpu_delta < 0:
                continue
            cores += cpu_delta / wall_delta
            covered += 1
        if covered:
            answer[host] = (cores, covered)
    previous.clear()
    previous.update(current)
    return answer


def _terminal_metrics(
    metrics: Metrics,
    queue_root: Path,
    *,
    now: float,
    window_seconds: float,
    limit: int,
    reader: fleet_census.KeptReads | None = None,
) -> bool:
    reader = fleet_census._fresh(reader)
    # A state directory that is not there, or is not a directory, makes the
    # window unproven.  The plain reader listed each one to find out; its
    # version answers the same question for one ``lstat``, and a directory
    # that exists but cannot be listed still fails the read below.
    accessible = all(reader.available(Path(queue_root) / state)
                     for state in (pool.record_store.DONE, pool.record_store.FAILED, pool.record_store.WITHDRAWN))
    endings = fleet_census.endings(queue_root, limit=limit, reader=reader)
    selected = [
        row for row in endings
        if (age := fleet_census.nonnegative_number(now - float(row.get("finished_unix", -math.inf)))) is not None
        and age <= window_seconds
    ]
    complete = (
        accessible
        and len(endings) < limit
        and all(not row.get("unreadable") for row in selected)
    )
    metrics.family(
        "prismabuild_terminal_outcomes_window_seconds",
        "Configured lookback window for recent terminal outcome gauges.",
    ).add(window_seconds)
    metrics.family(
        "prismabuild_terminal_outcomes_window_jobs",
        "Terminal records included in the current bounded lookback window.",
    ).add(len(selected))
    metrics.family(
        "prismabuild_terminal_outcomes_window_complete",
        "Whether the terminal record scan proved the configured window was not truncated by its record limit.",
    ).add(1 if complete else 0)
    terminal_success = metrics.family(
        "prismabuild_terminal_collection_success",
        "Whether terminal directories and every selected terminal record were readable for this snapshot.",
    )

    outcomes: dict[tuple[str, str], int] = defaultdict(int)
    timings: dict[tuple[str, str], list[float]] = defaultdict(list)
    for row in selected:
        host = _host(row.get("host")) or "unknown"
        outcome = str(row.get("status") or "unknown")
        outcome = outcome if outcome in OUTCOMES else "unknown"
        outcomes[(host, outcome)] += 1
        if row.get("unreadable"):
            continue
        # ``read_endings`` already projected these fields from its bounded
        # read. Opening the complete record again doubled both NFS traffic and
        # the allocation spike from rows that embedded action logs.
        published = fleet_census.nonnegative_number(row.get("published_unix"))
        claimed = fleet_census.nonnegative_number(row.get("claimed_unix"))
        finished = fleet_census.nonnegative_number(row.get("timing_finished_unix"))
        if published is not None and claimed is not None and claimed >= published:
            timings[(host, "queue_wait")].append(claimed - published)
        if claimed is not None and finished is not None and finished >= claimed:
            timings[(host, "execution")].append(finished - claimed)

    outcomes_family = metrics.family(
        "prismabuild_terminal_outcomes",
        "Terminal outcomes observed in the bounded recent window; this is a restart-safe gauge, not a counter.",
    )
    for (host, outcome), count in outcomes.items():
        outcomes_family.add(count, host=host, outcome=outcome)

    queue_timing = metrics.family(
        "prismabuild_queue_wait_seconds",
        "Mean or maximum publish-to-claim time among terminal records with usable timestamps in the bounded window.",
    )
    execution_timing = metrics.family(
        "prismabuild_execution_seconds",
        "Mean or maximum claim-to-finish time among terminal records with usable timestamps in the bounded window.",
    )
    timing_jobs = metrics.family(
        "prismabuild_terminal_timing_window_jobs",
        "Terminal records contributing to each timing gauge in the bounded window.",
    )
    for (host, phase), values in timings.items():
        target = queue_timing if phase == "queue_wait" else execution_timing
        target.add(sum(values) / len(values), host=host, stat="mean")
        target.add(max(values), host=host, stat="max")
        timing_jobs.add(len(values), host=host, phase=phase)
    _box_window_peaks(metrics, selected)

    readable = accessible and all(not row.get("unreadable") for row in selected)
    terminal_success.add(1 if readable else 0)
    return readable


#: The GPU metrics that are a reading *against a reference*, and so have to be
#: separated by the scope of the reference they were taken against.  Watts and
#: bytes are absolute and compare across any reference; a fraction and the
#: denominator it used do not (#806).
_SCOPED_BOX_WINDOW_METRICS = frozenset((
    "gpu_power_peak_watts", "gpu_power_reference_watts", "gpu_power_peak_fraction",
))


def _box_window_peaks(metrics: Metrics, rows: Iterable[Mapping[str, object]]) -> None:
    """Publish the heaviest box-window reading each host reported, by scope.

    Absent rather than zero for a host whose endings carried no box window,
    which is how a box with no flight recorder differs from a box that idled.

    ``scope`` is the reference the GPU power readings were taken against:
    ``measured_peak`` and ``declared_fallback`` are GPU-only, ``soc_tdp`` is
    the whole-module envelope, and ``unknown`` is a record filed before the
    reference was scoped at all.  It is a label and not a suffix because the
    alternative is a ``max`` over two denominators, which is a number taken
    against neither.  Readings with no reference carry an empty scope, which
    Prometheus reads as no label, so the family keeps one label set.
    """

    peaks: dict[tuple[str, str, str], float] = {}
    for row in rows:
        if row.get("unreadable"):
            continue
        host = _host(row.get("host")) or "unknown"
        scope = row.get("gpu_power_reference_scope")
        scope = scope if isinstance(scope, str) and scope else "unknown"
        for field, metric in (
            ("gpu_power_peak_w", "gpu_power_peak_watts"),
            ("gpu_power_reference_w", "gpu_power_reference_watts"),
            ("gpu_power_peak_fraction", "gpu_power_peak_fraction"),
            ("gpu_framebuffer_used_peak_bytes", "gpu_framebuffer_used_peak_bytes"),
            ("gpu_framebuffer_total_bytes", "gpu_framebuffer_total_bytes"),
            ("memory_peak_bytes", "memory_peak_bytes"),
            ("io_write_bytes", "io_write_bytes"),
            ("io_read_bytes", "io_read_bytes"),
        ):
            value = fleet_census.nonnegative_number(row.get(field))
            if value is None:
                continue
            key = (host, metric, scope if metric in _SCOPED_BOX_WINDOW_METRICS else "")
            peaks[key] = max(peaks.get(key, value), value)
    box = metrics.family(
        "prismabuild_terminal_box_window",
        "Heaviest per-action resource reading among the host's terminal records in the bounded window; GPU power is measured against the GPU-only reference named by the scope label, and every metric is absent rather than zero where no record carried it.",
    )
    for (host, metric, scope), value in sorted(peaks.items()):
        box.add(value, host=host, metric=metric, scope=scope)


def _release_metrics(
    metrics: Metrics,
    queue_root: Path,
    *,
    now: float,
    window_seconds: float,
    limit: int,
    reader: fleet_census.KeptReads | None = None,
) -> bool:
    """Count the unstarted-claim releases each box produced in the window.

    Issue #263.  ``reap_stale`` releases a claim whose lease never appeared
    and whose attempt was never published: the action returns to ``ready``
    unrunnable-through-no-fault-of-its-own, uncharged, and counted.  A rising
    release rate on ONE box is the signal, because the window it comes out of
    -- between the claim rename and the first lease write -- is filesystem
    latency on that box, measured at 45 s against a 30 s grace (issue #222).

    The box is not on the requeued item.  ``_shape_as_ready_item`` pops every
    claim-scoped field, ``claimed_host`` included, so by the time the counter
    is readable in ``ready`` the record no longer says who was holding it.
    The filing under ``withdrawn/superseded/`` does: ``RecordStore.file_superseded`` is
    called with the claimed record, before the pops.  So the per-box series is
    read there and the queue-wide one from the fleet_census.

    Bounded exactly as ``_terminal_metrics`` is, and for the same reason: this
    directory keeps every release this fleet has ever filed, and a scrape that
    reads all of them to report a handful is the slow path.  ``complete`` says
    whether the window was proved rather than truncated.
    """

    reader = fleet_census._fresh(reader)
    directory = Path(queue_root) / pool.record_store.WITHDRAWN / "superseded"
    selected: list[tuple[float, str]] = []
    readable = True
    try:
        # Names only: the filing time is in the name, so the window is
        # applied to a listing kept between scrapes, with nothing stat-ed.
        filings = reader.released_claim_filings(queue_root)
    except OSError:
        filings = []
        readable = False
    for when, path in filings:
        age = now - when
        if -_SKEW_S <= age <= window_seconds:
            selected.append((when, path))
    selected.sort(reverse=True)
    complete = readable and len(selected) <= limit

    counts: dict[str, int] = defaultdict(int)
    for _, path in selected[:limit]:
        record = reader.sidecar(Path(path))
        if isinstance(record, Exception):
            record = None
        if not isinstance(record, dict):
            readable = False
            continue
        owner = str(record.get("claimed_by") or "").split(":", 1)[0]
        counts[_host(record.get("claimed_host")) or _host(owner) or "unknown"] += 1

    events = metrics.family(
        "prismabuild_unstarted_release_events",
        "Claims released without an attempt in the bounded recent window, by the box that held the claim; this is a restart-safe gauge, not a counter.",
    )
    for host, count in counts.items():
        events.add(count, host=host)
    metrics.family(
        "prismabuild_unstarted_release_events_complete",
        "Whether the unstarted-release scan proved the configured window was not truncated by its record limit and every selected filing was readable.",
    ).add(1 if complete and readable else 0)
    return readable


def _starvation_metrics(
    metrics: Metrics,
    queue_root: Path,
    *,
    now: float,
    window_seconds: float,
    reader: fleet_census.KeptReads | None = None, census_reader=None) -> bool:
    """Fleet starvation gauges: tier fill, denials, mover depth (issue #661).

    Read-only derivation from records the fleet already files, following this
    module's conventions: restart-safe gauges (never counters), absent rather
    than zero where nothing was measured, no action-key labels, and a partial
    snapshot that reports its failure rather than dropping the scrape.
    """

    try:
        tier_facts = fleet_census.tiers(queue_root, view="tokens", now=now, reader=reader)
    except Exception:
        return False
    ok = tier_facts.completeness == "complete"
    announced = tier_facts.value["announced"]
    fill = metrics.family(
        "prismabuild_tier_fill_supply_mb_s",
        "Learned pool-side fill bandwidth per tier from the tier loop's latest announcement; "
        "best is the highest delivery since the last ceiling, ceiling the most recent measured "
        "shortfall, and probe_offer the live selected offer over a standing ceiling -- the "
        "larger of the fold's ceiling-plus-median reader and the ceiling plus the oldest ready "
        "mover's sealed demand. Absent, not zero, where the tier announced none.",
    )
    tokens = metrics.family(
        "prismabuild_tier_tokens",
        "Tier ledger tokens by kind and state; capacity kinds count GiB, the fill kind counts "
        "pool-side MB/s, and held is capacity less available.",
    )
    announce_age = metrics.family(
        "prismabuild_tier_announce_age_seconds",
        "Seconds since the tier loop last announced this tier (announced_unix). A live loop, "
        "idle or mid-cycle, keeps it below pool.OFFER_TIMEOUT_S; a loop stuck inside a cycle "
        "stops writing and it grows past that (#1115). Absent where no record was announced.",
    )
    for tier_id, record in announced.items():
        if isinstance(record, Mapping):
            stamped = fleet_census.nonnegative_number(record.get("announced_unix"))
            if stamped is not None:
                announce_age.add(max(0.0, now - stamped), tier=tier_id)
        supply = record.get("fill_supply") if isinstance(record, Mapping) else None
        if isinstance(supply, Mapping):
            fill.add(supply.get("best_mb_s"), tier=tier_id, stat="best")
            fill.add(supply.get("ceiling_mb_s"), tier=tier_id, stat="ceiling")
            fill.add(supply.get("probe_offer_mb_s"), tier=tier_id, stat="probe_offer")
    for tier_id, kind, total, free, held in tier_facts.value["tokens"]:
        tokens.add(total, tier=tier_id, resource=kind, state="capacity")
        tokens.add(free, tier=tier_id, resource=kind, state="available")
        tokens.add(held, tier=tier_id, resource=kind, state="held")

    # -- per-host denial counts by reason, windowed ------------------------
    denial_facts = fleet_census.denials(queue_root, profile="metrics", now=now,
                                         window_seconds=window_seconds, reader=census_reader)
    ok = denial_facts.completeness == "complete" and ok
    counts = denial_facts.value
    metrics.family(
        "prismabuild_claim_denial_window_seconds",
        "Configured lookback window for the per-host claim-denial gauges.",
    ).add(window_seconds)
    denials_family = metrics.family(
        "prismabuild_claim_denials",
        "Latest claim denial per action generation observed in the window, by host and reason; "
        "this is a restart-safe gauge, not a counter.",
    )
    for (host, reason), count in counts.items():
        denials_family.add(count, host=host, reason=reason)

    # -- mover queue depth --------------------------------------------------
    # An active action with movement-node shape: its residency block names a
    # byte range to stage, where a consumer's names leads.  The same range
    # test ``movers_claimed_on_tier`` stages on, counted here rather than
    # joined there so the depth needs no tier argument.
    depth = metrics.family(
        "prismabuild_mover_queue_depth",
        "Active actions with movement-node shape (a residency range to stage), by queue state.",
    )
    mover_facts = fleet_census.movers(queue_root, view="counts", reader=reader)
    for state, count in mover_facts.value.items():
        depth.add(count, state=state)
    ok = mover_facts.completeness == "complete" and ok
    return ok


_UNKNOWN_TIER = "unknown"


def _promotion_metrics(metrics: Metrics, queue_root: Path, *, now: float,
                       window_seconds: float, reader: fleet_census.KeptReads | None = None,
                       census_reader=None) -> bool:
    facts = fleet_census.promotion(queue_root, now=now, window_seconds=window_seconds,
                                   reader=reader, census_reader=census_reader)
    if facts.value is None:
        return False
    ok = facts.completeness == "complete"
    tier_depth = metrics.family(
        "prismabuild_mover_queue_depth_tier",
        "Active actions with movement-node shape (a residency range to stage), "
        "by tier and queue state. Known tiers always read, zero included; the "
        "single unknown tier reads only when a record names no usable tier.",
    )
    for (tier_id, state), count in sorted(facts.value["depth"].items()):
        tier_depth.add(count, tier=tier_id, state=state)
    waiting_family = metrics.family(
        "prismabuild_starvation_waiting_consumers",
        "Claimed consumers the quiet/grace rule reads as waiting on data, by "
        "the tier their frozen plan names. Known tiers always read, zero "
        "included; the unknown tier counts waiters with no readable plan.",
    )
    for tier_id, count in sorted(facts.value["waiting"].items()):
        waiting_family.add(count, tier=tier_id)
    quiet_family = metrics.family(
        "prismabuild_starvation_waiting_quiet_max_seconds",
        "Longest progress quiet among the tier's waiting consumers; absent, "
        "not zero, where none is waiting.",
    )
    for tier_id, value in sorted(facts.value["quiet_max"].items()):
        quiet_family.add(value, tier=tier_id)
    plans_family = metrics.family(
        "prismabuild_residency_plans",
        "Filed residency plans by tier and consumer queue state; the invalid "
        "state counts unreadable or rejected plans under the unknown tier.",
    )
    for (tier_id, state), count in sorted(facts.value["plans"].items()):
        plans_family.add(count, tier=tier_id, state=state)
    if facts.value["invalid_plans"]:
        plans_family.add(facts.value["invalid_plans"], tier=_UNKNOWN_TIER, state="invalid")
    staged_family = metrics.family(
        "prismabuild_residency_staged_phases",
        "Plan phases at or behind the read cursor the tier ledger says are "
        "staged, by tier and leg: the promoted frontier behind the cursor.",
    )
    unstaged_family = metrics.family(
        "prismabuild_residency_unstaged_phases",
        "Plan phases at or ahead of the read cursor the tier ledger does not "
        "say are staged, by tier and leg: the promotion backlog.",
    )
    backlog_family = metrics.family(
        "prismabuild_residency_unstaged_bytes",
        "Bytes in the promotion backlog, by tier and leg.",
    )
    for (tier_id, leg), value in sorted(facts.value["staged_phases"].items()):
        staged_family.add(value, tier=tier_id, leg=leg)
    for (tier_id, leg), value in sorted(facts.value["unstaged_phases"].items()):
        unstaged_family.add(value, tier=tier_id, leg=leg)
    for (tier_id, leg), value in sorted(facts.value["unstaged_bytes"].items()):
        backlog_family.add(value, tier=tier_id, leg=leg)
    metrics.family(
        "prismabuild_tier_move_window_seconds",
        "Configured lookback window for the per-tier movement receipt gauges.",
    ).add(window_seconds)
    metrics.family(
        "prismabuild_tier_move_window_complete",
        "Whether the mover-receipt scan proved the window was not truncated "
        "by its file cap and every selected receipt was readable.",
    ).add(1 if facts.value["move_complete"] and ok else 0)
    move_jobs_family = metrics.family(
        "prismabuild_tier_move_jobs",
        "Movement receipts filed in the window, by tier; a restart-safe "
        "gauge, not a counter.",
    )
    for tier_id, count in sorted(facts.value["move_jobs"].items()):
        move_jobs_family.add(count, tier=tier_id)
    measured_family = metrics.family(
        "prismabuild_tier_move_measured_jobs",
        "In-window receipts whose window read the staged bytes off the pool, "
        "by tier, under the fill fold's own share test; the remainder is "
        "adoption served resident. Jobs beside measured is the hit rate.",
    )
    for tier_id, count in sorted(facts.value["measured_jobs"].items()):
        measured_family.add(count, tier=tier_id)
    staged_bytes_family = metrics.family(
        "prismabuild_tier_move_staged_bytes",
        "Bytes movers reported staging in the window, by tier, over receipts "
        "carrying both byte counters; absent, not zero, where none did.",
    )
    for tier_id, value in sorted(facts.value["move_staged"].items()):
        staged_bytes_family.add(value, tier=tier_id)
    pool_read_family = metrics.family(
        "prismabuild_tier_move_pool_read_bytes",
        "Pool sector reads during movers' windows in the window, by tier, "
        "over the same receipts as the staged sum. It counts every pool "
        "reader, not one copy's bytes, so it can exceed the staged sum; "
        "read it beside measured jobs, never as a ratio's denominator.",
    )
    for tier_id, value in sorted(facts.value["move_pool_read"].items()):
        pool_read_family.add(value, tier=tier_id)
    rate_family = metrics.family(
        "prismabuild_tier_move_pool_rate_mb_s",
        "Pool-side delivery the tier's movers demonstrated in the window, by "
        "tier: best is the highest pool delivery any receipt measured, mean "
        "the average over receipts. Absent, not zero, with no measured rate.",
    )
    rate_jobs_family = metrics.family(
        "prismabuild_tier_move_rate_jobs",
        "Receipts contributing to the tier's pool-rate gauge in the window.",
    )
    for tier_id, rates in sorted(facts.value["move_rates"].items()):
        rate_family.add(max(rates), tier=tier_id, stat="best")
        rate_family.add(sum(rates) / len(rates), tier=tier_id, stat="mean")
        rate_jobs_family.add(len(rates), tier=tier_id)
    return ok


def collect_metrics(
    queue_root: str | Path = DEFAULT_QUEUE_ROOT,
    *,
    now: float | None = None,
    terminal_window_seconds: float = DEFAULT_TERMINAL_WINDOW_SECONDS,
    terminal_limit: int = DEFAULT_TERMINAL_LIMIT,
    previous: dict[tuple[str, str], tuple[float, float]] | None = None,
    reader: fleet_census.KeptReads | None = None,
) -> str:
    """Collect one non-atomic, read-only snapshot in Prometheus text format.

    ``reader`` is what the caller keeps between scrapes (``MetricsCache``
    holds one); omitted, every record is read afresh, as ``--once`` wants.
    The text is the same either way: a kept read is reused only while the
    directory it came from provably has not changed.

    ``previous`` is the caller's store of the last refresh's per-attempt
    counters, replaced in place. Passing it opts into the recent-cores rate;
    omitting it -- which ``--once`` does, having only one moment to report --
    simply leaves that family out. The store belongs to the caller rather than
    to this module so that two collectors cannot silently difference against
    each other's readings.
    """
    started = time.monotonic()
    reader = fleet_census.KeptReads() if reader is None else reader
    reader.begin()
    try:
        return _collect(queue_root, now=now,
                        terminal_window_seconds=terminal_window_seconds,
                        terminal_limit=terminal_limit, previous=previous,
                        reader=reader, started=started)
    finally:
        reader.end()


def _collect(
    queue_root: str | Path,
    *,
    now: float | None,
    terminal_window_seconds: float,
    terminal_limit: int,
    previous: dict[tuple[str, str], tuple[float, float]] | None,
    reader: fleet_census.KeptReads,
    started: float,
) -> str:
    sampled = time.time() if now is None else float(now)
    root = Path(queue_root).absolute()
    metrics = Metrics()
    success = True
    try:
        census = fleet_census.action_rows(root, reader=reader).value
    except Exception:  # A scrape reports the failure rather than dropping HTTP.
        census = {"nodes": [], "jobs": [], "queue": {"ready": None, "claimed": None}}
        success = False
    # The census lists ``workers/`` already; this only asks that it be there.
    if not reader.available(root / pool.record_store.WORKERS):
        success = False

    queue_summary = census.get("queue", {})
    queue_items = metrics.family(
        "prismabuild_queue_items", "Readable pull-queue records by active state.")
    oldest = metrics.family(
        "prismabuild_queue_oldest_age_seconds",
        "Age of the oldest readable record in each active queue state; zero means that readable state is empty.",
    )
    jobs = census.get("jobs", []) if isinstance(census.get("jobs"), list) else []
    releases = metrics.family(
        "prismabuild_queue_unstarted_releases",
        "Releases without an attempt carried by readable records now in each active queue state; this counts what the queue is still holding, not what happened in a window.",
    )
    for state in ("ready", "claimed"):
        count = queue_summary.get(state) if isinstance(queue_summary, Mapping) else None
        if fleet_census.nonnegative_number(count) is None:
            success = False
            continue
        queue_items.add(count, state=state)
        state_jobs = [row for row in jobs if row.get("state") == state.upper()]
        releases.add(sum(int(row.get("unstarted_releases") or 0) for row in state_jobs),
                     state=state)
        if not state_jobs:
            oldest.add(0, state=state)
        else:
            ages = [fleet_census.nonnegative_number(row.get("age_s")) for row in state_jobs]
            if all(age is not None for age in ages):
                oldest.add(max(ages), state=state)
            else:
                success = False

    worker_up = metrics.family(
        "prismabuild_worker_up",
        "Whether a syntactically valid worker offer is fresh enough for pool placement.",
    )
    worker_retired = metrics.family(
        "prismabuild_worker_retired",
        "Whether a valid worker offer has gone unrefreshed long enough that its box "
        "is treated as retired; the offer file is kept (#1040).",
    )
    offer_age = metrics.family(
        "prismabuild_worker_offer_age_seconds", "Age of a valid worker's last offer.")
    capacity = metrics.family(
        "prismabuild_worker_capacity",
        "Configured fresh-worker capacity; cpu is cores, gpu is devices, and memory resources are bytes.",
    )
    observed_capacity = metrics.family(
        "prismabuild_worker_observed_capacity",
        "Windowed fresh-worker capacity after foreign work; units follow worker capacity.",
    )
    memory_domain = metrics.family(
        "prismabuild_worker_memory_domain_info",
        "Fresh worker GPU memory domains; value is always one.",
    )
    memory_available = metrics.family(
        "prismabuild_worker_memory_available_bytes",
        "Coarse available host memory from the fresh worker offer, converted from integer GiB.",
    )
    loops = metrics.family(
        "prismabuild_worker_loops",
        "PrismaBuild worker loops running on the box that wrote this fresh offer; "
        "absent, not zero, when the offer did not measure it.",
    )
    evidence_age = metrics.family(
        "prismabuild_admission_evidence_age_seconds",
        "Age of the last persisted admission evidence; this is not continuous hardware monitoring.",
    )
    plateau = metrics.family(
        "prismabuild_admission_plateau",
        "Whether the last persisted GPU admission decision recorded a power-response plateau; this is not live hardware state.",
    )

    valid_hosts: set[str] = set()
    fresh_hosts: set[str] = set()
    resource_dimensions: dict[str, set[str]] = defaultdict(set)
    for node in census.get("nodes", []):
        host = _host(node.get("node"))
        state = node.get("state")
        if host is None or state not in {"live", "draining", "stale", "retired"}:
            success = False
            continue
        valid_hosts.add(host)
        # A draining offer is fresh evidence with a named state, not a scrape
        # failure (#1204).  ``worker_up`` keeps its existing meaning -- a
        # syntactically valid, fresh offer -- so a drain still reads up and is
        # not confused with a stopped loop, whose offer is stale and reads 0.
        # The state itself is exposed by pbstatus' node table; the offer's
        # configured capacity and its zero observed capacity are exported
        # exactly as written.
        fresh = state in {"live", "draining"}
        worker_up.add(1 if fresh else 0, host=host)
        worker_retired.add(1 if state == "retired" else 0, host=host)
        age = fleet_census.nonnegative_number(node.get("age_s"))
        if age is not None:
            offer_age.add(age, host=host)
        else:
            success = False
        if fresh:
            fresh_hosts.add(host)
            for resource, value in _resource_samples(node.get("capacity")):
                capacity.add(value, host=host, resource=resource)
                resource_dimensions[host].add(resource)
            for resource, value in _resource_samples(node.get("observed_capacity")):
                observed_capacity.add(value, host=host, resource=resource)
            detail = node.get("observed_detail")
            if isinstance(detail, Mapping):
                domains = detail.get("gpu_memory_domains")
                if isinstance(domains, list):
                    normalized = {
                        domain if isinstance(domain, str) and domain in {
                            "shared_system", "discrete", "unknown"
                        } else "unknown"
                        for domain in domains
                    }
                    for domain in sorted(normalized):
                        memory_domain.add(1, host=host, domain=domain)
                available_gib = fleet_census.nonnegative_number(detail.get("mem_available_gb"))
                if available_gib is not None:
                    memory_available.add(available_gib * GIB, host=host)
            # A pre-#254 offer carries no count.  That is a missing series and
            # not a zero one, and it is emphatically not a scrape failure:
            # every loop published before the field existed announces without
            # it, so setting ``success = False`` here would mark the whole
            # scrape bad for the duration of a rolling generation change.
            count = node.get("loops")
            if isinstance(count, int) and not isinstance(count, bool) and count >= 0:
                loops.add(count, host=host)
        admission = node.get("admission")
        if isinstance(admission, Mapping):
            for resource in ("cpu", "gpu"):
                sample = admission.get(resource)
                if not isinstance(sample, Mapping) or sample.get("state") == "not applicable":
                    continue
                age = fleet_census.nonnegative_number(sample.get("age_s"))
                if age is not None:
                    evidence_age.add(age, host=host, resource=resource)
                record = sample.get("record")
                if resource == "gpu" and isinstance(record, Mapping):
                    feedback = record.get("power_feedback")
                    is_plateau = isinstance(feedback, Mapping) and feedback.get("status") == "plateau"
                    plateau.add(1 if is_plateau else 0, host=host, resource="gpu")

    claimed_known = fleet_census.nonnegative_number(queue_summary.get("claimed")) is not None
    active = metrics.family(
        "prismabuild_active_jobs",
        "Claims with fresh leases by host and mutually exclusive cpu or gpu job kind.",
    )
    reserved = metrics.family(
        "prismabuild_reserved_resources",
        "Declared resources in valid claimed queue records; units follow worker capacity.",
    )
    active_by_host: dict[str, dict[str, int]] = defaultdict(lambda: {"cpu": 0, "gpu": 0})
    reserved_by_host: dict[str, dict[str, float]] = defaultdict(lambda: defaultdict(float))
    live_jobs: dict[str, list[Mapping[str, object]]] = defaultdict(list)
    unknown_active_hosts: set[str] = set()
    if claimed_known:
        for job in jobs:
            if job.get("state") != "CLAIMED":
                continue
            host = _host(job.get("node"))
            if host is None:
                success = False
                continue
            valid_hosts.add(host)
            for resource, value in _resource_samples(job.get("resources")):
                reserved_by_host[host][resource] += value
            if job.get("stale") is False:
                kind = "gpu" if dict(job.get("resources") or {}).get("gpu", 0) else "cpu"
                active_by_host[host][kind] += 1
                live_jobs[host].append(job)
            else:
                unknown_active_hosts.add(host)
        reported_hosts = fresh_hosts | set(active_by_host) | set(reserved_by_host)
        for host in sorted(reported_hosts):
            dimensions = resource_dimensions[host] | set(reserved_by_host[host])
            for resource in sorted(dimensions):
                reserved.add(reserved_by_host[host].get(resource, 0),
                             host=host, resource=resource)
            if host not in unknown_active_hosts:
                for kind in ("cpu", "gpu"):
                    active.add(active_by_host[host][kind], host=host, kind=kind)

    # A claim retained because its cleanup could not be proved is retried by a
    # local reaper forever, deliberately: concluding it would release tokens
    # for a payload nobody showed had stopped.  What that costs is a claim
    # nobody is looking at, so the retry loop has to be able to raise its hand
    # (#288).  Two aggregate series, not one per action: an alert asks "is
    # anything stuck and for how long", and an action key is unbounded
    # cardinality.
    pinned = metrics.family(
        "prismabuild_cleanup_pending_claims",
        "Claims on the host retained because their payload could not be proved stopped; the reservation is still held.",
    )
    pinned_age = metrics.family(
        "prismabuild_cleanup_pending_oldest_seconds",
        "Age of the oldest unproven cleanup on the host, from its first failure; absent when nothing is pending.",
    )
    if claimed_known:
        pinned_by_host: dict[str, int] = defaultdict(int)
        oldest_by_host: dict[str, float] = {}
        for job in jobs:
            if job.get("state") != "CLAIMED" or not job.get("cleanup_pending"):
                continue
            host = _host(job.get("node"))
            if host is None:
                continue
            pinned_by_host[host] += 1
            age = fleet_census.nonnegative_number(job.get("cleanup_pending_s"))
            # A record written before #288 carries no first-failure stamp.
            # That is a missing series, never a zero one: reporting 0 would
            # say "just started" about a cleanup that may have been pending
            # for hours.
            if age is not None:
                oldest_by_host[host] = max(oldest_by_host.get(host, age), age)
        for host in sorted(fresh_hosts | set(pinned_by_host)):
            pinned.add(pinned_by_host.get(host, 0), host=host)
            if host in oldest_by_host:
                pinned_age.add(oldest_by_host[host], host=host)

    observations = _attempt_telemetry(pool.PoolQueue(root), live_jobs, sampled,
                                      reader=reader)
    observed = metrics.family(
        "prismabuild_attempt_observed_resources",
        "Aggregate complete fresh exact-scope observations for every live claim on a host; cpu is lifetime-average cores and memory is current bytes.",
    )
    observed_jobs = metrics.family(
        "prismabuild_attempt_telemetry_jobs",
        "Live claims represented in the host's complete aggregate attempt telemetry.",
    )
    unavailable_jobs = metrics.family(
        "prismabuild_attempt_telemetry_unavailable_jobs",
        "Live claims on the host whose resource-scope telemetry could not be used; the aggregate is withheld whenever this is above zero.",
    )
    telemetry_age = metrics.family(
        "prismabuild_attempt_telemetry_age_seconds",
        "Age of the oldest credible resource-scope sample among the host's live claims; reported even when the aggregate is withheld.",
    )
    recent = metrics.family(
        "prismabuild_attempt_recent_cores",
        "Cores used by the host's live claims since the previous refresh, differenced per attempt; absent until a second refresh has something to difference.",
    )
    recent_jobs = metrics.family(
        "prismabuild_attempt_recent_cores_jobs",
        "Live claims the host's recent-cores figure was differenced over; it is the denominator, not a total.",
    )
    peaks = metrics.family(
        "prismabuild_attempt_peak_resources",
        "What the host's live claims have used at their heaviest: memory_peak_bytes is the largest single claim's peak, and the io_ figures are the bytes they have moved between them. Absent rather than zero where the sampler measured nothing.",
    )
    for host, values in sorted(observations.items()):
        for name, value in sorted(values.peaks.items()):
            peaks.add(value, host=host, resource=name)
    for host, values in sorted(observations.items()):
        # The count of live claims and how stale the oldest is are reported for
        # every host that has any, so a withheld aggregate is legible as a
        # withheld aggregate rather than as an absent host.
        unavailable_jobs.add(values.unavailable, host=host)
        if values.oldest_age_s is not None:
            telemetry_age.add(values.oldest_age_s, host=host)
        if values.complete:
            observed.add(values.cpu, host=host, resource="cpu")
            observed.add(values.memory_bytes, host=host, resource="memory_bytes")
            observed_jobs.add(float(values.jobs), host=host)
    for host, (cores, covered) in sorted(_recent_cores(observations, previous).items()):
        recent.add(cores, host=host)
        recent_jobs.add(float(covered), host=host)

    try:
        success = _terminal_metrics(
            metrics, root, now=sampled,
            window_seconds=terminal_window_seconds, limit=terminal_limit,
            reader=reader,
        ) and success
    except Exception:
        success = False
        metrics.family(
            "prismabuild_terminal_collection_success",
            "Whether terminal directories and every selected terminal record were readable for this snapshot.",
        ).add(0)

    try:
        success = _release_metrics(
            metrics, root, now=sampled,
            window_seconds=terminal_window_seconds, limit=terminal_limit,
            reader=reader,
        ) and success
    except Exception:  # A scrape reports the failure rather than dropping HTTP.
        success = False
        metrics.family(
            "prismabuild_unstarted_release_events_complete",
            "Whether the unstarted-release scan proved the configured window was not truncated by its record limit and every selected filing was readable.",
        ).add(0)

    try:
        success = _starvation_metrics(
            metrics, root, now=sampled,
            window_seconds=terminal_window_seconds, reader=reader,
         census_reader=reader) and success
    except Exception:  # A scrape reports the failure rather than dropping HTTP.
        success = False

    try:
        success = _promotion_metrics(
            metrics, root, now=sampled,
            window_seconds=terminal_window_seconds, reader=reader,
         census_reader=reader) and success
    except Exception:  # A scrape reports the failure rather than dropping HTTP.
        success = False
        metrics.family(
            "prismabuild_tier_move_window_complete",
            "Whether the mover-receipt scan proved the window was not truncated "
            "by its file cap and every selected receipt was readable.",
        ).add(0)

    _exporter_metrics(metrics, reader, started)
    metrics.family(
        "prismabuild_collection_success",
        "Whether critical queue inputs and selected terminal records were read and validated for this snapshot.",
    ).add(1 if success else 0)
    return metrics.render()


#: The ceiling the exporter's resident memory is read against (#1020).  The
#: role runs under the supervisor, which bounds no role's memory, so the
#: bound is this gauge pair rather than a unit's ``MemoryMax``.  Derived in
#: docs/pb_metrics.md ("How much memory the exporter may use") from the
#: measured peak on the live-shaped fixture and the growth of the history
#: directories.
RESIDENT_CEILING_BYTES = 680 * 1024 * 1024

#: The per-scrape counters of :meth:`fleet_census.KeptReads.scrape_counts`.
SCRAPE_READ_KINDS = ("listed", "kept", "parsed", "computed", "reused")

#: The families this module adds about its own work, none of them a reading
#: of the queue.  A comparison of two snapshots' queue readings leaves
#: these out: two scrapes of one queue take different times.
EXPORTER_FAMILIES = frozenset((
    "prismabuild_scrape_seconds", "prismabuild_scrape_reads",
    "prismabuild_exporter_resident_bytes",
    "prismabuild_exporter_resident_peak_bytes",
    "prismabuild_exporter_resident_ceiling_bytes",
))


def _resident_bytes() -> tuple[float | None, float | None]:
    """``VmRSS`` and ``VmHWM`` of this process, in bytes; ``None`` if unread."""

    try:
        with open("/proc/self/status", "rb") as stream:
            status = stream.read()
    except OSError:
        return None, None
    found: dict[bytes, float] = {}
    for line in status.splitlines():
        field_name, _, value = line.partition(b":")
        if field_name in (b"VmRSS", b"VmHWM"):
            parts = value.split()
            if len(parts) == 2 and parts[1] == b"kB" and parts[0].isdigit():
                found[field_name] = float(int(parts[0]) * 1024)
    return found.get(b"VmRSS"), found.get(b"VmHWM")


def _exporter_metrics(metrics: Metrics, reader: fleet_census.KeptReads, started: float) -> None:
    """What this snapshot cost, and what the exporter holds (#1020).

    The kept reads are justified by these, not by the fixture: a scrape's
    wall time and its reads, per snapshot, show what keeping saved on the
    live queue, and resident memory against its ceiling shows what keeping
    costs.
    """

    reads = metrics.family(
        "prismabuild_scrape_reads",
        "What this snapshot did: directories listed, directories answered "
        "from a kept listing (kept), records parsed, values computed from "
        "record bytes (computed) and values reused because their file had "
        "not changed (reused).",
    )
    for kind, count in reader.scrape_counts().items():
        reads.add(count, kind=kind)
    resident, peak = _resident_bytes()
    metrics.family(
        "prismabuild_exporter_resident_bytes",
        "The exporter process's resident memory (VmRSS) at this snapshot.",
    ).add(resident)
    metrics.family(
        "prismabuild_exporter_resident_peak_bytes",
        "The exporter process's peak resident memory (VmHWM) since it started.",
    ).add(peak)
    metrics.family(
        "prismabuild_exporter_resident_ceiling_bytes",
        "The resident memory the exporter is sized for; above it, what it "
        "keeps has outgrown the derivation in docs/pb_metrics.md.",
    ).add(RESIDENT_CEILING_BYTES)
    # Last, so it covers everything this snapshot did before rendering.
    metrics.family(
        "prismabuild_scrape_seconds",
        "Wall time this snapshot took to collect, up to rendering it.",
    ).add(time.monotonic() - started)


class MetricsCache:
    def __init__(self, queue_root: Path, cache_seconds: float,
                 terminal_window_seconds: float, terminal_limit: int) -> None:
        self.queue_root = queue_root
        self.cache_seconds = cache_seconds
        self.terminal_window_seconds = terminal_window_seconds
        self.terminal_limit = terminal_limit
        # One store per collector, so the rate is differenced only against
        # this collector's own previous reading.
        self.previous: dict[tuple[str, str], tuple[float, float]] = {}
        # What this server keeps between scrapes (#1020): on the queue's own
        # filesystem an unchanged queue costs one ``lstat`` per directory.
        self.reader = fleet_census.KeptReads()
        self._lock = threading.Lock()
        self._expires = 0.0
        self._text = ""

    def get(self) -> str:
        with self._lock:
            now = time.monotonic()
            if self._text and now < self._expires:
                return self._text
            self._text = collect_metrics(
                self.queue_root,
                terminal_window_seconds=self.terminal_window_seconds,
                terminal_limit=self.terminal_limit,
                previous=self.previous,
                reader=self.reader,
            )
            self._expires = now + self.cache_seconds
            return self._text


def _handler(cache: MetricsCache) -> type[BaseHTTPRequestHandler]:
    class Handler(BaseHTTPRequestHandler):
        def do_GET(self) -> None:  # noqa: N802
            if self.path.split("?", 1)[0] != "/metrics":
                self.send_error(404)
                return
            body = cache.get().encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "text/plain; version=0.0.4; charset=utf-8")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

        def log_message(self, format: str, *args: object) -> None:
            return

    return Handler


def parser() -> argparse.ArgumentParser:
    result = argparse.ArgumentParser(description=__doc__)
    result.add_argument("--queue-root", type=Path, default=DEFAULT_QUEUE_ROOT,
                        help="shared pull-queue directory to observe without writing")
    result.add_argument("--listen", default=DEFAULT_LISTEN,
                        help="HTTP bind address (default: loopback only)")
    result.add_argument("--port", type=int, default=DEFAULT_PORT,
                        help="HTTP port serving /metrics")
    result.add_argument("--cache-seconds", type=float, default=DEFAULT_CACHE_SECONDS,
                        help="reuse a snapshot for this many seconds between scrapes")
    result.add_argument("--terminal-window-seconds", type=float,
                        default=DEFAULT_TERMINAL_WINDOW_SECONDS,
                        help="lookback interval for retained terminal outcome gauges")
    result.add_argument("--terminal-limit", type=int, default=DEFAULT_TERMINAL_LIMIT,
                        help="maximum newest terminal records read in one snapshot")
    result.add_argument("--once", action="store_true",
                        help="print one Prometheus snapshot and exit")
    return result


def main(argv: list[str] | None = None) -> int:
    args = parser().parse_args(argv)
    if not 1 <= args.port <= 65535:
        parser().error("--port must be between 1 and 65535")
    if not math.isfinite(args.cache_seconds) or args.cache_seconds < 0:
        parser().error("--cache-seconds must be finite and nonnegative")
    if (not math.isfinite(args.terminal_window_seconds)
            or args.terminal_window_seconds <= 0):
        parser().error("--terminal-window-seconds must be positive and finite")
    if args.terminal_limit <= 0:
        parser().error("--terminal-limit must be positive")
    if args.once:
        sys.stdout.write(collect_metrics(
            args.queue_root,
            terminal_window_seconds=args.terminal_window_seconds,
            terminal_limit=args.terminal_limit,
        ))
        return 0
    # The server is the fleet's ``metrics`` role (#1020): one per fleet, on
    # the queue's host, spawned by that box's supervisor from the published
    # generation and stopped by it when a publish retires that generation.
    # The role's host-local singleton lock is taken before the port is bound,
    # so a second copy on the box -- a hand-started one, or an installed unit
    # beside the supervised role -- refuses instead of scanning the queue
    # twice.  ``--once`` answers one question and keeps nothing, so it takes
    # no lock.
    from prismabuild import role_session as runtime_gate  # noqa: PLC0415

    refused = runtime_gate.ROLE_SINGLETON_HELD_EXIT
    lock = runtime_gate.role_lock_path(Path(__file__))
    try:
        with runtime_gate.role_singleton(Path(__file__)):
            return _serve(args, refused=refused)
    except runtime_gate.RoleLockHeld as held:
        print(f"pbmetrics: refusing a second metrics exporter; {lock} is held by "
              + (f"pid {held.holder}" if held.holder is not None
                 else "an unreadable holder"),
              file=sys.stderr, flush=True)
        _refusal_record("role-lock-held", args, refused,
                        lock=str(lock), holder_pid=held.holder)
        return refused
    except runtime_gate.RoleLockUnavailable as exc:
        print(f"pbmetrics: refusing to serve without the metrics role "
              f"singleton lock: {exc}", file=sys.stderr, flush=True)
        _refusal_record("role-lock-unavailable", args, refused,
                        lock=str(lock), detail=str(exc))
        return refused


#: The schema of the one-line record a refusing exporter writes to its log.
REFUSAL_SCHEMA = "prismabuild.pbmetrics.refusal.v1"


def _refusal_record(reason: str, args: argparse.Namespace, code: int,
                    **detail: object) -> None:
    """One JSON line on stderr -- the role's log -- saying why it will not serve.

    The supervisor sends a role's output to ``pb-role-metrics.log``, so the
    refusal is found where the role's other output is, as one parseable
    line rather than a traceback.
    """

    record = {"schema": REFUSAL_SCHEMA, "role": "metrics", "reason": reason,
              "exit": code, "host": socket.gethostname(), "pid": os.getpid(),
              "unix": round(time.time(), 3), "listen": args.listen,
              "port": args.port, **detail}
    print(json.dumps(record, sort_keys=True), file=sys.stderr, flush=True)


def _port_holder(port: int) -> tuple[int | None, list[str] | None]:
    """The pid and argv listening on TCP ``port``, where cheap to find.

    The listening socket's inode from ``/proc/net/tcp`` and ``tcp6``, then
    the process whose descriptor table holds it.  Only processes this user
    may inspect are found; ``(None, None)`` otherwise, which is the answer
    for a holder owned by another user.
    """

    inodes: set[str] = set()
    for table in ("/proc/net/tcp", "/proc/net/tcp6"):
        try:
            with open(table) as stream:
                next(stream, None)
                for line in stream:
                    fields = line.split()
                    if len(fields) < 10 or fields[3] != "0A":   # LISTEN
                        continue
                    if int(fields[1].rsplit(":", 1)[1], 16) == port:
                        inodes.add(fields[9])
        except (OSError, ValueError, IndexError):
            continue
    wanted = {f"socket:[{inode}]" for inode in inodes if inode != "0"}
    if not wanted:
        return None, None
    try:
        pids = [name for name in os.listdir("/proc") if name.isdigit()]
    except OSError:
        return None, None
    for pid in pids:
        try:
            descriptors = os.listdir(f"/proc/{pid}/fd")
        except OSError:
            continue
        for descriptor in descriptors:
            try:
                if os.readlink(f"/proc/{pid}/fd/{descriptor}") not in wanted:
                    continue
            except OSError:
                continue
            try:
                with open(f"/proc/{pid}/cmdline", "rb") as stream:
                    argv = [part.decode(errors="replace")
                            for part in stream.read().split(b"\0") if part]
            except OSError:
                argv = None
            return int(pid), argv
    return None, None


def _serve(args: argparse.Namespace, *, refused: int) -> int:
    from prismabuild import role_session

    with role_session.stop_requests(signal.SIGTERM, signal.SIGINT) as stop:
        return _serve_requests(args, refused=refused, stop=stop)


def _serve_requests(args: argparse.Namespace, *, refused: int,
                    stop: threading.Event) -> int:
    from prismabuild import role_session

    class CompletingServer(ThreadingHTTPServer):
        def __init__(self, *args, **kwargs):
            self.request_threads = []
            super().__init__(*args, **kwargs)

        def verify_request(self, request, client_address):
            return not stop.is_set() and super().verify_request(request, client_address)

        def process_request(self, request, client_address):
            for thread in self.request_threads:
                thread.join(0)
            self.request_threads = [thread for thread in self.request_threads
                                    if thread.is_alive()]
            thread = threading.Thread(target=self.process_request_thread,
                                      args=(request, client_address), daemon=True)
            self.request_threads.append(thread)
            try:
                thread.start()
            except BaseException:
                self.request_threads.remove(thread)
                raise

        def join_requests(self):
            deadline = time.monotonic() + SHUTDOWN_GRACE_S
            for thread in self.request_threads:
                thread.join(max(0.0, deadline - time.monotonic()))
            return all(not thread.is_alive() for thread in self.request_threads)

    cache = MetricsCache(
        args.queue_root.absolute(), args.cache_seconds,
        args.terminal_window_seconds, args.terminal_limit,
    )
    try:
        server = CompletingServer((args.listen, args.port), _handler(cache))
    except OSError as exc:
        if exc.errno != errno.EADDRINUSE:
            raise
        # Another exporter -- an installed unit beside the supervised role,
        # whose lock this role cannot see -- already serves the port.  A
        # refusal, not a crash: exit as a held lock does, and say who.
        holder, argv = _port_holder(args.port)
        print(f"pbmetrics: refusing to serve; {args.listen}:{args.port} is "
              "already in use by "
              + (f"pid {holder}" if holder is not None else "another process"),
              file=sys.stderr, flush=True)
        _refusal_record("port-in-use", args, refused, holder_pid=holder,
                        holder_argv=argv)
        return refused
    server.timeout = 0.1
    try:
        while not stop.is_set():
            server.handle_request()
    finally:
        server.server_close()
    completed = server.join_requests()
    if completed and stop.is_set():
        gate = role_session.read_maintenance_gate()
        if (gate is not None
                and "drain_changed_unix" in role_session.drain_offer_fields(gate)):
            role_session.post_park_marker(gate)
    elif not completed:
        print(f"pbmetrics: request threads still active after {SHUTDOWN_GRACE_S:g}s; "
              "exiting without a park marker", file=sys.stderr, flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
